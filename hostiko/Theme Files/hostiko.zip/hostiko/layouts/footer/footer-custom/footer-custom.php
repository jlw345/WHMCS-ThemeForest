<?php

/**

 * Created by PhpStorm.

 * User: akd

 * Date: 8/13/2017

 * Time: 3:12 PM

 */

$hostiko_redux_option = get_option('opt_theme_options');
?>

<footer id="colophon" class="site-footer container">

	<?php do_action('bbfb_footer') ?>


</footer><!-- #colophon -->

