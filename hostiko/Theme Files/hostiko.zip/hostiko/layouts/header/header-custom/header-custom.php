<?php /** * Created by PhpStorm. * User: akd * Date: 8/12/2017 * Time: 5:05 PM */

$hostiko_redux_option = get_option( 'opt_theme_options' ); ?><!--top_bar-->

	<?php do_action('bbhb_header') ?>


<div class="clearfix"></div>