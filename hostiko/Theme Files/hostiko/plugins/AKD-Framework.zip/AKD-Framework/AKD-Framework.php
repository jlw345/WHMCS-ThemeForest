<?php
/**
 * Plugin Name: AKD-Framework
 * Plugin URI: http://http://akdesigner.com/
 * Description: AKD-Framework add Redux Framewor (theme option).
 * Version: 2.0.0
 * Author: AKD team
 * License: GPLv2 or later
 * Text Domain: AKD-Framework
 */
if (!defined('ABSPATH')) {
    exit();
}

	
//setup_globals
$file = __FILE__;

/* base name. */
$basename = plugin_basename($file);

/* base plugin. */
$plugin_dir = plugin_dir_path($file);
$plugin_url = plugin_dir_url($file);

/* base assets. */
$acess_dir = trailingslashit($plugin_dir . 'assets');
$acess_url = trailingslashit($plugin_url . 'assets');
//EOF //setup_globals
		

/* add WP_Filesystem. */
if ( !class_exists('WP_Filesystem') ) {
	require_once(ABSPATH . 'wp-admin/includes/file.php');
	WP_Filesystem();
}

/* inc redux framework */
require_once $plugin_dir . 'frameworks/ReduxCore/framework.php';


	
