<?php
get_template_part( 'template-parts/header-style/nav','search' );
get_template_part( 'template-parts/header-style/nav','sidebar' );
get_template_part( 'template-parts/header-style/nav','wpml' );

?>