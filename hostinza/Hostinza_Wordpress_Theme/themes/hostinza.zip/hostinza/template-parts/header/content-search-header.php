<?php
/**
 * Blog Header
 *
 */
?>
<!-- banner section -->
<section class="xs-banner inner-banner contet-to-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 align-self-center">
                <div class="xs-banner-content">
                    <h2 class="banner-title wow fadeInLeft" data-wow-duration="1.5s">
						<?php printf(esc_html__('Search Results for: %s', 'hostinza'), get_search_query()); ?>
					</h2>
                </div>
            </div>
        </div>
    </div>
</section>
