<?php
$fields[]= array(
    'type'        => 'switch',
    'settings'    => 'show_footer_widget',
    'label'       => esc_html__( 'Show Footer widget area', 'hostinza' ),
    'section'     => 'footer_section',
    'default'     => false,
    'choices'     => array(
        'on'  => esc_attr__( 'Enable', 'hostinza' ),
        'off' => esc_attr__( 'Disable', 'hostinza' ),
    ),
);
$fields[] = array(
    'type'        => 'select',
    'settings'    => 'footer_widget_layout',
    'label'       => esc_html__( 'Footer Widget Per Row', 'hostinza' ),
    'section'     => 'footer_section',
    'default'     => '3',
    'choices'     => array(
        '12' => esc_attr__( '1', 'hostinza' ),
        '6' => esc_attr__( '2', 'hostinza' ),
        '4' => esc_attr__( '3', 'hostinza' ),
        '3' => esc_attr__( '4', 'hostinza' ),
    ),
);

$fields[] = array(
    'type'        => 'image',
    'settings'    => 'footer_bg_image',
    'label'       => esc_html__( 'Background Image', 'hostinza' ),
    'section'     => 'footer_section',
);
$fields[] = array(
    'type'        => 'image',
    'settings'    => 'footer_logo',
    'label'       => esc_html__( 'Footer Logo', 'hostinza' ),
    'section'     => 'footer_section',
);
$fields[] = array(
    'type'        => 'color',
    'settings'    => 'footer_bg_color',
    'label'       => esc_html__( 'Background Color', 'hostinza' ),
    'section'     => 'footer_section',
    'transport'   => 'auto',
    'output'      => array(
        array(
            'element' 	=> '.footer-group',
            'property'	=> 'background-color',
        ),
    ),
);

$fields[] = array(
    'type'        => 'color',
    'settings'    => 'widget_title_color',
    'label'       => esc_html__( 'Widget Title Color', 'hostinza' ),
    'section'     => 'footer_section',
    'transport'   => 'auto',
    'output'      => array(
        array(
            'element' 	=> '.footer-widget .widget-title',
            'property'	=> 'color',
        ),
    ),
);

$fields[] = array(
    'type'        => 'color',
    'settings'    => 'footer_text_color',
    'label'       => esc_html__( 'Footer text color', 'hostinza' ),
    'section'     => 'footer_section',
    'transport'   => 'auto',
    'output'      => array(
        array(
            'element' 	=> 'footer.xs-footer-section.footer-group p',
            'property'	=> 'color',
        ),
    ),
);

$fields[] = array(
    'type'        => 'color',
    'settings'    => 'footer_link_color',
    'label'       => esc_html__( 'Footer link color', 'hostinza' ),
    'section'     => 'footer_section',
    'transport'   => 'auto',
    'output'      => array(
        array(
            'element' 	=> 'footer.xs-footer-section.footer-group a',
            'property'	=> 'color',
        )
    ),
);
/*
 *
 * Terms & security
 *
 */
$fields[] = array(
    'type'        => 'custom',
    'settings' => 'custom_title_terms',
    'label'       => '',
    'section'     => 'footer_section',
    'default'     => '<div class="xs-title-divider">'.esc_html__("Terms & security","hostinza").'</div>',
);

$fields[]= array(
    'type'        => 'switch',
    'settings'    => 'show_terms',
    'label'       => esc_html__( 'Show Terms & security', 'hostinza' ),
    'section'     => 'footer_section',
    'default'     => false,
    'choices'     => array(
        'on'  => esc_attr__( 'Enable', 'hostinza' ),
        'off' => esc_attr__( 'Disable', 'hostinza' ),
    ),
);

$fields[]= array(
    'type'        => 'textarea',
    'settings'    => 'terms_text',
    'label'       => esc_html__( 'Content', 'hostinza' ),
    'section'     => 'footer_section',
    'transport'   => 'postMessage',
    'required'      => array(
        array(
            'setting'   => 'show_terms',
            'operator'  => '==',
            'value'     => 1,
        )
    ),
    'js_vars'     => array(
        array(
            'element'  => '.xs-footer-section .footer-bottom-info p',
            'function' => 'html'
        ),
    ),
    'default'     => '',
);

$fields[] = array(

    'type'        => 'repeater',
    'label'       => esc_html__( 'Client Logo', 'hostinza' ),
    'section'     => 'footer_section',
    'row_label' => array(
        'type' => 'text',
        'value' => esc_attr__('Logo', 'hostinza' ),
    ),
    'settings'    => 'terms_logo',
    'default'     => array(
        array(
            'image' => '',
        ),
    ),
    'required'      => array(
        array(
            'setting'   => 'show_terms',
            'operator'  => '==',
            'value'     => 1,
        ),
    ),
    'fields' => array(
        'image' => array(
            'type'        => 'image',
            'label'       => esc_html__( 'Logo', 'hostinza' ),
            'default'     => '',
        )
    )
);

$fields[] = array(
    'type'        => 'custom',
    'settings' => 'custom_title_transparent',
    'label'       => '',
    'section'     => 'footer_section',
    'default'     => '<div class="xs-title-divider">'.esc_html__("Copyright Section","hostinza").'</div>',
);

$fields[]= array(
    'type'        => 'textarea',
    'settings'    => 'copyright_text',
    'label'       => esc_html__( 'Copyright text', 'hostinza' ),
    'section'     => 'footer_section',
    'transport'   => 'postMessage',
    'js_vars'     => array(
        array(
            'element'  => '.fundpress-footer-bottom .fundpress-copyright-text p',
            'function' => 'html'
        ),
    ),
    'default'     => esc_html__( 'Copyrights By Xpeedstudio - 2018', 'hostinza' ),
);

$fields[] = array(
    'type'        => 'color',
    'settings'    => 'copyright_bg_color',
    'label'       => esc_html__( 'Background color', 'hostinza' ),
    'section'     => 'footer_section',
    'transport'   => 'auto',
    'output'      => array(
        array(
            'element' 	=> '.xs-footer-section .xs-footer-bottom-layer',
            'property'	=> 'background-color',
        ),
        array(
            'element' 	=> '.fundpress-footer-version-2 .fundpress-footer-bottom-v2',
            'property'	=> 'background-color',
        ),
    ),
);

$fields[] = array(
    'type'        => 'color',
    'settings'    => 'copyright_text_color',
    'label'       => esc_html__( 'Text color', 'hostinza' ),
    'section'     => 'footer_section',
    'transport'   => 'auto',
    'output'      => array(
        array(
            'element' 	=> '.fundpress-footer-bottom .fundpress-copyright-text p',
            'property'	=> 'color',
        ),
        array(
            'element' 	=> '.fundpress-footer-bottom-v2 .fundpress-copyright-text-v2 p',
            'property'	=> 'color',
        ),
        array(
            'element' 	=> '.xs-social-list-v7 li.xs-text-content ',
            'property'	=> 'color',
        ),
    ),
);

$fields[] = array(
    'type'        => 'color',
    'settings'    => 'copyright_link_color',
    'label'       => esc_html__( 'Link color', 'hostinza' ),
    'section'     => 'footer_section',
    'transport'   => 'auto',
    'output'      => array(
        array(
            'element' 	=> '.fundpress-footer-bottom .fundpress-copyright-text p a',
            'property'	=> 'color',
        ),
        array(
            'element' 	=> '.fundpress-footer-bottom-v2 .fundpress-copyright-text-v2 p a',
            'property'	=> 'color',
        ),
        array(
            'element' 	=> '.fundpress-footer-bottom-v2 .fundpress-copyright-text-v2 p a',
            'property'	=> 'color',
        ),
        array(
            'element' 	=> '.xs-social-list-v7 li a',
            'property'	=> 'color',
        ),
    ),
);


$fields[] = array(

    'type'        => 'repeater',
    'label'       => esc_attr__( 'Social Control', 'hostinza' ),
    'section'     => 'footer_section',
    'priority'    => 10,
    'row_label' => array(
        'type' => 'text',
        'value' => esc_attr__('Social Profile', 'hostinza' ),
    ),
    'settings'    => 'footer_social_links',
    'default'     => array(
        array(
            'social_icon' => '',
            'social_url'  => '',
        ),
    ),
    'fields' => array(
        'social_icon' => array(
            'type'        => 'text',
            'label'       => esc_attr__( 'Social Icon', 'hostinza' ),
            'default'     => '',
        ),
        'social_url' => array(
            'type'        => 'text',
            'label'       => esc_attr__( 'Social URL', 'hostinza' ),
            'default'     => '',
        ),

    )
);