<?php 
$fields[]= array(
    'type'        => 'switch',
    'settings'    => 'blog_show_breadcrumb',
    'label'       => esc_html__( 'Show Breadcrumb', 'hostinza' ),
    'section'     => 'blog_banner_section',
    'default'     => false,
    'choices'     => array(
        true  => esc_attr__( 'Enable', 'hostinza' ),
        false => esc_attr__( 'Disable', 'hostinza' ),
    ),
);

$fields[] = array(
        'type'        => 'image',
        'settings'    => 'blog_banner_img',
        'label'       => esc_html__( 'Banner Image', 'hostinza' ),
        'section'     => 'blog_banner_section',
        'default'     => '',
);
$fields[]= array(
    'type'        => 'text',
    'settings'    => 'blog_banner_title',
    'label'       => esc_html__( 'Blog Banner Title', 'hostinza' ),
    'section'     => 'blog_banner_section',
    'transport'   => 'postMessage',
    'js_vars'     => array(
        array(
            'element'  => '.xs-banner-content h2.banner-title',
            'function' => 'html'
        ),
    ),
    'default'     => esc_html__( 'Our Blog', 'hostinza' ),
);



$fields[] = array(
        'type'        => 'image',
        'settings'    => 'single_banner_img',
        'label'       => esc_html__( 'Blog Details Banner Image', 'hostinza' ),
        'section'     => 'blog_banner_section',
        'default'     => '',
);
$fields[]= array(
    'type'        => 'text',
    'settings'    => 'single_banner_title',
    'label'       => esc_html__( 'Blog Details Banner Title', 'hostinza' ),
    'section'     => 'blog_banner_section',
    'transport'   => 'postMessage',
    'js_vars'     => array(
        array(
            'element'  => '.hostinza-blog h2',
            'function' => 'html'
        ),
    ),
    'default'     => esc_html__( 'Blog Details', 'hostinza' ),
);