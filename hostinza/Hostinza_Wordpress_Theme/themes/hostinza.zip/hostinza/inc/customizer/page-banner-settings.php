<?php
$fields[] = array(
        'type'        => 'image',
        'settings'    => 'page_banner_img',
        'label'       => esc_html__( 'Banner Image', 'hostinza' ),
        'section'     => 'page_banner_section',
        'default'     => '',
);
$fields[]= array(
    'type'        => 'text',
    'settings'    => 'page_banner_title',
    'label'       => esc_html__( 'Heading Title', 'hostinza' ), 
    'section'     => 'page_banner_section',
    'transport'   => 'postMessage',
    'js_vars'     => array(
        array(
            'element'  => '.hostinza-bolog h2',
            'function' => 'html'
        ),
    ),
    'default'     => esc_html__( '', 'hostinza' ),
);

$fields[]= array(
    'type'        => 'text',
    'settings'    => 'page_banner_subtitle',
    'label'       => esc_html__( 'Heading Sub Title', 'hostinza' ),
    'section'     => 'page_banner_section',
    'transport'   => 'postMessage',
    'js_vars'     => array(
        array(
            'element'  => '.hostinza-bolog h2',
            'function' => 'html'
        ),
    ),
    'default'     => esc_html__( '', 'hostinza' ),
);
