<?php
/*
Plugin Name: Iwthemesfw Core
Plugin URI: http://iwthemes.com
Description: Load custom extension needing by theme (Personalized Plugin)
Version: 1.0
Author: Iwthemes
Author URI: http://iwthemes.com
Text Domain: iwthemesfw_core
Domain Path: /languages
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action('plugins_loaded','iwthemesfw_core_load');
if(!function_exists('iwthemesfw_core_load')){
    function iwthemesfw_core_load(){

        //Define Constant Var
        define('IWTHEMESFW_LOADER_DIR',plugin_dir_path(__FILE__));

        //Load Text Domain
        load_textdomain('iwthemesfw_core', plugin_dir_path(__FILE__) . 'languages/iwthemesfw_core-' . get_locale() . '.mo');
        
        //Load Adds Elementor
        require IWTHEMESFW_LOADER_DIR.'/libs/addon-elementor/elementor-addon-elements.php';
        
        //Load Custom Post Types
        require IWTHEMESFW_LOADER_DIR.'cpt/iwthemesfw_core_add_ctp.php';

        //Load Customizer lib.
        require IWTHEMESFW_LOADER_DIR . '/libs/customizer/kirki.php';

        require IWTHEMESFW_LOADER_DIR. '/libs/advanced-custom-fields/acf.php';

        if( class_exists('acf') ):
            define( 'ACF_LITE', true );
            //Load Adds repeater for acf
            require IWTHEMESFW_LOADER_DIR. '/libs/acf-repeater/acf-repeater.php';
            //Load Meta box Elements
            //require IWTHEMESFW_LOADER_DIR.'metabox/metabox.php';
        endif;

    }
}
