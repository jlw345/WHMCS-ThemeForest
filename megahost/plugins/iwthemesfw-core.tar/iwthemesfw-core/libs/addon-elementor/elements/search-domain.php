<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_SearchDomain extends Widget_Base {

	public function get_name() {
		return 'wts-searchdomain';
	}

	public function get_title() {
		return __( 'EAE - Search Domain', 'elementor' );
	}

	public function get_icon() {
		return 'eicon-search';
	}


    public function get_categories() {
		return [ 'wts-eae' ];
	}


	protected function _register_controls() {
        
		$this->start_controls_section(
			'placeholder_title',
			[
				'label' => __( 'Placeholder Title', 'elementor' )
			]
		);

        $this->add_control(
            'title',
            [
                'label' => __( 'Placeholder Title', 'elementor' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter text', 'elementor' ),
                'default' => __( 'Enter your domain name here...', 'elementor' )
            ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
            'section_action_button',
            [
                'label' => __( 'Action Button', 'elementor' )
            ]
        );

        $this->add_control(
            'action_text',
            [
                'label' => __( 'Button Text', 'elementor' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Search', 'elementor' ),
                'default' => __( 'Search Domain', 'elementor' ),
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => __( 'Link to', 'elementor' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'http://your-link.com', 'elementor' ),
            ]
        );

        $this->end_controls_section();
        
        
	}

	protected function render( ) {
        
        $settings = $this->get_settings();
        
        $this->add_render_attribute('button','class','eae-sd-action-form');
        
        if ( ! empty( $settings['link']['url'] ) ) {
			$this->add_render_attribute( 'button', 'action', $settings['link']['url'].'/?ccce=domainchecker' );

			if ( ! empty( $settings['link']['is_external'] ) ) {
				$this->add_render_attribute( 'button', 'target', '_blank' );
			}
		}
        
        ?>
        <div class="wts-search-domain-wrapper">
            <form <?php echo $this->get_render_attribute_string( 'button' ); ?> method="post">
            <?php
            if(!empty($settings['title'])) {
            ?>
                <div class="eae-sd-input-wrapper">
                    <input type="text" name="domain" required="required"  placeholder="<?php echo $settings['title']; ?>">
                </div>
            <?php
            }

            if(!empty($settings['action_text'])){
            ?>
                <div class="eae-sd-button-wrapper">
                    <input type="submit" class="elementor-button-text" value="<?php echo $settings['action_text']; ?>">
                </div>
            <?php
            }
            ?>  
            </form>
        </div> <!-- close .wts-price-box-wrapper -->
        <?php
	}

	protected function content_template() {
		?>

		<?php
	}
}


Plugin::instance()->widgets_manager->register_widget_type( new Widget_SearchDomain() );
