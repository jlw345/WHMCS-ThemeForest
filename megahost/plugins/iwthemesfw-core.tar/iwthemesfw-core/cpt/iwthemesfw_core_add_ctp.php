<?php

function cptui_register_my_cpts() {

	/**
	 * Post Type: Footer Elements.
	 */

	$labels = array(
		"name" => __( "Footer Elements", "iwthemesfw" ),
		"singular_name" => __( "Footer Element", "iwthemesfw" ),
	);

	$args = array(
		"label" => __( "Footer Elements", "iwthemesfw" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => false,
		"rest_base" => "",
		"has_archive" => false,
		"show_in_menu" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "footer_elements", "with_front" => true ),
		"query_var" => true,
        "menu_icon" => "dashicons-media-code",
		"supports" => array( "title", "editor" ),
	);

	register_post_type( "footer_elements", $args );
}

add_action( 'init', 'cptui_register_my_cpts' );
