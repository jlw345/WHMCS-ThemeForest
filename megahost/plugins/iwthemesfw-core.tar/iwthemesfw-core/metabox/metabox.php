<?php
if(function_exists("register_field_group"))
{
	register_field_group(array (
		'id' => 'acf_page-options',
		'title' => 'Page Options',
		'fields' => array (
			array (
				'key' => 'field_5887ce8b2a5a2',
				'label' => 'Header',
				'name' => '',
				'type' => 'tab',
			),
			array (
				'key' => 'field_58a5e6b61546c',
				'label' => 'Style Header',
				'name' => 'style_header',
				'type' => 'radio',
				'choices' => array (
					'option_customizer' => 'Customizer Default',
					'option_1' => 'Header 1 ( Solid Background )',
					'option_2' => 'Header 2 ( Transparent Background )',
					'option_3' => 'Header 3 ( Hidden Header Elements )',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => '',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_595b75426a009',
				'label' => 'Hidden Top Bar Elements ?',
				'name' => 'hidden_top_bar_elements',
				'type' => 'true_false',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_58a5e6b61546c',
							'operator' => '==',
							'value' => 'option_1',
						),
					),
					'allorany' => 'all',
				),
				'message' => '',
				'default_value' => 0,
			),
			array (
				'key' => 'field_595b752c6a008',
				'label' => 'Hidden Support Bar ?',
				'name' => 'hidden_support_bar',
				'type' => 'true_false',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_58a5e6b61546c',
							'operator' => '==',
							'value' => 'option_1',
						),
					),
					'allorany' => 'all',
				),
				'message' => '',
				'default_value' => 0,
			),
			array (
				'key' => 'field_58a5f60e89ff8',
				'label' => 'Short Code Slide',
				'name' => 'short_code_slide',
				'type' => 'wysiwyg',
				'default_value' => '',
				'toolbar' => 'full',
				'media_upload' => 'yes',
			),
			array (
				'key' => 'field_58816b50b530f',
				'label' => 'Section Title',
				'name' => '',
				'type' => 'tab',
			),
			array (
				'key' => 'field_58816bad589ef',
				'label' => 'Text alignment',
				'name' => 'text_alignment',
				'type' => 'radio',
				'choices' => array (
					'default' => 'Customizer Default',
					'left' => 'Left',
					'center' => 'Center',
					'right' => 'Right',
					'hidden' => 'Hidden Section title',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => '',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_58816cc015988',
				'label' => 'Subtitle Info',
				'name' => 'subtitle_info',
				'type' => 'text',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_58816bad589ef',
							'operator' => '!=',
							'value' => 'hidden',
						),
					),
					'allorany' => 'any',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
			array (
				'key' => 'field_5887ca11770f0',
				'label' => 'Breadcrumbs Show',
				'name' => 'breadcrumbs_show',
				'type' => 'radio',
				'instructions' => 'Select to show or hide the breadcrumbs.',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_58816bad589ef',
							'operator' => '==',
							'value' => 'left',
						),
						array (
							'field' => 'field_58816bad589ef',
							'operator' => '==',
							'value' => 'right',
						),
						array (
							'field' => 'field_58816bad589ef',
							'operator' => '==',
							'value' => 'center',
						),
					),
					'allorany' => 'any',
				),
				'choices' => array (
					'show_breadcrumbs' => 'Show',
					'hidden_breadcrumbs' => 'Hidden',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => '',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_58816b5ab5310',
				'label' => 'Footer',
				'name' => '',
				'type' => 'tab',
			),
			array (
				'key' => 'field_598eebf6ccc9f',
				'label' => 'Main Footer',
				'name' => 'main_footer',
				'type' => 'radio',
				'choices' => array (
					'option_customizer' => 'Customizer Default',
					'different_footer' => 'Different Footer',
					'hidden_footer' => 'Hidden for this page',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => 'option_customizer',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_589a41ede1226',
				'label' => 'Select Footer',
				'name' => 'select_footer',
				'type' => 'relationship',
				'instructions' => 'Select if you want to display the main footer this page',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_598eebf6ccc9f',
							'operator' => '==',
							'value' => 'different_footer',
						),
					),
					'allorany' => 'all',
				),
				'return_format' => 'id',
				'post_type' => array (
					0 => 'footer_elements',
				),
				'taxonomy' => array (
					0 => 'all',
				),
				'filters' => array (
					0 => 'search',
				),
				'result_elements' => array (
					0 => 'post_type',
					1 => 'post_title',
				),
				'max' => 1,
			),
			array (
				'key' => 'field_595d5beb0d04e',
				'label' => 'Show Copy Bar?',
				'name' => 'show_footer_copy',
				'type' => 'radio',
				'instructions' => 'Select if you want to display the footer copy bar on this page',
				'choices' => array (
					'default_copy' => 'Customizer Default',
					'show_copy' => 'Show',
					'hidde_copy' => 'Hidden',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => 'default_copy',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_595d5c6ba65ae',
				'label' => 'Container Copy',
				'name' => 'container_copy',
				'type' => 'radio',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_595d5beb0d04e',
							'operator' => '==',
							'value' => 'show_copy',
						),
						array (
							'field' => 'field_595d5beb0d04e',
							'operator' => '==',
							'value' => 'default_copy',
						),
					),
					'allorany' => 'any',
				),
				'choices' => array (
					'default_container' => 'Customizer Default',
					'container' => 'Boxed',
					'container-fluid' => 'Full Width',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => 'default_container',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_58a603c533afe',
				'label' => 'Layout',
				'name' => '',
				'type' => 'tab',
			),
			array (
				'key' => 'field_58a603f50fcb1',
				'label' => 'Layout Pages',
				'name' => 'layout_pages',
				'type' => 'radio',
				'choices' => array (
					'default' => 'Customizer Default',
					'layout-wide' => 'Wide',
					'layout-semiboxed' => 'Semi Boxed',
					'layout-boxed' => 'Boxed',
					'layout-boxed-margin' => 'Boxed Margin',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => '',
				'layout' => 'horizontal',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'page_template',
					'operator' => '==',
					'value' => 'template-builder.php',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
			array (
				array (
					'param' => 'page_template',
					'operator' => '==',
					'value' => 'default',
					'order_no' => 0,
					'group_no' => 1,
				),
			),
			array (
				array (
					'param' => 'page_template',
					'operator' => '==',
					'value' => 'template-whmcs.php',
					'order_no' => 0,
					'group_no' => 2,
				),
			),
		),
		'options' => array (
			'position' => 'normal',
			'layout' => 'default',
			'hide_on_screen' => array (
			),
		),
		'menu_order' => 0,
	));
	register_field_group(array (
		'id' => 'acf_options-ctp',
		'title' => 'Options Ctp',
		'fields' => array (
			array (
				'key' => 'field_595be8d4ccc97',
				'label' => 'Header',
				'name' => '',
				'type' => 'tab',
			),
			array (
				'key' => 'field_595be8e2ccc98',
				'label' => 'Style Header',
				'name' => 'style_header',
				'type' => 'radio',
				'choices' => array (
					'option_customizer' => 'Customizer Default',
					'option_1' => 'Header 1 ( Solid Background )',
					'option_2' => 'Header 2 ( Transparent Background )',
					'option_3' => 'Header 3 ( Hidden Header Elements )',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => '',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_595be90460255',
				'label' => 'Hidden Top Bar Elements ?',
				'name' => 'hidden_top_bar_elements',
				'type' => 'true_false',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_595be8e2ccc98',
							'operator' => '==',
							'value' => 'option_1',
						),
					),
					'allorany' => 'all',
				),
				'message' => '',
				'default_value' => 0,
			),
			array (
				'key' => 'field_595be92ace581',
				'label' => 'Hidden Support Bar ?',
				'name' => 'hidden_support_bar',
				'type' => 'true_false',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_595be8e2ccc98',
							'operator' => '==',
							'value' => 'option_1',
						),
					),
					'allorany' => 'all',
				),
				'message' => '',
				'default_value' => 0,
			),
			array (
				'key' => 'field_58cacf1d72a71',
				'label' => 'Section Title',
				'name' => '',
				'type' => 'tab',
			),
			array (
				'key' => 'field_58cacf2772a72',
				'label' => 'Text alignment',
				'name' => 'text_alignment',
				'type' => 'radio',
				'choices' => array (
					'default' => 'Customizer Default',
					'left' => 'Left',
					'center' => 'Center',
					'right' => 'Right',
					'hidden' => 'Hidden Section title',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => 'default',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_595beea88c560',
				'label' => 'Hide highlighted background image?',
				'name' => 'hidden_background_image',
				'type' => 'true_false',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_58cacf2772a72',
							'operator' => '!=',
							'value' => 'hidden',
						),
					),
					'allorany' => 'all',
				),
				'message' => '',
				'default_value' => 0,
			),
			array (
				'key' => 'field_58cacf2e72a73',
				'label' => 'Subtitle Info',
				'name' => 'subtitle_info',
				'type' => 'text',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_58cacf2772a72',
							'operator' => '!=',
							'value' => 'hidden',
						),
					),
					'allorany' => 'any',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
			array (
				'key' => 'field_58cacff9d4cbe',
				'label' => 'Breadcrumbs Show',
				'name' => 'breadcrumbs_show',
				'type' => 'radio',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_58cacf2772a72',
							'operator' => '==',
							'value' => 'left',
						),
						array (
							'field' => 'field_58cacf2772a72',
							'operator' => '==',
							'value' => 'right',
						),
						array (
							'field' => 'field_58cacf2772a72',
							'operator' => '==',
							'value' => 'center',
						),
					),
					'allorany' => 'any',
				),
				'choices' => array (
					'show_breadcrumbs' => 'Show',
					'hidden_breadcrumbs' => 'Hidden',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => '',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_58cad01f376a0',
				'label' => 'Footer',
				'name' => '',
				'type' => 'tab',
			),
			array (
				'key' => 'field_598f76904bc0d',
				'label' => 'Main Footer',
				'name' => 'main_footer',
				'type' => 'radio',
				'choices' => array (
					'option_customizer' => 'Customizer Default',
					'different_footer' => 'Different Footer',
					'hidden_footer' => 'Hidden for this page',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => 'option_customizer',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_598f77daf5e93',
				'label' => 'Select Footer',
				'name' => 'select_footer',
				'type' => 'relationship',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_598f76904bc0d',
							'operator' => '==',
							'value' => 'different_footer',
						),
					),
					'allorany' => 'all',
				),
				'return_format' => 'id',
				'post_type' => array (
					0 => 'footer_elements',
				),
				'taxonomy' => array (
					0 => 'all',
				),
				'filters' => array (
					0 => 'search',
				),
				'result_elements' => array (
					0 => 'post_type',
					1 => 'post_title',
				),
				'max' => 1,
			),
			array (
				'key' => 'field_597a1531cee05',
				'label' => 'Show Copy Bar?',
				'name' => 'show_footer_copy',
				'type' => 'radio',
				'instructions' => 'Select if you want to display the footer copy bar on this page',
				'choices' => array (
					'default_copy' => 'Customizer Default',
					'show_copy' => 'Show',
					'hidde_copy' => 'Hidden',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => 'default_copy',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_597a154fcee06',
				'label' => 'Container Copy',
				'name' => 'container_copy',
				'type' => 'radio',
				'conditional_logic' => array (
					'status' => 1,
					'rules' => array (
						array (
							'field' => 'field_597a1531cee05',
							'operator' => '==',
							'value' => 'default_copy',
						),
						array (
							'field' => 'field_597a1531cee05',
							'operator' => '==',
							'value' => 'show_copy',
						),
					),
					'allorany' => 'any',
				),
				'choices' => array (
					'default_container' => 'Customizer Default',
					'container' => 'Boxed',
					'container-fluid' => 'Full Width',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => 'default_container',
				'layout' => 'horizontal',
			),
			array (
				'key' => 'field_58cad054027c0',
				'label' => 'Layout',
				'name' => '',
				'type' => 'tab',
			),
			array (
				'key' => 'field_58cad06095557',
				'label' => 'Layout Pages',
				'name' => 'layout_pages',
				'type' => 'radio',
				'choices' => array (
					'default' => 'Customizer Default',
					'layout-wide' => 'Wide',
					'layout-semiboxed' => 'Semi Boxed',
					'layout-boxed' => 'Boxed',
					'layout-boxed-margin' => 'Boxed Margin',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => '',
				'layout' => 'horizontal',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'post',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'normal',
			'layout' => 'default',
			'hide_on_screen' => array (
			),
		),
		'menu_order' => 1,
	));
	register_field_group(array (
		'id' => 'acf_sidebar-on-default-template-pages',
		'title' => 'Sidebar on Default template Pages',
		'fields' => array (
			array (
				'key' => 'field_58d5a922f387d',
				'label' => 'Sidebar Option',
				'name' => 'sidebar_option',
				'type' => 'radio',
				'choices' => array (
					'hidden' => 'Hidden',
					'left' => 'Left',
					'right' => 'Right',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => '',
				'layout' => 'vertical',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'page_template',
					'operator' => '==',
					'value' => 'default',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'side',
			'layout' => 'default',
			'hide_on_screen' => array (
			),
		),
		'menu_order' => 6,
	));
	register_field_group(array (
		'id' => 'acf_sidebar-single-post',
		'title' => 'Sidebar Single Post',
		'fields' => array (
			array (
				'key' => 'field_58d977b47a6e8',
				'label' => 'Sidebar Post',
				'name' => 'sidebar_post',
				'type' => 'radio',
				'choices' => array (
					'default' => 'Default Customizer',
					'hidden' => 'Hidden',
					'left' => 'Left',
					'right' => 'Right',
				),
				'other_choice' => 0,
				'save_other_choice' => 0,
				'default_value' => '',
				'layout' => 'vertical',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'post',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'side',
			'layout' => 'default',
			'hide_on_screen' => array (
			),
		),
		'menu_order' => 6,
	));
}