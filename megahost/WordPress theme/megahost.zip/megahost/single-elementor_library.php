<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package iwthemesfw
 */

get_header(); ?>

	<div id="primary">
        <div class="row">

            <main id="main" class="col-md-12" role="main">

            <?php
            while ( have_posts() ) : the_post();
               the_content();
            endwhile; // End of the loop.
            ?>

            </main>

        </div>
	</div>
<?php
get_footer();
