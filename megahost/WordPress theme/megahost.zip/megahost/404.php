<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package iwthemesfw
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
            <div class="container">
                <section class="error-404 not-found">
                    <header class="page-header">
                        <i class="fa fa-exclamation-triangle"></i>
                        <h1 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'megahost' ); ?></h1>
                    </header>

                    <div class="page-content">
                        <p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'megahost' ); ?></p>

                        <?php
                            get_search_form();
                        ?>

                    </div>
                </section>
            </div>
		</main>
	</div>
<?php
get_footer();
