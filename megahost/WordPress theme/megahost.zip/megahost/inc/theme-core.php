<?php

/**
 * Kirki-fallback.
 */
require get_template_directory() . '/inc/theme-core/kirki-fallback.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/theme-core/customizer.php';

/**
 * Custom Theme Functions.
 */
require get_template_directory() . '/inc/theme-core/theme-functions.php';

/**
 * Load Script And Styles
 */
require get_template_directory() . '/inc/theme-core/styles-theme.php';

/**
 * Inlcude TGM Plugins
 */
require get_template_directory() . '/inc/theme-core/tgm-load-plugins.php';

/**
* Load Aditional Scripts for Customizer
*/
require get_template_directory() . '/inc/theme-core/aditional-scripts.php';
