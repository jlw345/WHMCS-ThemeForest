<?php
/**
 * iwthemesfw Theme Customizer
 *
 * @package iwthemesfw
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function iwthemesfw_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
    $wp_customize->remove_section('colors');
    $wp_customize->remove_section('header_image');
}
add_action( 'customize_register', 'iwthemesfw_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function iwthemesfw_customize_preview_js() {
	wp_enqueue_script( 'iwthemesfw_customizer', get_template_directory_uri() . '/assets/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'iwthemesfw_customize_preview_js' );



// Customizer Options
if (class_exists('kirki')) {
    /**
     * Add the theme configuration
     */
    iwthemesfw_kirki::add_config( 'iwthemesfw', array(
        'option_type' => 'theme_mod',
        'capability'  => 'edit_theme_options',
    ) );

    /**
     * Add the theme settings panel
     */
    iwthemesfw_kirki::add_panel( 'theme_settings', array(
        'priority'    => 1,
        'title'       => esc_html__( 'Theme Settings', 'megahost' ),
        'description' => esc_html__( 'My Description', 'megahost' ),
    ));


    /**
     * Add the Skin section
     */
    iwthemesfw_kirki::add_section( 'skin', array(
        'title'      => esc_attr__( 'Colors', 'megahost' ),
        'priority'   => 3,
        'panel' => 'theme_settings',
        'capability' => 'edit_theme_options',
    ) );


    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'color',
        'settings'    => 'skin_theme',
        'description' => esc_html__('Choose a color skin for your theme.' , 'megahost'),
        'label'       => esc_html__( 'SITE ACCENT COLOR', 'megahost' ),
        'section'     => 'skin',
        'default'     => '#f9b644',
        'priority'    => 1,
        'alpha'       => true,
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'color',
        'settings'    => 'bg_body',
        'description' => esc_html__('Choose a color for the body.' , 'megahost'),
        'label'       => esc_html__( 'BODY BACKGROUND', 'megahost' ),
        'section'     => 'skin',
        'default'     => '#fff',
        'priority'    => 1,
        'alpha'       => true,
    ));



     /**
     * Add the Layouts
     */
    iwthemesfw_kirki::add_section( 'layouts', array(
        'title'      => esc_attr__( 'Layouts', 'megahost' ),
        'priority'   => 4,
        'panel' => 'theme_settings',
        'capability' => 'edit_theme_options',
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'layout_type',
        'label'       => esc_html__( 'Select Layout of the site', 'megahost' ),
        'section'     => 'layouts',
        'default'     => 'semiboxed',
        'priority'    => 10,
        'multiple'    => 1,
        'choices'     => array(
            'layout-wide' => esc_attr__( 'Wide', 'megahost' ),
            'layout-semiboxed' => esc_attr__( 'Semi Boxed', 'megahost' ),
            'layout-boxed' => esc_attr__( 'Boxed', 'megahost' ),
            'layout-boxed-margin' => esc_attr__( 'Boxed Margin', 'megahost' ),
        ),
    ));


     /**
     * Add the Header Options
     */
    iwthemesfw_kirki::add_section( 'header_style', array(
        'title'      => esc_attr__( 'Header Style', 'megahost' ),
        'priority'   => 5,
        'panel' => 'theme_settings',
        'capability' => 'edit_theme_options',
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'styles_header',
        'label'       => esc_attr__( 'Header Options', 'megahost' ),
        'description' => esc_html__('Please select one option' , 'megahost'),
        'section'     => 'header_style',
        'default'     => 'show',
        'priority'    => 10,
        'choices'     => array(
            'header_1'   => esc_attr__( 'Header 1 ( Solid Background )', 'megahost' ),
            'header_2' => esc_attr__( 'Header 2 ( Transparent Background )', 'megahost' ),
            'header_3' => esc_attr__( 'Header 3 ( Hidden Header Elements )', 'megahost' ),
        ),
    ));


     /**
     * Add the Support Options
     */
    iwthemesfw_kirki::add_section( 'header_support', array(
        'title'      => esc_attr__( 'Support Header', 'megahost' ),
        'priority'   => 5,
        'panel' => 'theme_settings',
        'capability' => 'edit_theme_options',
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'show_support',
        'label'       => esc_attr__( 'Show elements', 'megahost' ),
        'description' => esc_html__('Show or hide Client area ( Only on Header 1)' , 'megahost'),
        'section'     => 'header_support',
        'default'     => 'show',
        'priority'    => 10,
        'choices'     => array(
            'show'   => esc_attr__( 'Show', 'megahost' ),
            'hidden' => esc_attr__( 'Hidden', 'megahost' ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'     => 'text',
        'settings' => 'login_user',
        'label'    => esc_html__( 'Placeholder User Name', 'megahost' ),
        'section'  => 'header_support',
        'priority' => 10,
        'active_callback'    => array(
            array(
                'setting'  => 'show_support',
                'operator' => '==',
                'value'    => 'show',
            ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'     => 'text',
        'settings' => 'login_password',
        'label'    => esc_html__( 'Placeholder User Password', 'megahost' ),
        'section'  => 'header_support',
        'priority' => 10,
        'active_callback'    => array(
            array(
                'setting'  => 'show_support',
                'operator' => '==',
                'value'    => 'show',
            ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'     => 'text',
        'settings' => 'login_button',
        'label'    => esc_html__( 'Title Button', 'megahost' ),
        'section'  => 'header_support',
        'priority' => 10,
        'active_callback'    => array(
            array(
                'setting'  => 'show_support',
                'operator' => '==',
                'value'    => 'show',
            ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'     => 'text',
        'settings' => 'close_title',
        'label'    => esc_html__( 'Title Close', 'megahost' ),
        'section'  => 'header_support',
        'priority' => 10,
        'active_callback'    => array(
            array(
                'setting'  => 'show_support',
                'operator' => '==',
                'value'    => 'show',
            ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'     => 'text',
        'settings' => 'open_title',
        'label'    => esc_html__( 'Title Open', 'megahost' ),
        'section'  => 'header_support',
        'priority' => 10,
        'active_callback'    => array(
            array(
                'setting'  => 'show_support',
                'operator' => '==',
                'value'    => 'show',
            ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'     => 'text',
        'settings' => 'action_form',
        'label'    => esc_html__( 'Link clients Area Page', 'megahost' ),
        'section'  => 'header_support',
        'priority' => 10,
        'active_callback'    => array(
            array(
                'setting'  => 'show_support',
                'operator' => '==',
                'value'    => 'show',
            ),
        ),
    ));



    /**
     * Add the Top bar Elements Options
     */
    iwthemesfw_kirki::add_section( 'header_options', array(
        'title'      => esc_attr__( 'Top Bar', 'megahost' ),
        'priority'   => 5,
        'panel' => 'theme_settings',
        'capability' => 'edit_theme_options',
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'aling_elements',
        'label'       => esc_attr__( 'Align elements', 'megahost' ),
        'section'     => 'header_options',
        'default'     => 'left',
        'priority'    => 10,
        'choices'     => array(
            'left'   => esc_attr__( 'Left', 'megahost' ),
            'right' => esc_attr__( 'Right', 'megahost' ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'show_elements',
        'label'       => esc_attr__( 'Show elements', 'megahost' ),
        'description' => esc_html__('Show or hide items on all pages ( Only on Header 1)' , 'megahost'),
        'section'     => 'header_options',
        'default'     => 'show',
        'priority'    => 10,
        'choices'     => array(
            'show'   => esc_attr__( 'Show', 'megahost' ),
            'hidden' => esc_attr__( 'Hidden', 'megahost' ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'repeater',
        'label'       => esc_attr__( 'Top Bar Elements', 'megahost' ),
        'section'     => 'header_options',
        'priority'    => 10,
        'row_label' => array(
            'type' => 'text',
            'value' => esc_attr__('Element Bar', 'megahost' ),
        ),
        'settings'    => 'heder_elements',
        'active_callback'    => array(
            array(
                'setting'  => 'show_elements',
                'operator' => '==',
                'value'    => 'show',
            ),
        ),
        'default'     => array(
            array(
                'icon_class' => esc_attr__( 'fa fa-plane', 'megahost' ),
                'title_text' => esc_attr__( 'Support', 'megahost' ),
                'link_url'  => esc_url('#', 'megahost'),
            ),
            array(
                'icon_class' => esc_attr__( 'fa fa-cogs', 'megahost' ),
                'title_text' => esc_attr__( 'Client Area', 'megahost' ),
                'link_url'  => esc_url('#', 'megahost'),
            ),
            array(
                'icon_class' => esc_attr__( 'fa fa-phone', 'megahost' ),
                'title_text' => esc_attr__( 'Call Now', 'megahost' ),
                'link_url'  => esc_url('tel:+53 3459876', 'megahost'),
            ),
        ),
        'fields' => array(
            'icon_class' => array(
                'type'        => 'text',
                'label'       => esc_attr__( 'Icon Class', 'megahost' ),
                'description' => esc_attr__( 'Font Awesome Icon Class', 'megahost' ),
                'default'     => '',
            ),
            'title_text' => array(
                'type'        => 'text',
                'label'       => esc_attr__( 'Title Text', 'megahost' ),
                'description' => esc_attr__( 'This will be the label for your link', 'megahost' ),
                'default'     => '',
            ),
            'link_url' => array(
                'type'        => 'text',
                'label'       => esc_attr__( 'Link URL', 'megahost' ),
                'description' => esc_attr__( 'This will be the link URL', 'megahost' ),
                'default'     => '',
            ),
        )
    ));

     /**
     * Add the Section Title Options
     */
    iwthemesfw_kirki::add_section( 'section_title_options', array(
        'title'      => esc_attr__( 'Section Titles', 'megahost' ),
        'priority'   => 5,
        'panel' => 'theme_settings',
        'capability' => 'edit_theme_options',
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'aling_titles',
        'label'       => esc_attr__( 'Align Titles Info', 'megahost' ),
        'section'     => 'section_title_options',
        'default'     => 'left',
        'priority'    => 10,
        'choices'     => array(
            'left'   => esc_attr__( 'Left', 'megahost' ),
            'center'   => esc_attr__( 'Center', 'megahost' ),
            'right' => esc_attr__( 'Right', 'megahost' ),
            'hidden' => esc_attr__( 'Hidden', 'megahost' ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'show_breadcrumbs',
        'label'       => esc_attr__( 'Show Breadcrumbs', 'megahost' ),
        'section'     => 'section_title_options',
        'default'     => 'show',
        'priority'    => 10,
        'choices'     => array(
            'show'   => esc_attr__( 'Show', 'megahost' ),
            'hidden' => esc_attr__( 'Hidden', 'megahost' ),
        ),
        'active_callback'    => array(
            array(
                'setting'  => 'aling_titles',
                'operator' => '!=',
                'value'    => 'hidden',
            ),
        ),
    ));


    /**
     * Add the Footer Settings
     */
    iwthemesfw_kirki::add_section( 'footer', array(
        'title'      => esc_attr__( 'Footer Options', 'megahost' ),
        'priority'   => 6,
        'panel' => 'theme_settings',
        'capability' => 'edit_theme_options',
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'show_main_footer',
        'label'       => esc_html__( 'Show main footer?' , 'megahost' ),
        'description' => esc_html__('Select if you want to display the main footer on all pages.', 'megahost'),
        'section'     => 'footer',
        'default'     => 'show',
        'priority'    => 10,
        'choices'     => array(
            'show'  => esc_attr__( 'Show', 'megahost' ),
            'hidden'    => esc_attr__( 'Hidden', 'megahost' ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'select',
        'settings'    => 'select_footer',
        'label'       => __( 'Select Footer', 'megahost' ),
        'section'     => 'footer',
        'default'     => 'option-1',
        'priority'    => 10,
        'multiple'    => 1,
        'choices'     => Kirki_Helper::get_posts( array( 'post_type' => 'footer_elements' ) ),
        'active_callback'    => array(
            array(
                'setting'  => 'show_main_footer',
                'operator' => '==',
                'value'    => 'show',
            ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'show_footer_copy',
        'label'       => esc_html__( 'Show copy footer?' , 'megahost' ),
        'description' => esc_html__('Select if you want to display the footer copy bar on all pages.', 'megahost'),
        'section'     => 'footer',
        'default'     => 'show',
        'priority'    => 10,
        'choices'     => array(
            'show'  => esc_attr__( 'Show', 'megahost' ),
            'hidden'    => esc_attr__( 'Hidden', 'megahost' ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'     => 'textarea',
        'settings' => 'cb_footer_copry',
        'label'    => esc_html__( 'Footer Copry', 'megahost' ),
        'description' => esc_html__('Copyright Info.', 'megahost'),
        'section'  => 'footer',
        'priority' => 10,
        'active_callback'    => array(
            array(
                'setting'  => 'show_footer_copy',
                'operator' => '==',
                'value'    => 'show',
            ),
        ),
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'container_footer_copy',
        'label'       => esc_html__( 'Container Copy' , 'megahost'),
        'section'     => 'footer',
        'default'     => 'boxed_copy',
        'priority'    => 10,
        'choices'     => array(
            'container'  => esc_attr__( 'Boxed', 'megahost' ),
            'container-fluid'    => esc_attr__( 'Full Width', 'megahost' ),
        ),
        'active_callback'    => array(
            array(
                'setting'  => 'show_footer_copy',
                'operator' => '==',
                'value'    => 'show',
            ),
        ),
    ));



    /**
     * Add the Blog Settings
     */
    iwthemesfw_kirki::add_section( 'blog', array(
        'title'      => esc_attr__( 'Blog', 'megahost' ),
        'priority'   => 7,
        'panel' => 'theme_settings',
        'capability' => 'edit_theme_options',
    ));
    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'archive_sidebar',
        'label'       => esc_html__( 'Archive Sidebar(s)', 'megahost' ),
        'description' => esc_html__('This option affects your Post, category, tag, author and search pages.', 'megahost'),
        'section'     => 'blog',
        'default'     => 'right',
        'priority'    => 10,
        'choices'     => array(
            'hidden'  => esc_attr__( 'Hidden', 'megahost' ),
            'left'    => esc_attr__( 'Left', 'megahost' ),
            'right'   => esc_attr__( 'Right', 'megahost' ),
        ),
    ));
    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'sidebar_single',
        'label'       => esc_html__( 'Single Post Sidebar(s)', 'megahost' ),
        'description' => esc_html__('This option affects your single post pages.', 'megahost'),
        'section'     => 'blog',
        'default'     => 'right',
        'priority'    => 10,
        'choices'     => array(
            'hidden'  => esc_attr__( 'Hidden', 'megahost' ),
            'left'    => esc_attr__( 'Left', 'megahost' ),
            'right'   => esc_attr__( 'Right', 'megahost' ),
        ),
    ));


     /**
     * Add the Aditonal Scripts
     */
    iwthemesfw_kirki::add_section( 'additional_scripts', array(
        'title'      => esc_attr__( 'Aditional Scripts', 'megahost' ),
        'priority'   => 5,
        'panel' => 'theme_settings',
        'capability' => 'edit_theme_options',
    ));

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'     => 'text',
        'settings' => 'google_maps',
        'label'    => esc_html__( 'Google Maps API Key', 'megahost' ),
        'description' => esc_html__('Enter in your Maps API Key to enable your contact widget. Click Here to get your API Key.', 'megahost'),
        'section'  => 'additional_scripts',
        'priority' => 10,
    ) );

    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'     => 'textarea',
        'settings' => 'custom_scripts',
        'label'    => esc_html__( 'Custom Scripts', 'megahost' ),
        'description' => esc_html__('Enter in any custom script to include in your sites. Be sure to use double quotes for strings.', 'megahost'),
        'section'  => 'additional_scripts',
        'priority' => 10,
    ) );


    /**
     * Add the Rtl Support

    iwthemesfw_kirki::add_section( 'rtl', array(
        'title'      => esc_attr__( 'Rtl Support', 'iwthemesfw' ),
        'priority'   => 7,
        'panel' => 'theme_settings',
        'capability' => 'edit_theme_options',
    ));
    iwthemesfw_kirki::add_field( 'my_config', array(
        'type'        => 'radio',
        'settings'    => 'rtl_support',
        'label'       => esc_html__( 'Rtl Options', 'iwthemesfw' ),
        'description' => esc_html__('This option affects your Post, category, tag, author and search pages.', 'iwthemesfw'),
        'section'     => 'rtl',
        'default'     => 'disable',
        'priority'    => 10,
        'choices'     => array(
            'disable'    => esc_attr__( 'Disable', 'iwthemesfw' ),
            'enable'  => esc_attr__( 'Enable', 'iwthemesfw' ),
        ),
    )); */


}
