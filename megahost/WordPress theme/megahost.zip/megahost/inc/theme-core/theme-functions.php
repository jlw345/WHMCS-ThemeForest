<?php

// Increase length
function iwthemesfw_custom_excerpt_length( $length ) {
    return 45;
}
add_filter( 'excerpt_length', 'iwthemesfw_custom_excerpt_length' );


/**
 * Register Google font
*/
function iwthemesfw_google_font_url() {
	$font_url = '';
	if ( 'off' !== esc_html_x( 'on', 'Google font: on or off', 'megahost' ) ) {
		$font_url = add_query_arg( 'family', 'Open+Sans:400italic,300,400,600,700|Raleway:400,700', "https://fonts.googleapis.com/css" );
	}
	return $font_url;
}


// Pagination Function
function iwthemesfw_pagination($numpages = '', $pagerange = '', $paged='') {
  if (empty($pagerange)) {
    $pagerange = 2;
  }
  global $paged;
  if (empty($paged)) {
    $paged = 1;
  }
  if ($numpages == '') {
    global $wp_query;
    $numpages = $wp_query->max_num_pages;
    if(!$numpages) {
        $numpages = 1;
    }
  }
  $pagination_args = array(
    'base'            => get_pagenum_link(1) . '%_%',
    'total'           => $numpages,
    'current'         => $paged,
    'show_all'        => False,
    'end_size'        => 1,
    'mid_size'        => $pagerange,
    'prev_next'       => True,
    'prev_text'       => ('&laquo;'),
    'next_text'       => ('&raquo;'),
    'type'            => 'plain',
    'add_args'        => false,
    'add_fragment'    => ''
  );
  $paginate_links = paginate_links($pagination_args);

  if ($paginate_links) {
    echo "<nav class='custom-pagination'>";
      echo $paginate_links;
    echo "</nav>";
  }
}



//iwthemesfw_layout_display
if(!function_exists('iwthemesfw_layout_display')){
	function iwthemesfw_layout_display() {
        $value = '';
        if( function_exists('get_field') ){
             if(get_field('layout_pages') != 'default'){
                $value = get_field('layout_pages');
             }elseif(get_field('layout_pages') == 'default'){
                 $value = get_theme_mod( 'layout_type', 'semiboxed' );
             }else{
                 $value = get_theme_mod( 'layout_type', 'semiboxed' );
             }
        }else{
            $value = get_theme_mod( 'layout_type', 'semiboxed' );
        }
        echo esc_html($value);
    }
}


//Header Display Functions
if(!function_exists('iwthemesfw_header_display')){
    function iwthemesfw_header_display() {
        if( function_exists('get_field') ){
            if(get_field('style_header') != 'option_customizer'){
                $style_header = get_field('style_header');
                if($style_header == 'option_1'){
                    get_template_part( 'components/header/header', '1' );
                }
                elseif($style_header == 'option_2'){
                    get_template_part( 'components/header/header', '2' );
                }
                elseif($style_header == 'option_3'){
                    get_template_part( 'components/section-titles/title', 'default');
                }else{
                    get_template_part( 'components/header/header', '1' );
                }
            }else{
                $style_header = get_theme_mod( 'styles_header', 'header_1' );
                if($style_header == 'header_1'){
                    get_template_part( 'components/header/header', '1' );
                }
                elseif($style_header == 'header_2'){
                    get_template_part( 'components/header/header', '2' );
                }
                elseif($style_header == 'header_3'){
                    get_template_part( 'components/section-titles/title', 'default');
                }else{
                    get_template_part( 'components/header/header', '1' );
                }
            }
        }else{
            get_template_part( 'components/header/header', '1' );
        }
    }
}


//Breadcrumbs Function
if(!function_exists('iwthemesfw_breadcrumb_display')){
	/**
	 * Breadcrumbs display
	 * @pluggable
	 */
	function iwthemesfw_breadcrumb_display() {
	    global $post;
        $sep = '<li class="sep">&#47;</li>';

	    if (!is_front_page()){
	    	$home_link = '<li class="breadcrumbs-home"><a href="' . esc_url( home_url('/') ) . '">' . __('<i class="fa fa-home"></i>', 'megahost') . '</a></li>';
	    	$posts_page_id = get_option('page_for_posts');
	    	$posts_page_link = '<li><a href="'.esc_url(get_permalink( $posts_page_id )).'">'.esc_html(get_the_title($posts_page_id)).'</a></li>'.esc_html($sep);

			if ( !is_single()) {
				if ( is_page() && $post->post_parent ){
                      $format = '<li><a href="%s" title="%s">%s</a></li> <li class="sep-sub">&#47;</li>';
                      $anc = array_map( 'get_post', array_reverse( (array) get_post_ancestors( $post ) ) );
                      $links = array_map( 'get_permalink', $anc );
                      echo $home_link;
                      foreach ( $anc as $i => $apost ) {
                        $title = apply_filters( 'the_title', $apost->post_title );
                        printf( $format, $links[$i], esc_attr($title), esc_html($title) );
                      }
                      echo '<li class="sep-sub">'. esc_html($post->post_title) .'</li>';
                }else
                if(is_archive()){
                    echo $home_link;
                    the_archive_title( '<li class="sep-sub">', '</li>' );
                }
                elseif(is_search()){
                    echo $home_link;
                    echo '<li>'.esc_html__( 'Search Results for: ', 'megahost' ).'</li>';
                    echo '<li class="sep-sub">'.get_search_query().'</li>';
                }elseif(is_404()){
                    echo $home_link;
                    echo '<li class="sep-sub">'.esc_html__( '404 Page ', 'megahost' ).'</li>';
                }elseif(is_home()){
                    echo $home_link;
                    echo '<li class="sep-sub">'.esc_html__( 'News', 'megahost' ).'</li>';
                }
                else{
                    //echo $home_link.$posts_page_link;
                    echo $home_link;
                    the_title('<li class="sep-sub">','</li>');
                }
			} elseif ( is_single() ) {
				 echo $home_link;
                 the_title('<li class="sep-sub">','</li>');
			} else {
                //Display the post title.
                echo esc_html(get_the_title());
			}
		} //is_front_page
	} //end function
} //end function exists
