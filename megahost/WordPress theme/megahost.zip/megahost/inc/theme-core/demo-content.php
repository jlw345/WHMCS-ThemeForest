<?php
if ( ! function_exists( 'iwthemesfw_import_files' ) ) :
    function iwthemesfw_import_files() {
        return array(
            array(
                'import_file_name'             => esc_html('Default Demo' , 'megahost'),
                'local_import_file'            => trailingslashit( get_template_directory() ) . '/inc/lib/demo-data/demo-content.xml',
                'local_import_customizer_file' => trailingslashit( get_template_directory() ) . '/inc/lib/demo-data/customizer-export.dat',
                'import_preview_image_url'     => trailingslashit( get_template_directory() ) .'/inc/lib/demo-data/screenshot.png',
                'import_notice'                => esc_html( 'Please waiting for a few minutes, do not close the window or refresh the page until the data is imported.', 'megahost' ),
            ),
        );
    }
    add_filter( 'pt-ocdi/import_files', 'iwthemesfw_import_files' );
endif;


if ( ! function_exists( 'iwthemesfw_after_import' ) ) :
    function iwthemesfw_after_import( $selected_import ) {

        if ( 'Default Demo' === $selected_import['import_file_name'] ) {
            //Set Menu
            $top_menu = get_term_by('name', 'Header Menu', 'nav_menu');
            $footer_menu = get_term_by('name', 'Footer Menu', 'nav_menu');
            set_theme_mod( 'nav_menu_locations' , array(
                  'menu-1' => $top_menu->term_id,
                  'menu-2' => $footer_menu->term_id
                 )
            );

           //Set Front page
           $page = get_page_by_title( 'Home 1');
           if ( isset( $page->ID ) ) {
            update_option( 'page_on_front', $page->ID );
            update_option( 'show_on_front', 'page' );
           }


           //Import Revolution Slider
           if ( class_exists( 'RevSlider' ) ) {
               $slider_array = array(
                  get_template_directory()."/inc/lib/demo-data/slides/megahost-slider.tar",
                  get_template_directory()."/inc/lib/demo-data/slides/Layout-Semi-Boxed.tar",
              );

               $slider = new RevSlider();

               foreach($slider_array as $filepath){
                 $slider->importSliderFromPost(true,true,$filepath);
               }

               echo esc_html (' Slider processed', 'megahost');
          }
        }elseif ( 'Demo 2' === $selected_import['import_file_name'] ) {
            //Same codes as above for the demo 2
        }

    }
    add_action( 'pt-ocdi/after_import', 'iwthemesfw_after_import' );
endif;

add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );

?>
