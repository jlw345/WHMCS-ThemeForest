<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package iwthemesfw
 */

get_header(); ?>

    <?php
        $iwthemesfw_archive_sidebar = '';
        if( function_exists('get_field') ){
            $iwthemesfw_archive_sidebar = esc_attr(get_field( 'sidebar_post' ));
            if($iwthemesfw_archive_sidebar){
               if($iwthemesfw_archive_sidebar == 'default'){
                   $iwthemesfw_archive_sidebar = esc_attr(get_theme_mod( 'sidebar_single', 'right' ));
               }
            }else{
                $iwthemesfw_archive_sidebar = esc_attr(get_theme_mod( 'sidebar_single', 'right' ));
            }
        }else{
             $iwthemesfw_archive_sidebar = esc_attr(get_theme_mod( 'sidebar_single', 'right' ));
        }
        if($iwthemesfw_archive_sidebar == 'hidden'){
            $iwthemesfw_archive_sidebar_full = 'col-md-12';
        }else{
            $iwthemesfw_archive_sidebar_full = 'col-md-9';
        }
    ?>

	<div id="primary" class="container">
        <div class="row">

            <?php if($iwthemesfw_archive_sidebar == 'left'): ?>
                 <div class="col-md-3">
                    <?php get_sidebar(); ?>
                </div>
            <?php endif; ?>

            <main id="main" class="<?php echo esc_attr($iwthemesfw_archive_sidebar_full); ?>" role="main">

            <?php
            while ( have_posts() ) : the_post();

                get_template_part( 'components/post/content', get_post_format() );

                the_post_navigation();

                // If comments are open or we have at least one comment, load up the comment template.
                if ( comments_open() || get_comments_number() ) :
                    comments_template();
                endif;

            endwhile; // End of the loop.
            ?>

            </main>

            <?php if($iwthemesfw_archive_sidebar == 'right'): ?>
                 <div class="col-md-3">
                    <?php get_sidebar(); ?>
                </div>
            <?php endif; ?>

        </div>
	</div>
<?php
get_footer();
