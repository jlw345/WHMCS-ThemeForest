<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package iwthemesfw
 */

get_header(); ?>

	<div id="primary" class="container">
        <div class="row">
            <main id="main" class="col-md-9" role="main">

                <?php
                if ( have_posts() ) : ?>
                    <?php
                    /* Start the Loop */
                    while ( have_posts() ) : the_post();

                        /**
                         * Run the loop for the search to output the results.
                         * If you want to overload this in a child theme then include a file
                         * called content-search.php and that will be used instead.
                         */
                        get_template_part( 'components/post/content', 'search' );

                    endwhile;

                    iwthemesfw_pagination();

                else :

                    get_template_part( 'components/post/content', 'none' );

                endif; ?>

                </main>

                <div class="col-md-3">
                    <?php get_sidebar(); ?>
                </div>

        </div>
	</div>
<?php
get_footer();
