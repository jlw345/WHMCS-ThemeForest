<?php

$iwthemesfw_support_show = '';

if( function_exists('get_field') ){
    if(get_field('style_header') != 'option_customizer'){
        if(!get_field('hidden_support_bar')){
            $iwthemesfw_support_show = 'show';
        }
    }else{
        $iwthemesfw_support_show = get_theme_mod( 'show_support', 'show' );
    }
}else{
    $iwthemesfw_support_show = get_theme_mod( 'show_support', 'show' );
}
?>

<!--Login Client -->
<?php if($iwthemesfw_support_show == 'show'): ?>
<div class="jBar">
    <div class="container">
        <div class="row">
            <form id="frmlogin" name="frmlogin" action="<?php echo esc_html(get_theme_mod( 'action_form')); ?>/?ccce=dologin" method="post" >
              <input name="username" type="email" placeholder="<?php echo esc_html(get_theme_mod( 'login_user', 'User' )); ?>" required>
              <input name="password" type="password" placeholder="<?php echo esc_html(get_theme_mod( 'login_password', 'Password' )); ?>" required>
              <input type="submit" class="btn" value="<?php echo esc_html(get_theme_mod( 'login_button', 'Login' )); ?>">
            </form>
            <p class="jTrigger downarrow"><?php echo esc_html(get_theme_mod( 'close_title', 'close' )); ?></p>
        </div>
    </div>
</div>
<span class="jRibbon jTrigger up"><?php echo esc_html(get_theme_mod( 'open_title', 'Open' )); ?></span>
<div class="line"></div>
<!-- End Login Client -->
<?php endif; ?>
