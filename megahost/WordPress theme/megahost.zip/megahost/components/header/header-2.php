<header id="masthead" class="site-header header-2" role="banner">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-12">
                <?php iwthemesfw_the_custom_logo(); ?>
                <?php get_template_part( 'components/header/site', 'branding' ); ?>
            </div>

            <div class="col-md-8 col-sm-12">
                <?php get_template_part( 'components/navigation/navigation', 'top' ); ?>
            </div>
        </div>
    </div>
</header>

<?php get_template_part( 'components/section-titles/title', 'default'); ?>
