<nav id="site-navigation" class="main-navigation" role="navigation">
	<?php
        if(has_nav_menu('menu-1')){
            wp_nav_menu( array( 'theme_location' => 'menu-1', 'menu_id' => 'top-menu' ) );
        }
    ?>
</nav>
