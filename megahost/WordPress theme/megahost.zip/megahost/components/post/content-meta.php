		<div class="entry-meta">
			<?php iwthemesfw_posted_on(); ?>
		</div><!-- .entry-meta -->
