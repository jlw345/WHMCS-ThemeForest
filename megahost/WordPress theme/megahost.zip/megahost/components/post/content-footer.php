	<footer class="entry-footer">
		<?php iwthemesfw_entry_footer(); ?>
	</footer><!-- .entry-footer -->
