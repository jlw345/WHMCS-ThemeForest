<?php
    $iwthemesfw_container_copy = '';
    $iwthemesfw_copy_show = '';
    $show_copy_acf = '' ;
    $show_copy_kirki = '' ;
    $container_layout_acf = '';
    if( function_exists('get_field') ): $show_copy_acf = get_field('show_footer_copy'); endif;
    $show_copy_kirki = get_theme_mod( 'show_footer_copy');
    if( function_exists('get_field') ): $container_layout_acf = get_field('container_copy'); endif;
    $container_layout_kirki = get_theme_mod( 'container_footer_copy');


    if($show_copy_acf == 'show_copy'){
        $iwthemesfw_copy_show = 'show';
    }

    if($show_copy_kirki == 'show'){
        if($show_copy_acf != 'hidde_copy'){
            $iwthemesfw_copy_show = 'show';
        }
    }else{
        if($show_copy_acf == 'show_copy'){
            $iwthemesfw_copy_show = 'show';
        }
    }

    if($container_layout_acf != 'default_container'){
        $iwthemesfw_container_copy = $container_layout_acf;
    }

    if($container_layout_kirki){
        if($container_layout_acf == 'default_container'){
            $iwthemesfw_container_copy = $container_layout_kirki;
        }
    }

    if($show_copy_acf == ''){
        if($container_layout_kirki){
            $iwthemesfw_container_copy = $container_layout_kirki;
        }
    }

?>

<?php if($iwthemesfw_copy_show == 'show'): ?>
<div class="site-info">
	<div class="<?php if($iwthemesfw_container_copy){ echo esc_attr($iwthemesfw_container_copy); } else  echo esc_attr('container'); ?>">
        <div class="row">
            <div class="col-md-7">
                <nav class="footer-navigation">
                    <?php
                        if(has_nav_menu('menu-2')){
                            wp_nav_menu( array( 'theme_location' => 'menu-2', 'menu_id' => 'down-menu' ) );
                        }
                    ?>
                </nav>
            </div>

            <div class="col-md-5">
                <p><?php echo esc_html( get_theme_mod( 'cb_footer_copry' ) ); ?></p>
            </div>
        </div>
    </div>
</div><!-- .site-info -->
<?php endif; ?>
