<?php
    wp_reset_postdata();

    $main_footer = '';
    $id_footer_acf = '';
    $id_footer_kirki = '';
    $show_footer_kirki = '';
    $loop = '';
    $args = '';
    if( function_exists('get_field') ): $main_footer = get_field('main_footer'); endif;
    if( function_exists('get_field') ): $id_footer_acf = get_field('select_footer',false, false); endif;
    $id_footer_kirki = esc_html( get_theme_mod( 'select_footer' ) );
    $show_footer_kirki = esc_html( get_theme_mod( 'show_main_footer' ) );

    if($main_footer == 'different_footer'){
        if($id_footer_acf){
            $args = array( 'post_type' => 'footer_elements', 'post__in' => $id_footer_acf );
        }
    }

    if($main_footer == 'option_customizer'){
        if($id_footer_kirki){
            $args = array( 'post_type' => 'footer_elements', 'p' => $id_footer_kirki );
        }
    }

    if($show_footer_kirki == 'show'){
        if($main_footer != 'hidden_footer'){
            $loop = new WP_Query( $args );
            while ( $loop->have_posts() ) : $loop->the_post();
              the_content();
            endwhile;
        }
    }else{
        if($main_footer == 'different_footer'){
            $loop = new WP_Query( $args );
            while ( $loop->have_posts() ) : $loop->the_post();
              the_content();
            endwhile;
        }
    }

    if($main_footer == ''){
       if($show_footer_kirki == 'show'){
            $args = array( 'post_type' => 'footer_elements', 'p' => $id_footer_kirki );
            $loop = new WP_Query( $args );
            while ( $loop->have_posts() ) : $loop->the_post();
              the_content();
            endwhile;
        }
    }

    wp_reset_postdata();
?>
