<?php
/**
 * The template for displaying 404 pages (Not Found)
 */
get_header(); ?>

<section class="page404">
	<div class="container">
    	<div class="sixteen columns">
			<div class="text-center">
				<h1><?php _e('404', 'servereast'); ?></h1>
				<div class="content_404">
				<?php _e('The page you are looking for no longer exists. <br>Perhaps you can return back to the sites homepage see you can find what you are looking for.', 'servereast'); ?>
				</div>
				<div class="blog-link dark"><a class="btn btn-primary" href="<?php echo esc_url(home_url('/')); ?>"><?php _e('Back To Home', 'servereast'); ?></a></div>
			</div>
       </div> 	
    </div><!-- end container -->
</section><!-- end postwrapper -->

<?php get_footer(); ?>
