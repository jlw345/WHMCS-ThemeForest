<?php

 $link_audio = get_post_meta(get_the_ID(),'_cmb_link_audio', true);
 $link_video = get_post_meta(get_the_ID(),'_cmb_link_video', true);
get_header();
?>

<!-- Breadcrumps -->
<div class="breadcrumbs">
    <div class="row">
        <div class="col-sm-6">
            <h1><?php _e('Blog Single','servereast'); ?></h1>
        </div>
        <div class="col-sm-6">
            <?php servereast_breadcrumbs(); ?>
        </div>
    </div>
</div>
<!-- End of Breadcrumps -->

<!-- CONTENT BLOG -->
<?php while (have_posts()) : the_post(); ?>
<!-- content begin -->

  <div class="blog-page single">
    <div class="row">
      <div class="col-sm-8">
        <article>
          <?php $format = get_post_format(); ?>
            <?php if($format=='audio'){ ?>

              <iframe style="width:100%" src="<?php echo esc_url($link_audio); ?>"></iframe>

              <?php } elseif($format=='video'){ ?>
              <div class="embed-responsive embed-responsive-16by9">
                <iframe src="<?php echo esc_url($link_video); ?>"></iframe>
              </div>
              <?php } elseif($format=='gallery'){ ?>
                <?php
                  if ( function_exists('rwmb_meta') ) { 
                ?>  
                  <?php $images = rwmb_meta( '_cmb_images', "type=image" ); ?>
                  <?php if($images){ ?>
                    <div class="owl-post">
                      <?php                                                        
                        foreach ( $images as $image ) {                              
                      ?>
                      <?php $img = $image['full_url']; ?>
                        <div><img src="<?php echo esc_url($img); ?>" alt=""></div> 
                      <?php } ?>                   
                    </div>
                  <?php } ?>
                <?php } ?>
  
              <?php } else { $format=='image' ?>
              <?php
                if ( function_exists('rwmb_meta') ) { 
              ?>
                <?php $images = rwmb_meta( '_cmb_image', "type=image" ); ?>
                <?php if($images){ ?>
                <?php                                                        
                  foreach ( $images as $image ) {                              
                  ?>
                  <?php $img = $image['full_url']; ?>
                  <img src="<?php echo esc_url($img); ?>" alt="">
                  <?php } ?>
                <?php } ?>
              <?php } ?>

            <?php } ?>

            <div class="post-content">
            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <div class="thedate"><?php the_date( get_option( 'date_format' ) ); ?></div>
            <hr/>

            <?php the_content(); ?>

            <?php
                wp_link_pages( array(
                    'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'servereast' ) . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                    'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'servereast' ) . ' </span>%',
                    'separator'   => '<span class="screen-reader-text">, </span>',
                ) );
            ?>

            <?php if(has_tag()) { ?>
            <div class="tagcloud">
                <?php the_tags('','' ); ?>
            </div>
            <?php } ?>
          </article>
          
          <?php 
            the_post_navigation( array(
              'next_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Next Post', 'servereast' ) . '</span> ' .
                '<span class="screen-reader-text">' . __( 'Next post:', 'servereast' ) . '</span> ',
              'prev_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Previous Post', 'servereast' ) . '</span> ' .
                '<span class="screen-reader-text">' . __( 'Previous post:', 'servereast' ) . '</span> ',
            ) ); 
          ?>

          <?php
           if ( comments_open() || get_comments_number() ) :
            comments_template();
           endif;
          ?>

      </div>  
      <div class="col-sm-4">
          <?php get_sidebar();?>
      </div>
    </div>
  </div>
 </div>

<?php endwhile;?>
  <!-- END CONTENT BLOG -->
<?php get_footer(); ?>	





  