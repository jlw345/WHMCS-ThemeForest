(function($) {
    "use strict";

    $('.tnp-email').attr('placeholder', $('.tnp-field-email label').html());

    $('#navigation').find('.dropdown-menu').removeClass('dropdown-menu');
    $('#navigation').find('a').removeAttr('title');
    $('#bridge .navbar-nav li.dropdown').on( 'hover', function() {
        $(this).find('ul').toggleClass('show'); 
    } );

    $('#bridge').on('click','button.dropdown-toggle', function(){
        if($(this).next().hasClass('show')){
            $(this).next().removeClass('show');
        }else{
            $(this).next().addClass('show');
        }
    });

    // ______________ RESPONSIVE MENU
    $(document).ready(function() {

        $('#navigation').superfish({
            delay: 300,
            animation: {
                opacity: 'show',
                height: 'show'
            },
            speed: 'fast',
            dropShadows: false
        });

        $(function() {
            $('#navigation').slicknav({
                closedSymbol: "&#8594;",
                openedSymbol: "&#8595;"
            });
        });

    });

    // ______________ ANIMATE EFFECTS
    var wow = new WOW({
        boxClass: 'wow',
        animateClass: 'animated',
        offset: 0,
        mobile: false
    });
    wow.init();


    // ______________ BACK TO TOP BUTTON

    $(window).scroll(function() {
        if ($(this).scrollTop() > 300) {
            $('#back-to-top').fadeIn('slow');
        } else {
            $('#back-to-top').fadeOut('slow');
        }
    });
    $('#back-to-top').click(function() {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });

    $(".owl-post").owlCarousel({
        navigation: true, 
        slideSpeed : 600,
        autoPlay : 5000,
        singleItem:true,
        pagination: false
    });

    $("#testimonials-carousel").owlCarousel({
        items: 1,
        autoPlay: 5000,
        itemsDesktop: [1199, 1],
        itemsDesktopSmall: [979, 1],
        itemsTablet: [768, 1]
    });
    
    $('.myStat1').circliful();

    $('.most-popular').parents('.wpb_column').addClass('relative2');

    $(".price-per-period .permonth").click(function() {
            $(".monthprice").show();
            $(".yearprice").hide();
            $(".twoyearprice").hide();
            $(".price-per-period .permonth").addClass("btn-shared-checked");
            $(".price-per-period .permonth").removeClass("btn-default");
            $(".price-per-period .peryear").removeClass("btn-shared-checked");
            $(".price-per-period .peryear").addClass("btn-default");
            $(".price-per-period .per2yrs").removeClass("btn-shared-checked");
            $(".price-per-period .per2yrs").addClass("btn-default");
        });

        $(".price-per-period .peryear").click(function() {
            $(".monthprice").hide();
            $(".yearprice").show();
            $(".twoyearprice").hide();
            $(".price-per-period .permonth").removeClass("btn-shared-checked");
            $(".price-per-period .permonth").addClass("btn-default");
            $(".price-per-period .peryear").addClass("btn-shared-checked");
            $(".price-per-period .peryear").removeClass("btn-default");
            $(".price-per-period .per2yrs").removeClass("btn-shared-checked");
            $(".price-per-period .per2yrs").addClass("btn-default");
        });

        $(".price-per-period .per2yrs").click(function() {
            $(".monthprice").hide();
            $(".yearprice").hide();
            $(".twoyearprice").show();
            $(".price-per-period .permonth").removeClass("btn-shared-checked");
            $(".price-per-period .permonth").addClass("btn-default");
            $(".price-per-period .peryear").addClass("btn-default");
            $(".price-per-period .peryear").removeClass("btn-shared-checked");
            $(".price-per-period .per2yrs").removeClass("btn-default");
            $(".price-per-period .per2yrs").addClass("btn-shared-checked");
        });

        $( '.ot-tabs .vc_tta-tab' ).on( 'click', 'a', function( e ) {

            $( '.ot-tabs .vc_tta-tabs-list' ).find( '.vc_tta-tab' ).removeClass( 'vc_active' );
            $( this ).parent().addClass( 'vc_active' );
            var id = $( this ).attr( 'href' ).replace( '#', '' );
            $( '.ot-tabs .vc_tta-panels' ).find( '.vc_tta-panel' ).removeClass( 'vc_active').hide();
            $( '.ot-tabs .vc_tta-panels' ).find( '#' + id ).addClass( 'vc_active' ).show();

            return false;
        } );

        $("#tld-table").tablesorter();

        $('.domainsearch').on('click','.btn-primary', function(e){
            e.preventDefault();

            var domain = $('.domainsearch').find('input.form-control').val();
            var ext = $('.domainsearch').find('select.form-control').val();
            var action = $('.domainsearch').attr('action');
            if(domain == ''){
                $('.domainsearch').find('input.form-control').focus();
                return false;
            }
            $('#message .mess').html('');
            $('#message img').show();
            $('#message a.btn').hide();
          
             var data = {
                    'action': 'wdc_display',
                    'domain': domain,
                    'ext' : ext,
                    'security' : wdc_ajax.wdc_nonce
                  };
            $.post(wdc_ajax.ajaxurl, data, function(response) {
                var x = JSON.parse(response);
                var display = '';
                  if(x.status == 1){
                    display = x.text;
                    $('#message a.btn').css('display','inline-block');
                    $('.otdomain1').val(domain+ext);
                    $('.otdomain2').attr('name','domainsregperiod['+domain+ext+']');
                  }else if(x.status == 0) {
                    display = x.text;
                  }else{
                    display = "Error occured.";
                  }
                  $('#message img').hide();
                  $('#message .mess').html(display);
            } );

        });

         $('#message a.btn').on('click', function (e) {
            document.whmcs_com.submit();
        });

    

    var planval = $( '.vps-prices-container' ).find( '.planval' ).val();
    if( planval ) {
        planval = planval.split( '|' );
    }

    var memoryval = $( '.vps-prices-container' ).find( '.memoryval' ).val();
    if( memoryval ) {
        memoryval = memoryval.split( '|' );
    }

    var diskspaceval = $( '.vps-prices-container' ).find( '.diskspaceval' ).val();
    if( diskspaceval ) {
        diskspaceval = diskspaceval.split( '|' );
    }
     var bandwidthval = $( '.vps-prices-container' ).find( '.bandwidthval' ).val();
    if( bandwidthval ) {
        bandwidthval = bandwidthval.split( '|' );
    }
     var priceval = $( '.vps-prices-container' ).find( '.priceval' ).val();
    if( priceval ) {
        priceval = priceval.split( '|' );
    }

    var urlval = $( '.vps-prices-container' ).find( '.urlval' ).val();
    if( urlval ) {
        urlval = urlval.split( '|' );
    }

    var starting_point = $( '.vps-prices-container' ).find( '.point' ).val(); //Where the slider stops on first page load. Ideal to sign a plan as popular.

    $(document).ready(function() {

        $("#vps-slider").slider({
            range: 'min',
            animate: true,
            min: 1,
            max: $("#vps-slider").attr( 'data-number' ) , //Update this if you less or more plans
            paddingMin: 0,
            paddingMax: 0,
            slide: function(event, ui) {
                $('.vps-prices-container #disk_space_option span.how_much').html(diskspaceval[ui.value - 1]);
                $('.vps-prices-container #plan_option span.how_much').html(planval[ui.value - 1]);
                $('.vps-prices-container #memory_option span.how_much').html(memoryval[ui.value - 1]);
                $('.vps-prices-container #bandwidth_option span.how_much').html(bandwidthval[ui.value - 1]);
                $('.vps-prices-container #price_amount').html(priceval[ui.value - 1]);
                $('.vps-prices-container a.order-vps').attr('href', urlval[ui.value - 1]);


            },
            change: function(event, ui) {
                $('.vps-prices-container #disk_space_option span.how_much').html(diskspaceval[ui.value - 1]);
                $('.vps-prices-container #plan_option span.how_much').html(planval[ui.value - 1]);
                $('.vps-prices-container #memory_option span.how_much').html(memoryval[ui.value - 1]);
                $('.vps-prices-container #bandwidth_option span.how_much').html(bandwidthval[ui.value - 1]);
                $('.vps-prices-container #price_amount').html(priceval[ui.value - 1]);
                $('.vps-prices-container a.order-vps').attr('href', urlval[ui.value - 1]);
            }
        });


        $("#amount").val("$" + $("#vps-slider").slider("value"));
        $('#vps-slider').slider('value', starting_point);
        $('.vps-plan').click(function() {
            tt_amount = parseInt(this.id.slice(5)) + 1;
            $('#vps-slider').slider('how_much', tt_amount);
        });
    });


    var sync1 = $("#mainslider");
    var sync2 = $("#mainslider-nav");
    var speed = $("#mainslider").attr('data-speed');
    var num = $("#mainslider").attr('data-number');

    sync1.owlCarousel({
    singleItem : true,
    slideSpeed : speed,
    paginationSpeed: 800,
    navigation: false,
    pagination:false,
    autoPlay:7500,
    afterAction : syncPosition,
    responsiveRefreshRate : 200,
    });

    sync2.owlCarousel({
    items : num,
    itemsDesktop : [1199,num],
    itemsDesktopSmall : [979,(num-1)],
    itemsTablet : [768,(num-1)],
    itemsMobile : [479,1],
    pagination:false,
    responsiveRefreshRate : 100,
    afterInit : function(el){
    el.find(".owl-item").eq(0).addClass("synced");
    }
    });

    function syncPosition(el){
    var current = this.currentItem;
    $("#mainslider-nav")
    .find(".owl-item")
    .removeClass("synced")
    .eq(current)
    .addClass("synced")
    if($("#mainslider-nav").data("owlCarousel") !== undefined){
    center(current)
    }
    }

    $("#mainslider-nav").on("click", ".owl-item", function(e){
    e.preventDefault();
    var number = $(this).data("owlItem");
    sync1.trigger("owl.goTo",number);
    });

    function center(number){
    var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
    var num = number;
    var found = false;
    for(var i in sync2visible){
    if(num === sync2visible[i]){
    var found = true;
    }
    }

    if(found===false){
    if(num>sync2visible[sync2visible.length-1]){
    sync2.trigger("owl.goTo", num - sync2visible.length+2)
    }else{
    if(num - 1 === -1){
    num = 0;
    }
    sync2.trigger("owl.goTo", num);
    }
    } else if(num === sync2visible[sync2visible.length-1]){
    sync2.trigger("owl.goTo", sync2visible[1])
    } else if(num === sync2visible[0]){
    sync2.trigger("owl.goTo", num-1)
    }
    }
        

})(jQuery);
