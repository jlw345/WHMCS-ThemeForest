<article>
  <?php
    if ( function_exists('rwmb_meta') ) { 
  ?>
  <?php $images = rwmb_meta( '_cmb_images', "type=image" ); ?>

  <?php if($images){ ?>
    <div class="owl-post">
      <?php foreach ( $images as $image ) { ?>
      <?php $img = $image['full_url']; ?>
        <div><img src="<?php echo esc_url($img); ?>"></div>
      <?php } ?>
    </div>
  <?php } } ?>
  <div class="post-content">
      <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
      <div class="thedate"><?php the_date( get_option( 'date_format' ) ); ?></div>
      <hr/>
      <p><?php echo servereast_excerpt(); ?></p>

      <a class="button" href="<?php the_permalink(); ?>"><?php _e('Continue reading','servereast'); ?></a>
  </div>
</article>