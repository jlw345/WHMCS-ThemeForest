<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  <?php if(has_post_thumbnail()) { ?><img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt="" /><?php } ?>
  <div class="post-content">
      <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
      <div class="thedate"><?php the_date( get_option( 'date_format' ) ); ?></div>
      <hr/>
      <p><?php echo servereast_excerpt(); ?></p>

      <a class="button" href="<?php the_permalink(); ?>"><?php _e('Continue reading','servereast'); ?></a>
  </div>
</article>