<?php

/**
 * Template Name: Full Width
 */

get_header(); ?>

<!-- Breadcrumps -->
<div class="breadcrumbs">
    <div class="row">
        <div class="col-sm-6">
            <h1><?php the_title(); ?></h1>
        </div>
        <div class="col-sm-6">
            <?php servereast_breadcrumbs(); ?>
        </div>
    </div>
</div>
<!-- End of Breadcrumps -->
               
<?php while (have_posts()) : the_post()?>

    <?php the_content(); ?>
    
<?php endwhile; ?>

<!-- content close -->
<?php get_footer(); ?>