<?php
/**
 * Template Name: Template Shop
 */
get_header(); ?>

<!-- Breadcrumps -->
<div class="breadcrumbs">
    <div class="row">
        <div class="col-sm-6">
            <h1><?php the_title(); ?></h1>
        </div>
        <div class="col-sm-6">
            <?php servereast_breadcrumbs(); ?>
        </div>
    </div>
</div>
<!-- End of Breadcrumps -->

<div class="blog-page page-default">
    <div class="row">
        <div class="col-sm-8">
                       
            <?php while (have_posts()) : the_post()?>
            
                <?php the_post_thumbnail() ?>
                <article> 
                <?php the_content(); ?>
                </article>
                <?php wp_link_pages(); ?>
                
                <?php

                 if ( comments_open() || get_comments_number() ) :
                  comments_template();
                 endif;
                ?>
                
            <?php endwhile; ?>

        </div>

        <div class="col-md-4">
            <?php get_sidebar('shop');?>
        </div>

    </div>
</div>
<!-- content close -->
<?php get_footer(); ?>