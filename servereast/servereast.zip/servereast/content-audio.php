<?php 
$link_audio = get_post_meta(get_the_ID(),'_cmb_link_audio', true);

?>

<article>
  <?php if($link_audio) { ?>
  <div class="audio-post">
    <iframe width="100%" src="<?php echo esc_url( $link_audio ); ?>"></iframe>
  </div>
  <?php } ?>
  <div class="post-content">
      <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
      <div class="thedate"><?php the_date( get_option( 'date_format' ) ); ?></div>
      <hr/>
      <p><?php echo servereast_excerpt(); ?></p>

      <a class="button" href="<?php the_permalink(); ?>"><?php _e('Continue reading','servereast'); ?></a>
  </div>
</article> 