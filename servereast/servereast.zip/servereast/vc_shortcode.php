<?php 


//Custom Heading
if(function_exists('vc_map')){

   vc_map( array(

   "name"      => __("OT Heading", 'servereast'),

   "base"      => "heading",

   "class"     => "",

   "icon" => "icon-st",

   "category"  => 'Content',

   "params"    => array(

      array(

         "type"      => "textarea",

         "holder"    => "div",

         "class"     => "",

         "heading"   => __("Text", 'servereast'),

         "param_name"=> "text",

         "value"     => "Heading",

      ),
      array(

        "type" => "dropdown",

        "heading" => __('Element Tag', 'servereast'),

        "param_name" => "tag",

        "value" => array(   
                     __('Select Tag', 'servereast') => '',

                     __('h1', 'servereast') => 'h1',

                     __('h2', 'servereast') => 'h2',

                     __('h3', 'servereast') => 'h3',  

                     __('h4', 'servereast') => 'h4',

                     __('h5', 'servereast') => 'h5',

                     __('h6', 'servereast') => 'h6',  

                     __('p', 'servereast')  => 'p',

                     __('div', 'servereast') => 'div',
                    ),
    

      ),
      array(

        "type" => "dropdown",

        "heading" => __('Text Align', 'servereast'),

        "param_name" => "align",

        "value" => array(   

                     __('Select Align', 'servereast') => '',

                     __('left', 'servereast') => 'left',

                     __('right', 'servereast') => 'right',  

                     __('center', 'servereast') => 'center',

                     __('justify', 'servereast') => 'justify',
                     
                    ),     

      ),
      array(

         "type"      => "textfield",

         "holder"    => "div",

         "class"     => "",

         "heading"   => __("Font Size", 'servereast'),

         "param_name"=> "size",

         "value"     => "",


      ),
      array(

         "type"      => "colorpicker",

         "holder"    => "div",

         "class"     => "",

         "heading"   => __("Color", 'servereast'),

         "param_name"=> "color",

         "value"     => "",

      ),
      array(

         "type"      => "textfield",

         "holder"    => "div",

         "class"     => "",

         "heading"   => __("Margin Bottom", 'servereast'),

         "param_name"=> "bot",

         "value"     => "",

      ),
      array(

         "type"      => "textfield",

         "holder"    => "div",

         "class"     => "",

         "heading"   => __("Class Extra", 'servereast'),

         "param_name"=> "class",

         "value"     => "",

      ),
    )));

}

// Buttons

if(function_exists('vc_map')){

   vc_map( array(

   "name" => __("OT Button", 'servereast'),

   "base" => "button",

   "class" => "",

   "category" => 'Content',

   "icon" => "icon-st",

   "params" => array(

      array(

         "type" => "textfield",

         "holder" => "div",

         "class" => "",

         "heading" => __("Button Text", 'servereast'),

         "param_name" => "btntext",

         "value" => "",

         "description" => __("", 'servereast')

      ),
      array(

         "type" => "textfield",

         "holder" => "div",

         "class" => "",

         "heading" => __("Button Link", 'servereast'),

         "param_name" => "btnlink",

         "value" => '',

         "description" => __("", 'servereast')

      ),

      array(

         "type" => "dropdown",

         "holder" => "div",

         "class" => "",

         "heading" => __("Button Type", 'servereast'),

         "param_name" => "type",

         "value" => array(   

                     __('Default', 'servereast') => 'default',  

                     __('Primary', 'servereast') => 'primary',

                     __('Info', 'servereast') => 'info',

                     __('Success', 'servereast') => 'success',  

                     __('Warning', 'servereast') => 'warning',

                     __('Danger', 'servereast') => 'danger',
                    ),

         "description" => __("", 'servereast')

      ),
      array(

         "type" => "dropdown",

         "holder" => "div",

         "class" => "",

         "heading" => __("Button Size", 'servereast'),

         "param_name" => "size",

         "value" => array( 

                     __('Regular size', 'servereast') => 'default', 

                     __('Large', 'servereast') => 'large',

                     __('Small', 'servereast') => 'small',
                    ),

         "description" => __("", 'servereast')

      ),
      array(

         "type" => "checkbox",

         "holder" => "div",

         "class" => "",

         "heading" => __("Not Radius ?", 'servereast'),

         "param_name" => "radius",

         "description" => __("", 'servereast')

      ),
    )
    ));

}

//Call To Action

if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Call To Action", 'servereast'),
   "base"      => "callta",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'Content',
   "params"    => array(
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Text Call", 'servereast'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Text left call to action", 'servereast')
      ),
      array(
         "type" => "vc_link",
         "holder" => "div",
         "class" => "",
         "heading" => __("Button Action", 'servereast'),
         "param_name" => "btn",
         "value" => "",
         "description" => __("Button right call to action", 'servereast')
      ),
      array(
         "type" => "colorpicker",
         "holder" => "div",
         "class" => "",
         "heading" => __("Button Color", 'servereast'),
         "param_name" => "color",
         "value" => "",
         "description" => __("Color button right call to action", 'servereast')
      ),
    )));
}

//Register "container" content element. It will hold all your inner (child) content elements
if(function_exists('vc_map')){
vc_map( array(
    "name"                    => __("Home Slider", "servereast"),
    "base"                    => "homeslide",
    "as_parent"               => array('only' => 'slide_item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element"         => true,
    "icon"                    => "icon-st",
    "show_settings_on_create" => false,
    "params"                  => array(
         array(
            "type"       => "textfield",
            "heading"    => __("Slider Speed", "servereast"),
            "param_name" => "speed",
         ),
        // add params same as with any other content element
        array(
            "type"        => "textfield",
            "heading"     => __("Extra class name", "servereast"),
            "param_name"  => "el_class",
            "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "servereast")
        )
    ),
    "js_view" => 'VcColumnView'
) );
}
if(function_exists('vc_map')){
vc_map( array(
    "name" => __("Slide Item", "servereast"),
    "base" => "slide_item",
    "content_element" => true,
    "icon" => "icon-st",
    "as_child" => array('only' => 'homeslide'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(
        // add params same as with any other content element
         array(
            "type" => "attach_image",
            "heading" => __("Image Slide", "servereast"),
            "param_name" => "image",
        ),
        array(
            "type" => "textfield",
            "heading" => __("Title Tab", "servereast"),
            "param_name" => "title",
        ),
        array(
            "type" => "iconpicker",
            "heading" => __("Icon Tab", "servereast"),
            "param_name" => "icon",
            'value' => '', // default value to backend editor admin_label
            'settings' => array(
            'iconsPerPage' => 4000,
            // default 100, how many icons per/page to display, we use (big number) to display all icons in single page
         ),
         
         'description' => __( 'Select icon from library.', 'servereast' ),
        ),
        array(
            "type" => "textfield",
            "heading" => __("Big Text Slide", "servereast"),
            "param_name" => "btext",
        ),
        array(
            "type" => "textfield",
            "heading" => __("Small Text Slide", "servereast"),
            "param_name" => "stext",
        ),
        array(
            "type" => "textfield",
            "heading" => __("Label Button", "servereast"),
            "param_name" => "btn",
        ),
        array(
            "type" => "textfield",
            "heading" => __("Link Button", "servereast"),
            "param_name" => "link",
        ),
    )
) );
}
//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Homeslide extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Slide_Item extends WPBakeryShortCode {
    }
}


//Background Video

if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Background Video", 'servereast'),
   "base"      => "bgvideo",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'Content',
   "params"    => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Link mp4",
         "param_name" => "mp4",
         "value" => "",
         "description" => __("Input link mp4 video html5.", 'servereast')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Link webm",
         "param_name" => "webm",
         "value" => "",
         "description" => __("Input link webm video html5", 'servereast')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Link ogv",
         "param_name" => "ogv",
         "value" => "",
         "description" => __("Input link ogv video html5.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Big Text",
         "param_name" => "btext",
         "value" => "",
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Small Text",
         "param_name" => "stext",
         "value" => "",
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Label Button",
         "param_name" => "btn",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Link Button",
         "param_name" => "link",
         "value" => "",
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => "Video Muted?",
         "param_name" => "mute",
         "value" => "",
         'group'       => __( 'Extra Options', 'servereast' ),
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Min Height (px)",
         "param_name" => "high",
         "value" => "",
         "description" => __("Height Video. Ex: 300px.", 'servereast'),
         'group'       => __( 'Extra Options', 'servereast' ),
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Padding top (%)",
         "param_name" => "top",
         "value" => "",
         "description" => __("Content padding top. Ex: 15%.", 'servereast'),
         'group'       => __( 'Extra Options', 'servereast' ),
      ),
    )));
}

// Servereast search domain
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Search Domain Form", 'servereast'),
   "base"      => "servereast_search_domain",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'Content',
   "params"    => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link WHMCS", 'servereast'),
         "param_name" => "actionlink",
         "value" => "",
         "description" => __("Enter link your whmcs,<br> 
          Example 1: http://demo.vegatheme.com/servereast/whmcs-bridge <br>
          Example 2: http://demo.vegatheme.com/whmcs6", 'servereast')
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => "Use WHMCS Bridge?",
         "param_name" => "bridge",
         "value" => "",
         "description" => __("Tick this if link WHMCS like as: http://demo.vegatheme.com/servereast/whmcs-bridge", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Button Text", 'servereast'),
         "param_name" => "buttontext",
         "value" => "",
         "description" => __("Button Text", 'servereast')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("List Domains", 'servereast'),
         "param_name" => "domain",
         "value" => "",
         "description" => __("List Domain show in silder. Follow structure: .com|.net|.info", 'servereast')
      ),
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => "Change Image Loading",
         "param_name" => "image",
         "value" => "",
         "description" => __("Upload image loading search.", 'servereast')
      ),
      array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => "Show List Domains Slider",
         "param_name" => "slide",
         "value" => "",
      ),
       array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Number Show", 'servereast'),
         "param_name" => "number",
         "value" => "",
         'dependency'  => array( 'element' => 'slide', 'value' => 'true' ),
         "description" => __("Number Domains Visible", 'servereast')
      ),
    )));
}


//Carousel Image

if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Carousel Images", 'servereast'),
   "base"      => "carouselimg",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'Content',
   "params"    => array(
      array(
         "type" => "attach_images",
         "holder" => "div",
         "class" => "",
         "heading" => "Images",
         "param_name" => "gallery",
         "value" => "",
         "description" => __("Upload images.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Number Images", 'servereast'),
         "param_name" => "number",
         "value" => "",
         "description" => __("Number Images Visible.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Carousel Speed", 'servereast'),
         "param_name" => "speed",
         "value" => "",
         "description" => __("Default: 4000.", 'servereast')
      ),
    )));
}


// Pricing Table
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Pricing Table", 'servereast'),
   "base" => "pricingtable",
   "class" => "",
   "category" => 'Content',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title Pricing", 'servereast'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title display in Pricing Table.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Start From", 'servereast'),
         "param_name" => "start",
         "value" => "",
         "description" => __("Text Starting from.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Price Pricing", 'servereast'),
         "param_name" => "price",
         "value" => "",
         "description" => __("Price display in Pricing Table.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Time", 'servereast'),
         "param_name" => "per",
         "value" => "",
         "description" => __("Per Month or Year display in Pricing Table.", 'servereast')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Detail Pricing", 'servereast'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content Pricing Table.", 'servereast')
      ),
     array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Label Button", 'servereast'),
         "param_name" => "btn",
         "value" => "",
         "description" => __("Text display in button.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link Button", 'servereast'),
         "param_name" => "link",
         "value" => "",
         "description" => __("Link in button.", 'servereast')
      ),
     array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => __("Featured Pricing?", 'servereast'),
         "param_name" => "featured",
         "value" => "",
         "description" => __("", 'servereast')
      ),
    )));
}

//Buttons Tabs

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Pricing Tab Buttons", 'servereast'),
   "base" => "btntabs",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Label Button 1", 'servereast'),
         "param_name" => "btn1",
         "value" => "",
         "description" => __("Text Button 1", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Label Button 2", 'servereast'),
         "param_name" => "btn2",
         "value" => "",
         "description" => __("Text Button 2", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Label Button 3", 'servereast'),
         "param_name" => "btn3",
         "value" => "",
         "description" => __("Text Button 3", 'servereast')
      ),
    )));
}

// Pricing Table Tabs
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Pricing Table Tabs", 'servereast'),
   "base" => "pricingtable2",
   "class" => "",
   "category" => 'Content',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => __("Header Column?", 'servereast'),
         "param_name" => "head",
         "value" => "",
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title Pricing", 'servereast'),
         "param_name" => "title",
         "value" => "",
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
         "description" => __("Title display in Pricing Table.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Price Pricing", 'servereast'),
         "param_name" => "price",
         "value" => "",
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
         "description" => __("Price display in Pricing Table.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Time", 'servereast'),
         "param_name" => "per",
         "value" => "",
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
         "description" => __("Per Month or Year display in Pricing Table.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Price Pricing Tab2", 'servereast'),
         "param_name" => "price2",
         "value" => "",
         'group'       => __( 'Tab 2 Options', 'servereast' ),
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
         "description" => __("Price display in Pricing Table.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Time Tab2", 'servereast'),
         "param_name" => "per2",
         "value" => "",
         'group'       => __( 'Tab 2 Options', 'servereast' ),
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
         "description" => __("Per Month or Year display in Pricing Table.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Price Pricing Tab3", 'servereast'),
         "param_name" => "price3",
         "value" => "",
         'group'       => __( 'Tab 3 Options', 'servereast' ),
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
         "description" => __("Price display in Pricing Table.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Time Tab3", 'servereast'),
         "param_name" => "per3",
         "value" => "",
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
         'group'       => __( 'Tab 3 Options', 'servereast' ),
         "description" => __("Per Month or Year display in Pricing Table.", 'servereast')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Detail Pricing", 'servereast'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content Pricing Table.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Label Button", 'servereast'),
         "param_name" => "btn",
         "value" => "",
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
         "description" => __("Text display in button.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link Button", 'servereast'),
         "param_name" => "link",
         "value" => "",
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
         "description" => __("Link in button.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link Button", 'servereast'),
         "param_name" => "link2",
         "value" => "",
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
         'group'       => __( 'Tab 2 Options', 'servereast' ),
         "description" => __("Link in button.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link Button", 'servereast'),
         "param_name" => "link3",
         "value" => "",
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
         'group'       => __( 'Tab 3 Options', 'servereast' ),
         "description" => __("Link in button.", 'servereast')
      ),
     array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => __("Featured Pricing?", 'servereast'),
         "param_name" => "featured",
         "value" => "",
         'dependency'  => array( 'element' => 'head', 'is_empty' => true ),
      ),
    )));
}

//Compare Table

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Compare Table", 'servereast'),
   "base" => "compare_table",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array(
      array(
        "type"        => 'textarea',
        "holder"      => 'div',
        "heading"     => __('Titles','servereast'),
        "param_name"  => 'titles',
        "value"       => '',
        "description" => __("Enter titles for element (Note: divide columns with '|').",'servereast')
      ),
      array(
        "type"        => 'textarea_html',
        "holder"      => 'div',
        "heading"     => __('Content','servereast'),
        "param_name"  => 'content',
        'value'       => '',
        "description" => __("Enter the content ( Note: divide columns with '|' and devide rows with linebreaks (Enter)).",'servereast')
      ),  
      array(
         "type" => "checkbox",
         "holder" => "div",
         "class" => "",
         "heading" => __("Table Sorter?", 'servereast'),
         "param_name" => "sort",
         "value" => "",
         "description" => __("Sorter by title.", 'servereast')
      ),
      array(
        'type'        => 'textfield',
        'holder'      => 'div',
        'heading'     => __( 'Extra class name', 'servereast' ),
        'param_name'  => 'class_name',
        'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'servereast' ),
      ),
    )));
}

//Circle Process

if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Circle Process", 'servereast'),
   "base"      => "cprocess",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'Content',
   "params"    => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Title",
         "param_name" => "title",
         "value" => "",
         "description" => __("Title Process.", 'servereast')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Text or Number in Circle",
         "param_name" => "text",
         "value" => "",
         "description" => __("", 'servereast')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Percent",
         "param_name" => "percent",
         "value" => "",
         "description" => __("Number percent process.", 'servereast')
      ), 
    )));
}

//Clients Logo 

if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Client Logos", 'servereast'),
   "base"      => "logos",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'Content',
   "params"    => array(
      array(
         "type" => "attach_images",
         "holder" => "div",
         "class" => "",
         "heading" => "Logo Client",
         "param_name" => "gallery",
         "value" => "",
         "description" => __(".", 'servereast')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Number Images", 'servereast'),
         "param_name" => "number",
         "value" => "",
         "description" => __("Number Images Visible. Default: 6.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Carousel Speed", 'servereast'),
         "param_name" => "speed",
         "value" => "",
         "description" => __("Default: 5000.", 'servereast')
      ),
      array(

         "type" => "dropdown",

         "holder" => "div",

         "class" => "",

         "heading" => __("Style Show", 'servereast'),

         "param_name" => "type",

         "value" => array(

                     __('Grid', 'servereast') => 'type1', 

                     __('Carousel', 'servereast') => 'type2',
                    ),

         "description" => __("", 'servereast')

      ),
    )));
}


// Services
if(function_exists('vc_map')){
	
	vc_map( array(
   "name" => __("OT Services Box", 'servereast'),
   "base" => "services",
   "class" => "",
   "category" => 'Content',
   "icon" => "icon-st",
   "params" => array(
      array(

         "type" => "dropdown",

         "holder" => "div",

         "class" => "",

         "heading" => __("Type Box", 'servereast'),

         "param_name" => "type",

         "value" => array(

                     __('Box with small icon', 'servereast') => 'type1', 

                     __('Box with big icon', 'servereast') => 'type2',

                     __('Box not with Icon', 'servereast') => 'type3',
                    ),

         "description" => __("", 'servereast')

      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'servereast'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title display in box.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Icon", 'servereast'),
         "param_name" => "icon",
         "value" => "",
         'dependency'  => array( 'element' => 'type', 'value' => array( 'type1', 'type2', ) ),
         "description" => __("Icon in box. Add class follow: http://fontawesome.io/icons/", 'servereast')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'servereast'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Detail in box.", 'servereast')
      ),
      
    )
    ));
}


// Support Box
if(function_exists('vc_map')){
   
   vc_map( array(
   "name" => __("OT Support Box", 'servereast'),
   "base" => "supportbox",
   "class" => "",
   "category" => 'Content',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'servereast'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title display in box.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Icon", 'servereast'),
         "param_name" => "icon",
         "value" => "",
         "description" => __("Icon in box. Add class follow: http://fontawesome.io/icons/", 'servereast')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'servereast'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Detail in box.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link", 'servereast'),
         "param_name" => "link",
         "value" => "",
         "description" => __("Link box.", 'servereast')
      ),
      
    )
    ));
}

// VPS Order
if(function_exists('vc_map')){
   
   vc_map( array(
   "name" => __("OT VPS Order", 'servereast'),
   "base" => "vpsorder",
   "class" => "",
   "category" => 'Content',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'servereast'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title display in box.", 'servereast')
      ),
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => __("Top Image", 'servereast'),
         "param_name" => "image",
         "value" => "",
         "description" => __("Upload image top.", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Number Order", 'servereast'),
         "param_name" => "number",
         "value" => "",
         "description" => __("Input number int.", 'servereast')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'servereast'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Detail in box.", 'servereast')
      ),
      
    )
    ));
}


//Register "container" content element. It will hold all your inner (child) content elements
if(function_exists('vc_map')){
vc_map( array(
    "name"                    => __("VPS Plans", "servereast"),
    "base"                    => "vpsplans",
    "as_parent"               => array('only' => 'single_plan'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element"         => true,
    "icon"                    => "icon-st",
    "show_settings_on_create" => false,
    "params"                  => array(
         array(
            "type"       => "textfield",
            "heading"    => __("Label Button Order", "servereast"),
            "param_name" => "btn",
        ),
         array(
            "type"       => "textfield",
            "heading"    => __("Start Point", "servereast"),
            "param_name" => "point",
        ),
        // add params same as with any other content element
        array(
            "type"        => "textfield",
            "heading"     => __("Extra class name", "servereast"),
            "param_name"  => "el_class",
            "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "servereast")
        )
    ),
    "js_view" => 'VcColumnView'
) );
}
if(function_exists('vc_map')){
vc_map( array(
    "name" => __("VPS Single Plan", "servereast"),
    "base" => "single_plan",
    "content_element" => true,
    "icon" => "icon-st",
    "as_child" => array('only' => 'vpsplans'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(
        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Title", "servereast"),
            "param_name" => "title",
        ),
        array(
            "type" => "textfield",
            "heading" => __("Disk Space", "servereast"),
            "param_name" => "disk",
        ),
        array(
            "type" => "textfield",
            "heading" => __("Ram", "servereast"),
            "param_name" => "ram",
        ),
        array(
            "type" => "textfield",
            "heading" => __("Bandwidth", "servereast"),
            "param_name" => "band",
        ),
        array(
            "type" => "textfield",
            "heading" => __("Price", "servereast"),
            "param_name" => "price",
        ),
        array(
            "type" => "textfield",
            "heading" => __("Link", "servereast"),
            "param_name" => "link",
        ),
    )
) );
}
//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_VPSPlans extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Single_Plan extends WPBakeryShortCode {
    }
}

// Testimonial Slider

if(function_exists('vc_map')){
   
   vc_map( array(
   "name" => __("OT Testimonials", 'servereast'),
   "base" => "testslide",
   "class" => "",
   "category" => 'Content',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Testimonial",
         "param_name" => "number",
         "value" => "",
      ),
    )
    ));
}


//Google Map

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Google Map", 'servereast'),
   "base" => "ggmap",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array(  
    array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("ID Map", 'servereast'),
         "param_name" => "idmap",
         "value" => "map-canvas",
         "description" => __("Please enter ID Map, map-canvas1, map-canvas2, map-canvas3, ..etc", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Height Map", 'servereast'),
         "param_name" => "height",
         "value" => 320,
         "description" => __("Please enter number height Map, 300, 350, 380, ..etc. Default: 420.", 'servereast')
      ),    
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Latitude", 'servereast'),
         "param_name" => "lat",
         "value" => -37.817,
         "description" => __("Please enter <a href='http://www.latlong.net/'>Latitude</a> google map", 'servereast')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Longitude", 'servereast'),
         "param_name" => "long",
         "value" => 144.962,
         "description" => __("Please enter <a href='http://www.latlong.net/'>Longitude</a> google map", 'servereast')

      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Zoom Map", 'servereast'),
         "param_name" => "zoom",
         "value" => 13,
         "description" => __("Please enter Zoom Map, Default: 15", 'servereast')
      ),
    array(
            "type" => "colorpicker",
            "holder" => "div",
            "class" => "",
            "heading" => __("Map color", 'servereast'),
            "param_name" => "mapcolor",
            "value" => '', //Default White color
            "description" => __("Choose Map color", 'servereast')
         ),
     
    array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => "Icon Map marker",
         "param_name" => "icon",
         "value" => "",
         "description" => __("Icon Map marker, 47 x 68", 'servereast')
      ),  
       
    )));

}
 ?>