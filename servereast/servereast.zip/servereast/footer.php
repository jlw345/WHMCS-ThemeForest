<?php
/**
 * The template for displaying the footer
 */
?>

    <?php if(servereast_theme_option('topfooter')) { ?>
    <!--  Footer -->
    <div class="social">
        <div class="row">

            <div class="col-sm-6">
                <ul>
                    <?php servereast_socials(); ?>
                </ul>
            </div>

            <div class="col-sm-6">
                <div id="mc_embed_signup">
                    <?php if ( is_active_sidebar('newsletter') ) { dynamic_sidebar('newsletter'); } ?>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>

    <section class="footer">
        <div class="row">
            <?php get_sidebar('footer');?>
        </div>
    </section>
    <?php if(servereast_theme_option('copyr')) { ?>
    <div class="bot-footer">
        <div class="row text-center"><?php echo wp_kses(servereast_theme_option('copyr'), wp_kses_allowed_html('post')); ?></div>
    </div>
    <?php } ?>
    <!--  End of Footer -->
    <a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

<?php wp_footer(); ?>
    
</body>
</html>