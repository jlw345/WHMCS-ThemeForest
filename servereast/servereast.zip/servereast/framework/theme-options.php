<?php
/**
 * Register default theme options fields
 *
 * @package ServerEast
 */


/**
 * Register theme options fields
 *
 * @since  1.0
 *
 * @return array Theme options fields
 */
function servereast_theme_option_fields() {
	$options = array();

	// Help information
	$options['help'] = array(
		'document' => 'http://vegatheme.com/docs/servereast/',
		'support' => 'http://vegatheme.com/support/servereast/',
	);


	// Sections
	$options['sections'] = array(
		'general' => array(
			'icon' => 'cog',
			'title' => __( 'General', 'servereast' ),
		),
		'header' => array(
			'icon' => 'browser',
			'title' => __( 'Header', 'servereast' ),
		),
		'content' => array(
			'icon' => 'news',
			'title' => __( 'Blog', 'servereast' ),
		),
		'footer' => array(
			'icon' => 'rss',
			'title' => __( 'Footer', 'servereast' ),
		),
		'style' => array(
			'icon' => 'palette',
			'title' => __( 'Style', 'servereast' ),
		),
		'export' => array(
			'icon' => 'upload-to-cloud',
			'title' => __( 'Backup - Restore', 'servereast' ),
		),
	);

	// Fields
	$options['fields'] = array();
	$options['fields']['general'] = array(
		array(
			'name' => 'logo',
			'label' => __( 'Logo', 'servereast' ),
			'type' => 'image',
		),
		array(
			'name' => 'home_screen_icons',
			'label' => __( 'Home Screen Icons', 'servereast' ),
			'desc' => __( 'Select image file that will be displayed on home screen of handheld devices.', 'servereast' ),
			'type' => 'group',
			'children' => array(
				array(
					'name' => 'icon_ipad_retina',
					'type' => 'icon',
					'subdesc' => __( 'IPad Retina (144x144px)', 'servereast' ),
				),
				array(
					'name' => 'icon_ipad',
					'type' => 'icon',
					'subdesc' => __( 'IPad (72x72px)', 'servereast' ),
				),

				array(
					'name' => 'icon_iphone_retina',
					'type' => 'icon',
					'subdesc' => __( 'IPhone Retina (114x114px)', 'servereast' ),
				),

				array(
					'name' => 'icon_iphone',
					'type' => 'icon',
					'subdesc' => __( 'IPhone (57x57px)', 'servereast' ),
				)
			)
		),
	);

	$options['fields']['header'] = array(
		array(
			'name' => 'stickymenu',
			'label' => __( 'Sticky Menu', 'servereast' ),
			'desc' => __( 'Enable sticky the menu on the top of site', 'servereast' ),
			'type' => 'switcher',
			'default' => 0,
		),
		array(
			'name' => 'breadcrumb',
			'label' => __( 'Breadcrumbs', 'servereast' ),
			'desc' => __( 'Enable breadcrumbs on the pages', 'servereast' ),
			'type' => 'switcher',
			'default' => 1,
		),
		array(
			'name' => 'bread_color',
			'label' => __( 'Breadcrumbs Background', 'servereast' ),
			'type' => 'color',
		),
	);

	$options['fields']['content'] = array(
		array(
			'name' => 'excerpt_length',
			'label' => __( 'Excerpt Length', 'servereast' ),
			'type' => 'number',
			'size' => 'small',
			'default' => 30,
		),
	);


	$options['fields']['footer'] = array(
		array(
			'name' => 'topfooter',
			'label' => __( 'Top Footer', 'servereast' ),
			'type' => 'switcher',
			'default' => 1,
		),
		array(
			'name' => 'copyr',
			'label' => __( 'Copyright Text', 'servereast' ),
			'type' => 'editor',
		),
		array(
			'name' => 'topfooter_color',
			'label' => __( 'Top Footer Color', 'servereast' ),
			'type' => 'color',
		),
		array(
			'name' => 'footer_color',
			'label' => __( 'Footer Background', 'servereast' ),
			'type' => 'background',
		),
		array(
			'name' => 'socials',
			'label' => __( 'Socials', 'servereast' ),
			'type' => 'social',
			'subdesc' => __( 'Click to social icon to add link', 'servereast' ),
		),
	);

	$options['fields']['style'] = array(
		array(
			'name' => 'custom_color_scheme',
			'label' => __( 'Custom Color Scheme', 'servereast' ),
			'desc' => __( 'Enable custom color scheme to pick your own color scheme', 'servereast' ),
			'type' => 'group',
			'layout' => 'vertical',
			'children' => array(
				array(
					'name' => 'custom_color_scheme',
					'type' => 'switcher',
					'default' => false,
				),
				array(
					'name' => 'custom_color_1',
					'type' => 'color',
					'subdesc' => __( 'Custom Primary Color', 'servereast' ),
				),
				array(
					'name' => 'custom_color_2',
					'type' => 'color',
					'subdesc' => __( 'Custom Secondary Color', 'servereast' ),
				),
			)
		),
		array(
			'type' => 'divider',
		),
		array(
			'name' => 'custom_css',
			'label' => __( 'Custom CSS', 'servereast' ),
			'type' => 'code_editor',
			'language' => 'css',
			'subdesc' => __( 'Enter your custom style rules here', 'servereast' )
		),
	);
	
	$options['fields']['export'] = array(
		array(
			'name' => 'backup',
			'label' => __( 'Backup Settings', 'servereast' ),
			'subdesc' => __( 'You can tranfer the saved options data between different installs by copying the text inside the text box. To import data from another install, replace the data in the text box with the one from another install and click "Import Options" button above', 'servereast' ),
			'type' => 'backup',
		),
	);

	return $options;
}

add_filter( 'servereast_theme_options', 'servereast_theme_option_fields' );

/**
 * Generate custom color scheme css
 *
 * @since 1.0
 */
function servereast_generate_custom_color_scheme() {
	parse_str( $_POST['data'], $data );

	if ( ! isset( $data['custom_color_scheme'] ) || ! $data['custom_color_scheme'] ) {
		return;
	}

	$color_1 = $data['custom_color_1'];
	$color_2 = $data['custom_color_2'];
	if ( ! $color_1 && ! $color_2 ) {
		return;
	}

	// Getting credentials
	$url = wp_nonce_url( 'themes.php?page=theme-options' );
	if ( false === ( $creds = request_filesystem_credentials( $url, '', false, false, null ) ) ) {
		return; // stop the normal page form from displaying
	}

	// Try to get the wp_filesystem running
	if ( ! WP_Filesystem( $creds ) ) {
		// Ask the user for them again
		request_filesystem_credentials( $url, '', true, false, null );
		return;
	}

	global $wp_filesystem;

	// Prepare LESS to compile
	$less = $wp_filesystem->get_contents( get_template_directory() . '/css/color-schemes.less' );
	if(  $color_1 ) {
		$less .= ".custom-color-scheme { .color-scheme($color_1); }";
	}
	
	if(  $color_2 ) {
		$less .= ".custom-color-scheme { .color-scheme-2($color_2); }";
	}

	// Compile
	require get_template_directory() . '/framework/theme-options/lessc.inc.php';
	$compiler = new lessc;
	$compiler->setFormatter( 'compressed' );
	$css = $compiler->compile( $less );

	// Get file path
	$upload_dir = wp_upload_dir();
	$dir = path_join( $upload_dir['basedir'], 'custom-css' );
	$file = $dir . '/color-scheme.css';

	// Create directory if it doesn't exists
	wp_mkdir_p( $dir );
	$wp_filesystem->put_contents( $file, $css, FS_CHMOD_FILE );


	wp_send_json_success();
}

add_action( 'servereast_ajax_generate_custom_css', 'servereast_generate_custom_color_scheme' );

/**
 * Load script for theme options
 *
 * @since 1.0.0
 *
 * @param string $hook
 */
function servereast_enqueue_admin_scripts( $hook ) {
	if ( 'appearance_page_theme-options' != $hook ) {
		return;
	}

	$min = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

}

add_action( 'admin_enqueue_scripts', 'servereast_enqueue_admin_scripts' );
