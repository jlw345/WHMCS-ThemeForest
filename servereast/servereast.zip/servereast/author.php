<?php

get_header();

?>

<!-- Breadcrumps -->
<div class="breadcrumbs">
    <div class="row">
        <div class="col-sm-6">
            <h1><?php printf( __( 'All posts by: %s', 'servereast' ), get_the_author() ); ?></h1>
        </div>
        <div class="col-sm-6">
            <?php servereast_breadcrumbs(); ?>
        </div>
    </div>
</div>
<!-- End of Breadcrumps -->

<!-- Blog -->
<div class="blog-page">
    <div class="row">
        <div class="col-sm-8">
            <?php if(have_posts()) :


                while (have_posts()): the_post();                        

                get_template_part( 'content', get_post_format() ) ;

                endwhile;?>

                <?php else: ?>

                <h1><?php _e('Nothing Found Here!', 'servereast'); ?></h1>

            <?php endif ?>
            <nav>
                <ul class="pagination">
                    <?php echo servereast_pagination(); ?>
                </ul>
            </nav>

        </div>

        <div class="col-sm-4">
            <?php get_sidebar();?>
        </div>
    </div>
</div>
<!-- content close -->
<?php get_footer(); ?>