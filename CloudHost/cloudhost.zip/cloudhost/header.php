<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package CloudHost
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="hfeed site">

	<?php if( !is_page_template( 'template-comming-soon.php' ) ): ?>
		<?php do_action( 'cloudhost_before_header' ); ?>
		<header id="site-header" class="site-header header" >
			<?php do_action( 'cloudhost_header' ); ?>
		</header><!-- #masthead -->
		<?php do_action( 'cloudhost_after_header' ); ?>

		<div id="content" class="site-content">
			<?php if ( ! is_page_template( 'template-full-width.php' ) && ! is_page_template( 'template-homepage.php' )  && ! is_page_template( 'template-whmcs.php' ) ) : ?>
			<div class="container">
				<div class="row">
					<?php endif; ?>
	<?php endif; ?>