CloudHost - Responsive Hosting WordPress Theme
------------------------------

CloudHost is a Modern Multipurpose WordPress Theme. This theme is suited for any type of website, hosting or personal or business use. The Landing Page is designed with modern look and feel while keeping in mind to make it user friendly and eye catching so that people using it can get the best out of their website.


Changelog
---------
Version 1.0.7:
- Update: Visual Composer 5.4.2.
- Update: Revolution Slider 5.4.6.2.
- Fix: Don't show background image of the page header in category, search page.

Version 1.0.6:
- New: Add new option to get testimonial by categories in Testimonial Carousel
- Update: Visual Composer 5.1.1.
- Update: Revolution Slider 5.4.3.1.

Version 1.0.5:
- Update: Visual Composer 5.1.
- Update: Revolution Slider 5.4.1.

Version 1.0.4:
- Update: Visual Composer 5.0.
- Fix: Can't scroll on mobile
- Fix: Some bugs about CSS

Version 1.0.3:
- Fix: Can't change Title Area Background in pages

Version 1.0.2:
- Update: Style Theme Options

Version 1.0.1:
- Update: Color Scheme

Version 1.0:
- First release
