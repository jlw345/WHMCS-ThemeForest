<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package CloudHost
 */
?>
<?php if ( ! is_page_template( 'template-comming-soon.php' )  ) : ?>
					<?php if ( ! is_page_template( 'template-full-width.php' ) && ! is_page_template( 'template-homepage.php' )  && ! is_page_template( 'template-whmcs.php' ) ) : ?>

					</div> <!-- .row -->
				</div><!-- .container -->
			<?php endif; ?>
	</div><!-- #content -->
<?php endif; ?>
	<?php
	$css_class = '';
	if( cloudhost_theme_option( 'bg_footer' ) ) {
		$css_class = 'has-bg-footer';
	}
	?>

	<footer id="colophon" class="site-footer <?php echo esc_attr( $css_class ); ?>">
		<?php do_action( 'cloudhost_footer' ); ?>
	</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
