jQuery( document ).ready( function( $ ) {
	"use strict";

	// Show/hide settings for post format when choose post format
	var $format = $( '#post-formats-select' ).find( 'input.post-format' ),
		$formatBox = $( '#post-format-settings' );

	$format.on( 'change', function() {
		var	type = $format.filter( ':checked' ).val();

		$formatBox.hide();
		if( $formatBox.find( '.rwmb-field' ).hasClass( type ) ) {
			$formatBox.show();
		}

		$formatBox.find( '.rwmb-field' ).slideUp();
		$formatBox.find( '.' + type ).slideDown();
	} );
	$format.filter( ':checked' ).trigger( 'change' );

	// Show/hide settings for custom layout settings
	$( '#custom_layout' ).on( 'change', function() {
		if( $( this ).is( ':checked' ) ) {
			$( '.rwmb-field.custom-layout' ).slideDown();
		}
		else {
			$( '.rwmb-field.custom-layout' ).slideUp();
		}
	} ).trigger( 'change' );

	// Hide team info
	$( '#team-member-info' ).find( '.team-member-address' ).hide();
	$( '#team-member-info' ).find( '.team-member-phone' ).hide();
	$( '#team-member-info' ).find( '.team-member-email' ).hide();
	$( '#team-member-info' ).find( '.team-member-url' ).hide();

	// Show/hide settings for template settings
	$( '#page_template' ).on( 'change', function() {



		if( $( this ).val() == 'template-full-width.php' || $( this ).val() == 'template-homepage.php'  ) {
			$( '#display-settings .hide-fullwidth' ).hide();

			if( $( this ).val() == 'template-homepage.php' ) {
				$( '#display-settings .hide-homepage' ).hide();
			} else {
				$( '#display-settings .hide-homepage' ).hide();
				$( '#display-settings .hide-fullwidth' ).show();
			}

		}
		else {
			if( $( this ).val() == 'template-comming-soon.php' ) {
				$( '#display-settings .show-commingson' ).show();
				$( '#display-settings .hide-homepage' ).hide();
			}
			else {
				$( '#display-settings .show-commingson' ).hide();
				$( '#display-settings .hide-homepage' ).show();
			}
		}

	} ).trigger( 'change' );
} );
