(function ($) {
    'use strict';

    $(function () {

        // Flex slider for gallery
        $( '.format-gallery-slider .slides' ).owlCarousel( {
            singleItem: true,
            slideSpeed : 800,
            navigation: true,
            pagination: false,
            autoPlay: true,
            paginationSpeed : 1000,
            navigationText: ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>']
        } );

        // Click the icon navbar-toggle show/hide menu mobile
        $('#site-header').on('click', '.navbar-toggle', function (e) {
            e.preventDefault();
            $('#site-header .primary-nav').slideToggle();
            $(this).toggleClass( 'active' );
        });

        // Show menu when resize to bigger
        $(window).resize( function() {
            if ( $(window).width() > 991 ) {
                $('#site-header .primary-nav').show();
            } else {
                $('#site-header .primary-nav').hide();
                $('#site-header').find('.navbar-toggle').removeClass('active');
            }
        } );

        $( '#site-header' ).find( '.menu > .menu-item-has-children > a' ).append( '<span class="toggle-children fa fa-chevron-down"></span>' );
        $( '#site-header' ).on( 'click', '.toggle-children', function( e ) {
            e.preventDefault();
            $( this ).parents( 'li' ).toggleClass( 'show-children' );
        } );

        // Fit Video
        $('.entry-header .format-video').fitVids({customSelector: 'iframe'});

        /**
         * Search toggle
         */
        $('.header-menu-right .menu-item-search').on('click', '.item-search', function (e) {
            e.preventDefault();

            $(this).closest('.menu-item-search').toggleClass('show-search-form');
        });

        $('.header-menu-left .menu-item-search').on('click', '.item-search', function (e) {
            e.preventDefault();

            if( $('#site-header').hasClass( 'minimized' ) ) {
                $(this).closest('.menu-item-search').toggleClass('show-search-form');
            }
        });

        $(window).scroll( function() {
            var heightTop = 0;
            if( $( 'body').hasClass('has-topbar') ) {
                heightTop += 20;
            }
            if (  $(window).scrollTop() > heightTop  ) {
                $('.header-sticky #site-header').addClass( 'minimized' );
                if( $( '.header-menu-left').hasClass('header-sticky') ) {
                    $('#site-header .primary-nav').find( '.navbar').addClass( 'row' );
                    $('#site-header .primary-nav').find( '.primary-logo').addClass( 'col-xs-6 col-sm-3 col-md-3' );
                    $('#site-header .primary-nav').find( '.nav').addClass( 'col-xs-6 col-md-9 col-sm-9' );
                }

            } else {
                $('.header-sticky #site-header').removeClass( 'minimized' );
                if( $( '.header-menu-left').hasClass('header-sticky') ) {
                    $('#site-header .primary-nav').find( '.navbar').removeClass( 'row' );
                    $('#site-header .primary-nav').find( '.primary-logo').removeClass( 'col-xs-6 col-sm-3 col-md-3' );
                    $('#site-header .primary-nav').find( '.nav').removeClass( 'col-xs-6 col-md-9 col-sm-9' );
                }
            }

        } ).trigger( 'scroll' );

        $( '.live-chat-widget').on( 'click', '.btn-live-chat', function(e) {
            e.preventDefault();
            $( '#wp-live-chat-header').click();

        } );

    });
})(jQuery);