<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package CloudHost
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<section class="error-404 text-center">
				<div class="not-found container">
					<h1 class="page-title">404</h1>
					<div class="page-content col-sm-6 col-sm-offset-3 col-md-6 col-md-offset-3">
						<h3><?php esc_html_e( 'This page not be found', 'cloudhost' ); ?></h3>
						<p><?php esc_html_e( 'We are really sorry, but the page you requested is missing..', 'cloudhost' ); ?></p>
						<p>
							<?php esc_html_e( 'Perhaps searching again can help. Or back to', 'cloudhost' ); ?>
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" ><?php esc_html_e( ' home page', 'cloudhost' ); ?></a>
						</p>

						 <?php get_search_form(); ?>

					</div><!-- .page-content -->
				</div>
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer(); ?>
