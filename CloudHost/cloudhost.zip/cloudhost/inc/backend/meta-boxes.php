<?php
/**
 * Registering meta boxes
 *
 * All the definitions of meta boxes are listed below with comments.
 *
 * For more information, please visit:
 * @link http://www.deluxeblogtips.com/meta-box/
 */


/**
 * Enqueue script for handling actions with meta boxes
 *
 * @since 1.0
 *
 * @param string $hook
 */
function cloudhost_meta_box_scripts($hook) {
    // Detect to load un-minify scripts when WP_DEBUG is enable
    $min = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';

    if (in_array($hook, array('post.php', 'post-new.php'))) {
        wp_enqueue_script('cloudhost-meta-boxes', get_template_directory_uri() . "/js/backend/meta-boxes.js", array('jquery'), '20160629', true);
    }
}

add_action('admin_enqueue_scripts', 'cloudhost_meta_box_scripts');

/**
 * Registering meta boxes
 *
 * Using Meta Box plugin: http://www.deluxeblogtips.com/meta-box/
 *
 * @see http://www.deluxeblogtips.com/meta-box/docs/define-meta-boxes
 *
 * @param array $meta_boxes Default meta boxes. By default, there are no meta boxes.
 *
 * @return array All registered meta boxes
 */
function cloudhost_register_meta_boxes($meta_boxes) {
    // Post format's meta box
    $meta_boxes[] = array(
        'id'       => 'post-format-settings',
        'title'    => esc_html__('Format Details', 'cloudhost'),
        'pages'    => array('post'),
        'context'  => 'normal',
        'priority' => 'high',
        'autosave' => true,
        'fields'   => array(
            array(
                'name'             => esc_html__('Image', 'cloudhost'),
                'id'               => 'image',
                'type'             => 'image_advanced',
                'class'            => 'image',
                'max_file_uploads' => 1,
            ),
            array(
                'name'  => esc_html__('Gallery', 'cloudhost'),
                'id'    => 'images',
                'type'  => 'image_advanced',
                'class' => 'gallery',
            ),
            array(
                'name'  => esc_html__('Audio', 'cloudhost'),
                'id'    => 'audio',
                'type'  => 'textarea',
                'cols'  => 20,
                'rows'  => 2,
                'class' => 'audio',
            ),
            array(
                'name'  => esc_html__('Video', 'cloudhost'),
                'id'    => 'video',
                'type'  => 'textarea',
                'cols'  => 20,
                'rows'  => 2,
                'class' => 'video',
            ),
            array(
                'name'  => esc_html__('Link', 'cloudhost'),
                'id'    => 'url',
                'type'  => 'textarea',
                'cols'  => 20,
                'rows'  => 1,
                'class' => 'link',
            ),
            array(
                'name'  => esc_html__('Text', 'cloudhost'),
                'id'    => 'url_text',
                'type'  => 'textarea',
                'cols'  => 20,
                'rows'  => 1,
                'class' => 'link',
            ),
            array(
                'name'  => esc_html__('Quote', 'cloudhost'),
                'id'    => 'quote',
                'type'  => 'textarea',
                'cols'  => 20,
                'rows'  => 2,
                'class' => 'quote',
            ),
            array(
                'name'  => esc_html__('Author', 'cloudhost'),
                'id'    => 'quote_author',
                'type'  => 'textarea',
                'cols'  => 20,
                'rows'  => 1,
                'class' => 'quote',
            ),
            array(
                'name'  => esc_html__('Author URL', 'cloudhost'),
                'id'    => 'author_url',
                'type'  => 'textarea',
                'cols'  => 20,
                'rows'  => 1,
                'class' => 'quote',
            ),
            array(
                'name'  => esc_html__('Status', 'cloudhost'),
                'id'    => 'status',
                'type'  => 'textarea',
                'cols'  => 20,
                'rows'  => 1,
                'class' => 'status',
            ),
        ),
    );

    // Display Settings
    $meta_boxes[] = array(
        'id'       => 'display-settings',
        'title'    => esc_html__('Display Settings', 'cloudhost'),
        'pages'    => array('page'),
        'context'  => 'normal',
        'priority' => 'high',
        'fields'   => array(
            array(
                'name'  => esc_html__('Background Image', 'cloudhost'),
                'id'    => 'heading_bg_comming',
                'type'  => 'heading',
                'class' => 'show-commingson',
            ),
            array(
                'name'             => esc_html__('Choose Background Image', 'cloudhost'),
                'id'               => 'bg_commingsoon',
                'type'             => 'image_advanced',
                'max_file_uploads' => 1,
                'class'            => 'show-commingson',
            ),
            array(
                'name'  => esc_html__('Title Area', 'cloudhost'),
                'id'    => 'heading_title_area',
                'type'  => 'heading',
                'class' => 'hide-homepage hide-fullwidth',
            ),
            array(
                'name'  => esc_html__('Hide Title Area', 'cloudhost'),
                'id'    => 'hide_title_area',
                'type'  => 'checkbox',
                'std'   => false,
                'class' => 'hide-homepage hide-fullwidth',
            ),
            array(
                'name'             => esc_html__('Title Area Background', 'cloudhost'),
                'id'               => 'title_area_bg',
                'type'             => 'image_advanced',
                'max_file_uploads' => 1,
                'class'            => 'bg-title-area hide-homepage hide-fullwidth',
            ),
            array(
                'name'  => esc_html__('Hide Breadcrumb', 'cloudhost'),
                'id'    => 'hide_breadcrumb',
                'type'  => 'checkbox',
                'std'   => false,
                'class' => 'hide-homepage hide-fullwidth',
            ),
            array(
                'name' => esc_html__('Layout', 'cloudhost'),
                'id'   => 'heading_layout',
                'type' => 'heading',
                'class' => 'hide-homepage',
            ),
            array(
                'name' => esc_html__('Custom Layout', 'cloudhost'),
                'id'   => 'custom_layout',
                'type' => 'checkbox',
                'class' => 'hide-homepage',
                'std'  => false,
            ),
            array(
                'name'    => esc_html__('Layout', 'cloudhost'),
                'id'      => 'layout',
                'type'    => 'image_select',
                'class'   => 'custom-layout hide-homepage',
                'options' => array(
                    'full-content'    => get_template_directory_uri() . '/inc/libs/theme-options/img/sidebars/empty.png',
                    'sidebar-content' => get_template_directory_uri() . '/inc/libs/theme-options/img/sidebars/single-left.png',
                    'content-sidebar' => get_template_directory_uri() . '/inc/libs/theme-options/img/sidebars/single-right.png',
                ),
            ),
            array(
                'name' => esc_html__('Style', 'cloudhost'),
                'id'   => 'heading_layout',
                'type' => 'heading',
            ),
            array(
                'name' => esc_html__('Custom CSS', 'cloudhost'),
                'id'   => 'custom_css',
                'type' => 'textarea',
                'std'  => false,
            ),
        ),
    );

    return $meta_boxes;
}

add_filter('rwmb_meta_boxes', 'cloudhost_register_meta_boxes');


function cloudhost_unregister_theme_post_types() {
    global $wp_post_types;
    if (post_type_exists('team_showcase')) {
        unset($wp_post_types['team_showcase']);
    }
}

add_action('init', 'cloudhost_unregister_theme_post_types', 20);