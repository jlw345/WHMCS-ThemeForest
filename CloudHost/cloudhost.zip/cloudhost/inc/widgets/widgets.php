<?php
/**
 * Load and register widgets
 *
 * @package CloudHost
 */

require_once get_template_directory() . '/inc/widgets/recent-posts.php';
require_once get_template_directory() . '/inc/widgets/tabs.php';
require_once get_template_directory() . '/inc/widgets/social-media-links.php';
require_once get_template_directory() . '/inc/widgets/live-chat.php';

/**
 * Register widgets
 *
 * @since  1.0
 *
 * @return void
 */
function cloudhost_register_widgets() {
	register_widget( 'CloudHost_Recent_Posts_Widget' );
	register_widget( 'CloudHost_Tabs_Widget' );
	register_widget( 'CloudHost_Social_Links_Widget' );
	register_widget( 'CloudHost_Live_Chat_Widget' );
}
add_action( 'widgets_init', 'cloudhost_register_widgets' );