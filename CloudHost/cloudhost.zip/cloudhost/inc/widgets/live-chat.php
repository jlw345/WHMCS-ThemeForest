<?php

class CloudHost_Live_Chat_Widget extends WP_Widget {

    /**
     * Holds widget settings defaults, populated in constructor.
     *
     * @var array
     */
    protected $defaults;

    /**
     * Constructor
     */
    function __construct() {
        $this->defaults = array(
            'title'          => '',
            'support_text'   => '',
            'number'         => '',
            'live_chat_text' => ''
        );

        parent::__construct(
            'live-chat-widget',
            esc_html__('CloudHost - Live Chat', 'cloudhost'),
            array(
                'classname'   => 'live-chat-widget live-chat',
                'description' => esc_html__('Display links to live chat.', 'cloudhost'),
            ),
            array('width' => 600, 'height' => 350)
        );
    }

    /**
     * Outputs the HTML for this widget.
     *
     * @param array $args An array of standard parameters for widgets in this theme
     * @param array $instance An array of settings for this widget instance
     *
     * @return void Echoes it's output
     */
    function widget($args, $instance) {
         $instance = wp_parse_args( $instance, $this->defaults );

        extract($args);
        echo $before_widget;

        if ($title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base))
            echo $before_title . $title . $after_title;

        echo '<div class="lc-left">';
        echo '<div class="lc-title"><i class="fa fa-phone"></i>' . $instance['support_text'] . '</div>';
        echo '<div class="lc-number">' . $instance['number'] . '</div>';
        echo '</div>';
        echo '<div class="lc-right">';
        echo '<a href="#" class="btn-live-chat"><i class="fa fa-comments-o"></i>' . $instance['live_chat_text'] . '</a>';
        echo '</div>';

        echo $after_widget;
    }

    /**
     * Update widget
     *
     * @param array $new_instance New widget settings
     * @param array $old_instance Old widget settings
     *
     * @return array
     */
    function update($new_instance, $old_instance) {
        $new_instance['title'] = strip_tags($new_instance['title']);
        $new_instance['support_text'] = strip_tags($new_instance['support_text']);
        $new_instance['number'] = strip_tags($new_instance['number']);
        $new_instance['live_chat_text'] = strip_tags($new_instance['live_chat_text']);

        return $new_instance;
    }

    /**
     * Displays the form for this widget on the Widgets page of the WP Admin area.
     *
     * @param array $instance
     *
     * @return array
     */
    function form($instance) {
        $instance = wp_parse_args( $instance, $this->defaults );
        ?>

        <p>
            <label
                for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title', 'cloudhost'); ?></label>
            <input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
                   name="<?php echo esc_attr($this->get_field_name('title')); ?>"
                   value="<?php echo esc_attr($instance['title']); ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'support_text' ) ); ?>"><?php esc_html_e( 'Support Text', 'cloudhost' ); ?></label>
            <p><input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'support_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'support_text' ) ); ?>" type="text" size="10" value="<?php echo  $instance['support_text']; ?>"></p>
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number', 'cloudhost' ); ?></label>
             <p><input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" size="10" value="<?php echo  $instance['number']; ?>"></p>
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'live_chat_text' ) ); ?>"><?php esc_html_e( 'Live Chat Text', 'cloudhost' ); ?></label>
            <p><input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'live_chat_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'live_chat_text' ) ); ?>" type="text" size="10" value="<?php echo  $instance['live_chat_text']; ?>"></p>
        </p>
        <?php
    }
}
