<?php
/**
 * Custom functions for entry.
 *
 * @package CloudHost
 */

/**
 * Prints HTML with meta information for the current post-date/time and author.
 *
 * @since 1.0.0
 */
function cloudhost_posted_on() {
	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date( ' d.M.Y' ) )
	);
	$archive_year  = get_the_time('Y');
	$archive_month = get_the_time('m');
	$archive_day   = get_the_time('d');

	$posted_on = sprintf(
		'<a href="' . esc_url( get_day_link( $archive_year, $archive_month, $archive_day) ) . '" class="entry-date entry-meta" rel="bookmark">' . $time_string . '</a>'
	);
	$posted_on .= sprintf(
		'<span class="entry-author entry-meta">'. esc_html__( ' By', 'cloudhost' ).'<a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	$comments =  wp_count_comments( get_the_ID() );
	if( $comments ) {
		$total_comments = $comments->total_comments;
			$comments =  intval( $total_comments ) ;
	}
	$comment = sprintf(
		'<span class="entry-comment entry-meta"><i class="fa fa-comments-o"></i>' . $comments . '</span>'
	);
	return '<div class="entry-metas">' . $posted_on .  $comment . '</div>';
}

/**
 * Prints HTML with meta information for the categories, tags and comments.
 *
 * @since 1.0.0
 */
function cloudhost_entry_footer() {
	// Hide category and tag text for pages.
	if ( 'post' == get_post_type() ) {
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( ', ' );
		if ( $categories_list ) {
			printf( '<span class="cat-links">' . esc_html__( 'Posted in %1$s', 'cloudhost' ) . '</span>', $categories_list );
		}
		/* translators: used between list items, there is a space after the comma */
		$tags_list = get_the_tag_list( '', ', ' );
		if ( $tags_list ) {
			printf( '<span class="tags-links">' . esc_html__( 'Tagged %1$s', 'cloudhost' ) . '</span>', $tags_list );
		}
	}
	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		echo '<span class="comments-link">';
		comments_popup_link( esc_html__( 'Leave a comment', 'cloudhost' ), esc_html__( '1 Comment', 'cloudhost' ), esc_html__( '% Comments', 'cloudhost' ) );
		echo '</span>';
	}
	edit_post_link( esc_html__( 'Edit', 'cloudhost' ), '<span class="edit-link">', '</span>' );
}

/**
 * Get or display limited words from given string.
 * Strips all tags and shortcodes from string.
 *
 * @since 1.0.0
 * @param integer $num_words The maximum number of words
 * @param string  $more      More link.
 * @param bool    $echo      Echo or return output
 *
 * @return string|void Limited content.
 */
function cloudhost_content_limit( $content, $num_words, $more = "&hellip;", $echo = true ) {

	// Strip tags and shortcodes so the content truncation count is done correctly
	$content = strip_tags( strip_shortcodes( $content ), apply_filters( 'cloudhost_content_limit_allowed_tags', '<script>,<style>' ) );

	// Remove inline styles / scripts
	$content = trim( preg_replace( '#<(s(cript|tyle)).*?</\1>#si', '', $content ) );

	// Truncate $content to $max_char
	$content = wp_trim_words( $content, $num_words );

	if ( $more )
	{
		$output = sprintf(
			'<p>%s <a href="%s" class="more-link" title="%s">%s</a></p>',
			$content,
			esc_url(get_permalink()),
			sprintf( esc_html__( 'Continue reading &quot;%s&quot;', 'cloudhost' ), the_title_attribute( 'echo=0' ) ),
			esc_html( $more )
		);
	}
	else
	{
		$output = sprintf( '<p>%s</p>', $content );
	}

	if ( !$echo )
		return $output;

	echo $output;
}

/**
 * Show entry thumbnail base on its format
 *
 * @since  1.0
 */
function cloudhost_entry_thumbnail( $size = 'cloudhost-blog-normal' ) {
	$html      = '';
	$css_class = 'format-' . get_post_format();

	if( is_single() ) {
		$size = 'cloudhost-blog-large-thumb';
	}

	$size = apply_filters( 'cloudhost_post_format_thumbnail_size', $size );

	switch ( get_post_format() ) {
		case 'image':
			$image = cloudhost_get_image( array(
				'size'     => $size,
				'format'   => 'src',
				'meta_key' => 'image',
				'echo'     => false,
			) );

			if ( ! $image ) {
				break;
			}

			$html = sprintf(
				'<a class="entry-image" href="%1$s" title="%2$s"><img src="%3$s" alt="%2$s"></a>',
				esc_url( get_permalink() ),
				the_title_attribute( 'echo=0' ),
				esc_url( $image )
			);
			break;
		case 'gallery':
			$images = cloudhost_get_meta( 'images', "type=image&size=$size" );

			if ( empty( $images ) ) {
				break;
			}

			$gallery = array();
			foreach ( $images as $image ) {
				$gallery[] = '<li>' . '<img src="' . esc_url( $image['url'] ) .'" alt="' . the_title_attribute( 'echo=0' ) . '">' . '</li>';
			}
			$html .= '<div class="format-gallery-slider entry-image"><ul class="slides">' . implode( '', $gallery ) . '</ul></div>';
			break;
		case 'audio':

			$thumb = get_the_post_thumbnail( get_the_ID(), $size );
			if ( !empty( $thumb ) ) {
				$html .= '<a class="entry-image" href="' . esc_url(get_permalink()) . '">' . $thumb . '</a>';
			} else {
				$css_class .= ' no-thumb';
			}

			$audio = cloudhost_get_meta( 'audio' );
			if ( ! $audio ) {
				break;
			}

			// If URL: show oEmbed HTML or jPlayer
			if ( filter_var( $audio, FILTER_VALIDATE_URL ) ) {
				// Try oEmbed first
				if ( $oembed = @wp_oembed_get( $audio ) ) {
					$html .= $oembed;
				}
				// Use audio shortcode
				else {
					$html .= '<div class="audio-player">' . wp_audio_shortcode( array( 'src' => $audio ) ) . '</div>';
				}
			}
			// If embed code: just display
			else {
				$html .= $audio;
			}
			break;
		case 'video':
			$video = cloudhost_get_meta( 'video' );
			if ( ! $video ) {
				break;
			}

			// If URL: show oEmbed HTML
			if ( filter_var( $video, FILTER_VALIDATE_URL ) ) {
				if ( $oembed = @wp_oembed_get( $video ) ) {
					$html .= $oembed;
				}
				else {
					$atts = array(
						'src'   => $video,
						'width' => 848,
					);
					if ( has_post_thumbnail() ) {
						$atts['poster'] = cloudhost_get_image( 'format=src&echo=0&size=full' );
					}
					$html .= wp_video_shortcode( $atts );
				}
			}
			// If embed code: just display
			else {
				$html .= $video;
			}
			break;
		case 'link':
			$thumb = get_the_post_thumbnail( get_the_ID(), $size );
			if ( !empty( $thumb ) ) {
				$html .= '<a class="entry-image" href="' . esc_url( get_permalink() ) . '">' . $thumb . '</a>';
			} else {
				$css_class .= ' no-thumb';
			}

			$link = cloudhost_get_meta( 'url' );
			$text = cloudhost_get_meta( 'url_text' );

			if ( ! $link ) {
				break;
			}

			$html .= sprintf( '<a href="%s" class="link-block">%s</a>', esc_url( $link ), $text ? $text : $link );

			break;
		case 'quote':

			$thumb = get_the_post_thumbnail( get_the_ID(), $size );
			if ( !empty( $thumb ) ) {
				$html .= '<a class="entry-image" href="' . esc_url(get_permalink()) . '">' . $thumb . '</a>';
			} else {
				$css_class .= ' no-thumb';
			}

			$quote      = cloudhost_get_meta( 'quote' );
			$author     = cloudhost_get_meta( 'quote_author' );
			$author_url = cloudhost_get_meta( 'author_url' );

			if ( ! $quote ) {
				break;
			}

			$html .= sprintf(
				'<blockquote>%s<cite>%s</cite></blockquote>',
				esc_html( $quote ),
				empty( $author_url ) ? $author : '<a href="' . esc_url( $author_url ) . '"> - ' . $author . '</a>'
			);

			break;
		default:
			$thumb = cloudhost_get_image( array(
				'size'     => $size,
				'meta_key' => 'image',
				'echo'     => false,
			) );
			if ( empty( $thumb ) ) {
				break;
			}

			$html .= '<a class="entry-image" href="' . esc_url(get_permalink()) . '">' . $thumb . '</a>';
			break;
	}

	if ( $html = apply_filters( __FUNCTION__, $html, get_post_format() ) ) {
		$css_class = esc_attr( $css_class );
		return "<div class='entry-format $css_class'>$html</div>";
	}
}



/**
 * Get author meta
 *
 * @since  1.0
 *
 */
function cloudhost_author_box() {
	?>
	<div class="post-author-box clearfix">
		<div class="post-author-avatar">
			<?php echo get_avatar( get_the_author_meta( 'ID' ), 100 ); ?>
		</div>
		<div class="post-author-desc">
			<div class="post-author-name">
				<?php the_author_meta( 'display_name' ); ?>
				<p><?php the_author_meta( 'description' ); ?></p>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Share link socials
 *
 * @since  1.0
 */
function cloudhost_share_link_socials( $title, $link, $media ) {
	?>
	<div class="social-links">
		<a target="_blank" title="<?php echo esc_attr( $title ); ?>" class="share-facebook cloudhost-facebook"
		   href="http://www.facebook.com/sharer.php?u=<?php echo urlencode( $link ); ?>&t=<?php echo urlencode( $title ); ?>"><i
				class="fa fa-facebook"></i></a>
		<a class="share-twitter cloudhost-twitter"
		   href="http://twitter.com/share?text=<?php echo esc_attr( $title ); ?>&url=<?php echo urlencode( $link ); ?>"
		   title="<?php echo urlencode( $title ); ?>" target="_blank"><i class="fa fa-twitter"></i></a>
		<a target="_blank" title="<?php echo esc_attr( $title ); ?>" class="share-google-plus cloudhost-google-plus"
		   href="https://plus.google.com/share?url=<?php echo urlencode( $link ); ?>&text=<?php echo urlencode( $title ); ?>"><i
				class="fa fa-google-plus"></i></a>
		<a target="_blank" title="<?php echo esc_attr( $title ); ?>" class="share-linkedin cloudhost-linkedin"
		   href="http://www.linkedin.com/shareArticle?url=<?php echo urlencode( $link ); ?>&title=<?php echo urlencode( $title ); ?> "><i
				class="fa fa-linkedin"></i></a>
		<a target="_blank" title="<?php echo esc_attr( $title ); ?>" class="share-pinterest cloudhost-pinterest"
		   href="http://pinterest.com/pin/create/button?media=<?php echo urlencode( $media ); ?>&url=<?php echo urlencode( $link ); ?>&description=<?php echo urlencode( $title ); ?> "><i
				class="fa fa-pinterest"></i></a>
	</div>
	<?php
}


