<?php
/**
 * Custom functions for layout.
 *
 * @package Foster
 */

/**
 * Get layout base on current page
 *
 * @return string
 */
function cloudhost_get_layout() {
	$layout  = cloudhost_theme_option( 'default_layout' );

	if ( is_page() && cloudhost_get_meta( 'custom_layout' ) ) {
		$layout = cloudhost_get_meta( 'layout' );
	} elseif ( is_page() ) {
		$layout = cloudhost_theme_option( 'page_layout' );
	} elseif( is_search() ) {
		$layout = 'full-content';
	}

	return $layout;
}

/**
 * Get Bootstrap column classes for content area
 *
 * @since  1.0
 *
 * @return array Array of classes
 */
function cloudhost_get_content_columns( $layout = null ) {
	$layout = $layout ? $layout : cloudhost_get_layout();
	if ( 'full-content' == $layout ) {
		return array( 'col-md-12' );
	}

	return array( 'col-md-9', 'col-sm-12', 'col-xs-12' );
}

/**
 * Echos Bootstrap column classes for content area
 *
 * @since 1.0
 */
function cloudhost_content_columns( $layout = null ) {
	echo implode( ' ', cloudhost_get_content_columns( $layout ) );
}
