<?php
/**
 * Hooks for template archive
 *
 * @package CloudHost
 */


/**
 * Sets the authordata global when viewing an author archive.
 *
 * This provides backwards compatibility with
 * http://core.trac.wordpress.org/changeset/25574
 *
 * It removes the need to call the_post() and rewind_posts() in an author
 * template to print information about the author.
 *
 * @since 1.0
 * @global WP_Query $wp_query WordPress Query object.
 * @return void
 */
function cloudhost_setup_author() {
	global $wp_query;

	if ( $wp_query->is_author() && isset( $wp_query->post ) ) {
		$GLOBALS['authordata'] = get_userdata( $wp_query->post->post_author );
	}
}
add_action( 'wp', 'cloudhost_setup_author' );


/**
 * Change more string at the end of the excerpt
 *
 * @since  1.0
 *
 * @param string $more
 *
 * @return string
 */
function cloudhost_excerpt_more( $more ) {
	$more = '&hellip;';

	return $more;
}

add_filter( 'excerpt_more', 'cloudhost_excerpt_more' );

/**
 * Change length of the excerpt
 *
 * @since  1.0
 *
 * @param string $length
 *
 * @return string
 */
function cloudhost_excerpt_length( $length ) {
	$excerpt_length = intval( cloudhost_theme_option( 'excerpt_length' ) );
	if ( $excerpt_length > 0 ) {
		return $excerpt_length;
	}

	return $length;
}

add_filter( 'excerpt_length', 'cloudhost_excerpt_length' );

/**
 * The archive title
 *
 * @since  1.0
 *
 * @param  array $title
 *
 * @return mixed
 */
function cloudhost_the_archive_title( $title ) {
	if ( is_search() ) {
		$title = sprintf( esc_html__( 'Search Results', 'cloudhost' ) );
	} elseif ( is_404() ) {
		$title = sprintf( esc_html__( 'Page Not Found', 'cloudhost' ) );
	} elseif ( is_page() ) {
		$title = get_the_title();
	}  elseif ( is_home() && is_front_page() ) {
		$title = esc_html__( 'The Latest Posts', 'cloudhost' );
	} elseif ( is_home() && ! is_front_page() ) {
		$title = get_the_title( get_option( 'page_for_posts' ) );
	}  elseif( is_single() ) {
		$title = esc_html__( 'Single Blog', 'cloudhost' );
	} elseif ( is_tax() ) {
		$title = single_term_title( '', false ) ;
	}

	return $title;
}

add_filter( 'get_the_archive_title', 'cloudhost_the_archive_title' );



/**
 * Custom fields comment form
 *
 * @since  1.0
 *
 * @return  array  $fields
 */
function comment_form_cloudhost_fields() {
	global $commenter, $aria_req;

	$fields =  array(
		'author'=>	'<p class="comment-form-author col-md-4 col-sm-12">' .
			'<input id ="author" placeholder="' . esc_html__( 'Full name', 'cloudhost' ) . ' " name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) .
			'" size    ="30"' . $aria_req . ' /></p>',

		'email' =>	'<p class="comment-form-email col-md-4 col-sm-12">' .
			'<input id ="email" placeholder="' . esc_html__( 'Email', 'cloudhost' ) . '" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
			'" size    ="30"' . $aria_req . ' /></p>',

		'url'   =>	'<p class="comment-form-url col-md-4 col-sm-12">' .
			'<input id ="url" placeholder="' . esc_html__( 'Subject', 'cloudhost' ) . '" name="url" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) .
			'" size    ="30" /></p>'
	);
	return $fields;
}
add_filter( 'comment_form_default_fields', 'comment_form_cloudhost_fields' );
