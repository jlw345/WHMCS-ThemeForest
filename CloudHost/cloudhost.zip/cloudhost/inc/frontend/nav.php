<?php
/**
 * Hooks for template nav menus
 *
 * @package CloudHost
 */

/**
 * Get our wp_nav_menu() fallback, wp_page_menu(), to show a home link.
 *
 * @since 1.0
 * @param array $args Configuration arguments.
 * @return array
 */
function cloudhost_page_menu_args( $args ) {
	$args['show_home'] = true;
	return $args;
}
add_filter( 'wp_page_menu_args', 'cloudhost_page_menu_args' );

/**
 * Add extra items to the end of primary menu
 *
 * @since  1.0.0
 *
 * @param  string $items Items list
 * @param  object $args  Menu options
 *
 * @return string
 */
function cloudhost_nav_menu_extra_items( $items, $args ) {
	if ( 'primary' != $args->theme_location ) {
		return $items;
	}

	$extras = cloudhost_theme_option( 'menu_extra' );
	if ( ! $extras ) {
		return $items;
	}

	foreach ( $extras as $item ) {
		switch ($item) {
			case 'search':
				$items .= sprintf(
					'<li class="extra-menu-item menu-item-search">
					<a href="#" class="item-search">
						<i class="fa fa-search"></i>
					</a>
					<form class="search-form" method="get" action="%s">
						<input type="text" placeholder="%s" name="s" class="search-field">
						<input type="submit" class="btn-submit">
					</form>
				</li>',
					esc_url(home_url('/')),
					esc_attr__('Enter your search term...', 'cloudhost')
				);

				break;
		}
	}

	return $items;
}

add_filter( 'wp_nav_menu_items', 'cloudhost_nav_menu_extra_items', 10, 2 );