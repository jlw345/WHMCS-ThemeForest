<?php
/**
 * Hooks for template header
 *
 * @package CloudHost
 */

/**
 * Enqueue scripts and styles.
 *
 * @since 1.0
 */
function cloudhost_enqueue_scripts() {
	/**
	 * Register and enqueue styles
	 */

	wp_deregister_style( 'font-awesome' ); // Dont use font awesome from Visual Composer. It is older version.
	wp_enqueue_style( 'cloudhost-font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css', array(), '4.3.0' );
	wp_enqueue_style( 'cloudhost-font-icomoon', get_template_directory_uri() . '/css/icomoon.css', array(), '20160629' );
	wp_enqueue_style( 'cloudhost-bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css', array(), '3.3.2' );
	wp_enqueue_style( 'cloudhost-fonts', cloudhost_fonts_url(), array(), '20160629' );
	wp_enqueue_style( 'cloudhost', get_stylesheet_uri(), array( 'cloudhost-fonts', 'cloudhost-bootstrap', 'cloudhost-font-awesome', 'cloudhost-font-icomoon' ), '20160629' );

	wp_add_inline_style( 'cloudhost', cloudhost_header_styles() );

	// Load custom color scheme file
	if ( intval( cloudhost_theme_option( 'custom_color_scheme' ) ) && cloudhost_theme_option( 'custom_color_1' ) ) {
		$upload_dir = wp_upload_dir();
		$dir        = path_join( $upload_dir['baseurl'], 'custom-css' );
		$file       = $dir . '/color-scheme.css';
		wp_enqueue_style( 'cloudhost-color-scheme', $file, '20160525' );
	}


	/**
	 * Register and enqueue scripts
	 */
	$min = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	wp_enqueue_script( 'html5shiv', get_template_directory_uri() . '/js/html5shiv.min.js', array(), '3.7.2' );
	wp_script_add_data( 'html5shiv', 'conditional', 'lt IE 9' );
	wp_enqueue_script( 'respond', get_template_directory_uri() . '/js/respond.min.js', array(), '1.4.2' );
	wp_script_add_data( 'respond', 'conditional', 'lt IE 9' );

	wp_enqueue_script( 'cloudhost-plugins', get_template_directory_uri() . "/js/plugins$min.js", array( 'jquery' ), '20160629', true );
	wp_enqueue_script( 'cloudhost', get_template_directory_uri() . "/js/scripts$min.js", array( 'cloudhost-plugins' ), '20160629', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}

add_action( 'wp_enqueue_scripts', 'cloudhost_enqueue_scripts' );


/**
 * Custom scripts and styles on header
 *
 * @since  1.0.0
 */
function cloudhost_header_styles() {
	/**
	 * All Custom CSS rules
	 */
	$inline_css = '';

	// Logo
	$logo_size_width = intval( cloudhost_theme_option( 'logo_size_width' ) );
	$logo_css        = $logo_size_width ? 'width:' . $logo_size_width . 'px; ' : '';

	$logo_size_height = intval( cloudhost_theme_option( 'logo_size_height' ) );
	$logo_css .= $logo_size_height ? 'height:' . $logo_size_height . 'px; ' : '';

	$logo_margin_top = intval( cloudhost_theme_option( 'logo_margin_top' ) );
	$logo_css .= $logo_margin_top ? 'margin-top:' . $logo_margin_top . 'px;' : '';

	$logo_margin_right = intval( cloudhost_theme_option( 'logo_margin_right' ) );
	$logo_css .= $logo_margin_right ? 'margin-right:' . $logo_margin_right . 'px;' : '';

	$logo_margin_bottom = intval( cloudhost_theme_option( 'logo_margin_bottom' ) );
	$logo_css .= $logo_margin_bottom ? 'margin-bottom:' . $logo_margin_bottom . 'px;' : '';

	$logo_margin_left = intval( cloudhost_theme_option( 'logo_margin_left' ) );
	$logo_css .= $logo_margin_left ? 'margin-left:' . $logo_margin_bottom . 'px;' : '';

	if ( ! empty( $logo_css ) ) {
		$inline_css .= '.site-header .logo img ' . ' {' . $logo_css . '}';
	}

	if ( is_page_template( 'template-comming-soon.php' ) ) {
		$page_css   = '';
		$bg_comming = get_post_meta( get_the_ID(), 'bg_commingsoon', true );

		if ( $bg_comming ) {
			$bg_comming = wp_get_attachment_image_src( $bg_comming, 'full' );
			$page_css   = $bg_comming ? " body{ background-image: url($bg_comming[0]); }" : '';

		}
		$inline_css .= $page_css;
	} elseif ( is_page() ) {

		$page_css = '';
		if ( get_post_meta( get_the_ID(), 'hide_title_area', true ) ) {
			$page_css = '';
		} elseif ( $banner = get_post_meta( get_the_ID(), 'title_area_bg', true ) ) {
			if ( $banner ) {
				$banner   = wp_get_attachment_image_src( $banner, 'full' );
				$page_css = $banner ? ".site-banner { background-image: url($banner[0]); }" : '';
			}
		} else {
			$title_area = cloudhost_theme_option( 'title_area_pages' );
			if ( $title_area ) {
				$banner = cloudhost_theme_option( 'title_area_bg_pages' );
				if ( $banner ) {
					$page_css = ".site-banner { background-image: url($banner); }";
				}
			}
		}

		$inline_css .= $page_css;

	} elseif ( is_404() ) {
		$bg_404 = cloudhost_theme_option( 'bg_404' );
		if ( $bg_404 ) {
			$inline_css .= " .error404 .site-content { background-image: url($bg_404); } ";
		}

		$title_area = cloudhost_theme_option( 'title_area' );
		if ( $title_area ) {
			$banner = cloudhost_theme_option( 'title_area_bg' );
			if ( $banner ) {
				$inline_css .= ".site-banner { background-image: url($banner); }";
			}
		}
	} else {

		$post_id = get_the_ID();
		if ( ( is_home() && ! is_front_page() ) ) {
			$post_id = get_queried_object_id();
		}

		$page_css = '';
		if ( get_post_meta( $post_id, 'hide_title_area', true ) ) {
			$page_css = '';
		} elseif ( get_post_meta( $post_id, 'title_area_bg', true ) ) {
			$banner = get_post_meta( $post_id, 'title_area_bg', true );
			if ( $banner ) {
				$banner   = wp_get_attachment_image_src( $banner, 'full' );
				$page_css = $banner ? ".site-banner { background-image: url($banner[0]); }" : '';
			}
		} else {
			$title_area = cloudhost_theme_option( 'title_area' );
			if ( $title_area ) {
				$banner = cloudhost_theme_option( 'title_area_bg' );
				if ( $banner ) {
					$inline_css .= ".site-banner { background-image: url($banner); }";
				}
			}
		}

		$inline_css .= $page_css;
	}

	$bg_footer = cloudhost_theme_option( 'bg_footer' );
	if ( $bg_footer ) {
		$inline_css .= ".site-footer { background-image: url($bg_footer); }";
	}


	// Custom CSS from singular post/page
	$css_custom = get_post_meta( get_the_ID(), 'custom_css', true ) . cloudhost_theme_option( 'custom_css' );
	if ( ! empty( $css_custom ) ) {
		$inline_css .= $css_custom;
	}

	return $inline_css;

}

	/**
	 * Custom scripts and styles on header
	 *
	 * @since  1.0.0
	 */
	function cloudhost_header_scripts() {
		/**
		 * Custom header javascripts
		 */
		$custom_js = '';
		if ( $header_scripts = cloudhost_theme_option( 'header_scripts' ) ) {
			$custom_js .= $header_scripts;
		}

		// Output javascipt
		if ( ! empty( $custom_js ) ) {
			echo $custom_js;
		}

	}

	add_action( 'wp_head', 'cloudhost_header_scripts' );


	/**
	 * Show a title area
	 *
	 * @since 1.0.0
	 */
	function cloudhost_show_title_area() {

		$css_class = '';
		if ( is_page() ) {

			if ( is_page_template( 'template-homepage.php' ) ) {
				return;
			}

			if ( ! cloudhost_theme_option( 'title_area_pages' ) ) {
				return;
			} elseif ( get_post_meta( get_the_ID(), 'hide_title_area', true ) ) {
				return;
			} elseif ( ! get_post_meta( get_the_ID(), 'title_area_bg', true ) ) {
				$css_class = 'no-background';
			} else {
				if ( ! cloudhost_theme_option( 'title_area_bg_pages' ) ) {
					$css_class = 'no-background';
				}
			}
		} elseif ( is_single() ) {
			if ( get_post_meta( get_the_ID(), 'hide_title_area', true ) ) {
				return;
			} elseif ( ! get_post_meta( get_the_ID(), 'title_area_bg', true ) ) {
				$css_class = 'no-background';
			} else {
				if ( ! cloudhost_theme_option( 'title_area_bg' ) ) {
					$css_class = 'no-background';
				}
			}

		} elseif ( is_404() ) {
			$css_class = 'no-background';
		} else {
			if ( ! cloudhost_theme_option( 'title_area' ) ) {
				return;
			} elseif ( ! cloudhost_theme_option( 'title_area_bg' ) ) {
				$css_class = 'no-background';
			}
		}

		?>
		<div class="site-banner title-area text-center <?php echo esc_attr( $css_class ); ?>">
			<div class="container title-area-content">
				<?php echo the_archive_title( '<h1>', '</h1>' ); ?>
				<?php echo cloudhost_get_breadcrumbs(); ?>
			</div>
		</div>
		<?php
	}

	add_action( 'cloudhost_after_header', 'cloudhost_show_title_area' );


	/**
	 * Get breadcrumbs
	 *
	 * @since  1.0.0
	 *
	 *
	 *
	 *
	 * @return string
	 */
	function cloudhost_get_breadcrumbs() {
		if ( ! cloudhost_theme_option( 'breadcrumb' ) ) {
			return;
		}

		if ( is_page() && cloudhost_get_meta( 'hide_breadcrumb' ) ) {
			return;
		}

		$pages = cloudhost_theme_option( 'show_breadcrumb' );
		if ( empty( $pages ) ) {
			return;
		}

		if ( is_front_page() ) {
			return;
		} elseif ( is_home() && ! is_front_page() && ! in_array( 'blog', $pages ) ) {
			return;
		} elseif ( is_singular( 'post' ) && ! in_array( 'post', $pages ) ) {
			return;
		} elseif ( is_page() && ! in_array( 'page', $pages ) ) {
			return;
		}
		ob_start();
		?>
		<nav class="breadcrumbs">
			<?php
			cloudhost_breadcrumbs(
				array(
					'before' => '',
				)
			);
			?>
		</nav>
		<?php
		return ob_get_clean();
	}

	/**
	 * Display the site header
	 *
	 * @since 1.0.0
	 */
	function cloudhost_show_header() {
		$container = 'container';

		$header_layout = cloudhost_theme_option( 'header_layout' );

		if ( $header_layout == 'menu-right' ):

			?>
			<div class="<?php echo esc_attr( $container ); ?> header-container">
				<div class="navbar row">
					<div class="navbar-header col-xs-12 col-sm-12 col-md-3">
						<?php get_template_part( 'parts/logo' ); ?>
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
							<span class="fa fa-bars"></span>
						</button>
					</div>
					<!-- end navbar-header -->

					<nav id="site-navigation" class="primary-nav nav col-xs-12 col-md-9 col-sm-12">
						<div class="main-nav">
							<?php
							if ( has_nav_menu( 'primary' ) ) {
								wp_nav_menu(
									array(
										'theme_location' => 'primary',
										'container'      => false
									)
								);
							}
							?>
						</div>
					</nav>
				</div>
			</div>
			<?php
		else :
			?>

			<div class="navbar-logo">
				<div class="container">
					<div class="row">
						<div class="navbar-header col-xs-12 col-sm-12 col-md-6">
							<?php get_template_part( 'parts/logo' ); ?>
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="fa fa-bars"></span>
							</button>
						</div>
					</div>
				</div>
			</div>
			<div class="primary-nav">
				<div class="container">
					<div class="navbar">
						<div class="primary-logo">
							<?php get_template_part( 'parts/logo' ); ?>
						</div>
						<!-- end navbar-header -->
						<nav id="site-navigation" class="nav">
							<div class="main-nav">
								<?php
								if ( has_nav_menu( 'primary' ) ) {
									wp_nav_menu(
										array(
											'theme_location' => 'primary',
											'container'      => false
										)
									);
								}
								?>
							</div>
						</nav>
					</div>
				</div>
			</div>
			<?php
		endif;
	}

	add_action( 'cloudhost_header', 'cloudhost_show_header', 5 );

	/**
	 * Display topbar on top of site
	 *
	 * @since 1.0.0
	 */
	function cloudhost_show_topbar() {
		if ( ! cloudhost_theme_option( 'topbar' ) ) {
			return;
		}
		?>
		<div id="topbar" class="topbar">
			<div class="container">
				<div class="row">
					<div class="topbar-left topbar-widgets col-md-6 hidden-sm hidden-xs">
						<?php
						if ( is_active_sidebar( 'topbar-left' ) ) {
							dynamic_sidebar( 'topbar-left' );
						} ?>
					</div>

					<div class="topbar-right topbar-widgets col-xs-12 col-sm-12 col-md-6">
						<?php if ( is_active_sidebar( 'topbar-right' ) ) {
							dynamic_sidebar( 'topbar-right' );
						} ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	add_action( 'cloudhost_before_header', 'cloudhost_show_topbar', 5 );