<?php
/**
 * Hooks for displaying elements on footer
 *
 * @package CloudHost
 */

/**
 * Display footer widgets
 *
 * @since 1.0.0
 */
function cloudhost_footer_extra() {

	if( !cloudhost_theme_option( 'footer_extra' ) || is_page_template( 'template-comming-soon.php' ) ) {
		return;
	}


	?>
	<div id="footer-extra" class="footer-extra footer-area">
		<div class="container footer-container">
			<div class="row">
				<?php
				$footer_logo = cloudhost_theme_option( 'footer_logo' );
				if( $footer_logo ) {
					printf( '<div class="footer-logo"><img alt="logo" src="%s" /></div>',esc_url( $footer_logo ) );
				}
				echo '<div class="footer-info col-md-8 col-md-offset-2">';
				echo do_shortcode( wp_kses( cloudhost_theme_option( 'footer_info' ), wp_kses_allowed_html( 'post' ) ) );
				echo '</div>';
				?>
			</div>
		</div>
	</div>
	<?php
}

if( cloudhost_theme_option( 'footer_extra_possition' ) == 'above' ) {
	add_action( 'cloudhost_footer', 'cloudhost_footer_extra', 5 );
} else {
	add_action( 'cloudhost_footer', 'cloudhost_footer_extra', 15 );
}



/**
 * Display footer widgets
 *
 * @since 1.0.0
 */
function cloudhost_footer_widgets() {

	if( !cloudhost_theme_option( 'footer_widgets' ) || is_page_template( 'template-comming-soon.php' ) ) {
		return;
	}
	?>
	<div id="footer-widgets" class="footer-widgets widgets-area footer-area">
		<div class="container footer-container">
			<div class="row">
				<?php
				$columns = max( 1, absint( cloudhost_theme_option( 'footer_widget_columns' ) ) );
				for( $i = 1; $i <= $columns; $i++ ) :
					$col_class = 'col-xs-12 col-sm-6 col-md-' . floor( 12 / $columns );
					if( $columns == 5  ) {
						if( $i == 1 ) {
							$col_class = 'col-xs-12 col-sm-6 col-md-4';
						} else {
							$col_class = 'col-xs-12 col-sm-6 col-md-2';
						}
					}
					?>
					<div
						class="footer-sidebar footer-<?php echo esc_attr( $i ) ?> <?php echo esc_attr( $col_class ) ?>">
						<?php
						$sidebar = 'footer-sidebar-' . $i;
						if (is_active_sidebar( $sidebar )) {
						dynamic_sidebar( "footer-$i" );
						}?>
					</div>
				<?php endfor; ?>

			</div>
		</div>
	</div>
	<?php
}

add_action( 'cloudhost_footer', 'cloudhost_footer_widgets', 10 );


/**
 * Display cloudhost copyright after site footer
 *
 * @since 1.0.0
 */
function cloudhost_copyright() {
	?>
	<div id="footer-copyright" class="footer-copyright">
		<div class="container">
			<?php
			$socials = array_filter( (array) cloudhost_theme_option( 'footer_socials' ) );
			$copyright = do_shortcode( wp_kses( cloudhost_theme_option( 'footer_copyright' ), wp_kses_allowed_html( 'post' ) ) );
			$payment =  wp_kses( cloudhost_theme_option( 'footer_payment' ), wp_kses_allowed_html( 'post' ) );
			$css_class = 'col-xs-12 col-md-6 col-sm-6 column-2';
			if( $socials && $copyright && $payment ) {
				$css_class = 'col-xs-12 col-md-4 col-sm-6 column-3';
			}

			printf( '<div class="row">' );

			if( $payment ) {
				printf( '<div class="foot-payment ' . $css_class . '">' );
				echo $payment;
				printf( '</div>' );
			}

			if( $copyright ) {
				printf( '<div class="foot-copyright ' . $css_class . '">' );
				print $copyright;
				printf( '</div>' );
			}

			if( $socials ) {
				printf( '<div class="foot-socials ' . $css_class . '">' );
				foreach( $socials as $social => $url ) {
					if ( $social == 'google' ) {
						$social = 'google-plus';
					} elseif ( $social == 'vimeo' ) {
						$social = 'vimeo-square';
					} elseif ( $social == 'mail' ) {
						$social = 'envelope';
					}
					printf( '<a href="%s" target="_blank" class="social-%s"><i class="fa fa-%s"></i></a>', esc_url( $url ), esc_attr( $social ), esc_attr( $social ) );
				}
				printf( '</div>' );
			}
			printf( '</div>' );
			?>
		</div>
	</div>
	<?php
}

add_action( 'cloudhost_footer', 'cloudhost_copyright', 20 );

/**
 * Add modal to footer
 *
 * @since 1.0.0
 */
function cloudhost_modal() {
	?>
	<div id="modal-panel" class="modal-panel modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<div class="domain-name"></div>
					<button type="button"  class="close fd-close-modal" data-dismiss="modal">&#215;<span class="sr-only"></span></button>
				</div>
				<div class="modal-body">

				</div>
			</div>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'cloudhost_modal' );


/**
 * Add scripts to footer
 *
 * @since 1.0.0
 */
function cloudhost_footer_scripts() {
	$scripts = '';

	// Get custom js from theme options
	$scripts .= cloudhost_theme_option( 'footer_scripts' );


	echo $scripts;
}
add_action( 'wp_footer', 'cloudhost_footer_scripts' );