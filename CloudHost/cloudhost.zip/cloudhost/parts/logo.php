<?php
/**
 * The template part for displaying the main logo on header
 *
 * @package Foster
 */

$logo = cloudhost_theme_option( 'logo' );

if( ! $logo ) {
	$logo = get_template_directory_uri() . '/img/logo.png';

	if( intval(cloudhost_theme_option( 'header_transparent' ) ) && cloudhost_theme_option( 'header_layout' ) == 'menu-right' ) {
		$logo = get_template_directory_uri() . '/img/logo2.png';
	}
}

$logo2 = cloudhost_theme_option( 'logo2' );
if( ! $logo2 ) {
	$logo2 = get_template_directory_uri() . '/img/logo.png';
}

if( cloudhost_theme_option( 'header_sticky' ) ) {
	$logo2 = sprintf( '<img class="logo-sticky" alt="%s" src="%s" />', esc_attr( get_bloginfo( 'name' ) ), esc_url( $logo2 ) );
} else {
	$logo2 = '';
}

?>
<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo">
	<img alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" src="<?php echo esc_url( $logo ); ?>" />
	<?php echo $logo2; ?>
</a>

<?php
printf(
	'<%1$s class="site-title"><a href="%2$s" rel="home">%3$s</a></%1$s>',
	is_home() || is_front_page() ? 'h1' : 'p',
	esc_url( home_url( '/' ) ),
	get_bloginfo( 'name' )
);
?>
<h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
