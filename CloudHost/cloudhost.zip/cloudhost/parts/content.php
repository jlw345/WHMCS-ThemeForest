<?php
/**
 * The template used for displaying entry content on archive pages
 *
 * @package CloudHost
 */

$checkthumb = cloudhost_entry_thumbnail();
$css_class = 'col-md-12 col-sm-12';
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('blog-wapper'); ?>>
	<div class="row">
		<?php if( !empty($checkthumb)) :
			$css_class = 'col-md-6 col-sm-6';
			?>

			<div class="col-md-6 col-sm-6 blog-left">
				<header class="entry-header">
					<?php echo cloudhost_entry_thumbnail(); ?>
				</header><!-- .entry-header -->
			</div>
		<?php endif; ?>
		<div class="<?php echo esc_attr( $css_class ); ?>">
			<div class="entry-content">
				<?php
				the_title( sprintf( '<h1 class="entry-title"><a href="%s" class="post-title" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' );
				?>
				<?php
				echo cloudhost_posted_on();
				?>
				<div class="entry-desc">
					<?php the_excerpt(); ?>
				</div>

				<a class="btn-link readmore" href="<?php the_permalink() ?>"><?php esc_html_e( 'Read more', 'cloudhost' ) ?></a>

			</div><!-- End entry-content -->
		</div>
	</div>

</article>
