<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package CloudHost
 */

if ( 'full-content' == cloudhost_get_layout() ) {
	return;
}

$sidebar = 'blog-sidebar';

if ( is_page() ) {
	$sidebar = 'page-sidebar';
}
?>

<div id="secondary" class="widget-area col-xs-12 col-sm-12 col-md-3" role="complementary">
	<?php
	if (is_active_sidebar($sidebar)) {
		dynamic_sidebar($sidebar);
	}?>
</div><!-- #secondary -->
