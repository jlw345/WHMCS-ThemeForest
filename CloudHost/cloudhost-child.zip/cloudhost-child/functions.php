<?php
add_action( 'wp_enqueue_scripts', 'cloudhost_child_enqueue_scripts', 20 );

function cloudhost_child_enqueue_scripts() {
    wp_dequeue_style( 'cloudhost' );
    wp_enqueue_style( 'cloudhost-style', get_template_directory_uri() . '/style.css', array( 'cloudhost-fonts', 'cloudhost-bootstrap', 'cloudhost-font-awesome', 'cloudhost-font-icomoon') );
    wp_enqueue_style( 'cloudhost-child-style', get_stylesheet_uri() );
}
