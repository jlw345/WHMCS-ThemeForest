<?php
/**
 * Include and setup custom metaboxes and fields.
 *
 * @category YourThemeOrPlugin
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress
 */

add_filter( 'cmb_meta_boxes', 'cmb_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */
$textdomain = "cloudy7";
function cmb_sample_metaboxes( array $meta_boxes ) {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_cmb_';
	
  
   
    // Add other metaboxes as needed
    
    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('post'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
             array(
                'name' => 'Select',
                'desc' => 'Select type show rating',
                'id'   => $prefix . 'post_select',
                'type'    => 'select',
                'options'   => array(
                    array( 'value' => 'one', 'name' => 'One Star' ),
                    array( 'value' => 'two', 'name' => 'Two Star' ),
                    array( 'value' => 'three', 'name' => 'Three Star' ),
                    array( 'value' => 'four', 'name' => 'Four Star' ),
                    array( 'value' => 'none', 'name' => 'Five Star'),
                    ),
            'placeholder'     => 'Select an Item',
                    ),
         
            array(
                'name' => 'Link share facebook',
                'desc' => 'Input Link share facebook',
                'id'   => $prefix . 'single_facebook',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link share twitter',
                'desc' => 'Input Link share twitter',
                'id'   => $prefix . 'single_twitter',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link share linkedin',
                'desc' => 'Input Link share linkedin',
                'id'   => $prefix . 'single_linkedin',
                'type'    => 'text',
            ),
          
        )
    );

$meta_boxes[] = array(
        'id'         => 'vps_setting',
        'title'      => 'Vps Setting',
        'pages'      => array('Vps'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
             array(
                'name' => 'Text Badge',
                'desc' => 'Input text badge',
                'id'   => $prefix . 'text_badge',
                'type'    => 'text',
            ),
             array(
                'name' => 'Image',
                'desc' => 'Input Image ',
                'id'   => $prefix . 'vps_image',
                'type'    => 'file',
            ),
             array(
                'name' => 'Title',
                'desc' => 'Input title',
                'id'   => $prefix . 'vps_title',
                'type'    => 'text',
            ),
             array(
                'name' => 'Text Small',
                'desc' => 'Input small text',
                'id'   => $prefix . 'text_small',
                'type'    => 'text',
            ),
             array(
                'name' => 'Currency',
                'desc' => 'Input currency',
                'id'   => $prefix . 'vps_currency',
                'type'    => 'text',
            ),
             array(
                'name' => 'Price',
                'desc' => 'Input price',
                'id'   => $prefix . 'vps_price',
                'type'    => 'text',
            ),
             array(
                'name' => 'Period',
                'desc' => 'Input period',
                'id'   => $prefix . 'vps_period',
                'type'    => 'text',
            ),

             array(
                'name' => 'Info 1',
                'desc' => 'Input info 1',
                'id'   => $prefix . 'vps_info1',
                'type'    => 'text',
            ),
             array(
                'name' => 'Info 2',
                'desc' => 'Input info 2',
                'id'   => $prefix . 'vps_info2',
                'type'    => 'text',
            ),
             array(
                'name' => 'Info 3',
                'desc' => 'Input info 3',
                'id'   => $prefix . 'vps_info3',
                'type'    => 'text',
            ),
             array(
                'name' => 'Info 4',
                'desc' => 'Input info 4',
                'id'   => $prefix . 'vps_info4',
                'type'    => 'text',
            ),
             array(
                'name' => 'Info 5',
                'desc' => 'Input info 5',
                'id'   => $prefix . 'vps_info5',
                'type'    => 'text',
            ),
             array(
                'name' => 'Link',
                'desc' => 'Input link',
                'id'   => $prefix . 'vps_link',
                'type'    => 'text',
            ),
             array(
                'name' => 'Text Button',
                'desc' => 'Input text button',
                'id'   => $prefix . 'text_btn',
                'type'    => 'text',
            ),
          
        )
    );


$meta_boxes[] = array(
        'id'         => 'product_setting',
        'title'      => 'Product Setting',
        'pages'      => array('Product'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
             array(
                'name' => 'Title of page',
                'desc' => 'Input title of page shop details',
                'id'   => $prefix . 'shop_details_title',
                'type'    => 'text',
            ),
            array(
                'name' => 'Item active',
                'desc' => 'Input the item of this page',
                'id'   => $prefix . 'item_shop_active',
                'type'    => 'text',
            ),
          
        )
    );

$meta_boxes[] = array(
        'id'         => 'domain_setting',
        'title'      => 'Domain Setting',
        'pages'      => array('Domain'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Select',
                'desc' => 'Select type wrapper',
                'id'   => $prefix . 'select',
                'type'    => 'select',
                'options'   => array(
                    array( 'value' => '1', 'name' => 'Normal Package' ),
                    array( 'value' => '2', 'name' => 'Promotional Package( green badge)' ),
                    array( 'value' => '3', 'name' => 'Grey badge'),
                    ),
            'placeholder'     => 'Select an Item',
                    ),
             array(
                'name' => 'Text Badge',
                'desc' => 'Input text badge',
                'id'   => $prefix . 'text_badge',
                'type'    => 'text',
            ),
             array(
                'name' => 'Title',
                'desc' => 'Input title',
                'id'   => $prefix . 'title',
                'type'    => 'text',
            ),
             array(
                'name' => 'Text Small',
                'desc' => 'Input small text',
                'id'   => $prefix . 'text_small',
                'type'    => 'text',
            ),
             array(
                'name' => 'Currency',
                'desc' => 'Input currency',
                'id'   => $prefix . 'currency',
                'type'    => 'text',
            ),
             array(
                'name' => 'Price',
                'desc' => 'Input price',
                'id'   => $prefix . 'price',
                'type'    => 'text',
            ),
             array(
                'name' => 'Period',
                'desc' => 'Input period',
                'id'   => $prefix . 'period',
                'type'    => 'text',
            ),
             array(
                'name' => 'Promotional Text',
                'desc' => 'Promotional Text',
                'id'   => $prefix . 'text_promo',
                'type'    => 'text',
            ),
             array(
                'name' => 'Promotional Currency',
                'desc' => 'Input currency',
                'id'   => $prefix . 'currency2',
                'type'    => 'text',
            ),
             array(
                'name' => 'Promotional Price',
                'desc' => 'Promotional Price',
                'id'   => $prefix . 'price_promotion',
                'type'    => 'text',
            ),
             array(
                'name' => 'Promotional Period',
                'desc' => 'Input period',
                'id'   => $prefix . 'period2',
                'type'    => 'text',
            ),
             array(
                'name' => 'Link',
                'desc' => 'Input link',
                'id'   => $prefix . 'link',
                'type'    => 'text',
            ),
             array(
                'name' => 'Text Button',
                'desc' => 'Input text button',
                'id'   => $prefix . 'text_btn',
                'type'    => 'text',
            ),
          
        )
    );


	return $meta_boxes;
}

add_action( 'init', 'cmb_initialize_cmb_meta_boxes', 9999 );
/**
 * Initialize the metabox class.
 */
function cmb_initialize_cmb_meta_boxes() {

	if ( ! class_exists( 'cmb_Meta_Box' ) )
		require_once 'init.php';

} 