<?php
// register post type Vps
add_action( 'init', 'register_cloudy7_Vps' );
function register_cloudy7_Vps() {
    
    $labels = array( 
        'name' => __( 'Vps', 'cloudy7' ),
        'singular_name' => __( 'Vps', 'cloudy7' ),
        'add_new' => __( 'Add New Vps', 'cloudy7' ),
        'add_new_item' => __( 'Add New Vps', 'cloudy7' ),
        'edit_item' => __( 'Edit Vps', 'cloudy7' ),
        'new_item' => __( 'New Vps', 'cloudy7' ),
        'view_item' => __( 'View Vps', 'cloudy7' ),
        'search_items' => __( 'Search Vps', 'cloudy7' ),
        'not_found' => __( 'No Vps found', 'cloudy7' ),
        'not_found_in_trash' => __( 'No Vps found in Trash', 'cloudy7' ),
        'parent_item_colon' => __( 'Parent Vps:', 'cloudy7' ),
        'menu_name' => __( 'Vps', 'cloudy7' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Vps',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Vps', 'type' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Vps', $args );
}
add_action( 'init', 'create_Type_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Type_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Type', 'cloudy7' ),
    'singular_name' => __( 'Type', 'cloudy7' ),
    'search_items' =>  __( 'Search Type','cloudy7' ),
    'all_items' => __( 'All Type','cloudy7' ),
    'parent_item' => __( 'Parent Type','cloudy7' ),
    'parent_item_colon' => __( 'Parent Type:','cloudy7' ),
    'edit_item' => __( 'Edit Type','cloudy7' ), 
    'update_item' => __( 'Update Type','cloudy7' ),
    'add_new_item' => __( 'Add New Type','cloudy7' ),
    'new_item_name' => __( 'New Type Name','cloudy7' ),
    'menu_name' => __( 'Type','cloudy7' ),
  );     

// Now register the taxonomy

  register_taxonomy('type',array('Vps'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));

}

// register post type1 Domain
add_action( 'init', 'register_cloudy7_Domain' );
function register_cloudy7_Domain() {
    
    $labels = array( 
        'name' => __( 'Domain', 'cloudy7' ),
        'singular_name' => __( 'Domain', 'cloudy7' ),
        'add_new' => __( 'Add New Domain', 'cloudy7' ),
        'add_new_item' => __( 'Add New Domain', 'cloudy7' ),
        'edit_item' => __( 'Edit Domain', 'cloudy7' ),
        'new_item' => __( 'New Domain', 'cloudy7' ),
        'view_item' => __( 'View Domain', 'cloudy7' ),
        'search_items' => __( 'Search Domain', 'cloudy7' ),
        'not_found' => __( 'No Domain found', 'cloudy7' ),
        'not_found_in_trash' => __( 'No Domain found in Trash', 'cloudy7' ),
        'parent_item_colon' => __( 'Parent Domain:', 'cloudy7' ),
        'menu_name' => __( 'Domain', 'cloudy7' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Domain',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Domain', 'type1' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Domain', $args );
}
add_action( 'init', 'create_type1_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_type1_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'type1', 'cloudy7' ),
    'singular_name' => __( 'type1', 'cloudy7' ),
    'search_items' =>  __( 'Search type1','cloudy7' ),
    'all_items' => __( 'All type1','cloudy7' ),
    'parent_item' => __( 'Parent type1','cloudy7' ),
    'parent_item_colon' => __( 'Parent type1:','cloudy7' ),
    'edit_item' => __( 'Edit type1','cloudy7' ), 
    'update_item' => __( 'Update type1','cloudy7' ),
    'add_new_item' => __( 'Add New type1','cloudy7' ),
    'new_item_name' => __( 'New type1 Name','cloudy7' ),
    'menu_name' => __( 'type1','cloudy7' ),
  );     

// Now register the taxonomy

  register_taxonomy('type1',array('Domain'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type1' ),
  ));

}

?>