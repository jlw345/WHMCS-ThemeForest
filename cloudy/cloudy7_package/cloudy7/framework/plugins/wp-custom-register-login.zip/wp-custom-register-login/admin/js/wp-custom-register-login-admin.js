(function($) {
    'use strict';
    
})(jQuery);
