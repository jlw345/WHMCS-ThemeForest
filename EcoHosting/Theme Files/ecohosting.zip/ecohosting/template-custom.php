<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 * Template Name: Custom Page
 *
 */
 
get_header();

$layouts = ecohost_meta_id('custom_page_layout');

if( $layouts ){
    foreach( $layouts as $layout ){

        switch( $layout ){
            case '1' : get_template_part('eco-parts/container');
                break;
            case '2' : get_template_part('eco-parts/fullwidth');
                break;
            default : 
            #.....
                break;
        }

    }
}

get_footer();
?>