<?php 
/**
 * @version    2
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

if( is_active_sidebar('ecohost-woo') )
 ?>       
<div class="col-md-4 blog-page-sidebar">
    <?php 
        dynamic_sidebar('ecohost-woo');
    ?>
</div>
<?php 
endif;
?>
