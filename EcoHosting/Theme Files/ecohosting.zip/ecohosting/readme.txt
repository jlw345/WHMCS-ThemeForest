=== EcoHosting ===
Contributors: ThemeLooks
Requires at least: WordPress 4.1
Tested : WordPress 4.6.1-trunk
Version: 1.9.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: two-columns, left-sidebar, right-sidebar, flexible-header, accessibility-ready, custom-background, custom-colors, custom-header, custom-menu, theme-options, editor-style, featured-images, microformats, post-formats, sticky-post, threaded-comments, translation-ready
Text Domain: ecohosting

== Description ==
EcoHosting is a Responsive Hosting and WHMCS WordPress Theme designed for All kinds of Hosting Business. Anyone can easily update/edit this wp theme to follow our Well Sorted Documentation.

* Mobile-first, Responsive Layout
* Custom Colors
* Custom Header
* Social Links
* Menu Description
* Post Formats
* WHMCS Support
* The GPL v2.0 or later license. :) Use it to make something cool.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in EcoHosting in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
5. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Copyright ==
gpu


http://themelooks.us/demo/ecohosting/wordpress/ecohosting/



