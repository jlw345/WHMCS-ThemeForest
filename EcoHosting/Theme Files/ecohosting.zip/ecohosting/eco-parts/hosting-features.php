<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

?>
<!-- Pricing Table Area Start -->
<div id="pricingTable" class="price-details">

<?php 
// 
$hostfeatures = ecohost_meta_id( 'hosting-feature-content');

if( $hostfeatures ):
foreach( $hostfeatures as $hostfeature ):
?>

    <div class="item">
        <div class="container">
            <?php 
            // Section Title
            if( isset( $hostfeature['_eco_hostfeature-title'] ) && $hostfeature['_eco_hostfeature-title'] ):
            ?>
            <div class="section-title">
                <h2><?php echo esc_html( $hostfeature['_eco_hostfeature-title'] ); ?></h2>
            </div>
            <?php 
            endif;
            ?>
            <div class="row reset-margin">
            <?php 
            if( isset( $hostfeature['_eco_hostfeature-one-head'] ) && $hostfeature['_eco_hostfeature-one-head'] ){
                
                $child = 'first-child';
            }else{
                $child = '';
            }
            ?>
                <div class="col-md-2 col-sm-6 pricing-table-item <?php echo esc_html( $child ); ?>">
                    <div class="pt-body">
                        <div class="pt-features">
                            <ul class="text-left">
                            <?php 
                            if( isset( $hostfeature['_eco_hostfeature-leftHeading'] ) && $hostfeature['_eco_hostfeature-leftHeading'] ){
                             
                                foreach( $hostfeature['_eco_hostfeature-leftHeading'] as $lheading ){
                                    echo '<li data-toggle="tooltip" title="'.esc_html( $lheading ).'">'.esc_html( $lheading ).'</li>';
                                }
                            }
                            ?>
                                
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-10">
                    <div class="row">
                    
                        <div class="col-md-3 col-sm-6 pricing-table-item">
                        <?php 
                        if( isset( $hostfeature['_eco_hostfeature-one-head'] ) && $hostfeature['_eco_hostfeature-one-head'] ){
                         
                            echo '<div class="pt-head">';
                                echo '<div class="pt-plan">'.esc_html( $hostfeature['_eco_hostfeature-one-head'] ).'</div>';
                            echo '</div>';
                        }
                        ?>

                            <div class="pt-body">
                                <div class="pt-features">
                                    <ul>
                                    <?php 
                                    if( isset( $hostfeature['_eco_hostfeature-one'] ) && $hostfeature['_eco_hostfeature-one'] ){
                                        foreach( $hostfeature['_eco_hostfeature-one'] as $feaone ){
                                            
                                            $check = strstr( $feaone, 'fa-');
                                           
                                            if( $check ){
                                                echo '<li><i class="fa '. esc_html( $feaone ) .'"></i></li>';
                                            }else{
                                                echo '<li>'. esc_html( $feaone ) .'</li>';   
                                            }
                                  
                                        }
                                        
                                    }
                                    ?>  
                                    </ul>
                                </div>
                            </div>
                            <?php 
                            if( !empty( $hostfeature['_eco_hostfeature-one-btntext'] ) && !empty( $hostfeature['_eco_hostfeature-one-btnurl'] ) ){
                                echo '<div class="pt-footer">';
                                    echo '<a href="'.esc_url( $hostfeature['_eco_hostfeature-one-btnurl'] ).'" class="btn btn-custom-reverse">'.esc_html( $hostfeature['_eco_hostfeature-one-btntext'] ).'</a>';
                                echo '</div>';
                            }
                            ?>
                        </div>
                        
                        <div class="col-md-3 col-sm-6 pricing-table-item">
                        <?php 
                        if( isset( $hostfeature['_eco_hostfeature-two-head'] ) && $hostfeature['_eco_hostfeature-two-head'] ){
                         
                            echo '<div class="pt-head">';
                                echo '<div class="pt-plan">'.esc_html( $hostfeature['_eco_hostfeature-two-head'] ).'</div>';
                            echo '</div>';
                        }
                        ?>
                            <div class="pt-body">
                                <div class="pt-features">
                                    <ul>
                                    <?php 
                                    if( isset( $hostfeature['_eco_hostfeature-two'] ) && $hostfeature['_eco_hostfeature-two'] ){
                                        foreach( $hostfeature['_eco_hostfeature-two'] as $featwo ){
                                            
                                            $check = strstr( $featwo, 'fa-');
                                           
                                            if( $check ){
                                                echo '<li><i class="fa '. esc_html( $featwo ) .'"></i></li>';
                                            }else{
                                                echo '<li>'. esc_html( $featwo ) .'</li>';   
                                            }
                                               
                                        }
                                        
                                    }
                                    ?> 
                                    </ul>
                                </div>
                            </div>
                            <?php 
                            if( !empty( $hostfeature['_eco_hostfeature-two-btntext'] ) && !empty( $hostfeature['_eco_hostfeature-two-bnturl'] ) ){
                                echo '<div class="pt-footer">';
                                    echo '<a href="'.esc_url( $hostfeature['_eco_hostfeature-two-bnturl'] ).'" class="btn btn-custom-reverse">'.esc_html( $hostfeature['_eco_hostfeature-two-btntext'] ).'</a>';
                                echo '</div>';
                            }
                            ?>
                        </div>
                        <div class="col-md-3 col-sm-6 pricing-table-item">
                        <?php 
                        if( isset( $hostfeature['_eco_hostfeature-three-head'] ) && $hostfeature['_eco_hostfeature-three-head'] ){
                         
                            echo '<div class="pt-head">';
                                echo '<div class="pt-plan">'.esc_html( $hostfeature['_eco_hostfeature-three-head'] ).'</div>';
                            echo '</div>';
                        }
                        ?>
                            <div class="pt-body">
                                <div class="pt-features">
                                    <ul>
                                    <?php 
                                    if( isset( $hostfeature['_eco_hostfeature-three'] ) && $hostfeature['_eco_hostfeature-three'] ){
                                        foreach( $hostfeature['_eco_hostfeature-three'] as $feathree ){
                                            
                                            $check = strstr( $feathree, 'fa-');
                                           
                                            if( $check ){
                                                echo '<li><i class="fa '. esc_html( $feathree ) .'"></i></li>';
                                            }else{
                                                echo '<li>'. esc_html( $feathree ) .'</li>';   
                                            }
                                            
                                               
                                        }
                                        
                                    }
                                    ?> 
                                    </ul>
                                </div>
                            </div>
                            <?php 
                            if( !empty( $hostfeature['_eco_hostfeature-three-btntext'] ) && !empty( $hostfeature['_eco_hostfeature-three-btnurl'] ) ){
                                echo '<div class="pt-footer">';
                                    echo '<a href="'.esc_url( $hostfeature['_eco_hostfeature-three-btnurl'] ).'" class="btn btn-custom-reverse">'.esc_html( $hostfeature['_eco_hostfeature-three-btntext'] ).'</a>';
                                echo '</div>';
                            }
                            ?>
                        </div>
                        <div class="col-md-3 col-sm-6 pricing-table-item">
                        <?php 
                        if( isset( $hostfeature['_eco_hostfeature-four-head'] ) && $hostfeature['_eco_hostfeature-four-head'] ){
                         
                            echo '<div class="pt-head">';
                                echo '<div class="pt-plan">'.esc_html( $hostfeature['_eco_hostfeature-four-head'] ).'</div>';
                            echo '</div>';
                        }
                        ?>
                            <div class="pt-body">
                                <div class="pt-features">
                                    <ul>
                                    <?php 
                                    if( isset( $hostfeature['_eco_hostfeature-four'] ) && $hostfeature['_eco_hostfeature-four'] ){
                                        foreach( $hostfeature['_eco_hostfeature-four'] as $feafour ){
                                            
                                            $check = strstr( $feafour, 'fa-');
                                           
                                            if( $check ){
                                                echo '<li><i class="fa '. esc_html( $feafour ) .'"></i></li>';
                                            }else{
                                                echo '<li>'. esc_html( $feafour ) .'</li>';   
                                            }
                                              
                                        }
                                        
                                    }
                                    ?> 
                                    </ul>
                                </div>
                            </div>
                            <?php 
                            if( !empty( $hostfeature['_eco_hostfeature-four-btntext'] ) && !empty( $hostfeature['_eco_hostfeature-four-btnurl'] ) ){
                                echo '<div class="pt-footer">';
                                    echo '<a href="'.esc_url( $hostfeature['_eco_hostfeature-four-btnurl'] ).'" class="btn btn-custom-reverse">'.esc_html( $hostfeature['_eco_hostfeature-four-btntext'] ).'</a>';
                                echo '</div>';
                            }
                            ?>
                        </div>
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php 
endforeach;
endif;
?>
</div>
<!-- Pricing Table Area End -->