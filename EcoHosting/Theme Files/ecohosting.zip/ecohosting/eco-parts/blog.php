<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

?>
<!-- Blog Area Start -->
<div id="blog">
    <div class="container">
    
        <?php 
            // section title
            echo ecohost_section_heading('blog-title');
        ?>
        <div class="row">
            <?php 
            $postNumber = ecohost_opt('eco_front_blogPost_number');
            // Blog Item
            $args = array(
                'post_type' => 'post',
                'posts_per_page' => esc_html( $postNumber ),
            );
            
            $loop = new WP_Query( $args );
            
            if( $loop-> have_posts() ):
                while( $loop-> have_posts() ): $loop-> the_post();
                if( !is_sticky() ):
            ?>
            <div class="col-md-6">
                <div class="blog-item">
                    <div class="row">
                        <div class="col-md-6">
                            <!-- Blog Item Image Start -->
                            <div class="blog-item-img">
                                <?php 
                                if( has_post_format('video') ){
                                    echo ecohost_embedded_media( array( 'video', 'iframe' ) );
                                    
                                }elseif( has_post_format('audio') ){
                                    echo ecohost_embedded_media( array( 'audio', 'iframe' ) );
                                    
                                }else{
                                    echo '<a href="'.esc_url( get_the_permalink() ).'">';
                                        the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) );
                                    echo '</a>';  
                                }
                                ?>

                            </div>
                            <!-- Blog Item Image End -->
                        </div>
                        <div class="col-md-6">
                            <!-- Blog Item Content Start -->
                            <div class="blog-item-content">
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                <div class="metadata">
                                    <i class="fa fa-calendar"></i><a href="<?php echo esc_url( ecohost_blog_date_permalink() ); ?>"><?php echo get_the_date('d/m/y'); ?></a>
                                    <span class="divider"> <?php esc_html_e( '|', 'ecohosting' ); ?> </span>
                                    <i class="fa fa-user"></i><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php echo esc_html( get_the_author() ); ?></a>
                                </div>
                                <?php echo ecohost_excerpt_length( ecohost_opt('eco_front_blogPost_excerpt') ); ?> 
                                
                            </div>
                            <div class="post-read-more-btn">
                                <a href="<?php the_permalink(); ?>" class="btn btn-custom-reverse"><?php esc_html_e( 'Read More', 'ecohosting' ); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php 
                endif;
                endwhile;
                wp_reset_postdata();
            endif;
            ?>
            
        </div>
    </div>
</div>
<!-- Blog Area End -->