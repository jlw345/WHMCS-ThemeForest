<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

    // Overlay 
    if( ecohost_meta_id('faq_overlay') ){
        $overlay = ' class="bg--overlay"';
    }else{
        $overlay = '';
    }
 
?>
<!-- FAQ Area Start -->
<div id="faq" <?php echo ecohost_section_bg('faq_bgimg'). $overlay; ?>>
    <div class="container">
        <div class="row">
            <div class="col-md-5 hidden-sm hidden-xs">
            <?php 
            if( ecohost_meta_id('faq-image') ){
                echo '<img src="'.esc_url( ecohost_meta_id('faq-image') ).'" alt="'.esc_attr__( 'image', 'ecohosting' ).'" class="img-responsive">';
            }
            ?>
            </div>
            <div class="col-md-7">
                <?php 
                $title = ecohost_meta_id('faq-section-title');
                if( $title ){
                    echo '<div class="section-title text-left">';
                        echo '<h2>'.esc_html( $title ).'</h2>';
                    echo '</div>';   
                }
                ?>

                <!-- Section Title End -->
                <div class="faq-content">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane fade in active" id="sharedTab">
                            <div class="panel-group accordion" id="accordion1" role="tablist">
                                <!-- Accordion Item Start -->
                                <?php 
                                $term = ecohost_meta_id('faq-taxonoy');
                                $args = array(
                                    'post_type'      => 'faq',
                                    'posts_per_page' => 1,
                                    'tax_query' => array(
                                        array(
                                            'taxonomy' => 'faq-categories',
                                            'field'    => 'slug',
                                            'terms'    => esc_html( $term ),
                                        )
                                    )
                                );
                                $loop = new WP_Query( $args );
                                if( $loop->have_posts() ) :
                                
                                    while( $loop->have_posts() ): $loop->the_post();
                                    $faq_contents = ecohost_meta_id('faq-content');
                                    $i = 1;
                                    foreach( $faq_contents as $faq_content ):
                                ?>
                                    <div class="panel panel-default <?php echo ( $i == 1 ) ? 'active': '';?>">
                                        <div class="panel-heading" role="tab">
                                            <a href="#faqTabQ<?php echo esc_attr( $i ); ?>" role="button" data-toggle="collapse" data-parent="#accordion1" class="<?php echo ( $i == 1)? '' : 'collapsed'; ?>">
                                                <h4 class="panel-title"><?php echo esc_html( $faq_content['_eco_faq-title'] ); ?> <i class="fa fa-minus"></i></h4>
                                            </a>
                                        </div>
                                        <div id="faqTabQ<?php echo esc_attr( $i ); ?>" class="panel-collapse collapse <?php echo ( $i == 1)? 'in' : ''; ?>" role="tabpanel">
                                            <div class="panel-body link-color--child">
                                            <?php 
                                            if( isset( $faq_content['_eco_faq-desc'] ) ){
                                                echo '<p>'.ecohost_wp_kses_allow( $faq_content['_eco_faq-desc'] ).'</p>';
                                            }
                                            ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php 
                                    $i++;
                                    endforeach;
                                    endwhile;
                                     wp_reset_postdata();
                                endif;
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- FAQ Area End -->