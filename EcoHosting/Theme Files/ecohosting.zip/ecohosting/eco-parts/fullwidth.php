<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

if( have_posts() ):
while( have_posts()):the_post();


$ids = get_post_meta( $post->ID, '_eco_sections_ids', true );

$sections = json_decode( $ids );

if( $sections ){
    foreach( $sections as $section ){
        switch( $section ){
            
            case 'features' : get_template_part('eco-parts/features');
                break;
            case 'single-features' : get_template_part('eco-parts/features-single');
                break;
            case 'counter' : get_template_part('eco-parts/counter');
                break;
            case 'testimonial' : get_template_part('eco-parts/testimonial');
                break;
            case 'team' : get_template_part('eco-parts/team');
                break;
            case 'flat-content' : get_template_part('eco-parts/flatcontent');
                break;
            case 'flat-content-one' : get_template_part('eco-parts/flatcontent', 'one');
                break;
            case 'blog' : get_template_part('eco-parts/blog');
                break;
            case 'faq' : get_template_part('eco-parts/faq');
                break;
            case 'faq-tab' : get_template_part('eco-parts/faq-tab');
                break;
            case 'history' : get_template_part('eco-parts/history');
                break;
            case 'vps' : get_template_part('eco-parts/vpspricing-slide');
                break;
            case 'brand' : get_template_part('eco-parts/brands');
                break;
            case 'certificate' : get_template_part('eco-parts/certificate');
                break;
            case 'affiliate-features' : get_template_part('eco-parts/affiliate-features');
                break;
            case 'affiliate-counter' : get_template_part('eco-parts/affiliate-counter');
                break;
            case 'affiliate-pricing' : get_template_part('eco-parts/affiliate-pricing');
                break;
            case 'domainSearch' : get_template_part('eco-parts/domain-search');
                break;
            case 'domain-pricing' : get_template_part('eco-parts/domain-pricing');
                break;
            case 'dedicate-pricing' : get_template_part('eco-parts/dedicated-pricing');
                break;
            case 'hosting-feature' : get_template_part('eco-parts/hosting-features');
                break;
            case 'hosting-pricing' : get_template_part('eco-parts/hosting-priceingTable');
                break;
            case 'hosting-pricing-v2' : get_template_part('eco-parts/hosting-priceingTable-v2');
                break;
            case 'datacenter' : get_template_part('eco-parts/datacenter-location');
                break;
            default:
                #....
                break;
        }
    }
}

// If comments are open comment template.
if ( comments_open() || get_comments_number() ) {
    comments_template();
}
endwhile;
wp_reset_postdata();
else :
    get_template_part( 'template/content', 'none' );
endif;

