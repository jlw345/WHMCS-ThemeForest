<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
    // Overlay 
    if( ecohost_meta_id('history_overlay') ){
        $overlay = ' class="bg--overlay"';
    }else{
        $overlay = '';
    }
 

?>
<!-- History Area Start -->
<div id="history" <?php echo ecohost_section_bg('history_bgimg'). $overlay; ?>>
    <div class="container">
        <?php 
        // Section Title
        echo ecohost_section_heading('history-section-title');
        
        ?>
        <ul class="timeline">
        
            <?php 
                $histories = ecohost_meta_id('history-content');
                if( $histories ):
                $i = 1;
                foreach( $histories as $history ):
                if( $history ):
            ?>
                <li class="<?php echo ( $i%2 == 0 ) ? 'timeline-inverted' : ''; ?>">
                    <div class="timeline-badge">
                        <i class="fa fa-circle"></i>
                    </div>
                    <div class="timeline-panel">
                        <div class="timeline--date">
                            <p><?php echo esc_html( $history['_eco_history-year'] ); ?></p>
                        </div>
                        <div class="timeline-body link-color--child">
                            <p><?php echo ecohost_wp_kses_allow( $history['_eco_history-descriptions'] ); ?></p>
                        </div>
                    </div>
                </li>                
            <?php
                endif;
                $i++;
                endforeach;
                endif;
            ?>
        </ul>
    </div>
</div>