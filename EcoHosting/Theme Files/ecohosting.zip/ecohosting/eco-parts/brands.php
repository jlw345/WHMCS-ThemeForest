<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

    // Overlay 
    if( ecohost_meta_id('brand_overlay') ){
        $overlay = ' class="bg--overlay"';
    }else{
        $overlay = '';
    }
 
?>
<div id="brands" <?php echo ecohost_section_bg('brand_bgimg'). $overlay; ?>>
    <div class="container">
        <div class="row brands-slider reset-margin">
            <?php 
            $imgs = ecohost_meta_id('brand-image');
            if( is_array( $imgs ) ){
                foreach( $imgs as $img ){
                    if( $img ){
                        echo '<div class="col-md-12">';
                            echo '<img src="'.esc_url( $img ).'" alt="'.esc_attr__( 'Brand Image', 'ecohosting' ).'" class="img-responsive">';
                        echo '</div>';
                    }
                }
            }
            ?>
        </div>
    </div>
</div>