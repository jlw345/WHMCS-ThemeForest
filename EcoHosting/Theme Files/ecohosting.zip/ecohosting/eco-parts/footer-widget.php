<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

?>
<!-- Footer Area Start -->
    <?php 
    if( ecohost_opt( 'eco_footer_weiget_disabled' ) ):
    ?>
    <div id="footer">
        <div class="container">
            <div class="row">
                <?php 
              
                // footer widget one
                if( is_active_sidebar( 'footer-one' ) ){
                    dynamic_sidebar('footer-one');
                
                }
                
                // footer widget two
                if( is_active_sidebar( 'footer-two' ) ){
                    dynamic_sidebar('footer-two');
                }
                
                // footer widget two
                if( is_active_sidebar( 'footer-three' ) ){
                    dynamic_sidebar('footer-three');
                }                
                ?>
            </div>
        </div>
    </div>
    <?php 
    endif;
    ?>
<!-- Footer Area End -->
<?php 
if( ecohost_opt('eco_footer_top_disabled') ):
?>
    <div class="footer--contact-info">
        <div class="container">
            <div class="row">
                <?php 
                // Contact Info Item
                if( is_array( ecohost_opt('eco_footerTtop_contactInfo') ) ):
                    foreach( ecohost_opt('eco_footerTtop_contactInfo') as $contact ):
                ?>
                    <div class="col-md-3 col-xs-6">
                        <i class="fa <?php echo esc_html( $contact['icon'] ); ?>"></i>
                        <a href="<?php echo esc_url( $contact['url'] ); ?>"><?php echo esc_html( $contact['title'] ); ?></a>
                    </div>
                <?php 
                    endforeach;
                endif;
                ?>
            </div>
        </div>
    </div>
<?php 
endif;
?>
<!-- Copyright Area Start -->
<div id="copyright">
    <div class="container">
        <?php 
        // Copyright Text
        
        $allowhtml = array(
            'a' => array(
                'href' => array()
            ),
            'span' => array()
        );
        
        if( ecohost_opt('eco_copyright_text') ){
            echo '<p class="left">'.wp_kses( ecohost_opt('eco_copyright_text'), $allowhtml ).'</p>';
        }
        // We Accept
        if( ecohost_opt('eco_accpetPayment','url') ){
            
            echo '<p class="right">'.esc_html( 'We Accept:', 'ecohosting' ).' <img src="'.esc_url( ecohost_opt('eco_accpetPayment','url') ).'" alt="'.esc_attr__( 'payment accept image', 'ecohosting' ).'"></p>';
        }
        ?>        
    </div>
</div>
<!-- Copyright Area End -->