<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

    // Overlay 
    if( ecohost_meta_id('affiliate-counter_overlay') ){
        $overlay = ' bg--overlay';
    }else{
        $overlay = '';
    }
 
?>
<!-- Counter Area Start -->
<div id="aCounter" class="aCounter <?php echo esc_attr( $overlay ); ?>" <?php echo ecohost_section_bg('affiliate-counter-bg'); ?>>
    <div class="container">
        <div class="row">
        <?php 
        $counters = ecohost_meta_id('affiliate-counter-content');
        if( $counters ):
        foreach( $counters as $counter  ):
        if( $counter ):
        ?>
            <div class="col-md-3 col-sm-6">
                <div class="aCounter-holder">
                    <p class="aCounter-text"><?php echo esc_html( $counter['_eco_affiliate-counter-title'] ); ?></p>
                    <div class="aCounter-number-holder"><?php echo esc_html( $counter['_eco_affiliate-counter-currency'] ); ?><span class="counter-number"><?php echo esc_html( $counter['_eco_affiliate-counter-number'] ); ?></span></div>
                </div>
            </div>
        <?php 
        endif;
        endforeach;
        endif;
        ?>  
        </div>
    </div>
</div>
<!-- Counter Area End -->