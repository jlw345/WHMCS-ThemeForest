<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

    // Overlay 
    if( ecohost_meta_id('affiliate-pricing_overlay') ){
        $overlay = ' bg--overlay';
    }else{
        $overlay = '';
    }
 
?>
    <!-- Pricing Area Start -->
    <div id="pricing" class="apricing <?php echo esc_attr( $overlay ); ?>" <?php echo ecohost_section_bg('affiliate-pricing_bgimg'); ?>>
        <div class="container">
            <?php 
                // section title
                echo ecohost_section_heading('affiliate-pricing-title');
            ?>
            <div class="row">
            <?php 
            $pricing = ecohost_meta_id( 'affiliate-pricing-content' );
            if( is_array( $pricing ) ):
            foreach( $pricing as $price ):
            if( $price ):
            ?>
                <div class="col-md-3 col-sm-6">
                    <!-- Pricing Table Item Start -->
                    <div class="pricing-table-item">
                        <div class="pt-head">
                            <div class="caption"><?php echo esc_html( $price['_eco_affiliate-pricing-tag'] ); ?></div>
                            <div class="pt-price-tag"><?php echo esc_html( $price['_eco_affiliate-price'] ); ?></div>
                            <div class="pt-plan"><?php echo esc_html( $price['_eco_affiliate-pricing-plan'] ); ?></div>
                        </div>
                    </div>
                    <!-- Pricing Table Item End -->
                </div>
            <?php 
            endif;
            endforeach;
            endif;
            ?>
           </div>
            <?php 
            // button
            if( ecohost_meta_id('affiliate-pricing-btnText') && ecohost_meta_id('affiliate-pricing-btnUrl') ){
                
                echo '<div class="affiliate-signup-btn-holder">';
                    echo '<a href="'.esc_url( ecohost_meta_id('affiliate-pricing-btnUrl') ).'" class="btn btn-lg btn-custom-reverse">'.esc_html( ecohost_meta_id('affiliate-pricing-btnText') ).'</a>';
                echo '</div>';  
            }

            ?>

        </div>
    </div>
    <!-- Pricing Area End -->