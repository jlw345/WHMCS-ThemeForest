<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

?>

<div id="singleFeatures">
<?php 
$singFeatures = ecohost_meta_id('single-features');

$i = 1;
foreach( $singFeatures as $singFeature ):

    //
    if( isset( $singFeature['_eco_single-feature-bgcolor'] ) && $singFeature['_eco_single-feature-bgcolor'] ){
        
        $bgcolor = 'background-color:'.$singFeature['_eco_single-feature-bgcolor'].';';
    }else{
        $bgcolor = 'background-color:#f8f8f8;';
    }

    //
    if( isset( $singFeature['_eco_single-feature_textcolor'] ) && $singFeature['_eco_single-feature_textcolor'] ){
        
        $textcolor = 'color:'.$singFeature['_eco_single-feature_textcolor'].';';
    }else{
        $textcolor = 'color:#333333;';
    }
    //
    if( isset( $singFeature['_eco_single-feature_titlecolor'] ) && $singFeature['_eco_single-feature_titlecolor'] ){
        
        $titlecolor = 'color:'.$singFeature['_eco_single-feature_titlecolor'].';';
    }else{
        $titlecolor = 'color:#303030;';
    }
    //
    if( isset( $singFeature['_eco_single-feature_btncolor'] ) && $singFeature['_eco_single-feature_btncolor'] ){
        
        $btntextcolor = 'color:'.$singFeature['_eco_single-feature_btncolor'].';';
    }else{
        $btntextcolor = 'color:#fff;';
    }


// Ovearlay
if( isset( $singFeature['_eco_single-feature_overlay'] ) && $singFeature['_eco_single-feature_overlay'] ){
    $Ovearlay = ' bg--overlay';
}else{
   $Ovearlay = ''; 
}

?>
    <div class="single-feature<?php echo esc_attr( $Ovearlay ); ?>" <?php echo ecohost_single_feature_bg( $singFeature ); ?> style="<?php echo esc_attr( $textcolor.$bgcolor ); ?>">
        <div class="container">
            <div class="row">
                <?php 
                // left condisonal image
                if( !empty( $singFeature['_eco_single-featurebg-position'] ) && $singFeature['_eco_single-featurebg-position'] == 'left' ){
                    
                    if( !empty( $singFeature['_eco_single-feature-image'] ) ){
                        echo '<div class="col-md-5 single-feature--image">';
                            echo '<img src="'.esc_url( $singFeature['_eco_single-feature-image'] ).'" alt="'.esc_attr__( 'image', 'ecohosting' ).'" class="img-responsive">';
                        echo '</div>';   
                    }
                }
                
                // col-md-7
                
                echo '<div class="col-md-7 single-feature--content">';
                if( isset( $singFeature['_eco_single-feature-title'] ) && $singFeature['_eco_single-feature-title'] ){
                    echo '<h2 style="'.$titlecolor.'">'.esc_html( $singFeature['_eco_single-feature-title'] ).'</h2>';
                }
                
                if( isset( $singFeature['_eco_single-feature-descriptions'] ) && $singFeature['_eco_single-feature-descriptions'] ){
                    echo '<p>'.ecohost_wp_kses_allow( $singFeature['_eco_single-feature-descriptions']  ).'</p>';
                }
                if( isset( $singFeature['_eco_single-feature-btnText'] ) && isset( $singFeature['_eco_single-feature-btnUrl'] )  ){
                    if( $singFeature['_eco_single-feature-btnUrl'] && $singFeature['_eco_single-feature-btnText'] ){
                        echo '<a href="'.esc_url( $singFeature['_eco_single-feature-btnUrl'] ).'" class="btn btn-custom-reverse" style="'.$btntextcolor.'">'.esc_html( $singFeature['_eco_single-feature-btnText'] ).'</a>';
                    }
                }
                echo '</div>';
                
                //right condisonal image
                if( !empty( $singFeature['_eco_single-featurebg-position'] ) && $singFeature['_eco_single-featurebg-position'] == 'right' ){
                    if( !empty( $singFeature['_eco_single-feature-image'] ) ){
                        echo '<div class="col-md-5 single-feature--image">';
                            echo '<img src="'.esc_url( $singFeature['_eco_single-feature-image'] ).'" alt="'.esc_attr__( 'image', 'ecohosting' ).'" class="img-responsive">';
                        echo '</div>';   
                    }
                }
                
                ?>
            </div>
        </div>
    </div> 
<?php 
$i++;   
endforeach;
?>
</div> 