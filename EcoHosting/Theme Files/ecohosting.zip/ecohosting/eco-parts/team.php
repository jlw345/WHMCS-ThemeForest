<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

    // Overlay 
    if( ecohost_meta_id('team_overlay') ){
        $overlay = ' class="bg--overlay"';
    }else{
        $overlay = '';
    }
 
?>
<!-- Team Area Start -->
<div id="team" <?php echo ecohost_section_bg('team_bgimg'). $overlay; ?>>
    <div class="container">
        <?php 
        // Section Title
        echo ecohost_section_heading('team-section-title');
        
        ?>
        <div class="row">
        <?php 
        $members = ecohost_meta_id( 'team-content' );
        if( $members ):
        foreach( $members as $member ):
        ?>
            <div class="col-md-3 col-sm-6">
                <!-- Team Member Item Start -->
                <div class="team-item">
                    <div class="team-img">
                        <!-- Team Member Image Start -->
                        <?php 
                        if( isset( $member['_eco_team-member-image'] ) && $member['_eco_team-member-image'] ){
                            echo '<img src="'.esc_url( $member['_eco_team-member-image'] ).'" alt="'.esc_attr__( 'Team Member Picture', 'ecohosting' ).'" class="img-responsive">';
                        }
                        ?>
                        
                        <!-- Team Member Image End -->
                        <!-- Team Member Social Links Start -->
                        <div class="team-social-links">
                            <ul>
                            <?php 
                            // facebook
                            if( isset( $member['_eco_team-fb-url'] ) && $member['_eco_team-fb-url'] ){
                                echo '<li><a href="'.esc_url( $member['_eco_team-fb-url'] ).'"><i class="fa fa-facebook"></i></a></li>';
                            }
                            
                            // twitter 
                            if( isset( $member['_eco_team-tw-url'] ) && $member['_eco_team-tw-url'] ){
                                echo '<li><a href="'.esc_url( $member['_eco_team-tw-url'] ).'"><i class="fa fa-twitter"></i></a></li>';
                            }
                            // google-plus
                            if( isset( $member['_eco_team-gp-url'] ) && $member['_eco_team-gp-url'] ){
                                echo '<li><a href="'.esc_url( $member['_eco_team-gp-url'] ).'"><i class="fa fa-google-plus"></i></a></li>';
                            }
                            // linkedin 
                            if( isset( $member['_eco_team-link-url'] ) && $member['_eco_team-link-url'] ){
                                echo '<li><a href="'.esc_url( $member['_eco_team-link-url'] ).'"><i class="fa fa-linkedin"></i></a></li>';
                            }
                            ?>
                            </ul>
                        </div>
                        <!-- Team Member Social Links End -->
                    </div>
                    <!-- Team Member Info Start -->
                    <div class="team-info">
                        <?php
                        // member name                         
                        if( isset( $member['_eco_team-member-name'] ) && $member['_eco_team-member-name'] ){
                            echo '<h2>'.esc_html( $member['_eco_team-member-name'] ).'</h2>';  
                        }
                        // designation
                        if( isset( $member['_eco_team-member-designation'] ) && $member['_eco_team-member-designation'] ){
                            echo '<p>'.esc_html( $member['_eco_team-member-designation'] ).'</p>';
                        }
                        
                        ?>
                    </div>
                    <!-- Team Member Info End -->
                </div>
                <!-- Team Member Item End -->
            </div>
        <?php 
        endforeach;
        endif;
        ?>
       </div>
    </div>
</div>