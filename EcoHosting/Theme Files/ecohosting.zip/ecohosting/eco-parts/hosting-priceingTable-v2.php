<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
 
     // Overlay 
    if( ecohost_meta_id('hosting-pricingv2_overlay') ){
        $overlay = ' class="bg--overlay"';
    }else{
        $overlay = '';
    }
 

?>
<!-- Pricing Table Area Start -->
<div id="pricingTable" <?php echo ecohost_section_bg('hosting-pricingv2-bg').$overlay; ?>>
    <div class="container">
        <?php 
            // section title
            echo ecohost_section_heading('hosting-pricingv2-title');
            
            // label 
            $labels = ecohost_meta_id( 'hosting-pricingv2-label' );
            
            //Hosting pricing post query 
            $args = array(
                'post_type' => 'hosting-price',
                'posts_per_page' => 1,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'hosting-categories',
                        'field'    => 'slug',
                        'terms'    => ecohost_meta_id('hostingv2-cat')
                    )
                )
            );
            $loop = new WP_Query( $args );
            if( $loop->have_posts() ):
                while( $loop->have_posts() ) : $loop->the_post();
                $pricing = ecohost_meta_id( 'hosting-content' );
                
            
        ?>
        <div class="row reset-margin">
            <div class="col-md-2 col-sm-6 pricing-table-item first-child">
                <div class="pt-body">
                    <div class="pt-features">
                        <ul class="text-left">
                        <?php 
                        if( is_array( $labels ) ){
                            foreach( $labels as $label ){
                                if( $label ){
                                    echo '<li>'.esc_html( $label ).'</li>';
                                }
                                
                            }    
                        }

                        ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-10">
                <div class="row">
                
                <?php 
                    foreach( $pricing as $price ): 
                    
                    if( isset( $price['_eco_hosting-active'] ) && $price['_eco_hosting-active'] ){
                        $active = 'popular';
                    }else{
                       $active = ''; 
                    }
                    
                ?>
                <div class="col-md-3 col-sm-6 pricing-table-item <?php echo esc_html( $active ); ?>">
                    <!-- Pricing Table Item Start -->
                    <div class="pt-head">
                    <?php 
                    if( isset( $price['_eco_hosting-popular-indicat'] ) && $price['_eco_hosting-popular-indicat'] ){
                        echo '<div class="popular-indicator"><i class="fa fa-diamond"></i></div>';
                    }
                    ?>
                    
                        <div class="caption"><?php echo esc_html( $price['_eco_hosting-subtitle'] ); ?></div>
                        <div class="pt-price-tag"><?php echo esc_html( $price['_eco_hosting-price'] ); ?><span><?php echo esc_html( $price['_eco_hosting-duration'] ); ?></span></div>
                        <div class="pt-plan"><?php echo esc_html( $price['_eco_hosting-title'] ); ?></div>
                    </div>
                    <div class="pt-body">
                        <div class="pt-features">
                            <ul>
                            <?php 
                            foreach( $price['_eco_hosting-feature'] as $feature ){
                                echo '<li>'.esc_html( $feature ).'</li>';
                            }
                            ?>
                            </ul>
                        </div>
                    </div>
                    <?php 
                    if( isset( $price['_eco_hosting-url'] ) && isset( $price['_eco_hosting-btntext'] ) ){
                        echo '<div class="pt-footer">';
                            echo '<a href="'.esc_url( $price['_eco_hosting-url'] ).'" class="btn btn-custom-reverse">'.esc_html( $price['_eco_hosting-btntext'] ).'</a>';
                        echo '</div>';  
                    }
                    ?>
                    <!-- Pricing Table Item End -->
                </div>
                <?php 
                    endforeach;
                ?>
                     
                </div>
            </div>
        </div>
        <?php 

            endwhile;
            wp_reset_postdata();
        endif;
        ?>
    </div>
</div>