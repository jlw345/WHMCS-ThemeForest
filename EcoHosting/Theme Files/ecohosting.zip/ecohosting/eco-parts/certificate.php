<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
    if( ecohost_meta_id('certificate_overlay') ){
        $overlay = ' class="bg--overlay"';
    }else{
        $overlay = '';
    }

?>
<div id="certificate" <?php echo ecohost_section_bg('certificate_bgimg'). $overlay; ?>>
    <div class="container">
        <?php 
        if( !empty( ecohost_meta_id('certificate-title') ) ){
            echo '<h2 class="h1">'.esc_html( ecohost_meta_id('certificate-title') ).'</h2>';
        }
        ?>
        
        <div class="certificate--img">
        <?php 
        $pictures = ecohost_meta_id('certificate-picture');
        if( is_array( $pictures ) ){
            foreach( $pictures as $picture ){
                if( $picture ){
                    echo '<img src="'.esc_url( $picture ).'" alt="'.esc_attr__( 'certificate picture', 'ecohosting' ).'">';
                }
                
            }
        }
        
        ?>  
        </div>
    </div>
</div>
    