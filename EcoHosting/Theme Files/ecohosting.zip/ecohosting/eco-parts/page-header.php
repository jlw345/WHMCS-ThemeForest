<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
 
    //Page Header 
    if( !get_header_image() ){
        
        if( !ecohost_section_bg('sliderbg_img') ) {
            $backgroud = 'data-bg-src="'.esc_url( ecohost_opt('eco_allHeader_bg', 'url') ).'"';
        }else {
           $backgroud = ecohost_section_bg('sliderbg_img');
        }
        
    }else{
       $backgroud =  'data-bg-src="'.esc_url( get_header_image() ).'"';
    }
    // Overlay
    // meta custom
    $overlay = '';
    if( ecohost_meta_id( 'sliderbg_overlay' ) == 'on' ){
        $overlay .= "bg--overlay";
    }elseif( ecohost_meta_id( 'sliderbg_overlay' ) == 'global' && ecohost_opt('eco_allHeader_overlay')  ){
        $overlay .= "bg--overlay";
    }else{
        $overlay .= "";
    }
    
    // blog page header
    if( is_blog() && ecohost_opt('eco_allHeader_overlay') ){
        $overlay .= "bg--overlay";
    }else{
        $overlay .= "";
    }

?>

<div id="pageTitle" class="HeaderAdjust <?php echo esc_attr( $overlay ); ?>" <?php echo wp_kses_post( $backgroud ); ?>>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="section-title">
                <?php 
				// title
				if(  is_ecohost_woocommerce_activated() && is_shop() ){
					echo '<h2>';
						woocommerce_page_title();
					echo '</h2>';
					
				}else{

					if ( is_archive() ){
						the_archive_title('<h2>', '</h2>');
					}elseif ( is_home() ){
						echo '<h2>'.esc_html__( 'Blog', 'ecohosting' ).'</h2>';
					}elseif(is_search()){
						echo '<h2>'.esc_html__( 'Search Result', 'ecohosting' ).'</h2>';
					} else{
						the_title( '<h2>', '</h2>' );
					}
				}
                ?>
                </div>
                <?php 
                // page header breadcrumbs 
                if( ecohost_opt('eco_enable_breadcrumb') ){
                    ecohost_breadcrumbs();   
                }
                
                ?>
            </div>
        </div>
    </div>
</div>