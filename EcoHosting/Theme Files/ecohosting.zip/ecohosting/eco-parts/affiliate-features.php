<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
    // Overlay 
    if( ecohost_meta_id('affiliate-features_overlay') ){
        $overlay = ' bg--overlay';
    }else{
        $overlay = '';
    }
?>
<div id="features" class="afeatures <?php echo esc_attr( $overlay ); ?>" <?php echo ecohost_section_bg('affiliate-features_bgimg'); ?>>
    <div class="container">
        <?php 
            // section title
            echo ecohost_section_heading('affiliate-features-title');
        ?>
        <div class="row">
            <?php 
            // Feature Item
            $features = ecohost_meta_id('affiliate-features-content');
            if( $features ):
            foreach( $features as $feature ):
            ?>
            <div class="col-md-4 col-sm-4 feature-item text-center">
            <?php 
            if( isset( $feature['_eco_affiliate-features-img'] ) && $feature['_eco_affiliate-features-img'] ){
                echo '<div class="feature-item-icon">';
                    echo '<img src="'.esc_url( $feature['_eco_affiliate-features-img'] ).'" alt="'.esc_attr__( 'image', 'ecohosting' ).'" class="img-responsive">';
                echo '</div>';  
            }
            ?>

                <div class="feature-item-content">
                <?php 
                // feature title
                if( isset( $feature['_eco_affiliate-features-title'] ) && $feature['_eco_affiliate-features-title'] ){
                    echo '<h4>'.esc_html( $feature['_eco_affiliate-features-title'] ).'</h4>';
                }
                // feature content
                if( isset( $feature['_eco_affiliate-features-desc'] ) && $feature['_eco_affiliate-features-desc'] ){
                    echo '<p>'.ecohost_wp_kses_allow( $feature['_eco_affiliate-features-desc'] ).'</p>';
                }
                ?>  
                </div>
                
            </div>
            <?php 
            endforeach;
            endif;
            ?>

        </div>
    </div>
</div>