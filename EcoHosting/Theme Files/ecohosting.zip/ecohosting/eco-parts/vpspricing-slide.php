<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
    // Overlay 
    if( ecohost_meta_id('vps_overlay') ){
        $overlay = ' bg--overlay';
    }else{
        $overlay = '';
    }
 

?>
<!-- VPS Pricing Area Start -->
<div id="vpsPricing" class="HeaderAdjust<?php echo esc_attr( $overlay ); ?>" <?php echo ecohost_section_bg('vps-bg'); ?>>
    <div class="container">
        <?php 
            // section title
            echo ecohost_section_heading('vps-title');
      
        ?>
        <form action="#" method="get">
            <!-- VPS Pricing Slider Start -->
            <div class="vps-pricing--slider-holder">
                <div class="pips"></div>
                <div class="vps-pricing--slider VPSPricingSlider"></div>
            </div>
            <!-- VPS Pricing Slider Start -->
            <!-- VPS Pricing Features Start -->
            <div class="vps-pricing--features">
                <div class="row reset-gutter">
                    <?php 
                    // VPS Pricing Item
                    $vpsTags = ecohost_meta_id( 'vpsslid-tag-content' );
                    
                    if( is_array( $vpsTags ) ):
                        foreach( $vpsTags as $vpsTag ):
  
                    ?>
                    <div class="col-md-2 col-xs-6 vps-pricing--feature">
                    <?php 
                    // tage image
                    if( isset( $vpsTag['_eco_vps-tag-img'] ) && $vpsTag['_eco_vps-tag-img'] ){
                        
                        echo '<div class="vps-pricing--feature-img">';
                            echo '<img src="'.esc_url( $vpsTag['_eco_vps-tag-img'] ).'" alt="'.esc_attr__( 'image', 'ecohosting' ).'" class="img-responsive">';
                        echo '</div>';   
                    }
                    // tag name
                    if( isset( $vpsTag['_eco_vps-tag-name'] ) && $vpsTag['_eco_vps-tag-name'] ){
                        
                        echo '<span class="vps-pricing--feature-name">'.esc_html( $vpsTag['_eco_vps-tag-name'] ).'</span>';  
                    }
                    ?>
                        <span class="vps-pricing--feature-value vps-pricing--cpu"></span>
                        <input type="hidden" name="cpuText" value="" class="InputCPUText" />
                    </div>
                    <?php 
                        endforeach;
                    endif;
                    ?>

                    <!-- VPS Pricing Action Button Start -->
                    <?php 
                    if( ecohost_meta_id('vps-btntext') ){
                        echo '<div class="col-md-2 col-xs-6 vps-pricing--action-btn">';
                            echo '<a href="#" class="btn btn-lg btn-custom-reverse">'.esc_html( ecohost_meta_id('vps-btntext') ).'</a>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>
            <!-- VPS Pricing Features End -->
        </form>
    </div>
</div>
<!-- VPS Pricing Area End -->