<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

    // Overlay 
    if( ecohost_meta_id('dedicate-pricing_overlay') ){
        $overlay = ' class="bg--overlay"';
    }else{
        $overlay = '';
    }
 
?>
<!-- Compare Area Start -->

<div id="compare" <?php echo ecohost_section_bg('dedicate-pricing-bg').$overlay; ?>>
    <div class="container">
        <?php 
            // section title
            echo ecohost_section_heading('dedicate-pricing-title');
            
            // query
            $tax_id =  get_post_meta( get_the_ID() , '_eco_dedicate-cat', true ) ;
            $args = array(
                'post_type' => 'dedicate-pricing',
                'posts_per_page' => 1,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'dedicate-categories',
                        'field' => 'slug',
                        'terms' => esc_html( $tax_id ),
                    )
                ),
            );
            $loop = new WP_Query( $args );
        
            if( $loop->have_posts() ):
            while( $loop->have_posts() ): $loop->the_post();
            $headings = get_post_meta( $post->ID, '_eco_dedicated-table-heading', true ); 
            $features = get_post_meta( $post->ID, '_eco_dedicated-content', true ); 
        ?>
        <table>
            <thead>
                <tr>
                <?php 
                if( is_array( $headings ) ){
                    $moblabel = array();
                    foreach( $headings as $heading ){
                        if( $heading ){
                            $moblabel[] .= $heading;
                            echo '<th>'.esc_html( $heading ).'</th>';
                        }
                    }
                }
                ?>
                </tr>
            </thead>
            <tbody>
            <?php 
            foreach( $features as $feature ):
            ?>
                <tr>
                <?php 
                if( isset( $feature['_eco_dedicated-feature'] ) && $feature['_eco_dedicated-feature'] ){
                    $i= 0;
                    foreach( $feature['_eco_dedicated-feature'] as $featur ){
                        echo '<td data-label="'.esc_attr( $moblabel[$i] ).'">'.esc_html( $featur ).'</td>';
                    $i++;
                    }    
                }

                // order button
                if( isset( $feature['_eco_dedicated-btntext'] ) && isset( $feature['_eco_dedicated-btnurl'] ) ){
                    echo '<td data-label="'.esc_attr( end( $moblabel ) ).'"><a href="'.esc_url( $feature['_eco_dedicated-btnurl'] ).'" class="btn btn-custom-reverse">'.esc_html( $feature['_eco_dedicated-btntext'] ).'</a></td>';
                }
                ?>  
                </tr>
            <?php 
            endforeach;
            ?>

           </tbody>
        </table>
        <?php 
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
    </div>
</div>
<!-- Compare Area End -->