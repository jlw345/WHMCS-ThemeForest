<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

    if( !ecohost_meta_id('sliderbg_video') ){
        $bg = ecohost_section_bg('sliderbg_img');
    }else{
        $bg = 'data-bg-video="'.esc_html( ecohost_meta_id('sliderbg_video') ).'"';
    }

    // Overlay
    // meta custom
    if( ecohost_meta_id( 'sliderbg_overlay' ) == 'on' ){
        $overlay = "bg--overlay";
    }elseif( ecohost_meta_id( 'sliderbg_overlay' ) == 'global' && ecohost_opt('eco_allHeader_overlay')  ){
        $overlay = "bg--overlay";
    }else{
        $overlay = "";
    }

	//
	if( ecohost_meta_id('slide_speed') ){
		$speed = ecohost_meta_id('slide_speed');
	}else{
		$speed = '4000';
	}

	
?>
<!-- Header Area Start -->
<div id="header" <?php echo wp_kses_post( $bg ); ?> class="HeaderAdjust <?php echo esc_attr( $overlay ); ?>">
    <!-- Header Slider Start -->
    <div id="header-slider" class="header-slider" data-spped="<?php echo esc_attr( $speed ); ?>">
        <?php 
        $sliders = ecohost_meta_id('slider-group-field');
        $i = 1;
        foreach( $sliders as $slider ):

            $contbg = isset( $slider['_eco_slide-contbg-color'] ) ? ' style=background-color:'.$slider['_eco_slide-contbg-color'] : '';
        
        ?>
        <div class="header-slider--item header-slider--item-<?php echo esc_html( $i ); ?>">
            <div class="container">
                <div class="row">
                <?php 
                if( isset( $slider['_eco_slider-title'] ) || isset( $slider['_eco_slider-content'] ) ):
                ?>
                    <div class="col-md-5 header-item-content-holder">
                        <div class="vc-parent">
                            <div class="vc-child">
                                <!-- Header Slider Content Start -->
                                <div class="header-item-content"<?php echo esc_attr( $contbg ); ?>>
                                <?php
                                // slider title
                                if( isset( $slider['_eco_slider-title'] ) && $slider['_eco_slider-title'] ){
                                    echo '<h1>'.esc_html( $slider['_eco_slider-title'] ).'</h1>';   
                                } 
                                // slider content
                                if( isset( $slider['_eco_slider-content'] ) && $slider['_eco_slider-content'] ){
                                    echo '<p>'.ecohost_wp_kses_allow( $slider['_eco_slider-content'] ).'</p>';   
                                } 
                                // slider list content
                                if( isset( $slider['_eco_slider-listcontent'] ) && $slider['_eco_slider-listcontent'] ){
                                    echo '<ul>'; 
                                        foreach( $slider['_eco_slider-listcontent'] as $list ){
                                            echo '<li>'.esc_html( $list ).'</li>';
                                        }
                                    echo '</ul>';   
                                }
                                // slider button 
                                if( isset( $slider['_eco_sliderbtn-text'] ) && $slider['_eco_sliderbtn-text']  ){
                                    if( $slider['_eco_sliderbtn-text'] ){
                                        echo '<div class="price">';
                                            echo '<a href="'.esc_url( $slider['_eco_slidebtn_url'] ).'" class="btn btn-lg btn-custom-reverse">'.esc_html( $slider['_eco_sliderbtn-text'] ).'</a>';
                                        echo '</div>';
                                    }
                                }
                                ?>

                                </div>
                                <!-- Header Slider Content End -->
                            </div>
                        </div>
                    </div>
                <?php 
                endif;
                ?>
                    <div class="col-md-7 header-item-img">
                        <div class="vc-parent">
                            <div class="vc-child">
                                <figure class="clearfix">
                                <?php 
                                if( isset( $slider['_eco_slider-img'] ) && $slider['_eco_slider-img'] ){
                                    echo '<img src="'.esc_url( $slider['_eco_slider-img'] ).'" alt="'.esc_attr__( 'image', 'ecohosting' ).'" class="img-responsive owl-fadeInUp">';
                                }
                                ?>
                                    
                                    <figcaption>
                                    <?php 
                                    if( isset( $slider['_eco_slider-badge2-title'] ) && $slider['_eco_slider-badge2-title'] ){
                                        echo '<div class="header-item-badge header-item-badge-1 owl-fadeInLeft">';
                                            echo '<p>'.esc_html( $slider['_eco_slider-badge2-title'] ).'<span>'.esc_html( $slider['_eco_slider-badge2-price'] ).'</span>'.esc_html( $slider['_eco_slider-badge2-duration'] ).'</p>';
                                        echo '</div>';
                                    }
                                    
                                    // badge 2 
                                    if( isset( $slider['_eco_slider-badge1-title'] ) && $slider['_eco_slider-badge1-title'] ){
                                        
                                        echo '<div class="header-item-badge header-item-badge-2 owl-fadeInRight">';
                                            echo '<p>'.esc_html( $slider['_eco_slider-badge1-title'] ).'<span>'.esc_html( $slider['_eco_slider-badge1-discount'] ).'</span>'.esc_html( $slider['_eco_slider-badge1-offer'] ).'</p>';
                                        echo '</div>';
                                    }
                                    ?>

                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php 
        $i++;
        endforeach;
        ?>
    </div>
    <!-- Header Slider End -->
    <?php 
    // Header Slider Nav
    if( is_array( $sliders ) ):
    ?>
    <div class="header--slider-nav">
        <div class="container">
            <ul>
            <?php 
            $i = 1;
            foreach( $sliders as $slider ){
                
                if( $i == 1 ){
                    $active = ' class="active"';
                }
                
                if( isset( $slider['_eco_slider-nav-icon'] ) || isset( $slider['_eco_slider-title'] ) ){
                    
                    echo '<li'.$active.'><p><i class="fa '.esc_html( $slider['_eco_slider-nav-icon'] ).'"></i><span>'.esc_html( $slider['_eco_slider-title'] ).'</span></p></li>';    
                }
            $i++;   
            }
            ?>
            </ul>
        </div>
    </div>
    <?php 
    endif;
    ?>
</div>