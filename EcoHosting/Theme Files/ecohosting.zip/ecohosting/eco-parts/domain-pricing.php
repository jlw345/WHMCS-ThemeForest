<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

    // Overlay 
    if( ecohost_meta_id('domain-pricing_overlay') ){
        $overlay = ' bg--overlay';
    }else{
        $overlay = '';
    }
 
?>
<!-- Domain pricing Area Start -->

<div id="pricingTable2" class="domains-page<?php echo esc_attr( $overlay ); ?>" <?php echo ecohost_section_bg('domain-pricing-bg'); ?>>
    <div class="container">
        <?php 
            // section title
            echo ecohost_section_heading('domain-pricing-title');
            
            // query
            $tax_id =  get_post_meta( get_the_ID() , '_eco_domain-cat', true ) ;
            $args = array(
                'post_type' => 'domain-pricing',
                'posts_per_page' => 1,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'domain-categories',
                        'field' => 'slug',
                        'terms' => esc_html( $tax_id ),
                    )
                ),
            );
            $loop = new WP_Query( $args );
        
            if( $loop->have_posts() ):
            while( $loop->have_posts() ): $loop->the_post();
            $headings = get_post_meta( $post->ID, '_eco_domain-table-heading', true ); 
            $features = get_post_meta( $post->ID, '_eco_domain-content', true ); 
        ?>
        <table>
            <thead>
                <tr>
                <?php 
                if( is_array( $headings ) ){
                    $moblabel = array();
                    foreach( $headings as $heading ){
                        if( $heading ){
                            $moblabel[] .= $heading;
                            echo '<th>'.esc_html( $heading ).'</th>';
                        }
                    }
                }
                ?>
                </tr>
            </thead>
            <tbody>
            <?php 
            foreach( $features as $feature ):
            ?>
                <tr>
                <?php 
                if( isset( $feature['_eco_domain-feature'] ) && $feature['_eco_domain-feature'] ){
                    $i = 0;
                    foreach( $feature['_eco_domain-feature'] as $featur ){
                        echo '<td data-label="'.esc_attr( $moblabel[$i] ).'">'.esc_html( $featur ).'</td>';
                    $i++;
                    }    
                }

                
                // order button
                if( isset( $feature['_eco_domain-btntext'] ) && isset( $feature['_eco_domain-btnurl'] ) ){
                    echo '<td data-label="'.esc_attr( end( $moblabel ) ).'"><a href="'.esc_url( $feature['_eco_domain-btnurl'] ).'" class="btn btn-custom-reverse">'.esc_html( $feature['_eco_domain-btntext'] ).'</a></td>';
                }
                ?>  
                </tr>
            <?php 
            endforeach;
            ?>

           </tbody>
        </table>
        <?php 
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
    </div>
</div>
<!-- Compare Area End -->