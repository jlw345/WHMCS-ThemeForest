<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
?>
    <!-- Blog Area Start -->
    <div id="blog" class="page">
        <div class="container">
            <div class="row">
                <!-- Blog Content Area Start -->
                <div class="col-md-12 blog-page-content">
                    <?php 
                        if( have_posts() ):
                        while( have_posts()):the_post();
                        
                        the_content(); 
                        
                        // If comments are open comment template.
                        if ( comments_open() || get_comments_number() ) {
                            comments_template();
                        }
                        endwhile;
                        wp_reset_postdata();
                        else :
                            get_template_part( 'template/content', 'none' );
                        endif;
                    ?>
                </div>
            </div>
        </div>
    </div>