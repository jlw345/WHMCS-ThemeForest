<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

?>
<!-- Domain Search Area Start -->
<div id="offer">
    <div class="container">
        <div class="row content">
        <?php 
        
        $tag = ecohost_meta_id('domafdfdfin-search-tag');
        $acturl = ecohost_meta_id('dom_search_acturl');
        
        // action url check
        if( $acturl ){
            $acturl = $acturl;
        }else{
            $acturl = '#';
        }
        // tags
        if( isset( $tag[0]['_eco_dom-search-tag-top'] ) || isset( $tag[0]['_eco_dom-search-tag-buttom'] ) ){
            echo '<div class="col-md-3 left-content">';
                echo '<p>';
                // search tag top
                if( isset( $tag[0]['_eco_dom-search-tag-top'] ) && $tag[0]['_eco_dom-search-tag-top'] ){
                    echo '<span>'.esc_html( $tag[0]['_eco_dom-search-tag-top'] ).'</span>';
                }
                // search tag buttom
                if( isset( $tag[0]['_eco_dom-search-tag-buttom'] ) && $tag[0]['_eco_dom-search-tag-buttom'] ){
                    echo esc_html( $tag[0]['_eco_dom-search-tag-buttom'] );   
                }
                echo '</p>';
            echo '</div>';
            
            echo '<div class="col-md-9 right-content">';
        }else{
            echo '<div class="col-md-12 right-content">';
        }
        ?>

            
                <div class="row">
                
                <?php 
                if( isset( $tag[0]['_eco_dom-search-tag-top'] ) || isset( $tag[0]['_eco_dom-search-tag-buttom'] ) ){
                    echo '<div class="col-md-8">';
                }else{
                   echo '<div class="col-md-6">'; 
                }
                ?>
                
                    
                        <!-- Offer Form Start -->
                        <form action="<?php echo esc_url( $acturl ); ?>" method="post" id="domainSearchForm">
                            <div class="row reset-gutter">
                                <div class="col-sm-6">
                                    <input class="form-control" name="domain" type="text" placeholder="<?php esc_attr_e( 'Enter your domain', 'ecohosting' ); ?>">
                                </div>
                                <div class="col-sm-3 select-box">
                                    <select class="form-control" name="ext">
                                    <?php
                                    $exts = ecohost_meta_id('search-domain-extension');
                                    foreach( $exts as $ext ){
                                        echo '<option>'.esc_html( $ext ).'</option>';   
                                    }
                                    ?>
                                    </select>
                                </div>
                                <div class="col-sm-3">
                                    <button class="btn submit-button-custom" type="submit"><?php esc_html_e( 'SEARCH', 'ecohosting' ); ?></button>
                                </div>
                            </div>
                        </form>
                        <!-- Offer Form End -->
                        <?php 
                        if( ecohost_meta_id('dom-offer-tag') ){
                            echo '<div class="domain--offer">';
                                echo '<span>'.esc_html( ecohost_meta_id('dom-offer-tag') ).'</span>';
                            echo '</div>';    
                        }
                        ?>
                    </div>
                    <?php 
                    if( isset( $tag[0]['_eco_dom-search-tag-top'] ) || isset( $tag[0]['_eco_dom-search-tag-buttom'] ) ){
                        echo '<div class="col-md-4 hidden-sm hidden-xs">';
                    }else{
                       echo '<div class="col-md-6">'; 
                    }
                    ?>
                    
                        <div class="row domain-ext hidden-xs">
                        <?php 
                        $domExts = ecohost_meta_id('dom-extension');
                        if( $domExts ){
                            foreach( $domExts as $domExt ){
                                if( isset( $domExt['_eco_extension-name'] ) || isset( $domExt['_eco_extension-duration'] ) ) {
                                    
                                    if( isset( $tag[0]['_eco_dom-search-tag-top'] ) || isset( $tag[0]['_eco_dom-search-tag-buttom'] ) ){
                                       echo '<div class="col-sm-4">';
                                    }else{
                                       echo '<div class="col-sm-2">'; 
                                    }
                                    
                                        echo '<div class="extension">';
                                            echo '<span class="name">'.esc_html( $domExt['_eco_extension-name'] ).'</span>';
                                            echo '<span>'.esc_html( $domExt['_eco_extension-price'] ).esc_html( $domExt['_eco_extension-duration'] ).'</span>';
                                        echo '</div>';
                                    echo '</div>';   
                                    
                                }   
                            }
                        }
                        ?>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Domain Search Area End -->