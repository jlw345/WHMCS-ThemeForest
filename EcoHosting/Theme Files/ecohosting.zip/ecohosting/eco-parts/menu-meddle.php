<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

?>
<!-- Primary Menu Start -->
<nav id="primaryMenu" class="navbar primary-menu-two">
    <div class="container">
        <!-- Logo Start -->
        <div class="primary--logo">
            <?php 
            // site logo
            if( has_custom_logo() ){
                the_custom_logo();
                
            }elseif( ecohost_theme_logo() ){
                echo ecohost_theme_logo();
                
            }else{
                echo '<h1><a href="'.esc_url( home_url('/') ).'">';
                    bloginfo('name');
                echo '</a></h1>';
            }
       
            ?>
        </div>
        <!-- Logo End -->
        <div class="primary--info clearfix">
        <?php 
        $support_info = ecohost_opt('eco_support_info');
        if( is_array( $support_info ) ):
        foreach( $support_info as $info ):
        ?>
            <div class="primary--info-item">
                
                    <?php 
                    if( !$info['icon'] ){
                        if( isset( $info['image'] ) && $info['image'] ){
                            echo '<div class="primary--icon">';
                            echo '<img src="'.esc_url( $info['image'] ).'" alt="'.esc_attr__( 'support image', 'ecohosting' ).'" class="img-responsive">';
                            echo '</div>';
                        }
                    }else{
                        echo '<div class="primary--icon">';
                            echo '<i class="fa '.esc_html( $info['icon'] ).'"></i>';
                        echo '</div>';   
                    }
                    ?>
                
                <div class="primary--content">
                    <?php 
                    // title
                    if( $info['title'] ){
                        echo '<p class="count">'.esc_html( $info['title'] ).'</p>';
                    }
                    // description
                    if( $info['description'] ){
                        echo '<p>'.esc_html( $info['description'] ).'</p>';
                    }
                    ?>
                </div>
            </div>
        <?php 
        endforeach;
        endif;
        ?>

        </div>
    </div>
</nav>