<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

?>
<!-- FAQ Area Start -->
<div id="faq">
    <div class="container">
        <div class="faq-categories">
            <ul class="nav" role="tablist">
            <?php
            $tabargs = array(
                'taxonomy' => 'faq-categories',
                'hide_empty' => false
            );
            $tabTerms = get_terms( $tabargs );
            if( is_array( $tabTerms ) ){
                $i = 1;
                foreach( $tabTerms as $tabTerm ){
                    if( $i != 1 ){
                        $class = "";
                    }else{
                       $class = "active"; 
                    }
                    
                    echo '<li role="presentation" class="'.esc_attr( $class ).'"><a href="#'.esc_attr( $tabTerm->slug ).'" aria-controls="'.esc_attr( $tabTerm->slug ).'" role="tab" data-toggle="tab">'.esc_html( $tabTerm->name ).'</a></li>';
                    
                $i++;
                }
            }
            ?>                
                
            </ul>
        </div>
        <div class="faq-content">
            <div class="tab-content">
            
            <div class="tab-content">
            <?php 
            if( is_array( $tabTerms ) ):
            $j = 1;
            foreach( $tabTerms as $tabTerm ):
            ?>
                <div role="tabpanel" class="tab-pane fade <?php echo ($j == 1 )? 'in active' : ''; ?>" id="<?php echo esc_attr( $tabTerm->slug ); ?>">
                    <div class="panel-group accordion" id="accordion<?php echo esc_attr( $j ); ?>" role="tablist">
                        <!-- Accordion Item Start -->
                           
                        
                        <?php 
                        $tabargs = array(
                            'post_type'      => 'faq',
                            'posts_per_page' => 1,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'faq-categories',
                                    'field'    => 'id',
                                    'terms'    => esc_html( $tabTerm->term_id ),
                                )
                            )

                        );
                        
                        $tabloop = new WP_Query( $tabargs );
                        if( $tabloop->have_posts() ) :
                        
                            while( $tabloop->have_posts() ): $tabloop->the_post();
                            
                            $faq_contents = ecohost_meta_id('faq-content');
                            $i = 1;
                            foreach( $faq_contents as $faq_content ):
                            ?>
                                <div class="panel panel-default <?php echo ( $i == 1)? 'active' : ''; ?>">
                                    <div class="panel-heading" role="tab">
                                        <a href="#sharedTabQ-<?php echo esc_attr( $tabTerm->term_id.'-'.$i ); ?>" class="<?php echo ( $i == 1)? '' : 'collapsed'; ?>" data-toggle="collapse" data-parent="#accordion<?php echo esc_attr( $j ); ?>" role="button">
                                            <h4 class="panel-title"><?php echo esc_html( $faq_content['_eco_faq-title'] ); ?> <i class="fa fa-minus"></i></h4>
                                        </a>
                                    </div>
                                    <div id="sharedTabQ-<?php echo esc_attr( $tabTerm->term_id.'-'.$i ); ?>" class="panel-collapse collapse <?php echo ( $i == 1)? 'in' : ''; ?>" role="tabpanel">
                                        <div class="panel-body link-color--child">
                                            <?php 
                                                if( $faq_content['_eco_faq-desc'] ){
                                                    echo '<p>'.ecohost_wp_kses_allow( $faq_content['_eco_faq-desc'] ).'</p>';
                                                }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            <?php
                                $i++;
                                endforeach;
                            endwhile;
                             wp_reset_postdata();
                        endif;
                        ?>
                    </div>
                </div>
            <?php 
            $j++;
            endforeach;
            endif;
            ?>
            </div>
           </div>
        </div>
    </div>
</div>
<!-- FAQ Area End -->