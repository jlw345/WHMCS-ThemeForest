<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
    // Overlay 
    if( ecohost_meta_id('testimonial_overlay') ){
        $overlay = ' class="bg--overlay"';
    }else{
        $overlay = '';
    }
 
?>
    <!-- Testimonial Area Start -->
    <div id="testimonial" <?php echo ecohost_section_bg('testimonial-bg'). $overlay; ?>>
        <?php 
            // section title
            echo ecohost_section_heading('testimonial-title');
        ?>
        <div class="testimonial-slider">
            <?php 
            $testimonials = ecohost_meta_id('testimonial-content');
            if( is_array( $testimonials ) ):
            foreach( $testimonials as $testimonial ):
            ?>
            <div class="testimonial-item" <?php echo ecohost_testimonial_bg( $testimonial ); ?>>
            <?php 
            if( isset( $testimonial['_eco_testimonial-descriptions'] ) && $testimonial['_eco_testimonial-descriptions'] ){
                echo '<div class="recommender-comment">';
                    echo '<p>'.esc_html( $testimonial['_eco_testimonial-descriptions'] ).'</p>';
                echo '</div>';   
            }
            ?>

                <div class="recommender-info">
                <?php 
                if( isset( $testimonial['_eco_testimonial-name'] ) && $testimonial['_eco_testimonial-name'] ){
                    echo '<span class="recommender-name">'.esc_html( $testimonial['_eco_testimonial-name'] ).'</span>';
                } 
                
                if( isset( $testimonial['_eco_testimonial-company'] ) && $testimonial['_eco_testimonial-company'] ){
                    
                    echo '<span class="recommender-role">'.esc_html( $testimonial['_eco_testimonial-company'] ).'</span>';
                }
                ?>

                </div>
            </div>
            <?php 
            endforeach;
            endif;
            ?>

        </div>
    </div>
    <!-- Testimonial Area End -->