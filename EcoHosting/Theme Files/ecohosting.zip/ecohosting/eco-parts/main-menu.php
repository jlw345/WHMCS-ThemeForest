<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

?>
<!-- Secondary Menu Start -->
<nav id="secondaryMenu" class="navbar">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#secondaryNavbar" aria-expanded="false" aria-controls="secondaryNavbar">
                <span class="sr-only"><?php esc_html_e( 'Toggle navigation', 'ecohosting' ); ?></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <?php 
            if( ecohost_opt('eco_display_headerCustomBtn') ){
                echo '<div class="login-btn hidden-lg hidden-md">';
                    echo '<a href="'.esc_url( ecohost_opt('eco_header_customBtnUrl') ).'" class="btn">'.esc_html( ecohost_opt('eco_header_customBtn') ).'</a>';
                echo '</div>';   
            }
            ?>
        </div>
        <!-- Secondary Menu Links Start -->
        <div id="secondaryNavbar" class="reset-padding navbar-collapse collapse">
                <?php
                if( has_nav_menu( 'primary-menu' ) ){
                    
                    $args = array(
                        'theme_location' => 'primary-menu',
                        'menu_class'     => 'secondary-menu-links nav navbar-nav',
                        'depth'          =>0,
                        'fallback_cb'    => 'wp_bootstrap_navwalker::fallback',
                        'walker'         => new wp_bootstrap_navwalker(),
                    );
                    wp_nav_menu( $args );
                }
                
                // main menu custom button
                if( ecohost_opt('eco_display_headerCustomBtn') ){  
                    echo '<ul class="secondary-menu-links nav navbar-nav navbar-right hidden-xs hidden-sm">';
                        echo '<li><a href="'.esc_url( ecohost_opt('eco_header_customBtnUrl') ).'" class="btn">'.esc_html( ecohost_opt('eco_header_customBtn') ).'</a></li>';
                    echo '</ul>';    
                }
                ?>
        </div>
        <!-- Secondary Menu Links End -->
    </div>
</nav>
<!-- Secondary Menu End -->