<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

    $getbgImg = ecohost_section_bg('flatContentone-bgimg');
    $overlay  = ecohost_section_bg('flatContentone-overlay');
    //
    if( $getbgImg ){
        $bgImg = $getbgImg;
    }else{
        $bgImg = '';
    }
    // 
    if( $overlay ){
        $overlay = 'class="bg-overlay"';
    }else{
        $overlay = '';
    }

?>
<!-- Flat Content Area Start -->
<div id="flatContentone" <?php echo wp_kses_post( $overlay.' '.$bgImg ); ?>>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <?php 
                // Section Title
                echo ecohost_section_heading('flatContentone-sectTitle');
                ?>
                <div class="content-flat">
                <?php 
                if( ecohost_meta_id('flatContentone-box') ){
					echo ecohost_get_wysiwyg_output( 'flatContentone-box' );
                }
                ?>
                </div>
            </div>
        </div>
    </div>
</div>