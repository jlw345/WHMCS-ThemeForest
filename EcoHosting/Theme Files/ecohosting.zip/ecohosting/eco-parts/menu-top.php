<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

?>
<!-- Menu Topbar Start -->
<div class="menu--topbar">
    <div class="container">
        <!-- Menu Topbar Contact Start -->
        <div class="menu-topbar--contact">
            <ul class="nav navbar-nav">
            <?php 
            // header tel
            if( ecohost_opt('eco_header_tel') ){
                $tel = str_replace( ' ','', ecohost_opt('eco_header_tel') );
                echo '<li><a href="tel:'.esc_attr( $tel ).'"><i class="fa fa-phone"></i>'.esc_html( ecohost_opt('eco_header_tel') ).'</a></li>';
            }
            
            // header email
            if( ecohost_opt('eco_header_email') ){
                echo '<li><a href="mailto:'.esc_attr( ecohost_opt('eco_header_email') ).'"><i class="fa fa-envelope"></i>'.esc_html( ecohost_opt('eco_header_email') ).'</a></li>';
            }
            ?>  
            </ul>
        </div>
        
        <?php 
        // Menu Topbar Social
        echo ecohost_social(
            array(
                'ul_class' => 'menu-topbar--social nav navbar-nav navbar-right'
            )
        );
        ?>
    </div>
</div>
<!-- Menu Topbar End -->