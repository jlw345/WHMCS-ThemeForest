<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

    if( ecohost_meta_id('counter_overlay') ){
        $overlay = 'bg--overlay';
    }else{
        $overlay = '';
    }
 
?>
<div class="counter <?php echo esc_attr( $overlay ); ?>" <?php echo ecohost_section_bg('counter-bg') ?>>
    <div class="container">
        <div class="row">
        
        <?php 
        $counters = ecohost_meta_id('counter-options');
        if( $counters ):
        foreach( $counters as $counter ):
        ?>
            <div class="col-sm-3 col-xs-6">
                <!-- Counter Item Start -->
                <div class="counter-holder">
                <?php 
                // counter image
                if( isset( $counter['_eco_counter-image'] ) && $counter['_eco_counter-image'] ){
                    if( empty( $counter['_eco_counter-icon'] ) ){
                        
                        echo '<div class="counter-icon"><img src="'.esc_url( $counter['_eco_counter-image'] ).'" alt="'.esc_attr__( 'counter image', 'ecohosting' ).'" class="img-responsive"></div>';
                    }
                }
    
                // 
                if( isset( $counter['_eco_counter-icon'] ) && $counter['_eco_counter-icon'] ){
                    echo '<div class="counter-icon"><i class="fa '.esc_attr( $counter['_eco_counter-icon'] ).'" aria-hidden="true"></i></div>';
                    
                }
                
                // title
                if( isset( $counter['_eco_counter-title'] ) && $counter['_eco_counter-title'] ){
                    echo '<p class="counter-text">'.esc_html( $counter['_eco_counter-title'] ).'</p>';
                }
                // 
                if( isset( $counter['_eco_counter-number'] ) && $counter['_eco_counter-number'] ){
                    echo '<div class="counter-number">'.esc_html( $counter['_eco_counter-number'] ).'</div>';
                }
                ?>   
                </div>
            </div>
        <?php 
        endforeach;
        endif;
        ?>

       </div>
    </div>
</div>