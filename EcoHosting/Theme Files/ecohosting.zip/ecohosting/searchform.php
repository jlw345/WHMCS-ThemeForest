<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
?>

<div class="search search--widget">
    <form action="<?php echo esc_url( home_url('/') ); ?>" method="get">
        <div class="input-group">
            <input type="text" placeholder="<?php esc_attr_e( 'Search', 'ecohosting' ); ?>"  name="s" class="form-control">
            <span class="input-group-addon">
                <button type="submit"><i class="fa fa-search"></i></button>
            </span>
        </div>
    </form>
</div>
