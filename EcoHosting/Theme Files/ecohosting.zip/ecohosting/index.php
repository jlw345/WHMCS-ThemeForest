<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
get_header();
?>
    <!-- Blog Area Start -->
    <div id="blog" class="page">
        <div class="container">
            <div class="row">
                <?php 
                // left sidebar
                if( ecohost_opt('eco_blog_sidebar') == '2' ){
                    get_sidebar();
                }
                    
                ?>
                <!-- Blog Content Area Start -->
                <?php 
                if( ecohost_opt('eco_blog_sidebar') == '1' ){
                    echo '<div class="col-md-8 col-md-offset-2 blog-page-content">';
                }else{
                    echo '<div class="col-md-8 blog-page-content">';
                }

                        // Blog Content Area
                        if( have_posts() ){
                            while( have_posts() ){
                                the_post();
                                
                                get_template_part('templates/content', get_post_format() );
                                
                            }
                            wp_reset_postdata();
                            get_template_part( 'templates/pagination' );
                        }else{
                            get_template_part( 'templates/content', 'none' );
                        }
                    ?>
                </div>
                <?php 
                // right sidebar
                if( ecohost_opt('eco_blog_sidebar') == '3' ){
                    get_sidebar();
                }
                if( !ecohost_opt('eco_blog_sidebar') ){
                   get_sidebar(); 
                }
                    
                ?>
            </div>
        </div>
    </div>
<?php
get_footer();
?>