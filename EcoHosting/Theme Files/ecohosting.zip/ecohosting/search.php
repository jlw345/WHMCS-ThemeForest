<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
get_header();
?>
    <!-- Blog Area Start -->
    <div id="blog" class="page">
        <div class="container">
            <div class="row">
                <!-- Blog Content Area Start -->
                <div class="col-md-8 blog-page-content">
                    <?php
                        // Blog Content Area
                        if( have_posts() ){
                            while( have_posts() ){
                                the_post();
                                
                                get_template_part('templates/content', get_post_format() );
                                
                            }
                            wp_reset_postdata();
                            get_template_part( 'templates/pagination' );
                        }else{
                            get_template_part( 'templates/content', 'none' );
                        }
                    ?>
                </div>
                <?php 
                    get_sidebar();
                ?>
            </div>
        </div>
    </div>
<?php
get_footer();
?>