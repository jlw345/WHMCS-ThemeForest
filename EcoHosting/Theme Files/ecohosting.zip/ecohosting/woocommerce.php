<?php 
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}
/**
 * @Packge    : EcoHosting
 * @version   : 2
 * @Author    : ThemeLooks
 * @Author URI: https://www.themelooks.com/
 */
 
get_header();
?>
    <!-- Blog Area Start -->
    <div id="blog" class="page">
        <div class="container">
            <div class="row">
                <?php 
                // left sidebar
                if( ecohost_opt('eco_woo_sidebar') == '2' ){
                    get_sidebar('woo');
                }
                    
                ?>
                <!-- Blog Content Area Start -->
                <?php 
                if( ecohost_opt('eco_woo_sidebar') == '1' ){
                    echo '<div class="col-md-12 blog-page-content">';
                }else{
                    echo '<div class="col-md-8 blog-page-content">';
                }
					// Blog Content Area
					if( have_posts() ){
						woocommerce_content();
					}else{
						get_template_part( 'templates/content', 'none' );
					}
                ?>
                </div>
                <?php 
                // right sidebar
                if( ecohost_opt('eco_woo_sidebar') == '3' ){
					get_sidebar('woo');
                }
                if( !ecohost_opt('eco_woo_sidebar') ){
					get_sidebar('woo'); 
                }
                    
                ?>
            </div>
        </div>
    </div>
<?php
get_footer();
?>