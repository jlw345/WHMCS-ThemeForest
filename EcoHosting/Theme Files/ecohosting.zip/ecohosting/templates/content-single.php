<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

?>

<div id="post-<?php the_ID(); ?>" <?php post_class('blog-item full-post'); ?>>
        <?php 
        // post thumbnail
        if( has_post_thumbnail() ):
        ?>
            <div class="blog-item-img">
                <a href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail('full', array('class' => 'img-responsive') ); ?>
                </a>
            </div>
        <?php 
        endif;
        ?>
        <div class="blog-item-content">
            <div class="metadata">
                <i class="fa fa-calendar"></i><a href="<?php echo esc_url( ecohost_blog_date_permalink() ); ?>"><?php echo get_the_date('d/m/y'); ?></a>
                <span class="divider"> <?php esc_html_e( '|', 'ecohosting' ); ?> </span>
                <i class="fa fa-user"></i><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php echo esc_html( get_the_author() ); ?></a>
            </div>
            <?php
            // content
            the_content();
            
            // link pages
            wp_link_pages( array(
            'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'ecohosting' ) . '</span>',
            'after'       => '</div>',
            'link_before' => '<span>',
            'link_after'  => '</span>',
            'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'ecohosting' ) . ' </span>%',
            'separator'   => '<span class="screen-reader-text">, </span>',
            ) );
        
            ?>
            
        </div>
       
       <?php 
        // show post category
        ecohost_posts_categories();
       ?>
        <div class="tags">
        <?php 
        // show post tag
        ecohost_posts_tag();
        ?>
        </div>

        <div class="row">
            <?php 
            // show avatar
            $avatar = get_avatar( get_the_author_meta( 'ID' ),70 );
            $url = get_avatar_url( get_the_author_meta( 'ID' ) );
            $blank = strpos( $url , 'd=blank');
            if( $avatar ):
            ?>
        
            <div class="col-sm-6">
                <div class="post-author-metadata">
                <?php 
                // avatar
                if( !$blank ){
                    echo wp_kses_post( $avatar );
                }
                ?>
                
                <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="post-author-name"><?php echo esc_html( get_the_author() ); ?></a>
                </div>
            </div>
            <?php 
            endif;
            ?>
            <?php
            if( ecohost_opt('eco_hide_shareBox') ):
            ?>
            <div class="col-sm-6">
                <div class="post-social-links">
                    <?php 
					if( function_exists( 'ecohost_social_sharing_buttons' ) ){
						ecohost_social_sharing_buttons();
					}
					?>
                </div>
            </div>
            <?php 
            endif;
            ?>
        </div>

        <div class="post-comments">
            
            <?php 
            // comment template.
            if ( comments_open() || get_comments_number() ) {
                comments_template();
            }
            ?>
        </div>
</div>