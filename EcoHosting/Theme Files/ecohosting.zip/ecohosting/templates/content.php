<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

?>

<div id="post-<?php the_ID(); ?>" <?php post_class('blog-item'); ?>>
    <div class="row">
        
            <?php 
            if( has_post_thumbnail() && !is_sticky() ):
            ?>
            <div class="col-md-6">
                <div class="blog-item-img">
                    <a href="<?php the_permalink(); ?>">
                        <?php the_post_thumbnail('full', array('class' => 'img-responsive') ); ?>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
            <?php
            else:
            ?>
            <div class="col-md-12">

            <?php
            
            if( is_sticky() && has_post_thumbnail() ){
                echo '<div class="blog-item-img">';
                    echo '<a href="'.esc_url( get_the_permalink() ).'">';
                        the_post_thumbnail('full', array('class' => 'img-responsive') );
                    echo '</a>';
                echo '</div>';
            }
            
            endif;
            ?>
        
            <div class="blog-item-content">
                <?php 
                if( get_the_title() ):
                ?>
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <?php 
                endif;
                ?>
                <div class="metadata">
                    <i class="fa fa-calendar"></i><a href="<?php echo esc_url( ecohost_blog_date_permalink() ); ?>"><?php echo get_the_date('d/m/y'); ?></a>
                    <span class="divider"> <?php esc_html_e( '|', 'ecohosting' ); ?> </span>
                    <i class="fa fa-user"></i><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php echo esc_html( get_the_author() ); ?></a>
                </div>
                <?php 
                // post excerpt
                
                echo ecohost_excerpt_length( ecohost_opt( 'eco_blog_postExcerpt' ) ); ?> 
                <?php
                    wp_link_pages( array(
                    'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'ecohosting' ) . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                    'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'ecohosting' ) . ' </span>%',
                    'separator'   => '<span class="screen-reader-text">, </span>',
                    ) );
            
                ?>

            </div>
            <div class="post-read-more-btn">
                <a href="<?php the_permalink(); ?>" class="btn btn-custom-reverse"><?php esc_html_e( 'Read More', 'ecohosting' ); ?></a>
            </div>
        </div>
    </div>
</div>
<hr>