<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
?>
<nav class="blog-page--pagination">
    <?php
    //Pagination
    if ( function_exists('wp_bootstrap_pagination') ){
        wp_bootstrap_pagination();
    }
    else {
        posts_nav_link();
    }
    ?>
</nav>