<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
get_header();
?>
    <!-- Blog Area Start -->
    <div id="blog" class="page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 blog-page-content">
                    <?php
                        // Blog Content Area
                        if( have_posts() ){
                            while( have_posts() ){
                                the_post();
                                
                                the_content();
                                
                                // If comments are open comment template.
                                if ( comments_open() || get_comments_number() ) {
                                    echo '<div class="post-comments inPage">';
                                    comments_template();
                                    echo '</div>';
                                } 
                            }
                            wp_reset_postdata();
                        }else{
                            get_template_part( 'templates/content', 'none' );
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
<?php
get_footer();
?>