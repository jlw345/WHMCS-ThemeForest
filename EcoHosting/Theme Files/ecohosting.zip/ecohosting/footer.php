<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

// 404 page check
if( !is_404() ){
// footer widget and footer bottom 
get_template_part( 'eco-parts/footer', 'widget' );

// Back To Top Button
ecohost_backTotop();
}
wp_footer(); 
?>
</body>
</html>