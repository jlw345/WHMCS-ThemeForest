<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>

    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

    <?php 
    // Preloader Start
    if( ecohost_opt('eco_display_preloader') ){
       ecohost_preloader(); 
    }
    

    // Menu Area 
    if( !is_404() ){
        echo '<div id="menu">';
            // menu top
            if( ecohost_opt('eco_display_headerTop') ){
                get_template_part( 'eco-parts/menu','top' );    
            }
            // menu meddle
            get_template_part( 'eco-parts/menu','meddle' );
            // main menu
            get_template_part( 'eco-parts/main','menu' );
        echo '</div>';
    }
    // page header
    $pageheader = ecohost_meta_id('slide_header_active');
    if( !is_404() ){
        switch( $pageheader ){
            case 'slider_vr1' : get_template_part( 'eco-parts/slider','vr1' );
                break;
            case 'slider_vr2' : get_template_part( 'eco-parts/slider','vr2' );
                break;
            case 'page_header' : get_template_part( 'eco-parts/page','header' );
                break;
            case 'none' : 
                    echo '<div class="page-header-none HeaderAdjust"></div>';
                break;
            default : get_template_part( 'eco-parts/page','header' );
                break;
        }
    }
 
    ?>
 