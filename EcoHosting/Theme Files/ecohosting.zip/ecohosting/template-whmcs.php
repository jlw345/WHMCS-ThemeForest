<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 * Template Name: Whmcs Page
 *
 */
 
get_header();
?>
    <!-- Blog Area Start -->
    <div id="blog" class="page">
        <?php
            // Blog Content Area
            if( have_posts() ){
                while( have_posts() ){
                    the_post();
                    
                    the_content();
                    
                    // If comments are open comment template.
                    if ( comments_open() || get_comments_number() ) {
                        echo '<div class="post-comments inPage">';
                        comments_template();
                        echo '</div>';
                    } 
                }
                wp_reset_postdata();
            }else{
                get_template_part( 'templates/content', 'none' );
            }
        ?>

    </div>
<?php
get_footer();
?>