<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
get_header();
?>
<!-- 404 Area Start -->
<div id="f0f">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="vc-parent">
                    <div class="vc-child">
                        <?php 
                        if( ecohost_opt('eco_fof_text') ){
                            echo '<div class="section-title">';
                                echo '<h2>'.esc_html( ecohost_opt('eco_fof_text') ).'</h2>';
                            echo '</div>';    
                            
                        }else{
                            echo '<div class="section-title">';
                                echo '<h2>404</h2>';
                            echo '</div>'; 
                        }
                        ?>

                        <div class="description">
                            <?php 
                            if( ecohost_opt('eco_fof_desc') ){
                                echo '<p>'.esc_html( ecohost_opt('eco_fof_desc') ).'</p>'; 
                                
                            }else{
                               echo '<p>Sorry, the page you\'re looking for is not found yet.</p>'; 
                            }
                            
                            // search form
                            get_search_form();
                            ?>

                            <a href="<?php echo esc_url( home_url('/') ); ?>" class="btn btn-lg btn-custom-reverse"><?php esc_html_e( 'Go Home', 'ecohosting' ); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 404 Area End -->
<?php
get_footer();
?>