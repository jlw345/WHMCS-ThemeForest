<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 * Template Name: Contact Page
 *
 */
get_header();

?>
    <!-- Contact Area Start -->
    <div id="contact" class="page">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <!-- Contact Address Area Start -->
                    <div class="contact-address">
                        <?php
                        if( ecohost_opt('eco_contact_title') ){
                            echo ' <h2>'.esc_html( ecohost_opt('eco_contact_title') ).'</h2>';
                        }
                        
                        ?>
                           
                        <!-- Contact Address Start -->
                        <address>
                        <?php 
                        // contact info
                        if( ecohost_opt('eco_contact_info') ){
                            echo '<p><i class="fa fa-home"></i>'.esc_html( ecohost_opt('eco_contact_info') ).'</p>';
                        }
                        // email
                        if( ecohost_opt('eco_email') ){
                            echo '<p><i class="fa fa-envelope"></i>'.esc_html( ecohost_opt('eco_email') ).'</p>';
                        }
                        // phone number 
                        if( ecohost_opt('eco_phone_number') ){
                            echo '<p><i class="fa fa-phone"></i>'.esc_html( ecohost_opt('eco_phone_number') ).'</p>';
                        }
                        // fax
                        
                        if( ecohost_opt('eco_fax') ){
                            echo '<p><i class="fa fa-fax"></i>'.esc_html( ecohost_opt('eco_fax') ).'</p>';
                        }
                        
                        ?> 
                        </address>
                        <div class="contact-social-links">
                            <?php 
                            // Contact Social Links
                            echo ecohost_social();
                            ?>
                        </div>
                    </div>
                    <!-- Contact Address Area End -->
                </div>
                <div class="col-sm-6 contact-form">
                <?php
                // contact form 7 shortcode 
                echo do_shortcode( ecohost_opt('eco_contact_form') );
                ?>
                </div>
            </div>
        </div>
    </div>
    
    <?php 
    // MAP Area
    if( ecohost_opt('eco_map_disabled') ){
        echo '<div id="map"></div>';
    }
    
    ?>
    
<?php 
get_footer();
?>