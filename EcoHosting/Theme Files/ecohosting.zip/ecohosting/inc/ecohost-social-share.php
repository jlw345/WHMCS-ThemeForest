<?php
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
// share button code
function ecohost_social_sharing_buttons() {
    
    // Get page URL 
    $ecohostURL = get_permalink();
    $ecohostSitetitle = get_bloginfo('name');
    // Get page title
    $ecohostTitle = str_replace( ' ', '%20', get_the_title());
    
    // Construct sharing URL without using any script
    $twitterURL = 'https://twitter.com/intent/tweet?text='.esc_html( $ecohostTitle ).'&amp;url='.esc_url( $ecohostURL ).'&amp;via='.esc_html( $ecohostSitetitle );
    $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.esc_url( $ecohostURL );
    $googleURL = 'https://plus.google.com/share?url='.esc_url( $ecohostURL );
    $linkedin = 'https://www.linkedin.com/shareArticle?mini=true&url='.esc_url( $ecohostURL ).'&title='.esc_html( $ecohostTitle );
     
    // Add sharing button at the end of page/page content
    $content  = '<ul>';
    $content .= '<li><a href="'. esc_url( $twitterURL ) .'" target="_blank"><i class="fa fa-twitter"></i></a></li>';
    $content .= '<li><a href="'.esc_url( $facebookURL ).'" target="_blank"><i class="fa fa-facebook"></i></a></li>';
    $content .= '<li><a href="'.esc_url( $googleURL ).'" target="_blank"><i class="fa fa-google-plus"></i></a></li>';
    $content .= '<li><a href="'.esc_url( $linkedin ).'" target="_blank"><i class="fa fa-linkedin"></i></a></li>';
    $content .= '</ul>';
    
    echo wp_kses_post( $content );

};
