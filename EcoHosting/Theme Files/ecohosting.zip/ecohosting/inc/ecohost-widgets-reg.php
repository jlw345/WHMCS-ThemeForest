<?php
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

function ecohost_widgets_init() {
    // sidebar widgets register
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', 'ecohosting' ),
        'id'            => 'ecohost-sidebar',
        'description'   => '',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
    // Woocommerce sidebar widgets register
    register_sidebar( array(
        'name'          => esc_html__( 'Woo Sidebar', 'ecohosting' ),
        'id'            => 'ecohost-woo',
        'description'   => '',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
    
    // footer widgets register
    register_sidebar( array(
        'name'          => esc_html__( 'Footer One', 'ecohosting' ),
        'id'            => 'footer-one',
        'description'   => '',
        'before_widget' => '<div class="col-md-6 footer-widget"><div class="footer-about">',
        'after_widget'  => '</div></div>',
        'before_title'  => '<h4>',
        'after_title'   => '</h4>',
    ) );
    register_sidebar( array(
        'name'          => esc_html__( 'Footer Two', 'ecohosting' ),
        'id'            => 'footer-two',
        'description'   => '',
        'before_widget' => '<div class="col-md-3 col-sm-6 footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4>',
        'after_title'   => '</h4>',
    ) );
    register_sidebar( array(
        'name'          => esc_html__( 'Footer Three', 'ecohosting' ),
        'id'            => 'footer-three',
        'description'   => '',
        'before_widget' => '<div class="col-md-3 col-sm-6 footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4>',
        'after_title'   => '</h4>',
    ) );
    
    
}
add_action( 'widgets_init', 'ecohost_widgets_init' );
