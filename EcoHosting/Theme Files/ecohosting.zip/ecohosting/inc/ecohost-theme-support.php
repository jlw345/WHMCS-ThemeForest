<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
// preloader callback
function ecohost_preloader(){
    
    echo '<div id="preloader">';
        echo '<div class="preloader--spinners">';
            echo '<div class="preloader--spinner preloader--spinner-1"></div>';
            echo '<div class="preloader--spinner preloader--spinner-2"></div>';
        echo '</div>';
    echo '</div>';
} 
// Back to top callback
function ecohost_backTotop(){
    
    echo '<div id="backToTop">';
        echo '<a href="#top"><i class="fa fa-angle-up"></i></a>';
    echo '</div>';
}

/**
 * vps pricing slider
 *
 */

//  vps pricing slider localize script
add_action('wp_enqueue_scripts','ecohost_localize_script');
function ecohost_localize_script(){

$x = '123';

wp_localize_script( 'ecohost-main', 'ajaxvps', array(
	'ajaxurl' => admin_url( 'admin-ajax.php' ),
	'vpscontent'   => $x,
    'vps_security' => wp_create_nonce('ecohosting-vps-security'), 
    'contact_security' => wp_create_nonce('ecohosting-contact-security'), 
    ));

}


// vps feature
add_action('wp_ajax_vpspricing_ajax', 'ecohost_vps_feature_ajax');
add_action('wp_ajax_nopriv_vpspricing_ajax', 'ecohost_vps_feature_ajax');
function ecohost_vps_feature_ajax(){
    if( check_ajax_referer( 'ecohosting-vps-security' , 'vps_security' , false) ) {
        $args = array(
            'post_type' => 'vpsslide',
            'posts_per_page' => 1
        );
        
        $loop = new WP_Query( $args );
            
        if( $loop->have_posts() ){
            while(  $loop->have_posts() ){
                $loop->the_post();
                
                $contents = ecohost_meta_id('vpsslid-plan-content');
                
                $data = json_encode( $contents );
                
                echo apply_filters( 'ecohost_vpsslide_json_data', $data );
                
            }
            wp_reset_postdata();
        }
    }else{
        echo '<div class="alert alert-danger" role="alert">'.esc_html__('Sorry something went wrongs.', 'ecohosting').'</div>';
    }
                
    die();
}


// contact page map 
add_action( 'wp_ajax_contactpage_map','ecohost_contactpage_map' );
add_action( 'wp_ajax_nopriv_contactpage_map','ecohost_contactpage_map' );
function ecohost_contactpage_map(){
    if( check_ajax_referer( 'ecohosting-contact-security' , 'contact_security' , false) ) {
        // lat
        if( ecohost_opt('eco_map_lat') ){
            $lat = ecohost_opt('eco_map_lat');
        }else{
            $lat = '23.790546';
        } 
        // lng    
        if( ecohost_opt('eco_map_lng') ){
            $lng = ecohost_opt('eco_map_lng');
        }else{
            $lng = '90.375583';
        } 
        // zoom    
        if( ecohost_opt('eco_map_zoom') ){
            $zoom = ecohost_opt('eco_map_zoom');
        }else{
            $zoom = '16';
        }
        
        $data = array(
            'lat'  => $lat,
            'lng'  => $lng,
            'zoom' => $zoom,
        );
        
        $data = json_encode( $data );
        
        echo apply_filters( 'ecohost_contactpagemap_json_data', $data );
    }else{
        echo '<div class="alert alert-danger" role="alert">'.esc_html__('Sorry something went wrongs.', 'ecohosting').'</div>';
    }
    
    die();

}