<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
add_action( 'wp_enqueue_scripts', 'ecohost_unlimited_color' );
function ecohost_unlimited_color(){
    
    wp_enqueue_style('custom-style', get_template_directory_uri() . '/css/custom-style.css' );
    
    $mainColor = ecohost_opt('unlimited-color');
    $mobnav = ecohost_opt('eco_headerMenu_color');
    $sliderColor = ecohost_meta_id('sliderbg_color');
    
    $flatContbg         = ecohost_meta_id('flatContent-bgColor');
    $flatContColor      = ecohost_meta_id('flatContent-TextColor');
    $flatContOvColor    = ecohost_meta_id('flatContent_overlaycolor');
    $flatContOvOpacity  = ecohost_meta_id('flatContent_overlayopacity');
    
    $flatContOnebg         = ecohost_meta_id('flatContentone-bgColor');
    $flatContOneColor      = ecohost_meta_id('flatContentone-TextColor');
    $flatContOneOvColor    = ecohost_meta_id('flatContentone_overlaycolor');
    $flatContOneOvOpacity  = ecohost_meta_id('flatContentone_overlayopacity');
    
    $bgColor           = ecohost_meta_id('feature-bgcolor');
    $textColor         = ecohost_meta_id('feature_textsectcolor');
    $featureOvColor    = ecohost_meta_id('feature_overlaycolor');
    $featureOvOpacity  = ecohost_meta_id('feature_overlayopacity');
    $iconColor         = ecohost_meta_id('feature_iconcolor');
    
    $countbgcolor   = ecohost_meta_id('counter-bgcolor');
    $countovcolor   = ecohost_meta_id('counter_overlaycolor');
    $countovopacity = ecohost_meta_id('counter_overlayopacity');
    $counttextColor = ecohost_meta_id('counter_textsectcolor');
    $countIconColor = ecohost_meta_id('counter_iconcolor');
    $countIconBoxColor = ecohost_meta_id('counter_iconboxColor');
    
    $certibgColor = ecohost_meta_id('certificate-bgcolor');
    $certiOvbg = ecohost_meta_id('certificate_overlaycolor');
    $certiOvOpacity = ecohost_meta_id('certificate_overlayopacity');
    $certitextColor = ecohost_meta_id('certificate_textsectcolor');
    
    $testibgColor   = ecohost_meta_id('testimonial-bgcolor');
    $testiTextColor = ecohost_meta_id('testimonial_textsectcolor');
    $testiOvbgColor = ecohost_meta_id('testimonial_overlaycolor');
    $testiOvOpacity = ecohost_meta_id('testimonial_overlayopacity');
    $testiImgbord = ecohost_meta_id('testimonial_bordercolor');
    $testiSectTitle = ecohost_meta_id('testimonial_sectTitleColor');
    
    $brindbgColor = ecohost_meta_id('brand-bgcolor');
    $brindOvbg = ecohost_meta_id('brand_overlaycolor');
    $brindOvOpacity = ecohost_meta_id('brand_overlayopacity');
    $brindBorderColor = ecohost_meta_id('brand_bordercolor');
    
    $hostbgColor = ecohost_meta_id('hosting-pricing-bgcolor');
    $hostOvColor = ecohost_meta_id('hosting-pricing_overlaycolor');
    $hostOvOpct = ecohost_meta_id('hosting-pricing_overlayopacity');
    $hostTitleColor = ecohost_meta_id('hosting-pricing_secttitleColor');
    
    $datacentbgColor = ecohost_meta_id('datacenter-bgcolor');
    $datacentTitleColor = ecohost_meta_id('datacenter_secttitleColor');
    $datacentOvColor = ecohost_meta_id('datacenter_overlaycolor');
    $datacentOvOpct = ecohost_meta_id('datacenter_overlayopacity');
    
    $faqbgColor = ecohost_meta_id('faq-bgcolor');
    $faqTitleColor = ecohost_meta_id('faq_textsectcolor');
    $faqOvColor = ecohost_meta_id('faq_overlaycolor');
    $faqOvOpct  = ecohost_meta_id('faq_overlayopacity');
    
    $teambgColor = ecohost_meta_id('team-bgcolor');
    $teamTitleColor = ecohost_meta_id('team_textsectcolor');
    $teamOvColor = ecohost_meta_id('team_overlaycolor');
    $teamOvOpct  = ecohost_meta_id('team_overlayopacity');
    $nametextColor  = ecohost_meta_id('team_nameColor');
    $desitextColor  = ecohost_meta_id('team_desiColor');
    
    $historybgColor = ecohost_meta_id('history-bgcolor');
    $historyOvColor = ecohost_meta_id('history_overlaycolor');
    $historyOvOpct = ecohost_meta_id('history_overlayopacity');
    $historyTitleColor  = ecohost_meta_id('history_sectTitlecolor');
    $historyYearcolor  = ecohost_meta_id('history_yearcolor');
    
    $aCounterbgColor = ecohost_meta_id('affiliate-counter-bgcolor');
    $aCounterOvColor = ecohost_meta_id('affiliate-counter_overlaycolor');
    $aCounterOvOpct  = ecohost_meta_id('affiliate-counter_overlayopacity');
    $aCounterBord    = ecohost_meta_id('affiliate-counter_bordercolor');
    $aCountertextColor    = ecohost_meta_id('affiliate-counter_textcolor');
    
    $afeaturesbgColor  = ecohost_meta_id('affiliate-features-bgcolor');
    $afeaturesOvColor  = ecohost_meta_id('affiliate-features_overlaycolor');
    $afeaturesOvOpct   = ecohost_meta_id('affiliate-features_overlayopacity');
    $afeaturessectColor   = ecohost_meta_id('affiliate-features_headingColor');
    $afeaturesTextColor   = ecohost_meta_id('affiliate-features_textcolor'); 
    
    $apricingbgColor  = ecohost_meta_id('affiliate-pricing-bgcolor');
    $apricingOvColor  = ecohost_meta_id('affiliate-pricing_overlaycolor');
    $apricingOvOpct   = ecohost_meta_id('affiliate-pricing_overlayopacity');
    $apricingsectTiColor   = ecohost_meta_id('affiliate-pricing_sectTitcolor');
    
    $pricingTablebgColor   = ecohost_meta_id('hosting-pricingv2-bgcolor');
    $pricingTableOvColor   = ecohost_meta_id('hosting-pricingv2_overlaycolor');
    $pricingTableOvOpct    = ecohost_meta_id('hosting-pricingv2_overlayopacity');
    $pricingTablesectTiColor = ecohost_meta_id('hostpricv2_textcolor');
    
    $comparebgColor   = ecohost_meta_id('dedicate-pricing-bgcolor');
    $compareOvColor   = ecohost_meta_id('dedicate-pricing_overlaycolor');
    $compareOvOpct    = ecohost_meta_id('dedicate-pricing_overlayopacity');
    $comparesectTiColor = ecohost_meta_id('dedicate-pricing_textsectcolor');
    
    $pricingTable2bgColor   = ecohost_meta_id('domain-pricing-bgcolor');
    $pricingTable2bordColor = ecohost_meta_id('domain-pricing-bordercolor');
    $pricingTable2OvColor   = ecohost_meta_id('domain-pricing_overlaycolor');
    $pricingTable2OvOpct    = ecohost_meta_id('domain-pricing_overlayopacity');
    $pricingTable2TxColor = ecohost_meta_id('domain-pricing_tableTextColor');
    $pricingTable2TitColor = ecohost_meta_id('domain-pricing_textsectcolor');
    
    $vpsPricingbgColor = ecohost_meta_id('vps-bgcolor');
    $vpsPricingOvColor = ecohost_meta_id('vps_overlaycolor');
    $vpsPricingOvOpct = ecohost_meta_id('vps_overlayopacity');
    $vpsPricingTitColor = ecohost_meta_id('vps_secttitleColor');
    $vpsPricingTextColor = ecohost_meta_id('vps_textColor');
    
    $offerbgColor = ecohost_meta_id('dom_search-bgcolor');
    $offerColor = ecohost_meta_id('dom_search_textcolor');
    $offerTagColor = ecohost_meta_id('dom_search_tagtextcolor');
    
    
/*------------------------------------*\
    COLORS
\*------------------------------------*/
$color="
.link-color--child a,
.menu-topbar--contact > ul > li > a > i.fa,
.menu-topbar--social > li > a:hover,
.menu-topbar--social > li > a:focus,
.primary--content p.count,
.primary--logo h1 a span,
.datacenter-location-marker,
#copyright p a,
.contact-info a:hover,
.contact-info a:focus,
.vps-pricing--slider .ui-slider-handle i.fa,
#pageTitle .breadcrumb > li > a:hover,
#pageTitle .breadcrumb > li > a:focus,
#pageTitle .breadcrumb > li.active,
#loginForm p.help-block a:hover,
.widget.recent-items a.footer-thumb-link:hover,
.widget.recent-items a.footer-thumb-link:focus,
.widget.categories li:hover a,
.widget.tags li:hover a,
.widget.archives li:hover a,
.blog-item:hover .blog-item-content h2 a,
.blog-item.full-post:hover a.btn-custom:hover,
.blog-item.full-post .post-author-metadata a:hover,
.comment-thumb a,
.blog-item-content li,
.blog-item-content blockquote,
.feature-item-icon i.fa,
body.page-template-template-whmcs #main-body a:hover,
body.page-template-template-whmcs div.header-lined h1,
.feature-item-content a,
.single-feature--content a,
.content-flat a,
.woocommerce .star-rating span:before,
.woocommerce p.stars a,
.products > .product > a:hover > h2,
.woocommerce .products > .product > a.added_to_cart:hover,
.product > .summary > .woocommerce-product-rating > a:hover,
.woocommerce .product > .summary > .price,
.product > .summary > .product_meta a:hover,
.blog-page-sidebar .widget .calendar_wrap table a:hover,
.blog-page-sidebar .widget .calendar_wrap table tbody td a,
.woocommerce-MyAccount-navigation > ul > li.is-active > a {
    color: {$mainColor};
}
#secondaryMenu .navbar-toggle .icon-bar {
    background-color: {$mobnav['regular']};
}

#flatContent {
   background-color: {$flatContbg};
   color: {$flatContColor};
}
#flatContent.bg-overlay:before {
    background-color: {$flatContOvColor};
    opacity: {$flatContOvOpacity};
}
#flatContentone {
   background-color: {$flatContOnebg};
   color: {$flatContOneColor};
}
#flatContentone.bg-overlay:before {
    background-color: {$flatContOneOvColor};
    opacity: {$flatContOneOvOpacity};
}
#features {
    background-color: {$bgColor};
    color: {$textColor};
}
#features.bg-overlay:before {
    background-color: {$featureOvColor};
    opacity: {$featureOvOpacity};
}
#features .feature-item-icon .fa {
    color: {$iconColor};
} 

.counter {
    background-color: {$countbgcolor};
}
.counter.bg--overlay:before {
    background-color: {$countovcolor};
    opacity: {$countovopacity};
}
.counter .counter-text,
.counter .counter-number {
    color: {$counttextColor};
}
.counter-icon .fa {
    color: {$countIconColor};
    background-color: {$countIconBoxColor};
}
#certificate {
    background-color: {$certibgColor};
    color: {$certitextColor};
}
#certificate.bg--overlay:before{
    background-color: {$certiOvbg};
    opacity: {$certiOvOpacity};
}

#testimonial {
    background-color: {$testibgColor};  
}
#testimonial .recommender-comment p,
#testimonial .recommender-info {
    color: {$testiTextColor};
}
#testimonial.bg--overlay:before {
    background-color: {$testiOvbgColor};
    opacity: {$testiOvOpacity};
}
.testimonial-slider .owl-page {
    border-color: {$testiImgbord};
}
#testimonial .section-title h2 {
    color: {$testiSectTitle};
}
#brands {
    background-color: {$brindbgColor};
    border-color: {$brindBorderColor};
}
#brands.bg--overlay:before {
    background-color: {$brindOvbg};
    opacity: {$brindOvOpacity};
}

#pricing {
    background-color: {$hostbgColor};
}
#pricing .section-title > h2 {
    color: {$hostTitleColor};
}
#pricing.bg--overlay:before {
    background-color: {$hostOvColor};
    opacity: {$hostOvOpct};
}
#datacenterLocations {
    background-color: {$datacentbgColor};
}
#datacenterLocations .section-title h2 {
    color: {$datacentTitleColor};
}
#datacenterLocations.bg--overlay:before {
    background-color: {$datacentOvColor};
    opacity: {$datacentOvOpct};
}

#faq {
    background-color: {$faqbgColor};
}

#faq.bg--overlay:before {
    background-color: {$faqOvColor};
    opacity: {$faqOvOpct};
}

#faq .section-title > h2 {
    color: {$faqTitleColor};
}
#team {
    background-color: {$teambgColor};
}
#team.bg--overlay:before {
    background-color: {$teamOvColor};
    opacity: {$teamOvOpct};
}

#team .section-title > h2 {
    color: {$teamTitleColor};
}
.team-info h2 {
    color: {$nametextColor};
}
.team-info > p {
   color:  {$desitextColor};
}

#history {
    background-color: {$historybgColor};
}
#history.bg--overlay:before {
    background-color: {$historyOvColor};
    opacity: {$historyOvOpct};
}

#history .section-title > h2 {
    color: {$historyTitleColor};
}
#history .timeline--date p {
    color: {$historyYearcolor};
}

#aCounter {
    background-color: {$aCounterbgColor};
}
#aCounter.bg--overlay:before {
    background-color: {$aCounterOvColor};
    opacity: {$aCounterOvOpct};
}
.aCounter-text {
    border-color: {$aCounterBord};
}
#aCounter .aCounter-text,
#aCounter .counter-number,
#aCounter .aCounter-number-holder {
    color: {$aCountertextColor};
}

.afeatures {
    background-color: {$afeaturesbgColor};
}
.afeatures.bg--overlay:before {
    background-color: {$afeaturesOvColor};
    opacity: {$afeaturesOvOpct};
}
.afeatures .section-title h2 {
    color: {$afeaturessectColor};
}
.afeatures .feature-item-content {
    color: {$afeaturesTextColor};
}

#pricing.apricing {
    background-color: {$apricingbgColor};
}
.apricing.bg--overlay:before {
    background-color: {$apricingOvColor};
    opacity: {$apricingOvOpct};
}

.apricing .section-title h2 {
    color: {$apricingsectTiColor};
}

#pricingTable {
    background-color: {$pricingTablebgColor};
}
#pricingTable.bg--overlay:before {
    background-color: {$pricingTableOvColor};
    opacity: {$pricingTableOvOpct};
}

#pricingTable .section-title h2 {
    color: {$pricingTablesectTiColor};
}

#compare {
    background-color: {$comparebgColor};
}
#compare.bg--overlay:before {
    background-color: {$compareOvColor};
    opacity: {$compareOvOpct};
}

#compare .section-title h2 {
    color: {$comparesectTiColor};
}

#pricingTable2.domains-page {
    background-color: {$pricingTable2bgColor};
    border-color: {$pricingTable2bordColor};
}
#pricingTable2.bg--overlay:before {
    background-color: {$pricingTable2OvColor};
    opacity: {$pricingTable2OvOpct};
}

#pricingTable2 table th,
#pricingTable2 .btn.btn-custom-reverse {
    color: {$pricingTable2TxColor};
}
#pricingTable2 .section-title h2 {
    color: {$pricingTable2TitColor};
}

#vpsPricing {
    background-color: {$vpsPricingbgColor};
}
#vpsPricing.bg--overlay:before {
    background-color: {$vpsPricingOvColor};
    opacity: {$vpsPricingOvOpct};
}

#vpsPricing .section-title h2 {
    color: {$vpsPricingTitColor};
}
.vps-pricing--action-btn .btn,
.vps-pricing--slider .ui-slider-handle em {
    color: {$vpsPricingTextColor};
}

#offer {
    background-color: {$offerbgColor};
}

#offer .right-content .extension {
    border-color: {$offerColor};
    color: {$offerColor};
}
#offer .left-content p,
#offer .domain--offer span,
#offer .btn.submit-button-custom {
    color: {$offerTagColor};
}
";


/*------------------------------------*\
    BACKGROUND COLORS
\*------------------------------------*/
$bgColor="
#secondaryMenu,
.secondary-menu-links > .dropdown > .dropdown-menu > li > a:hover,
.secondary-menu-links > .dropdown > .dropdown-menu > li > a:focus,
.secondary-menu-links > .dropdown > .dropdown-menu > li.active > a,
.secondary-menu-links > .dropdown > .dropdown-menu > li.active > a:hover,
.secondary-menu-links > .dropdown > .dropdown-menu > li.active > a:focus,
.secondary-menu-links > .dropdown > .dropdown-menu > li.open > a,
.secondary-menu-links > .dropdown > .dropdown-menu > li.open > a:hover,
.secondary-menu-links > .dropdown > .dropdown-menu > li.open > a:focus,
.secondary-menu-links li .dropdown-menu-thard > li > a:hover,
.secondary-menu-links li .dropdown-menu-thard > li > a:focus,
.secondary-menu-links li .dropdown-menu-thard > li.active > a,
.secondary-menu-links li .dropdown-menu-thard > li.active > a:hover,
.secondary-menu-links li .dropdown-menu-thard > li.active > a:focus,
.header-item-badge-2,
#backToTop a,
.header-item-content,
.header--slider-nav ul li p:hover i.fa,
.header--slider-nav ul li.active p i.fa,
#offer .left-content p,
#domainSearchForm button[type='submit'],
.domain--offer,
.section-title h2:before,
.btn-custom-reverse,
a.btn-custom-reverse,
.pt-plan,
.testimonial-slider .owl-page.active:before,
.footer-widget h4:before,
#subscribeForm .submit-button,
.pt-head .popular-indicator,
.accordion .panel-heading a,
.vps-pricing--slider .ui-slider-handle em,
#compare table thead,
.domain-banner-content p,
#pricingTable2 table thead,
.team-social-links ul li a:hover,
.team-social-links ul li a:hover,
.timeline--date,
.faq-categories ul li a:hover,
.faq-categories ul li.active a,
#testimonial.no-bg .testimonial-slider .owl-page.active:before,
#loginForm .submit-button,
.widget.search .input-group-addon,
.widget-title:before,
.post-social-links li a:hover,
a.comment-reply,
.post-comment-form-group .form-control.submit-btn,
.contact-address h2:before,
.contact-social-links li a:hover,
.contact-social-links li a:focus,
#contactForm .submit-button,
#preloader,
.primary--icon i.fa,
body.page-template-template-whmcs #bridge #nav,
body.page-template-template-whmcs #bridge #nav .dropdown-menu > li > a:hover,
body.page-template-template-whmcs #bridge #nav .dropdown-menu > li > a:focus,
body.page-template-template-whmcs #bridge .home-shortcuts,
body.page-template-template-whmcs #main-body .btn-primary,
body.page-template-template-whmcs #main-body .btn-primary[disabled],
body.page-template-template-whmcs #main-body a.list-group-item.active,
.blog-item.sticky:before,
.woocommerce a.button,
.woocommerce a.button.alt,
.woocommerce button.button,
.woocommerce button.button.alt,
.woocommerce input.button,
.woocommerce input.button.alt,
.woocommerce #respond input#submit,
.woocommerce span.onsale,
.woocommerce .woocommerce-pagination > .page-numbers > li > span.current,
.woocommerce .woocommerce-pagination > .page-numbers > li > a.current,
.woocommerce-product-search input[type='submit'] {
    background-color: {$mainColor};
}";


/*------------------------------------*\
    Slider BACKGROUND  COLORS
\*------------------------------------*/

$sliderbgColor = "
    #header {
        background-color: {$sliderColor};
    }
    #pageTitle {
        background-color: {$sliderColor};
    }
";

/*------------------------------------*\
    BORDER COLORS
\*------------------------------------*/
$bordColor="
.team-social-links ul li a:hover,
.team-social-links ul li a:hover,
#testimonial.no-bg .testimonial-slider .owl-page.active,
.post-social-links li a:hover,
.post-comment-form-group .form-control.submit-btn,
.contact-social-links li a:hover,
.contact-social-links li a:focus,
.blog-item-content blockquote,
body.page-template-template-whmcs #main-body .btn-primary,
body.page-template-template-whmcs #main-body .btn-primary[disabled],
body.page-template-template-whmcs #main-body a.list-group-item.active,
.blog-item.sticky,
.woocommerce span.onsale:before,
.woocommerce .woocommerce-pagination > .page-numbers > li > span.current,
.woocommerce .woocommerce-pagination > .page-numbers > li > a.current {
    border-color: {$mainColor};
}";

/* BORDER TOP COLORS */
$bordtopColor="
.domain--offer:before,
.pt-head,
.vps-pricing--slider .ui-slider-handle:before,
.faq-categories ul li a:before {
    border-top-color: {$mainColor};
}";

/* BORDER LEFT COLORS */
$bordLeft="
.header--slider-nav ul li:hover,
.header--slider-nav ul li.active {
    border-left-color: {$mainColor};
}";

/* BORDER BOTTOM COLORS */
$bordBottom="
.pt-head .caption {
    border-bottom-color: {$mainColor};
}";


wp_add_inline_style( 'custom-style', $color );
wp_add_inline_style( 'custom-style', $bgColor );
wp_add_inline_style( 'custom-style', $bordColor );
wp_add_inline_style( 'custom-style', $bordtopColor );
wp_add_inline_style( 'custom-style', $bordLeft );
wp_add_inline_style( 'custom-style', $bordBottom );
wp_add_inline_style( 'custom-style', $sliderbgColor );
 
}
