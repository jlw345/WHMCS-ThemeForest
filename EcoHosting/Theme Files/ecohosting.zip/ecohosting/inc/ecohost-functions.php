<?php 
/**
 * @version    2
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */
 
// ecohost theme option callback
function ecohost_opt( $id = null, $url = null ){
    global $ecohost_opt;
    
    if( $id && $url ){
        
        if( isset( $ecohost_opt[$id][$url] ) && $ecohost_opt[$id][$url] ){
            return $ecohost_opt[$id][$url];
        }
        
    }else{
        
        if( isset( $ecohost_opt[$id] )  && $ecohost_opt[$id] ){
            return $ecohost_opt[$id];
        }
        
    }
   
}

// ecohost custom meta id callback
function ecohost_meta_id( $id = '' ){
    
    $value = get_post_meta( get_the_ID(), '_eco_'.$id, true );
    
    return $value;
}
// Data attr background data-bg-src  
function ecohost_section_bg( $bg = null ) {                                               

    $background = ecohost_meta_id( $bg );
    
    if( $background ){
        return 'data-bg-src="'.esc_url( $background ).'"';
    }
    
}
// Data attr background data-bg-src single feature background  
function ecohost_single_feature_bg( $args = array() ) {     

    if( isset( $args['_eco_single-feature-bg'] ) && $args['_eco_single-feature-bg'] ){
        return 'data-bg-src="'.esc_url( $args['_eco_single-feature-bg'] ).'"';
    }else{
        return;
    }
    
}
// Data attr background data-recommender-thumb testimonial background  
function ecohost_testimonial_bg( $args = array() ) {     

    if( isset( $args['_eco_testimonial-image'] ) ){
        return 'data-recommender-thumb="'.esc_url( $args['_eco_testimonial-image'] ).'"';
    }else{
        return;
    }
    
}
// ecohost theme logo
function ecohost_theme_logo() {
    // escaping allow html
    $allowhtml = array(
        'a'    => array( 
            'href' => array()
        ),
        'span' => array(),
        'i'    => array( 
            'class' => array() 
        )
    );
    // site logo
    if( !ecohost_opt('eco_site_title') && ecohost_opt('eco_site_logo', 'url' )  ){
        return '<a href="'.esc_url( home_url('/') ).'" class="navbar-brand"><img src="'.esc_url( ecohost_opt('eco_site_logo', 'url' ) ).'" alt="'.esc_attr__( 'logo', 'ecohosting' ).'" /></a>';
         
    }elseif( ecohost_opt('eco_site_title') ){
        return '<h1><a href="'.esc_url( home_url('/') ).'">'.wp_kses( ecohost_opt('eco_site_title'), $allowhtml ).'</a></h1>';   
    }else{
        return;
    }
}
// blog post date permalink
function ecohost_blog_date_permalink(){
    $year  = get_the_time('Y'); 
    $month_link = get_the_time('m');
    $day   = get_the_time('d');

    $link = get_day_link( $year, $month_link, $day);
    
    return $link; 
}

// Blog Excerpt Length
if ( ! function_exists( 'ecohost_excerpt_length' ) ) :
function ecohost_excerpt_length( $limit = 30 ) {
	
	$excerpt = explode( ' ', get_the_content() );
    
	// $limit null check
    if( !null == $limit ){
        $limit = $limit;
    }else{
        $limit = 30;
    }
    
    
	if ( count( $excerpt ) >= $limit ) {
		array_pop( $excerpt );
		$exc_slice = array_slice( $excerpt, 0, $limit );
		$excerpt = implode( " ", $exc_slice ).' ...';
	} else {
		$exc_slice = array_slice( $excerpt, 0, $limit );
		$excerpt = implode( " ", $exc_slice );
	}
	
	$excerpt = '<p>'.preg_replace('`\[[^\]]*\]`','',$excerpt).'</p>';
	return $excerpt;
}
endif;


function custom_excerpt_length( $length ) {
	return 250;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );


//blog post categories 
if ( ! function_exists( 'ecohost_posts_categories' ) ) {
    function ecohost_posts_categories(){
        $categories = get_the_category ();
                
        if($categories){
        echo '<p>';
            $cat="";
            $cat.='<span class="post-category-text">'.esc_html__('CATEGORY:','ecohosting').'</span>';
            foreach($categories as $category){
                
            $cat.='<a href="'.esc_url( get_category_link( $category->term_id ) ).'" class="category-link">'.esc_html( $category->name ).'</a>'.' ';
            }
            echo wp_kses_post( $cat );
        echo '</p>';
        }
    }
}

// blog post tag 
if ( ! function_exists( 'ecohost_posts_tag' ) ) :
function ecohost_posts_tag(){
    $posttags= get_the_tags();
    $tag = "";
    $tag .= "<ul>";
    if($posttags){
        $tag .= "<li><strong>".esc_html__('Tags:','ecohosting')."</strong></li>";
        foreach($posttags as $posttag){
            $tag .= '<li><a href="'.esc_url(get_tag_link($posttag->term_id)).'" class="btn btn-custom">'.esc_html( $posttag->name ).'</a></li>';
        }
    }
    $tag .= "</ul>";
    echo wp_kses_post( $tag );
}
endif;

// ecohost comment template callback
function ecohost_comment_callback( $comment, $args, $depth ) {
    
      if ( 'div' === $args['style'] ) {
        $tag       = 'div';
        $add_below = 'comment';
    } else {
        $tag       = 'li';
        $add_below = 'div-comment';
    }
    ?>
    <<?php echo wp_kses_post( $tag ); ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?> id="comment-<?php comment_ID() ?>">
    <?php if ( 'div' != $args['style'] ) : ?>
        <div id="div-comment-<?php comment_ID() ?>" class="comment-body single-comment ">
    <?php endif; ?>
    <div class="comment-thumb">
    
        <a href="#" class="pull-left">
            <?php if ( $args['avatar_size'] != 0 ) echo get_avatar( $comment, $args['avatar_size'] ); ?>
        </a>
        
        <?php if ( $comment->comment_approved == '0' ) : ?>
             <em class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'ecohosting' ); ?></em>
              <br />
        <?php endif; ?>
        
        <div class="comment-meta pull-left">
            <?php printf( __( '<span class="comment-author-name">%s</span> says:', 'ecohosting' ), get_comment_author_link() ); ?>
            <?php edit_comment_link( esc_html__( '(Edit)', 'ecohosting' ), '  ', '' ); ?>
            <div class="date"><?php printf( __('%1$s at %2$s', 'ecohosting'), get_comment_date(),  get_comment_time() ); ?></div>
        </div>
    </div>
    <div class="comment-content">
        <div class="comment-text">
            <?php comment_text(); ?>
        </div>
    </div>  

    <?php comment_reply_link(array_merge( $args, array( 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']) ) ); ?>
 
    <?php if ( 'div' != $args['style'] ) : ?>
    </div>
    <?php endif; ?>
    <?php  
}

//  add class comment reply link
add_filter('comment_reply_link', 'ecohost_replace_reply_link_class');
function ecohost_replace_reply_link_class( $class ){
    $class = str_replace("class='comment-reply-link", "class='comment-reply btn btn-sm", $class);
    return $class;
}

// comments textarea top to  bottom .
add_filter( 'comment_form_fields', 'ecohost_move_comment_field_to_bottom' );
function ecohost_move_comment_field_to_bottom( $fields ) {
    $comment_field = $fields['comment'];
    unset( $fields['comment'] );
    $fields['comment'] = $comment_field;
    return $fields;
}

//audio format iframe match 
function ecohost_iframe_match(){   
    $audio_content = ecohost_embedded_media( array('audio', 'iframe') );
    $iframe_match=preg_match("/\iframe\b/i",$audio_content, $match);
    return $iframe_match;
}

//Post embedded media
function ecohost_embedded_media( $type = array() ){
    $content = do_shortcode( apply_filters( 'the_content', get_the_content() ) );
    $embed = get_media_embedded_in_content( $content, $type );
    
    if( in_array( 'audio' , $type) ):
    
        if( count( $embed ) > 0 ){
            $output = str_replace( '?visual=true', '?visual=false', $embed[0] );
        }else{
           $output = str_replace( '?visual=true', '?visual=false', $embed );
        }
        
    else:
    
        if( count( $embed ) > 0 ){
            $output = $embed[0];
        }else{
           $output = $embed; 
        }
    endif;
    
    return $output;
}

// social media
if ( ! function_exists( 'ecohost_social' ) ) :
function ecohost_social( $args = array() ){
global $bizlinks_opt;

$default = array(
    'ul_class' => '',
    'li_class' => '',
    'class'    => ''
);

$class = wp_parse_args( $args, $default );

if( $class['ul_class'] ){
   $ul_class = 'class="'.esc_attr( $class['ul_class'] ).'"';
}else{
   $ul_class = ''; 
}

if( $class['li_class'] ){
    $li_class = 'class="'.esc_attr( $class['li_class'] ).'"';
}else{
   $li_class = ''; 
}

if( $class['class'] ){
  $aclass = 'class="'.esc_attr( $class['class'] ).'"';
}else{
   $aclass = ''; 
}


ob_start();
if( ecohost_opt('eco_facebook_link') || ecohost_opt('eco_twitter_link') ):
?>

<ul <?php echo wp_kses_post( $ul_class ); ?>>
    <?php if( ecohost_opt('eco_facebook_link')  ): ?>
        <li <?php echo wp_kses_post( $li_class ); ?>><a href="<?php echo esc_url( ecohost_opt('eco_facebook_link') ); ?>" target="_blank" <?php echo wp_kses_post( $aclass ); ?>><i class="fa fa-facebook"></i></a></li>
    <?php endif; ?>
    <?php if( ecohost_opt('eco_twitter_link') ): ?>
        <li <?php echo wp_kses_post( $li_class ); ?>><a href="<?php echo esc_url( ecohost_opt('eco_twitter_link') ); ?>" target="_blank" <?php echo wp_kses_post( $aclass ); ?>><i class="fa fa-twitter"></i></a></li>
    <?php endif; ?>
    <?php if( ecohost_opt('eco_google_link') ):  ?>
        <li <?php echo wp_kses_post( $li_class ); ?>><a href="<?php echo esc_url( ecohost_opt('eco_google_link') ); ?>" target="_blank" <?php echo wp_kses_post( $aclass ); ?>><i class="fa fa-google-plus"></i></a></li>
    <?php endif; ?>
    <?php if( ecohost_opt('eco_youtube_link') ): ?>
        <li <?php echo wp_kses_post( $li_class ); ?>><a href="<?php echo esc_url( ecohost_opt('eco_youtube_link') );  ?>" target="_blank" <?php echo wp_kses_post( $aclass ); ?>><i class="fa fa-youtube"></i></a></li>
    <?php endif; ?>
    <?php if( ecohost_opt('eco_instagram_link') ): ?>
        <li <?php echo wp_kses_post( $li_class ); ?>><a href="<?php echo esc_url( ecohost_opt('eco_instagram_link') );  ?>" target="_blank" <?php echo wp_kses_post( $aclass ); ?>><i class="fa fa-instagram"></i></a></li>
    <?php endif; ?>
    <?php if( ecohost_opt('eco_vimeo_link') ): ?>
        <li <?php echo wp_kses_post( $li_class ); ?>><a href="<?php echo esc_url( ecohost_opt('eco_vimeo_link') );  ?>" target="_blank" <?php echo wp_kses_post( $aclass ); ?>><i class="fa fa-vimeo"></i></a></li>
    <?php endif; ?>
    <?php if( ecohost_opt('eco_linkedin_link') ): ?>
        <li <?php echo wp_kses_post( $li_class ); ?>><a href="<?php echo esc_url( ecohost_opt('eco_linkedin_link') );  ?>" target="_blank" <?php echo wp_kses_post( $aclass ); ?>><i class="fa fa-linkedin"></i></a></li>
    <?php endif; ?>
    <?php if( ecohost_opt('eco_behance_link') ): ?>
        <li <?php echo wp_kses_post( $li_class ); ?>><a href="<?php echo esc_url( ecohost_opt('eco_behance_link') );  ?>" target="_blank" <?php echo wp_kses_post( $aclass ); ?>><i class="fa fa-behance"></i></a></li>
    <?php endif; ?>
    <?php if( ecohost_opt('eco_pinterest_link') ): ?>
        <li <?php echo wp_kses_post( $li_class ); ?>><a href="<?php echo esc_url( ecohost_opt('eco_pinterest_link') );  ?>" target="_blank" <?php echo wp_kses_post( $aclass ); ?>><i class="fa fa-pinterest-p"></i></a></li>
    <?php endif; ?>
    <?php if( ecohost_opt('eco_dribbble_link') ): ?>
        <li <?php echo wp_kses_post( $li_class ); ?>><a href="<?php echo esc_url( ecohost_opt('eco_dribbble_link') );  ?>" target="_blank" <?php echo wp_kses_post( $aclass ); ?>><i class="fa fa-dribbble"></i></a></li>
    <?php endif; ?>
</ul>
<?php
endif;
$html = ob_get_clean();
return $html;
}
endif;

// section heading callback
function ecohost_section_heading( $title = '' ){
    
    $sectitle = ecohost_meta_id( $title );
    
    if( $sectitle ){
        
        echo '<div class="section-title">';
        
            if( $sectitle ){
                echo '<h2>'.esc_html( $sectitle ).'</h2>'; 
            }
        echo '</div>';   
    }
}
// wp kses allow html
function ecohost_wp_kses_allow( $data = '' ){
    
    $allow = array(
        'a' => array(
            'href' => array(),
            'target' => array()
        ),
        'span' => array(),
        'br'   => array(),
        'strong'   => array(),
    
    
    );
    
    return wp_kses( $data, $allow );
    
}
// Flat Content wysiwyg output
function ecohost_get_wysiwyg_output( $meta_id ) {
    
	global $wp_embed;

	$content = ecohost_meta_id( $meta_id );
	$content = $wp_embed->autoembed( $content );
	$content = $wp_embed->run_shortcode( $content );
	$content = wpautop( $content );
	$content = do_shortcode( $content );

	return $content;
}
// is blog
function is_blog() {
    
	return ( ((is_archive()) || (is_author()) || (is_category()) || (is_home()) || (is_single()) || (is_tag()) || (is_search())  ) ) ? true : false ;
}

// Woocommerce Check
if ( ! function_exists( 'is_ecohost_woocommerce_activated' ) ) {
	function is_ecohost_woocommerce_activated() {
		if ( class_exists( 'woocommerce' ) ) { return true; } else { return false; }
	}
}


/**
 * woo_hide_page_title
 *
 * Removes the "shop" title on the main shop page
*/

add_filter( 'woocommerce_show_page_title' , 'ecohost_hide_woo_page_title' );
function ecohost_hide_woo_page_title() {
	
	if( ecohost_opt('ecohost_woo_shoptitle_switch') == false ){
		return false;
	}else{
		return true;
	}
	
}

// Shop Page Product per page 
add_filter( 'loop_shop_per_page', 'ecohost_loop_shop_per_page', 20 );
function ecohost_loop_shop_per_page( $cols ) {

  // Return the number of products you wanna show per page.
  
	if( ecohost_opt( 'eco_woo_product_number' ) ){
		$num = ecohost_opt( 'eco_woo_product_number' );
	}else{
		$num = 10;
	}
  
  $cols = esc_html( $num );
  return $cols;
}




