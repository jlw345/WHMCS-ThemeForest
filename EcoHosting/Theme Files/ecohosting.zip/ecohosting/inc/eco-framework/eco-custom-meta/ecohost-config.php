<?php
/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB2 directory)
 *
 * Be sure to replace all instances of 'yourprefix_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category YourThemeOrPlugin
 * @package  Demo_CMB2
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/WebDevStudios/CMB2
 */

/**
 * Get the bootstrap! If using the plugin from wordpress.org, REMOVE THIS!
 */

if ( file_exists( get_template_directory() . '/cmb2/init.php' ) ) {
	require_once get_template_directory() . '/cmb2/init.php';
} elseif ( file_exists( get_template_directory() . '/CMB2/init.php' ) ) {
	require_once get_template_directory() . '/CMB2/init.php';
}

/**
 * Conditionally displays a metabox when used as a callback in the 'show_on_cb' cmb2_box parameter
 *
 * @param  CMB2 object $cmb CMB2 object
 *
 * @return bool             True if metabox should show
 */
function ecohost_show_if_front_page( $cmb ) {
	// Don't show this metabox if it's not the front page template
	if ( $cmb->object_id !== get_option( 'page_on_front' ) ) {
		return false;
	}
	return true;
}

/**
 * Conditionally displays a field when used as a callback in the 'show_on_cb' field parameter
 *
 * @param  CMB2_Field object $field Field object
 *
 * @return bool                     True if metabox should show
 */
function ecohost_hide_if_no_cats( $field ) {
	// Don't show this field if not in the cats category
	if ( ! has_tag( 'cats', $field->object_id ) ) {
		return false;
	}
	return true;
}

/**
 * Manually render a field.
 *
 * @param  array      $field_args Array of field arguments.
 * @param  CMB2_Field $field      The field object
 */
function ecohost_render_row_cb( $field_args, $field ) {
	$classes     = $field->row_classes();
	$id          = $field->args( 'id' );
	$label       = $field->args( 'name' );
	$name        = $field->args( '_name' );
	$value       = $field->escaped_value();
	$description = $field->args( 'description' );
	?>
	<div class="custom-field-row <?php echo esc_attr( $classes ); ?>">
		<p><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label></p>
		<p><input id="<?php echo esc_attr( $id ); ?>" type="text" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_html( $value ); ?>"/></p>
		<p class="description"><?php echo wp_kses_post( $description ); ?></p>
	</div>
	<?php
}

/**
 * Manually render a field column display.
 *
 * @param  array      $field_args Array of field arguments.
 * @param  CMB2_Field $field      The field object
 */
function ecohost_display_text_small_column( $field_args, $field ) {
	?>
	<div class="custom-column-display <?php echo esc_attr( $field->row_classes() ); ?>">
		<p><?php echo wp_kses_post( $field->escaped_value() ); ?></p>
		<p class="description"><?php echo wp_kses_post( $field->args( 'description' ) ); ?></p>
	</div>
	<?php
}

/**
 * Conditionally displays a message if the $post_id is 2
 *
 * @param  array             $field_args Array of field parameters
 * @param  CMB2_Field object $field      Field object
 */
function ecohost_before_row_if_2( $field_args, $field ) {
	if ( 2 == $field->object_id ) {
		echo '<p>Testing <b>"before_row"</b> parameter (on $post_id 2)</p>';
	} else {
		echo '<p>Testing <b>"before_row"</b> parameter (<b>NOT</b> on $post_id 2)</p>';
	}
}

add_action( 'cmb2_admin_init', 'ecohost_register_metabox' );
/**
 * Hook in and add a demo metabox. Can only happen on the 'cmb2_admin_init' or 'cmb2_init' hook.
 */
function ecohost_register_metabox() {
	$prefix = '_eco_';
	$prefixtype = '_etype_';
    
    /********************************\
        page layout select meta 
    \********************************/
    
	$ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'page_layout_section',
		'title'         => esc_html__( 'Page Layout', 'ecohosting' ),
        'context' => 'side',
        'priority' => 'high',
		'object_types'  => array( 'page', ), // Post type
	) );

	$ecohost_meta->add_field( array(
		'name'       => esc_html__( 'Page Layout', 'ecohosting' ),
		'desc'       => esc_html__( 'Set page layout container,fullwide or both', 'ecohosting' ),
		'id'         => $prefix . 'custom_page_layout',
		'type'       => 'multicheck',
        'options' => array(
            '1' => 'Container',
            '2' => 'Fullwidth',
            ),
	) );
    
    /********************************\
        Page Header and slider meta 
    \********************************/
    
	$ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'sliderPageheader_section',
		'title'         => esc_html__( 'Slider/Page Header section', 'ecohosting' ),
		'object_types'  => array( 'page', ), // Post type
        'closed'        => true
	) );

	$ecohost_meta->add_field( array(
		'name'             => esc_html__( 'Slider/Page Header Active', 'ecohosting' ),
		'id'               => $prefix . 'slide_header_active',
		'type'             => 'radio_inline',
		'options'          => array(
			'slider_vr1'    => esc_html__( 'Slider Version 1', 'ecohosting' ),
			'slider_vr2'    => esc_html__( 'Slider Version 2', 'ecohosting' ),
			'page_header'   => esc_html__( 'Page Header', 'ecohosting' ),
			'none'          => esc_html__( 'None', 'ecohosting' ),
		),
        'default' => 'page_header'
	)   );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background', 'ecohosting' ),
		'desc' => esc_html__( 'Use background image slide or page header.', 'ecohosting' ),
		'id'   => $prefix . 'sliderbg_img',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Video Background', 'ecohosting' ),
		'desc' => esc_html__( 'Video background in slider version one. Use only youtube video id', 'ecohosting' ),
		'id'   => $prefix . 'sliderbg_video',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Use slide background color.', 'ecohosting' ),
		'id'   => $prefix . 'sliderbg_color',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Check the radio button "on" to active the overlay. If you want to use global overlay then make sure you have selected the "Common Page Header Overlay" chackbox from the theme options. ', 'ecohosting' ),
		'id'   => $prefix . 'sliderbg_overlay',
		'type' => 'radio_inline',
        'options' => array(
            'on'     => 'On',
            'global' => 'Global',
            'none'   => 'None',
        )
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Slider Speed', 'ecohosting' ),
		'desc' => esc_html__( 'Set slider speed. Default slider speed 4000.', 'ecohosting' ),
		'id'   => $prefix . 'slide_speed',
		'type' => 'text',
	) );
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'slider-group-field',
		'type'        => 'group',
		'description' => esc_html__( 'Add Slider', 'ecohosting' ),
		'options'     => array(
			'group_title'   => esc_html__( 'Slider {#}', 'ecohosting' ), // {#} gets replaced by row number
			'add_button'    => esc_html__( 'Add Slider', 'ecohosting' ),
			'remove_button' => esc_html__( 'Remove Slider', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
		),
	) );
    
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'desc' => esc_html__( 'Slider Left side content title.', 'ecohosting' ),
		'id'   => $prefix . 'slider-title',
		'type' => 'text',
	) );
    
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Slider Nav Icon', 'ecohosting' ),
		'id'   => $prefix . 'slider-nav-icon',
        'desc' => esc_html__( 'Set slider nav icon use font awesome icon class like ( fa-hdd-o ). ', 'ecohosting' ),
		'type' => 'text',
	) );
    
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Content', 'ecohosting' ),
		'desc' => esc_html__( 'Slider left side content', 'ecohosting' ),
		'id'   => $prefix . 'slider-content',
		'type' => 'wysiwyg',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'List Content', 'ecohosting' ),
		'desc' => esc_html__( 'Slider left side content', 'ecohosting' ),
		'id'   => $prefix . 'slider-listcontent',
		'type' => 'text',
		'repeatable' => true
	) );
    
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Button Text', 'ecohosting' ),
		'id'   => $prefix . 'sliderbtn-text',
		'type' => 'text',
	) );
    
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Button Url', 'ecohosting' ),
		'id'   => $prefix . 'slidebtn_url',
		'type' => 'text_url',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name'    => esc_html__( 'Content Background Color', 'ecohosting' ),
		'id'      => $prefix . 'slide-contbg-color',
		'type'    => 'colorpicker',
		'default' => '#6aaf08'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Image', 'ecohosting' ),
		'id'   => $prefix . 'slider-img',
		'type' => 'file',
	) );
    
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Badge One Title', 'ecohosting' ),
		'id'   => $prefix . 'slider-badge1-title',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Badge One Discount  ', 'ecohosting' ),
		'id'   => $prefix . 'slider-badge1-discount',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Badge One Offer Tag ', 'ecohosting' ),
		'id'   => $prefix . 'slider-badge1-offer',
		'type' => 'text',
	) );
    
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Badge Two Title', 'ecohosting' ),
		'id'   => $prefix . 'slider-badge2-title',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Badge Two Price', 'ecohosting' ),
		'id'   => $prefix . 'slider-badge2-price',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Badge Two Duration', 'ecohosting' ),
		'id'   => $prefix . 'slider-badge2-duration',
		'type' => 'text',
	) );
    
    /***************************\
        Flat Content section 
    \***************************/
	$ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'flat-content_section',
		'title'         => esc_html__( 'Flat Content', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'flat-content_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'flatContent-sectTitle',
        'classes' => 'flatContent-content',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Content Box', 'ecohosting' ),
		'id'   => $prefix . 'flatContent-box',
        'classes' => 'flatContent-content',
		'type' => 'wysiwyg',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background', 'ecohosting' ),
		'id'   => $prefix . 'flatContent-bgimg',
        'classes' => 'flatContent-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'id'   => $prefix . 'flatContent-bgColor',
        'classes' => 'flatContent-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name'    => esc_html__( 'Ovarlay', 'ecohosting' ),
		'id'      => $prefix . 'flatContent-overlay',
        'classes' => 'flatContent-media',
		'type'    => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name'    => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc'    => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'      => $prefix . 'flatContent_overlaycolor',
        'classes' => 'flatContent-media',
		'type'    => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name'    => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc'    => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'      => $prefix . 'flatContent_overlayopacity',
        'classes' => 'flatContent-media',
		'type'    => 'text_small',
        'desc'    => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name'    => esc_html__( 'Text Color', 'ecohosting' ),
		'id'      => $prefix . 'flatContent-TextColor',
        'classes' => 'flatContent-media',
		'type'    => 'colorpicker',
	) );
	
    
    /*****************************\
        Flat One Content section 
    \*****************************/
	$ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'flat-content-one_section',
		'title'         => esc_html__( 'Flat One Content', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'flat-contentone_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'    => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'flatContentone-sectTitle',
        'classes' => 'flatContentone-content',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Content Box', 'ecohosting' ),
		'id'   => $prefix . 'flatContentone-box',
        'classes' => 'flatContentone-content',
		'type' => 'wysiwyg',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background', 'ecohosting' ),
		'id'   => $prefix . 'flatContentone-bgimg',
        'classes' => 'flatContentone-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'id'   => $prefix . 'flatContentone-bgColor',
        'classes' => 'flatContentone-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name'    => esc_html__( 'Ovarlay', 'ecohosting' ),
		'id'      => $prefix . 'flatContentone-overlay',
        'classes' => 'flatContentone-media',
		'type'    => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name'    => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc'    => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'      => $prefix . 'flatContentone_overlaycolor',
        'classes' => 'flatContentone-media',
		'type'    => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name'    => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc'    => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'      => $prefix . 'flatContentone_overlayopacity',
        'classes' => 'flatContentone-media',
		'type'    => 'text_small',
        'desc'    => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name'    => esc_html__( 'Text Color', 'ecohosting' ),
		'id'      => $prefix . 'flatContentone-TextColor',
        'classes' => 'flatContentone-media',
		'type'    => 'colorpicker',
	) );
	
    /***************************\
        Domain Search section 
    \***************************/
    
	$ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'domainSearch_section',
		'title'         => esc_html__( 'Domain Search Section', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'domainSearch_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Form Action URL', 'ecohosting' ),
		'desc' => esc_html__( 'Domain search form action url', 'ecohosting' ),
        'classes' => 'dom_search-content',
		'id'   => $prefix . 'dom_search_acturl',
		'type' => 'text_url',
	) );
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'domafdfdfin-search-tag',
		'type'        => 'group',
		'description' => esc_html__( 'Add Domain Search Tag', 'ecohosting' ),
        'classes' => 'dom_search-content',
        'repeatable' => false,
		'options'     => array(
			'group_title'   => esc_html__( 'Domain Search Tag', 'ecohosting' ), // {#} gets replaced by row number
			'sortable'      => false, // beta
			'closed'     => false, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Domain Seaerch Tag Title Top ', 'ecohosting' ),
		'id'   => $prefix . 'dom-search-tag-top',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Domain Search Tag Title Buttom', 'ecohosting' ),
		'id'   => $prefix . 'dom-search-tag-buttom',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name'       => esc_html__( 'Offer Tag', 'ecohosting' ),
		'id'         => $prefix . 'dom-offer-tag',
        'classes' => 'dom_search-content',
        'type'       => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name'       => esc_html__( 'Search Extension', 'ecohosting' ),
		'desc'       => esc_html__( 'Search domain extension', 'ecohosting' ),
		'id'         => $prefix . 'search-domain-extension',
        'classes' => 'dom_search-content',
        'type'       => 'text',
        'repeatable' => true
	) );
    // Domain Extension
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'dom-extension',
		'type'        => 'group',
		'description' => esc_html__( 'Add Domain Extension', 'ecohosting' ),
        'classes' => 'dom_search-content',
		'options'     => array(
			'group_title'   => esc_html__( 'Domain Extension {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Extension', 'ecohosting' ),
            'remove_button' => __( 'Remove Extension', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Extension Name', 'ecohosting' ),
		'id'   => $prefix . 'extension-name',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Extension Price', 'ecohosting' ),
		'id'   => $prefix . 'extension-price',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Duration', 'ecohosting' ),
		'id'   => $prefix . 'extension-duration',
		'type' => 'text',
	) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'dom_search-bgcolor',
        'classes' => 'dom_search-media',
		'type' => 'colorpicker',
	) );

    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set text color', 'ecohosting' ),
        'classes' => 'dom_search-media',
		'id'   => $prefix . 'dom_search_textcolor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Tag Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set tag text color', 'ecohosting' ),
        'classes' => 'dom_search-media',
		'id'   => $prefix . 'dom_search_tagtextcolor',
		'type' => 'colorpicker',
	) );
    
    
    /******************\
      Features section 
    \******************/
    
	$ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'features_section',
		'title'         => esc_html__( 'Features Section', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'features_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title ', 'ecohosting' ),
        'classes' => 'feature-section-content',
		'id'   => $prefix . 'feature-section-title',
		'type' => 'text',
	) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Feature Image', 'ecohosting' ),
		'id'   => $prefix . 'feature-img',
        'classes' => 'feature-section-content',
		'type' => 'file',
	) );
    
    // feature group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'group-feature',
		'type'        => 'group',
		'description' => esc_html__( 'Add Your Service Feature', 'ecohosting' ),
        'classes' => 'feature-section-content',
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Feature {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Feature', 'ecohosting' ),
            'remove_button' => __( 'Remove Feature', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Image', 'ecohosting' ),
		'id'   => $prefix . 'feature-image-icon',
		'type' => 'file',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Icon', 'ecohosting' ),
		'id'   => $prefix . 'feature-icon',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'id'   => $prefix . 'feature-title',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Descriptions', 'ecohosting' ),
		'id'   => $prefix . 'feature-descriptions',
		'type' => 'textarea',
	) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'feature_bgimg',
        'classes' => 'feature-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'feature-bgcolor',
        'classes' => 'feature-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'feature_overlay',
        'classes' => 'feature-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'feature_overlaycolor',
        'classes' => 'feature-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'feature_overlayopacity',
        'classes' => 'feature-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set text color', 'ecohosting' ),
        'classes' => 'feature-media',
		'id'   => $prefix . 'feature_textsectcolor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Icon Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set icon color', 'ecohosting' ),
        'classes' => 'feature-media',
		'id'   => $prefix . 'feature_iconcolor',
		'type' => 'colorpicker',
	) );
    
    /******************\
       single feature
    \******************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'single-features_section',
		'title'         => esc_html__( 'Single Features Section', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    // single feature group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'single-features',
		'type'        => 'group',
		'description' => esc_html__( 'Add Your single Service Feature', 'ecohosting' ),
        'classes' => 'single-features-content',
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Feature {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Feature', 'ecohosting' ),
            'remove_button' => __( 'Remove Feature', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Image', 'ecohosting' ),
		'id'   => $prefix . 'single-feature-image',
		'type' => 'file',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Image Position', 'ecohosting' ),
		'id'   => $prefix . 'single-featurebg-position',
		'type' => 'radio_inline',
        'options' => array(
            'right'  => 'Right',
            'left'   => 'Left'
        ),
        'default'   => 'right'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'id'   => $prefix . 'single-feature-title',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Descriptions', 'ecohosting' ),
		'id'   => $prefix . 'single-feature-descriptions',
		'type' => 'textarea',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Button Text', 'ecohosting' ),
		'id'   => $prefix . 'single-feature-btnText',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Button URL', 'ecohosting' ),
		'id'   => $prefix . 'single-feature-btnUrl',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Media Settings', 'ecohosting' ),
		'id'   => $prefix . 'single-feature-divider',
        'classes' => 'meta-divider',
		'type' => 'title'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Background', 'ecohosting' ),
		'id'   => $prefix . 'single-feature-bg',
		'type' => 'file',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'single-feature-bgcolor',
        'classes' => 'single-feature-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'single-feature_overlay',
        'classes' => 'counter-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set text color', 'ecohosting' ),
        'classes' => 'single-feature-media',
		'id'   => $prefix . 'single-feature_textcolor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set title color', 'ecohosting' ),
        'classes' => 'single-feature-media',
		'id'   => $prefix . 'single-feature_titlecolor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Button Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set button text color', 'ecohosting' ),
        'classes' => 'single-feature-media',
		'id'   => $prefix . 'single-feature_btncolor',
		'type' => 'colorpicker',
	) );
    
    
    /******************\
           Counter
    \******************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'counter_section',
		'title'         => esc_html__( 'Counter Section', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'counter_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    
    // counter feature group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'counter-options',
		'type'        => 'group',
		'description' => esc_html__( 'Add counter content', 'ecohosting' ),
        'classes' => 'counter-content',
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'counter {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add counter', 'ecohosting' ),
            'remove_button' => __( 'Remove counter', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'image', 'ecohosting' ),
		'id'   => $prefix . 'counter-image',
		'type' => 'file',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Icon', 'ecohosting' ),
		'id'   => $prefix . 'counter-icon',
        'desc' => esc_html__( 'Set slider nav icon use font awesome icon class like ( fa-hdd-o ). ', 'ecohosting' ),
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'id'   => $prefix . 'counter-title',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Count Number', 'ecohosting' ),
		'id'   => $prefix . 'counter-number',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background', 'ecohosting' ),
		'id'   => $prefix . 'counter-bg',
        'classes' => 'counter-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'counter-bgcolor',
        'classes' => 'counter-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'counter_overlay',
        'classes' => 'counter-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'counter_overlaycolor',
        'classes' => 'counter-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'counter_overlayopacity',
        'classes' => 'counter-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set text color', 'ecohosting' ),
        'classes' => 'counter-media',
		'id'   => $prefix . 'counter_textsectcolor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Icon Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set icon color', 'ecohosting' ),
        'classes' => 'counter-media',
		'id'   => $prefix . 'counter_iconcolor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Icon Box Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set icon box color', 'ecohosting' ),
        'classes' => 'counter-media',
		'id'   => $prefix . 'counter_iconboxColor',
		'type' => 'colorpicker',
	) );
    /******************\
        certificate
    \******************/
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'certificate_section',
		'title'         => esc_html__( 'Certificate Section', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'certificate_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'id'   => $prefix . 'certificate-title',
        'classes' => 'certificate-content',
		'type' => 'text',
	) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Certificate Picture', 'ecohosting' ),
		'id'   => $prefix . 'certificate-picture',
        'classes' => 'certificate-content',
		'type' => 'file_list',
	) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'certificate_bgimg',
        'classes' => 'certificate-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'certificate-bgcolor',
        'classes' => 'certificate-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'certificate_overlay',
        'classes' => 'certificate-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'certificate_overlaycolor',
        'classes' => 'certificate-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'certificate_overlayopacity',
        'classes' => 'certificate-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set text color', 'ecohosting' ),
        'classes' => 'certificate-media',
		'id'   => $prefix . 'certificate_textsectcolor',
		'type' => 'colorpicker',
	) );
   
    
    /******************\
        testimonial
    \******************/
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'testimonial_section',
		'title'         => esc_html__( 'Testimonial Section', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'testimonial_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'testimonial-title',
        'classes' => 'testimonial-content',
		'type' => 'text',
	) );
    
    // counter feature group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'testimonial-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add testimonial content', 'ecohosting' ),
        'classes' => 'testimonial-content',
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'testimonial {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add testimonial', 'ecohosting' ),
            'remove_button' => __( 'Remove testimonial', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Picture', 'ecohosting' ),
		'id'   => $prefix . 'testimonial-image',
		'type' => 'file',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Name', 'ecohosting' ),
		'id'   => $prefix . 'testimonial-name',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Company', 'ecohosting' ),
		'id'   => $prefix . 'testimonial-company',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Descriptions', 'ecohosting' ),
		'id'   => $prefix . 'testimonial-descriptions',
		'type' => 'textarea',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background', 'ecohosting' ),
		'id'   => $prefix . 'testimonial-bg',
        'classes' => 'testimonial-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'testimonial-bgcolor',
        'classes' => 'testimonial-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Image Border Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set image border color', 'ecohosting' ),
		'id'   => $prefix . 'testimonial_bordercolor',
        'classes' => 'testimonial-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'testimonial_overlay',
        'classes' => 'testimonial-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'testimonial_overlaycolor',
        'classes' => 'testimonial-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'testimonial_overlayopacity',
        'classes' => 'testimonial-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title color', 'ecohosting' ),
        'classes' => 'testimonial-media',
		'id'   => $prefix . 'testimonial_sectTitleColor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set text color', 'ecohosting' ),
        'classes' => 'testimonial-media',
		'id'   => $prefix . 'testimonial_textsectcolor',
		'type' => 'colorpicker',
	) );

    /******************\
        Brand
    \******************/
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'brand_section',
		'title'         => esc_html__( 'Brand Section', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'brand_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Brand Picture', 'ecohosting' ),
		'id'   => $prefix . 'brand-image',
        'classes' => 'brand-content',
		'type' => 'file_list',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'brand_bgimg',
        'classes' => 'brand-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'brand-bgcolor',
        'classes' => 'brand-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Border Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set border color', 'ecohosting' ),
		'id'   => $prefix . 'brand_bordercolor',
        'classes' => 'brand-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'brand_overlay',
        'classes' => 'brand-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'brand_overlaycolor',
        'classes' => 'brand-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'brand_overlayopacity',
        'classes' => 'brand-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );

    
    /******************\
            FAQ
    \******************/
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'faq_section',
		'title'         => esc_html__( 'FAQ', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'faq_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'faq-section-title',
        'classes' => 'faq-section-content',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Left Side Image', 'ecohosting' ),
		'id'   => $prefix . 'faq-image',
        'classes' => 'faq-section-content',
		'type' => 'file',
	) );
    $ecohost_meta->add_field(  array(
        'name'           => esc_html__( 'Faq Category', 'ecohosting' ),
        'desc'           => esc_html__( 'Set Faq category.', 'ecohosting' ),
        'classes'        => 'faq-section-content',
        'id'             => $prefix . 'faq-taxonoy',
        'type'           => 'select',
        // Use a callback to avoid performance hits on pages where this field is not displayed (including the front-end).
        'options_cb'     => 'ecohost_get_term_options',
        // Same arguments you would pass to `get_terms`.
        'get_terms_args' => array(
            'taxonomy'   => 'faq-categories',
            'hide_empty' => false,
            ),
    ) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'faq_bgimg',
        'classes' => 'faq-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'faq-bgcolor',
        'classes' => 'faq-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'faq_overlay',
        'classes' => 'faq-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'faq_overlaycolor',
        'classes' => 'faq-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'faq_overlayopacity',
        'classes' => 'faq-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set title color', 'ecohosting' ),
        'classes' => 'faq-media',
		'id'   => $prefix . 'faq_textsectcolor',
		'type' => 'colorpicker',
	) );  
    
    /******************\
            Team
    \******************/
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'team_section',
		'title'         => esc_html__( 'Team', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'team_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'team-section-title',
        'classes' => 'team-content',
		'type' => 'text',
	) );
    
    
    // team member content group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'team-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add team member content', 'ecohosting' ),
        'classes' => 'team-content',
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Member {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Member', 'ecohosting' ),
            'remove_button' => __( 'Remove Member', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Picture', 'ecohosting' ),
		'id'   => $prefix . 'team-member-image',
		'type' => 'file',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Name', 'ecohosting' ),
		'id'   => $prefix . 'team-member-name',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Designation', 'ecohosting' ),
		'id'   => $prefix . 'team-member-designation',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Facebook URL', 'ecohosting' ),
		'id'   => $prefix . 'team-fb-url',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Twitter URL', 'ecohosting' ),
		'id'   => $prefix . 'team-tw-url',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Google Plus URL', 'ecohosting' ),
		'id'   => $prefix . 'team-gp-url',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Linkedin URL', 'ecohosting' ),
		'id'   => $prefix . 'team-link-url',
		'type' => 'text',
	) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'team_bgimg',
        'classes' => 'team-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'team-bgcolor',
        'classes' => 'team-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Social Border Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set socail border color', 'ecohosting' ),
		'id'   => $prefix . 'team_bordercolor',
        'classes' => 'team-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'team_overlay',
        'classes' => 'team-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'team_overlaycolor',
        'classes' => 'team-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'team_overlayopacity',
        'classes' => 'team-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title color', 'ecohosting' ),
        'classes' => 'team-media',
		'id'   => $prefix . 'team_textsectcolor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Name Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set name text color', 'ecohosting' ),
        'classes' => 'team-media',
		'id'   => $prefix . 'team_nameColor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Designation Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set designation text color', 'ecohosting' ),
        'classes' => 'team-media',
		'id'   => $prefix . 'team_desiColor',
		'type' => 'colorpicker',
	) );

    /******************\
          History
    \******************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'history_section',
		'title'         => esc_html__( 'History', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'history_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'history-section-title',
        'classes' => 'history-content',
		'type' => 'text',
	) );
    
    
    // history content group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'history-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add history content', 'ecohosting' ),
        'classes' => 'history-content',
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'History {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add History', 'ecohosting' ),
            'remove_button' => __( 'Remove History', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Year ', 'ecohosting' ),
		'id'   => $prefix . 'history-year',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Descriptions', 'ecohosting' ),
		'id'   => $prefix . 'history-descriptions',
		'type' => 'textarea',
	) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'history_bgimg',
        'classes' => 'history-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'history-bgcolor',
        'classes' => 'history-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'history_overlay',
        'classes' => 'history-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'history_overlaycolor',
        'classes' => 'history-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'history_overlayopacity',
        'classes' => 'history-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title color', 'ecohosting' ),
        'classes' => 'history-media',
		'id'   => $prefix . 'history_sectTitlecolor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Year Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set year text color', 'ecohosting' ),
        'classes' => 'history-media',
		'id'   => $prefix . 'history_yearcolor',
		'type' => 'colorpicker',
	) );

    /******************\
     affiliate counter
    \******************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'affiliate-counter_section',
		'title'         => esc_html__( 'Affiliate Counter', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-counter_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    
    // affiliate counter content group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'affiliate-counter-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add affiliate counter content', 'ecohosting' ),
        'classes' => 'affiliate-counter-content',
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Affiliate Counter {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Counter', 'ecohosting' ),
            'remove_button' => __( 'Remove Counter', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-counter-title',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Currency', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-counter-currency',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Count Number', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-counter-number',
		'type' => 'text',
	) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-counter-bg',
        'classes' => 'afficount-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-counter-bgcolor',
        'classes' => 'afficount-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Divider Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set divider color', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-counter_bordercolor',
        'classes' => 'afficount-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-counter_overlay',
        'classes' => 'afficount-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-counter_overlaycolor',
        'classes' => 'afficount-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-counter_overlayopacity',
        'classes' => 'afficount-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set text color', 'ecohosting' ),
        'classes' => 'afficount-media',
		'id'   => $prefix . 'affiliate-counter_textcolor',
		'type' => 'colorpicker',
	) );
    
    /********************\
      affiliate-features
    \********************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'affiliate-features_section',
		'title'         => esc_html__( 'Affiliate Features', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-features_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-features-title',
        'classes' => 'affiliate-features-content',
		'type' => 'text',
	) );
    
    // affiliate features content group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'affiliate-features-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add affiliate features content', 'ecohosting' ),
        'classes' => 'affiliate-features-content',
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Affiliate Features {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Features', 'ecohosting' ),
            'remove_button' => __( 'Remove Features', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Image', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-features-img',
		'type' => 'file',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-features-title',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Descriptions', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-features-desc',
		'type' => 'textarea_small',
	) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-features_bgimg',
        'classes' => 'affifeat-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-features-bgcolor',
        'classes' => 'affifeat-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-features_overlay',
        'classes' => 'affifeat-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-features_overlaycolor',
        'classes' => 'affifeat-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-features_overlayopacity',
        'classes' => 'affifeat-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title color', 'ecohosting' ),
        'classes' => 'affifeat-media',
		'id'   => $prefix . 'affiliate-features_headingColor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set text color', 'ecohosting' ),
        'classes' => 'affifeat-media',
		'id'   => $prefix . 'affiliate-features_textcolor',
		'type' => 'colorpicker',
	) );
    
    /********************\
      affiliate pricing
    \********************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'affiliate-pricing_section',
		'title'         => esc_html__( 'Affiliate Pricing', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-pricing_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-pricing-title',
        'classes' => 'affiliate-pricing-content',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Button Text', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-pricing-btnText',
        'classes' => 'affiliate-pricing-content',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Button URL', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-pricing-btnUrl',
        'classes' => 'affiliate-pricing-content',
		'type' => 'text',
	) );
    
    // affiliate pricing content group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'affiliate-pricing-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add affiliate pricing content', 'ecohosting' ),
        'classes' => 'affiliate-pricing-content',
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Affiliate price {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add price', 'ecohosting' ),
            'remove_button' => __( 'Remove price', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Tag', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-pricing-tag',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Price', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-price',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Plan', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-pricing-plan',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-pricing_bgimg',
        'classes' => 'affipric-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-pricing-bgcolor',
        'classes' => 'affipric-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-pricing_overlay',
        'classes' => 'affipric-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-pricing_overlaycolor',
        'classes' => 'affipric-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'affiliate-pricing_overlayopacity',
        'classes' => 'affipric-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title color', 'ecohosting' ),
        'classes' => 'affipric-media',
		'id'   => $prefix . 'affiliate-pricing_sectTitcolor',
		'type' => 'colorpicker',
	) );

    /********************\
      Hosting pricing
    \********************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'hosting-pricing_section',
		'title'         => esc_html__( 'Hosting Pricing', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricing_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricing-title',
        'classes' => 'hosting-pricing-content',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Pricing Table Column', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricing-col',
        'classes' => 'hosting-pricing-content',
		'type' => 'select',
        'default'          => '3',
        'options'          => array(
            '6' => esc_html__( 'Column 2', 'ecohosting' ),
            '4' => esc_html__( 'Column 3', 'ecohosting' ),
            '3' => esc_html__( 'Column 4', 'ecohosting' ),
        ),
	) ); 
    
    $ecohost_meta->add_field(  array(
        'name'           => esc_html__( 'Hosting Category', 'ecohosting' ),
        'desc'           => esc_html__( 'Set hosting category.', 'ecohosting' ),
        'classes'        => 'hosting-pricing-content',
        'id'             => $prefix . 'hosting-cat',
        'type'           => 'select',
        // Use a callback to avoid performance hits on pages where this field is not displayed (including the front-end).
        'options_cb'     => 'ecohost_get_term_options',
        // Same arguments you would pass to `get_terms`.
        'get_terms_args' => array(
            'taxonomy'   => 'hosting-categories',
            'hide_empty' => false,
            ),
    ) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricing-bg',
        'classes' => 'hostpric-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricing-bgcolor',
        'classes' => 'hostpric-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricing_overlay',
        'classes' => 'hostpric-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricing_overlaycolor',
        'classes' => 'hostpric-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricing_overlayopacity',
        'classes' => 'hostpric-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title color', 'ecohosting' ),
        'classes' => 'hostpric-media',
		'id'   => $prefix . 'hosting-pricing_secttitleColor',
		'type' => 'colorpicker',
	) );
    
    /********************\
      Hosting pricing v2
    \********************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'hosting-pricing-v2_section',
		'title'         => esc_html__( 'Hosting Pricing Version 2', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricing-v2_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricingv2-title',
        'classes' => 'hosting-pricingv2-content',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Label', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricingv2-label',
        'classes' => 'hosting-pricingv2-content',
		'type' => 'text',
		'repeatable' => true,
	) );
    $ecohost_meta->add_field(  array(
        'name'           => esc_html__( 'Hosting Category', 'ecohosting' ),
        'desc'           => esc_html__( 'Set hosting category.', 'ecohosting' ),
        'classes'        => 'hosting-pricingv2-content',
        'id'             => $prefix . 'hostingv2-cat',
        'type'           => 'select',
        // Use a callback to avoid performance hits on pages where this field is not displayed (including the front-end).
        'options_cb'     => 'ecohost_get_term_options',
        // Same arguments you would pass to `get_terms`.
        'get_terms_args' => array(
            'taxonomy'   => 'hosting-categories',
            'hide_empty' => false,
            ),
    ) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricingv2-bg',
        'classes' => 'hostpricv2-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricingv2-bgcolor',
        'classes' => 'hostpricv2-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricingv2_overlay',
        'classes' => 'hostpricv2-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricingv2_overlaycolor',
        'classes' => 'hostpricv2-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'hosting-pricingv2_overlayopacity',
        'classes' => 'hostpricv2-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title color', 'ecohosting' ),
        'classes' => 'hostpricv2-media',
		'id'   => $prefix . 'hostpricv2_textcolor',
		'type' => 'colorpicker',
	) );
        
    /********************\
      Dedicate  pricing
    \********************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'dedicate-pricing_section',
		'title'         => esc_html__( 'Dedicate Pricing', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'dedicate-pricing_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'dedicate-pricing-title',
        'classes' => 'dedicate-pricing-content',
		'type' => 'text',
	) );
    
    $ecohost_meta->add_field(  array(
        'name'           => esc_html__( 'Dedicate Category', 'ecohosting' ),
        'desc'           => esc_html__( 'Set dedicate category.', 'ecohosting' ),
        'classes'        => 'dedicate-pricing-content',
        'id'             => $prefix . 'dedicate-cat',
        'type'           => 'select',
        // Use a callback to avoid performance hits on pages where this field is not displayed (including the front-end).
        'options_cb'     => 'ecohost_get_term_options',
        // Same arguments you would pass to `get_terms`.
        'get_terms_args' => array(
            'taxonomy'   => 'dedicate-categories',
            'hide_empty' => false,
            ),
    ) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'dedicate-pricing-bg',
        'classes' => 'dedicatepric-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'dedicate-pricing-bgcolor',
        'classes' => 'dedicatepric-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'dedicate-pricing_overlay',
        'classes' => 'dedicatepric-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'dedicate-pricing_overlaycolor',
        'classes' => 'dedicatepric-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'dedicate-pricing_overlayopacity',
        'classes' => 'dedicatepric-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title color', 'ecohosting' ),
        'classes' => 'dedicatepric-media',
		'id'   => $prefix . 'dedicate-pricing_textsectcolor',
		'type' => 'colorpicker',
	) );    
    
    /********************\
      Domain  pricing
    \********************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'domain-pricing_section',
		'title'         => esc_html__( 'Domain Pricing', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'domain-pricing_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title', 'ecohosting' ),
		'id'   => $prefix . 'domain-pricing-title',
        'classes' => 'domain-pricing-content',
		'type' => 'text',
	) );
    
    $ecohost_meta->add_field(  array(
        'name'           => esc_html__( 'Domain Category', 'ecohosting' ),
        'desc'           => esc_html__( 'Set Domain category.', 'ecohosting' ),
        'classes'        => 'domain-pricing-content',
        'id'             => $prefix . 'domain-cat',
        'type'           => 'select',
        // Use a callback to avoid performance hits on pages where this field is not displayed (including the front-end).
        'options_cb'     => 'ecohost_get_term_options',
        // Same arguments you would pass to `get_terms`.
        'get_terms_args' => array(
            'taxonomy'   => 'domain-categories',
            'hide_empty' => false,
            ),
    ) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'domain-pricing-bg',
        'classes' => 'domprice-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'domain-pricing-bgcolor',
        'classes' => 'domprice-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Border Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set Border color', 'ecohosting' ),
		'id'   => $prefix . 'domain-pricing-bordercolor',
        'classes' => 'domprice-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'domain-pricing_overlay',
        'classes' => 'domprice-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'domain-pricing_overlaycolor',
        'classes' => 'domprice-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'domain-pricing_overlayopacity',
        'classes' => 'domprice-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Table Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set table text color', 'ecohosting' ),
        'classes' => 'domprice-media',
		'id'   => $prefix . 'domain-pricing_tableTextColor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title color', 'ecohosting' ),
        'classes' => 'domprice-media',
		'id'   => $prefix . 'domain-pricing_textsectcolor',
		'type' => 'colorpicker',
	) );
    
    /********************\
      Hosting Feature
    \********************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'hosting-feature_section',
		'title'         => esc_html__( 'Hosting Feature', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    
    // affiliate pricing content group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'hosting-feature-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add hosting feature content', 'ecohosting' ),
        'classes'        => 'hosting-feature-content',
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Hosting Feature {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Hosting Feature', 'ecohosting' ),
            'remove_button' => __( 'Remove Hosting Feature', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-title',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Left Heading', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-leftHeading',
		'type' => 'text',
		'repeatable' => true
	) );
    
    // Feature One
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature One', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-one-title',
        'classes' => 'meta-divider',
		'type' => 'title'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature One Heading', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-one-head',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature One', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-one',
		'type' => 'text',
		'repeatable' => true
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature One Button Text', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-one-btntext',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature One Button URL', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-one-btnurl',
		'type' => 'text'
	) );
    
    // Feature Two
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Two', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-two-title',
        'classes' => 'meta-divider',
		'type' => 'title'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Two Heading', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-two-head',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Two', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-two',
		'type' => 'text',
		'repeatable' => true
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Two Button Text', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-two-btntext',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Two Button Text', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-two-bnturl',
		'type' => 'text'
	) );
    
    //Feature Three
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Three', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-three-title',
        'classes' => 'meta-divider',
		'type' => 'title'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Three Heading', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-three-head',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Three', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-three',
		'type' => 'text',
		'repeatable' => true
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Three Button Text', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-three-btntext',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Three Button URL', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-three-btnurl',
		'type' => 'text'
	) );
    //Feature Four
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Four', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-four-title',
        'classes' => 'meta-divider',
		'type' => 'title'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Four Heading', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-four-head',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Four', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-four',
		'type' => 'text',
		'repeatable' => true
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Four Button Text', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-four-btntext',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature Four Button URL', 'ecohosting' ),
		'id'   => $prefix . 'hostfeature-four-btnurl',
		'type' => 'text'
	) );
    
    
    
    /********************\
      Datacenter 
    \********************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'datacenter_section',
		'title'         => esc_html__( 'Datacenter', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'datacenter_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'id'   => $prefix . 'datacenter-title',
        'classes'   => 'datacenter-content',
		'type' => 'text',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Map Image', 'ecohosting' ),
		'id'   => $prefix . 'datacenter-mapimg',
        'classes'   => 'datacenter-content',
		'type' => 'file',
	) );
    
    // Datacenter content group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'datacenter-map-content',
        'classes'   => 'datacenter-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add datacenter Map Location', 'ecohosting' ),
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Location {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Location', 'ecohosting' ),
            'remove_button' => __( 'Remove Location', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Location Name', 'ecohosting' ),
		'id'   => $prefix . 'datacenter-location-name',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Top Position', 'ecohosting' ),
		'id'   => $prefix . 'datacenter-location-postop',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Left Position', 'ecohosting' ),
		'id'   => $prefix . 'datacenter-location-posleft',
		'type' => 'text'
	) );
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ecohosting' ),
		'desc' => esc_html__( 'Set background image', 'ecohosting' ),
		'id'   => $prefix . 'datacenter-bg',
        'classes' => 'datacenter-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'datacenter-bgcolor',
        'classes' => 'datacenter-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'datacenter_overlay',
        'classes' => 'datacenter-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'datacenter_overlaycolor',
        'classes' => 'datacenter-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'datacenter_overlayopacity',
        'classes' => 'datacenter-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title color', 'ecohosting' ),
        'classes' => 'datacenter-media',
		'id'   => $prefix . 'datacenter_secttitleColor',
		'type' => 'colorpicker',
	) );
    
    /*****************************\
      Vps pricing Slid Feature
    \*****************************/
    
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefix . 'vps_section',
		'title'         => esc_html__( 'VPS Slide', 'ecohosting' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ecohosting' ),
		'id'   => $prefix . 'vps_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ecohosting' ),
			'media'   => esc_html__( 'Media', 'ecohosting' )
		),
        'default' => 'content'
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'id'   => $prefix . 'vps-title',
        'classes'   => 'vps-content',
		'type' => 'text',
	) ); 
    
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Button Text', 'ecohosting' ),
		'id'   => $prefix . 'vps-btntext',
        'classes'   => 'vps-content',
		'type' => 'text',
	) );  
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background', 'ecohosting' ),
		'id'   => $prefix . 'vps-bg',
        'classes' => 'vps-media',
		'type' => 'file',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set background color', 'ecohosting' ),
		'id'   => $prefix . 'vps-bgcolor',
        'classes' => 'vps-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay', 'ecohosting' ),
		'id'   => $prefix . 'vps_overlay',
        'classes' => 'vps-media',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay color', 'ecohosting' ),
		'id'   => $prefix . 'vps_overlaycolor',
        'classes' => 'vps-media',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ecohosting' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ecohosting' ),
		'id'   => $prefix . 'vps_overlayopacity',
        'classes' => 'vps-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ecohosting' ),
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set section title color', 'ecohosting' ),
        'classes' => 'vps-media',
		'id'   => $prefix . 'vps_secttitleColor',
		'type' => 'colorpicker',
	) );
    $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ecohosting' ),
		'desc' => esc_html__( 'Set text color', 'ecohosting' ),
        'classes' => 'vps-media',
		'id'   => $prefix . 'vps_textColor',
		'type' => 'colorpicker',
	) );
    
    // Vps pricing Slid tag name and image content group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'vpsslid-tag-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add VPS Slide Tag and image', 'ecohosting' ),
        'classes'   => 'vps-content',
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Tag  {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Tag', 'ecohosting' ),
            'remove_button' => __( 'Remove Tag', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Name', 'ecohosting' ),
		'id'   => $prefix . 'vps-tag-name',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Image', 'ecohosting' ),
		'id'   => $prefix . 'vps-tag-img',
		'type' => 'file'
	) );
    

    
    
    
    /***************************************************************\
                            Post type meta
    \***************************************************************/
    
    // FAQ
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefixtype . 'faq_post_type',
		'title'         => esc_html__( 'FAQ', 'ecohosting' ),
		'object_types'  => array( 'faq' ), // Post type
        'closed'        => true
	) );
    
    // counter feature group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'faq-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add FAQ Content', 'ecohosting' ),
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'FAQ {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add FAQ', 'ecohosting' ),
            'remove_button' => __( 'Remove FAQ', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'id'   => $prefix . 'faq-title',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Faq Content', 'ecohosting' ),
		'id'   => $prefix . 'faq-desc',
		'type' => 'textarea',
	) );
    
    
    // Hosting pricing
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefixtype . 'hosting_price',
		'title'         => esc_html__( 'Hosting Price', 'ecohosting' ),
		'object_types'  => array( 'hosting-price' ), // Post type
        'closed'        => true
	) );


    // Hosting pricing group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'hosting-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add Hosting Pricing Table', 'ecohosting' ),
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Pricing Table {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Pricing Table', 'ecohosting' ),
            'remove_button' => __( 'Remove Pricing Table', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Sub Title', 'ecohosting' ),
		'id'   => $prefix . 'hosting-subtitle',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Title', 'ecohosting' ),
		'id'   => $prefix . 'hosting-title',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Price', 'ecohosting' ),
		'id'   => $prefix . 'hosting-price',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Duration', 'ecohosting' ),
		'id'   => $prefix . 'hosting-duration',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Active', 'ecohosting' ),
		'id'   => $prefix . 'hosting-active',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Popular Indicator', 'ecohosting' ),
		'id'   => $prefix . 'hosting-popular-indicat',
		'type' => 'checkbox',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Button Text', 'ecohosting' ),
		'id'   => $prefix . 'hosting-btntext',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Button URL', 'ecohosting' ),
		'id'   => $prefix . 'hosting-url',
		'type' => 'text',
	) );
    
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature', 'ecohosting' ),
		'id'   => $prefix . 'hosting-feature',
		'type' => 'text',
		'repeatable' => true,
	) );
    
    // Dedicated Pricing
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefixtype . 'dedicated_post_type',
		'title'         => esc_html__( 'Dedicated', 'ecohosting' ),
		'object_types'  => array( 'dedicate-pricing' ), // Post type
        'closed'        => true
	) );
        $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Set Table Heading', 'ecohosting' ),
		'id'   => $prefix . 'dedicated-table-heading',
		'type' => 'text',
		'repeatable' => true,
	) );
    // Dedicated feature group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'dedicated-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add dedicate pricing table features', 'ecohosting' ),
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Pricing Table {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Pricing Table', 'ecohosting' ),
            'remove_button' => __( 'Remove Pricing Table', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature', 'ecohosting' ),
		'id'   => $prefix . 'dedicated-feature',
		'type' => 'text',
		'repeatable' => true
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Button Text', 'ecohosting' ),
		'id'   => $prefix . 'dedicated-btntext',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Button URL', 'ecohosting' ),
		'id'   => $prefix . 'dedicated-btnurl',
		'type' => 'text',
	) );
    
    // Domain Pricing
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefixtype . 'domain_post_type',
		'title'         => esc_html__( 'Domain', 'ecohosting' ),
		'object_types'  => array( 'domain-pricing' ), // Post type
        'closed'        => true
	) );
        $ecohost_meta->add_field( array(
		'name' => esc_html__( 'Set Table Heading', 'ecohosting' ),
		'id'   => $prefix . 'domain-table-heading',
		'type' => 'text',
		'repeatable' => true,
	) );
    // Domain feature group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'domain-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add domain pricing table features', 'ecohosting' ),
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Pricing Table {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Pricing Table', 'ecohosting' ),
            'remove_button' => __( 'Remove Pricing Table', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Feature', 'ecohosting' ),
		'id'   => $prefix . 'domain-feature',
		'type' => 'text',
		'repeatable' => true
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Button Text', 'ecohosting' ),
		'id'   => $prefix . 'domain-btntext',
		'type' => 'text',
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Button URL', 'ecohosting' ),
		'id'   => $prefix . 'domain-btnurl',
		'type' => 'text',
	) );
    
    // Vps 
    $ecohost_meta = new_cmb2_box( array(
		'id'            => $prefixtype . 'vps_post_type',
		'title'         => esc_html__( 'VPS Plan', 'ecohosting' ),
		'object_types'  => array( 'vpsslide' ), // Post type
        'closed'        => true
	) );
    
    // Vps pricing Slid plan content group
    $group_field_id = $ecohost_meta->add_field( array(
		'id'          => $prefix . 'vpsslid-plan-content',
		'type'        => 'group',
		'description' => esc_html__( 'Add VPS Slide Plan', 'ecohosting' ),
        'repeatable' => true,
		'options'     => array(
			'group_title'   => esc_html__( 'Plan  {#}', 'ecohosting' ), // {#} gets replaced by row number
            'add_button'    => __( 'Add Plan', 'ecohosting' ),
            'remove_button' => __( 'Remove Plan', 'ecohosting' ),
			'sortable'      => false, // beta
			'closed'     => true, // true to have the groups closed by default
            
            
		),
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Plan Name', 'ecohosting' ),
		'id'   => $prefix . 'vps_plan_name',
		'type' => 'text'
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Plan Feature', 'ecohosting' ),
		'id'   => $prefix . 'vps_plan_feature',
		'type' => 'text',
		'repeatable' => true
	) );
    $ecohost_meta->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Plan Button URL', 'ecohosting' ),
		'id'   => $prefix . 'vps_plan_btnurl',
		'type' => 'text'
	) );
    
}

