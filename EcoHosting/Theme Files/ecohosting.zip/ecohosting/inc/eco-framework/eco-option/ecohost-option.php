<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "ecohost_opt";

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    $sampleHTML = '';
    if ( file_exists( get_template_directory() . '/info-html.html' ) ) {
        Redux_Functions::initWpFilesystem();

        global $wp_filesystem;

        $sampleHTML = $wp_filesystem->get_contents( get_template_directory(). '/info-html.html' );
    }


    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'EcoHosting Options', 'ecohosting' ),
        'page_title'           => esc_html__( 'EcoHosting Options', 'ecohosting' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */


    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'ecohosting' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'ecohosting' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'ecohosting' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'ecohosting' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'ecohosting' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */

    /*

        As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


     */
     
    // Themelooks customize Fields

    // -> START General Fields

    Redux::setSection( $opt_name, array(
        'title'            => __( 'General', 'ecohosting' ),
        'id'               => 'eco_general',
        'customizer_width' => '450px',
        'icon'             => 'el el-cog',
        'fields'           => array(
            
            array(
                'id'       => 'eco_display_preloader',
                'type'     => 'switch',
                'title'    => __( 'Display Preloader', 'ecohosting' ),
                'subtitle' => __( 'Switch On to Display Preloader', 'ecohosting' ),
                'default'  => true,
            ),
            array(
                'id'       => 'eco_enable_breadcrumb',
                'type'     => 'switch',
                'title'    => __( 'Page breadcrumb Hide', 'ecohosting' ),
                'subtitle' => __( 'Hide breadcrumb from page header', 'ecohosting' ),
                'default'  => '1',
            ),
            array(
                'id'          => 'eco_ecohost_body_fonts',
                'type'        => 'typography', 
                'title'       => __('Body Typography', 'ecohosting'),
                'google'      => true, 
                'font-backup' => true,
                'output'      => array( 'body', 'p' ),
                'units'       =>'px',
                'subtitle'    => __('Typography option with each property can be called individually.', 'ecohosting'),
                'text-align'  => false,
                'line-height' => false,
                'font-backup' => false,
                'color'       => false,
                'font-size'   => false,
                'subsets'     => false,
                'line-height' => false,
                'default'     => array(
                    'font-family' => 'Roboto', 
                    'google'      => true,
                ),
            ),
            array(
                'id'          => 'eco_ecohost_header_fonts',
                'type'        => 'typography', 
                'title'       => __('Heading Typography', 'ecohosting'),
                'google'      => true, 
                'font-backup' => true,
                'output'      => array('h1', 'h2', 'h3', 'h4', 'h5', 'h6', '.whmcs-template-five h1', '.whmcs-template-five h2', '.whmcs-template-five h3', '.whmcs-template-five h4', '.whmcs-template-five h5', '.whmcs-template-five h6' ),
                'units'       => 'px',
                'subtitle'    => __('Typography option with each property can be called individually.', 'ecohosting'),
                'text-align'  => false,
                'line-height' => false,
                'font-backup' => false,
                'color'       => false,
                'font-size'   => false,
                'subsets'     => false,
                'line-height' => false,
                'default'     => array(
                    'font-family' => 'Roboto', 
                    'google'      => true,

                ),
            ),

            array(
                'id'       => 'unlimited-color',
                'type'     => 'color',
                'title'    => __('Custom Theme Color', 'ecohosting'), 
                'subtitle' => __('Pick a unlimited mian color for the theme (default: #6aaf08).', 'ecohosting'),
                'default'  => '#6aaf08',
                'validate' => 'color'
            ),         
        )
    ) );
    
    /* End General Fields */


    
    // -> START Header

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Header', 'ecohosting'),
        'id'         => 'eco_header_option',
        'icon'       => 'el el-credit-card',
        'fields'     => array(      
            array(
                'id'       => 'eco_display_headerTop',
                'type'     => 'switch',
                'title'    => __( 'Display Header Top', 'ecohosting' ),
                'subtitle' => __( 'Switch On to Display header top', 'ecohosting' ),
                'default'  => true,
            ),
            array(
                'id'       => 'eco_header_tel',
                'type'     => 'text',
                'title'    => __( 'Phone Number', 'ecohosting' ),
                'subtitle' => __( 'Set phone number', 'ecohosting' ),
                'default'  =>'+4440000000',
                'required' => array( 'eco_display_headerTop', 'equals', 1 )
            ),
            array(
                'id'       => 'eco_header_email',
                'type'     => 'text',
                'title'    => __( 'Email', 'ecohosting' ),
                'subtitle' => __( 'Set email', 'ecohosting' ),
                'default'  => 'example@example.com',
                'required' => array( 'eco_display_headerTop', 'equals', 1 )
            ),
            array(
                'id'       => 'eco_headerTop_bg',
                'type'     => 'background',
                'output'   => array('.menu--topbar' ),
                'title'    => __( 'Header Top Background', 'ecohosting' ),
                'subtitle' => __( 'Set header top background color', 'ecohosting' ),
                'default'  => array(
                    'background-color' => '#303030',
                ),
                'required' => array( 'eco_display_headerTop', 'equals', 1 )
            ),
            array(
                'id'       => 'eco_headerTop_color',
                'type'     => 'link_color',
                'output'   => array('.menu-topbar--contact > ul > li > a', '.menu-topbar--social > li > a'),
                'title'    => __( 'Header Top Text Color', 'ecohosting' ),
                'subtitle' => __( 'Set header top text and hover color.', 'ecohosting' ),
                'active'   => false,
                'default'  => array(
                    'regular' => '#303030',
                    'hover' => '#303030',
                ),
                'required' => array( 'eco_display_headerTop', 'equals', 1 )
            ),
            array(
                'id'       => 'eco_site_logo',
                'type'     => 'media',
                'url'      => true,
                'title'    => __( 'Logo', 'ecohosting' ),
                'compiler' => 'true',
                'subtitle' => __( 'Upload your site logo for header Version one (recommendation png format)', 'ecohosting' ),
            ),
            array(
                'id'       => 'eco_site_logoretina',
                'type'     => 'media',
                'url'      => true,
                'title'    => __( 'Logo Retina Version', 'ecohosting' ),
                'compiler' => 'true',
                'subtitle' => __( 'Upload your site logo retina version.', 'ecohosting' ),
            ),
            array(
                'id'       => 'eco_site_logo_dimensions',
                'type'     => 'dimensions',
                'output'   => array( '.navbar-brand > img' ),
                'units'    => array('em','px','%'),
                'title'    => __('Logo Dimensions (Width/Height).', 'ecohosting'),
                'subtitle' => __('Set logo dimensions to choose width, height, and unit.', 'ecohosting'),
                'default'  => array(
                    'Width'   => '100', 
                    'Height'  => '50'
                ),
            ),
            array(
                'id'       => 'eco_site_title',
                'type'     => 'text',
                'validate' => 'html',
                'title'    => __( 'Text Logo', 'ecohosting' ),
                'subtitle' => __( 'Write your logo text use as logo ( You can use span tag for text color)', 'ecohosting' ),
                'default'  => __( '<span><i class="fa fa-tree"></i>Eco</span>Hosting','ecohosting' ),
            ),
            array(
                'id'          => 'eco_support_info',
                'type'        => 'slides',
                'title'       => __( 'Support Info', 'ecohosting' ),
                'subtitle'    => __( 'Add support info.', 'ecohosting' ),
                'show'        => array( 
                    'title'          => true,
                    'description'    => true,
                    'progress'       => false,
                    'icon'           => true,
                    'facts-title1'   => false,
                    'facts-title2'   => false,
                    'facts-number-2' => false,
                    'facts-title3'   => false,
                    'facts-number-3' => false,
                    'facts-number'   => false,
                    'url'            => false,
                    'image_upload'   => true,
                )
            ),
            array(
                'id'       => 'eco_display_headerCustomBtn',
                'type'     => 'switch',
                'title'    => __( 'Display Header Custom Button', 'ecohosting' ),
                'subtitle' => __( 'Switch On to Display header custom button', 'ecohosting' ),
                'default'  => true,
            ),            
            array(
                'id'    => 'eco_header_customBtn',
                'type'  => 'text',
                'title'  => __( 'Custom Button Text', 'ecohosting' ),
                'subtitle' => __( 'Set main menu custom button text', 'ecohosting' ),
                'default'=> 'Client Area',
                'required' => array( 'eco_display_headerCustomBtn', 'equals', 1 )
            ), 
            array(
                'id'    => 'eco_header_customBtnUrl',
                'type'  => 'text',
                'title'  => __( 'Custom Button Url', 'ecohosting' ),
                'subtitle' => __( 'Set main menu custom button url', 'ecohosting' ),
                'default'=> '#',
                'required' => array( 'eco_display_headerCustomBtn', 'equals', 1 )
            ),
            array(
                'id'       => 'eco_header_menu',
                'type'     => 'background',
                'output'   => array('#secondaryMenu'),
                'title'    => __( 'Menu Background', 'ecohosting' ),
                'subtitle' => __( 'Sticky change menu background color', 'ecohosting' ),
                'default'  => array(
                    'background-color' => '#6aaf08',
                ),
                'background-repeat' => false,
                'background-attachment' => false,
                'background-position' => false,
                'background-image' => false,
                'background-size' => false,
            ), 
            array(
                'id'       => 'eco_headerMenu_color',
                'type'     => 'link_color',
                'output'   => array( '.secondary-menu-links li a' ),
                'title'    => __( 'Menu Color', 'ecohosting' ),
                'subtitle' => __( 'Set menu and hover color.', 'ecohosting' ),
                'active'   => false,
                'default'  => array(
                    'regular' => '#ffffff',
                    'hover' => '#ffffff',
                )
            ),
            array(
                'id'       => 'eco_allHeader_bg',
                'type'     => 'media',
                'title'    => __( 'Common Page Header Background', 'ecohosting' ),
                'subtitle' => __( 'Set page common header background', 'ecohosting' ),
            ), 
            array(
                'id'       => 'eco_allHeader_overlay',
                'type'     => 'checkbox',
                'title'    => __( 'Common Page Header Overlay', 'ecohosting' ),
                'subtitle' => __( 'Set page common header background Overlay', 'ecohosting' ),
            ),            
            
        ),

    ) );
    
    /* End Header */

     
    /*
    * Login Page URL Options
    */
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Login Page URL', 'ecohosting' ),
        'desc'       => __( 'Create login page for WHMCS custom login from dashboard > Pages > add new ( Select template whmcs login page )', 'ecohosting' ),
        'id'         => 'eco_login_page',
        'icon'       => 'el el-folder-open',
        'fields'     => array(

            array(
                'id'       => 'eco_loginactionUrl',
                'type'     => 'text',
                'title'    => __( 'Login Action URL', 'ecohosting' ),
                'subtitle' => __( 'Set Login form action url', 'ecohosting' ),
                'default'  => '#',                
            ),
            array(
                'id'       => 'eco_loginForgetPasswordUrl',
                'type'     => 'text',
                'title'    => __( 'Forget Password  URL', 'ecohosting' ),
                'subtitle' => __( 'Set forget password button  url', 'ecohosting' ),
                'default'  => '#',                
            ),
   
        ),
        
    ) );
    
    
    /*
    * Subscribe section options
    */
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Subscribe', 'ecohosting' ),
        'id'         => 'eco_subscribe_section',
        'icon'       => 'el el-envelope',
        'fields'     => array(
        
            array(
                'id'       => 'eco_subscribe_apikey',
                'type'     => 'text',
                'title'    => __( 'API Key', 'ecohosting' ),
                'subtitle' => __( 'Set mailchimp api key', 'ecohosting' )
            ),
            array(
                'id'       => 'eco_subscribe_listid',
                'type'     => 'text',
                'title'    => __( 'List ID', 'ecohosting' ),
                'subtitle' => __( 'Set mailchimp list id', 'ecohosting' )
            ),
        ),
        
    ) );
    
    
    /* End Section Setting Page */
    
    // -> START Blog Page

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Blog', 'ecohosting' ),
        'id'         => 'eco_blog_page',
        'icon'  => 'el el-blogger',
        'fields'     => array(
      
        
            array(
                'id'       => 'eco_blog_sidebar',
                'type'     => 'image_select',
                'title'    => __( 'Select blog layout', 'ecohosting' ),
                'subtitle' => __( 'Choose your blog sidebar layout ', 'ecohosting' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => '1 Column',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    '2' => array(
                        'alt' => '2 Column Left',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    '3' => array(
                        'alt' => '2 Column Right',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    ),

                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'eco_front_blogPost_number',
                'type'     => 'text',
                'title'    => __( 'Front Posts Number', 'ecohosting' ),
                'subtitle' => __( 'How many post you want to show blog section', 'ecohosting' ),
                'default'  => '4',
            ),
            array(
                'id'       => 'eco_front_blogPost_excerpt',
                'type'     => 'text',
                'title'    => __( 'Front Posts Excerpt', 'ecohosting' ),
                'subtitle' => __( 'How many word you want to show per post in blog section', 'ecohosting' ),
                'default'  => '30',
            ),
            array(
                'id'       => 'eco_blog_postExcerpt',
                'type'     => 'text',
                'title'    => __( 'Blog Posts Excerpt', 'ecohosting' ),
                'subtitle' => __( 'How many word you want to show per post in blog ', 'ecohosting' ),
                'default'  =>'30',
            ), 
            array(
                'id'       => 'eco_hide_shareBox',
                'type'     => 'checkbox',
                'title'    => __( 'social share box show/hide', 'ecohosting' ),
                'subtitle' => __( 'Uncheck to hide social share-box in single post view', 'ecohosting' ),
                'default'  => '1'// 1 = on | 0 = off
            ),          
        ),
    ) );
    
    /* End blog Page */
    
    // -> START WooCommerce Page

    Redux::setSection( $opt_name, array(
        'title'      => __( 'WooCommerce Page', 'ecohosting' ),
        'id'         => 'eco_woo_page',
        'icon'  => 'el el-shopping-cart',
        'fields'     => array(
      
            array(
                'id'       => 'eco_woo_sidebar',
                'type'     => 'image_select',
                'title'    => __( 'Select blog layout', 'ecohosting' ),
                'subtitle' => __( 'Choose your blog sidebar layout ', 'ecohosting' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => '1 Column',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    '2' => array(
                        'alt' => '2 Column Left',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    '3' => array(
                        'alt' => '2 Column Right',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    ),

                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'eco_woo_product_number',
                'type'     => 'text',
                'title'    => __( 'Shop Page Product Per Page', 'ecohosting' ),
                'subtitle' => __( 'How many product you want to show shop page', 'ecohosting' ),
                'default'  => '10',
            ), 
            array(
                'id'       => 'ecohost_woo_shoptitle_switch',
                'type'     => 'switch',
                'title'    => __( 'Display Shop Title', 'ecohosting' ),
                'subtitle' => __( 'Switch On to display shop title.', 'ecohosting' ),
                'default'  => true,
            ), 			
        ),
    ) );
    
    /* End WooCommerce Page */
    
    // -> START 404 Page

    Redux::setSection( $opt_name, array(
        'title'      => __( '404 Page', 'ecohosting' ),
        'id'         => 'eco_404_page',
        'icon'       => 'el el-ban-circle',
        'fields'     => array(
            array(
                'id'       => 'eco_fof_text',
                'type'     => 'text',
                'title'    => __( '404 Text', 'ecohosting' ),
                'subtitle' => __( 'Set 404 description text ', 'ecohosting' ),
                'default'  => '404',                
            ),
            array(
                'id'       => 'eco_fof_desc',
                'type'     => 'text',
                'title'    => __( '404 Description', 'ecohosting' ),
                'subtitle' => __( 'Set 404 description text ', 'ecohosting' ),
                'default'  => 'It looks like nothing was found at this location. Maybe try one of the links below or a search?',                
            ),
            array(
                'id'       => 'eco_fof_background',
                'type'     => 'background',
                'output'   => array( '#f0f' ),
                'title'    => __( '404 Background', 'ecohosting' ),
                'subtitle' => __( '404 page background with image, color, etc.', 'ecohosting' ),
                'default'  => array(
                    'background-color' => '#ffffff',
                ),
            ),

        ),
    ) );
    
    /* End 404 Page */
    

    // -> START Contact Page

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Contact', 'ecohosting' ),
        'id'         => 'eco_contact_page',
        'icon'  => 'el el-address-book',
        'fields'     => array(
        
            array(
                'id'       => 'eco_contact_title',
                'type'     => 'text',
                'title'    => __( 'Title', 'ecohosting' ),
                'subtitle' => __( 'Write your Contact Title', 'ecohosting' ),
                'default'  =>'Contact Information',
            ),
            array(
                'id'       => 'eco_contact_info',
                'type'     => 'text',
                'title'    => __( 'Contact Information', 'ecohosting' ),
                'subtitle' => __( 'Write your Contact address', 'ecohosting' ),
                'default'  =>'1234 12th Avenue NW, East Shawarapara, Dhaka',
            ),
            array(
                'id'       => 'eco_phone_number',
                'type'     => 'text',
                'title'    => __( 'Phone Number', 'ecohosting' ),
                'subtitle' => __( 'Add Phone number', 'ecohosting' ),
                'default'  =>'(425) 392-2328',
            ),
            array(
                'id'       => 'eco_fax',
                'type'     => 'text',
                'title'    => __( 'Fax', 'ecohosting' ),
                'subtitle' => __( 'Add Fax number', 'ecohosting' ),
                'default'  =>'(425) 392-2328',
            ),
            array(
                'id'       => 'eco_email',
                'type'     => 'text',
                'title'    => __( 'Email', 'ecohosting' ),
                'subtitle' => __( 'Add email address', 'ecohosting' ),
                'default'  =>'info@example.com',
            ),
            array(
                'id'       => 'eco_contact_form',
                'type'     => 'editor',
                'title'    => __( 'Contact Form', 'ecohosting' ),
                'subtitle' => __( 'Use contact form 7 plugin shortcode', 'ecohosting' ),
            ),
            array(
                'id'       => 'eco_map_disabled',
                'type'     => 'switch',
                'title'    => __( 'Map Enabled/Disabled', 'ecohosting' ),
                'subtitle' => __( 'If you want to do not show map you can Disabled  ', 'ecohosting' ),
                'default'  => true,
                'on'       => 'Enabled',
                'off'      => 'Disabled',
            ),
            array(
                'id'       => 'eco_map_apikey',
                'type'     => 'text',
                'title'    => __( 'API Key', 'ecohosting' ),
                'subtitle' => __( 'Set your google map api key', 'ecohosting' ),
                'required' => array('eco_map_disabled', 'equals', true)
            ),
            array(
                'id'       => 'eco_map_lat',
                'type'     => 'text',
                'title'    => __( 'Map Lat', 'ecohosting' ),
                'subtitle' => __( 'Set your google map latitude', 'ecohosting' ),
                'default'  =>23.790546,
                'required' => array('eco_map_disabled', 'equals', true)
              
            ),
            array(
                'id'       => 'eco_map_lng',
                'type'     => 'text',
                'title'    => __( 'Map Lng', 'ecohosting' ),
                'subtitle' => __( 'Set your google map longitude', 'ecohosting' ),
                'default'  =>90.375583,
                'required' => array('eco_map_disabled', 'equals', true)
               
            ),
            array(
                'id'       => 'eco_map_zoom',
                'type'     => 'text',
                'title'    => __( 'Map Zoom', 'ecohosting' ),
                'subtitle' => __( 'Set your google map zooming', 'ecohosting' ),
                'default'  =>16,
                'required' => array('eco_map_disabled', 'equals', true)
           
            ),

            
        ),
    ) );
    
    /* End Contact Page */
    
    
    // -> START Social Media

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Social', 'ecohosting' ),
        'id'         => 'eco_social_media',
        'icon'  => 'el el-globe',
        'fields'     => array(
            array(
                'id'       => 'eco_facebook_link',
                'type'     => 'text',
                'title'    => __( 'Facebook', 'ecohosting' ),
                'subtitle' => __( 'Add Facebook URL', 'ecohosting' ),
            ),
            array(
                'id'       => 'eco_twitter_link',
                'type'     => 'text',
                'title'    => __( 'Twitter', 'ecohosting' ),
                'subtitle' => __( 'Add Twitter URL', 'ecohosting' ),
            ),
            array(
                'id'       => 'eco_google_link',
                'type'     => 'text',
                'title'    => __( 'google plus', 'ecohosting' ),
                'subtitle' => __( 'Add google plus URL', 'ecohosting' ),
            ),
            array(
                'id'       => 'eco_youtube_link',
                'type'     => 'text',
                'title'    => __( 'Youtube', 'ecohosting' ),
                'subtitle' => __( 'Add youtube URL', 'ecohosting' ),
            ),
            array(
                'id'       => 'eco_instagram_link',
                'type'     => 'text',
                'title'    => __( 'Instagram', 'ecohosting' ),
                'subtitle' => __( 'Add Instagram URL', 'ecohosting' ),
            ),
            array(
                'id'       => 'eco_vimeo_link',
                'type'     => 'text',
                'title'    => __( 'Vimeo', 'ecohosting' ),
                'subtitle' => __( 'Add vimeo plus URL', 'ecohosting' ),
            ),
            array(
                'id'       => 'eco_linkedin_link',
                'type'     => 'text',
                'title'    => __( 'Linkedin', 'ecohosting' ),
                'subtitle' => __( 'Add linkedin plus URL', 'ecohosting' ),
            ),
            array(
                'id'       => 'eco_behance_link',
                'type'     => 'text',
                'title'    => __( 'Behance', 'ecohosting' ),
                'subtitle' => __( 'Add behance plus URL', 'ecohosting' ),
            ),          
            array(
                'id'       => 'eco_pinterest_link',
                'type'     => 'text',
                'title'    => __( 'Pinterest', 'ecohosting' ),
                'subtitle' => __( 'Add pinterest plus URL', 'ecohosting' ),
            ),          
            array(
                'id'       => 'eco_dribbble_link',
                'type'     => 'text',
                'title'    => __( 'Dribbble', 'ecohosting' ),
                'subtitle' => __( 'Add dribbble plus URL', 'ecohosting' ),
            ),   
        ),
    ) );
    
    /* End social Media */
    
    // -> START Footer Media

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer', 'ecohosting' ),
        'id'         => 'eco_footer_section',
        'icon'  => 'el el-photo',
        'fields'     => array(
            array(
                'id'       => 'eco_footer_weiget_disabled',
                'type'     => 'switch',
                'title'    => __( 'Footer Widgets Enabled/Disabled', 'ecohosting' ),
                'subtitle' => __( 'Disabled footer Widgets section  ', 'ecohosting' ),
                'default'  => 1,
                'on'       => 'Enabled',
                'off'      => 'Disabled',
            ),
            array(
                'id'       => 'eco_footer_weiget_background',
                'type'     => 'background',
                'output'   => array( '#footer' ),
                'title'    => __( 'Footer Widgets Background', 'ecohosting' ),
                'subtitle' => __( 'Footer Widgets section background with image, color, etc.', 'ecohosting' ),
                'required' => array( 'eco_footer_weiget_disabled', 'equals', 1 ),
                'default'  => array(
                    'background-color' => '#303030',
                ),
                
            ),
            array(
                'id'       => 'eco_footer_top_disabled',
                'type'     => 'switch',
                'title'    => __( 'Footer Top Enabled/Disabled', 'ecohosting' ),
                'subtitle' => __( 'Disabled Top footer Widgets section  ', 'ecohosting' ),
                'default'  => 1,
                'on'       => 'Enabled',
                'off'      => 'Disabled',
            ),
            array(
                'id'          => 'eco_footerTtop_contactInfo',
                'type'        => 'slides',
                'title'       => __( 'Contact Info', 'ecohosting' ),
                'show'        => array( 
                    'title'          => true,
                    'description'    => false,
                    'progress'       => false,
                    'icon'           => true,
                    'facts-number'   => false,
                    'facts-title1'   => false,
                    'facts-title2'   => false,
                    'facts-number-2' => false,
                    'facts-title3'   => false,
                    'facts-number-3' => false,
                    'url'            => true,
                    'image_upload'   => false,
                ),
                'required' => array( 'eco_footer_top_disabled', 'equals', 1 ),
            ),
            array(
                'id'       => 'eco_footer_top_background',
                'type'     => 'background',
                'output'   => array( '.footer--contact-info' ),
                'title'    => __( 'Footer Top Background', 'ecohosting' ),
                'subtitle' => __( 'Footer top section background with image, color, etc.', 'ecohosting' ),
                'default'  => array(
                    'background-color' => '#232328',
                ),
                'required' => array( 'eco_footer_top_disabled', 'equals', 1 ),
            ),
            array(
                'id'       => 'eco_copyright_text',
                'type'     => 'text',
                'title'    => __( 'Copyright', 'ecohosting' ),
                'subtitle' => __( 'Add Copyright ', 'ecohosting' ),
                'default'  => __( 'Copyright 2018 &copy; <a href="#">EcoHosting</a>. All Rights Reserved.', 'ecohosting' ),
            ),
            array(
                'id'       => 'eco_accpetPayment',
                'type'     => 'media',
                'url'      => true,
                'title'    => __( 'Payments Accpet', 'ecohosting' ),
                'subtitle' => __( 'Upload payments accpeted logo', 'ecohosting' )
            ),
            array(
                'id'       => 'eco_footer_copyright_background',
                'type'     => 'background',
                'output'   => array( '#copyright' ),
                'title'    => __( 'Footer Background', 'ecohosting' ),
                'subtitle' => __( 'Footer section background with image, color, etc.', 'ecohosting' ),
                'default'  => array(
                    'background-color' => '#222',
                ),
            ),
            
        ),
    ) );
    
    /* End Footer Media */

    /*
     * <--- END SECTIONS
     */


    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */

    /*
    *
    * --> Action hook examples
    *
    */

    // If Redux is running as a plugin, this will remove the demo notice and links
    //add_action( 'redux/loaded', 'remove_demo' );

    // Function to test the compiler hook and demo CSS output.
    // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
    //add_filter('redux/options/' . $opt_name . '/compiler', 'compiler_action', 10, 3);

    // Change the arguments after they've been declared, but before the panel is created
    //add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );

    // Change the default value of a field after it's been set, but before it's been useds
    //add_filter('redux/options/' . $opt_name . '/defaults', 'change_defaults' );

    // Dynamically add a section. Can be also used to modify sections/fields
    //add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');

    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $return['error'] = $field;
                $field['msg']    = 'your custom error message';
            }

            if ( $warning == true ) {
                $return['warning'] = $field;
                $field['msg']      = 'your custom warning message';
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => __( 'Section via hook', 'ecohosting' ),
                'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'ecohosting' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }
    }