<?php 
/**
 * @version    1.7
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

if( is_active_sidebar('ecohost-sidebar') ):
 ?>       
<div class="col-md-4 blog-page-sidebar">
    <?php 
        dynamic_sidebar('ecohost-sidebar');
    ?>
</div>
<?php 
endif;
?>
