<?php 
$link_audio = get_post_meta(get_the_ID(),'_cmb_link_audio', true);

?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  <div class="entry">
    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
    <?php if($link_audio) { ?>
    <div class="embed-responsive embed-responsive-16by9">
      <iframe width="100%" src="<?php echo esc_url( $link_audio ); ?>"></iframe>
    </div>
    <?php } ?>
    <p><?php echo cloudme_excerpt(); ?></p>

    <a href="<?php the_permalink(); ?>" class="small radius button"><?php esc_html_e('Read More','cloudme'); ?></a>

    <div class="meta"><?php the_time( get_option( 'date_format' ) ); ?>, <?php esc_html_e('Written by','cloudme'); ?> <?php the_author_posts_link(); ?> <i class="fa fa-comment-o"></i><a href=""><?php comments_number( '0 comment', '1 comment', '% comments' ); ?></a></div>
  </div>
</div>