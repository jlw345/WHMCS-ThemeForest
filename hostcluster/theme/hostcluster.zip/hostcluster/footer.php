<?php
/**
 * The template for displaying the footer.
 *
*/
?>

    <?php if ( class_exists( 'ReduxFrameworkPlugin' ) ) { ?>
        <!-- BACK TO TOP BUTTON -->
        <a class="back-to-top modeltheme-is-visible modeltheme-fade-out" href="<?php echo esc_url('#0'); ?>">
            <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
        </a>
    <?php } else { ?>
        <?php if (hostcluster('mt_backtotop_status') == true) { ?>
            <!-- BACK TO TOP BUTTON -->
            <a class="back-to-top modeltheme-is-visible modeltheme-fade-out" href="<?php echo esc_url('#0'); ?>">
                <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
            </a>
        <?php } ?>
    <?php } ?>


    <!-- FOOTER -->
    <?php $theme_init = new hostcluster_init_class; ?>
    <footer class="<?php echo esc_attr($theme_init->hostcluster_get_footer_variant()); ?>">

        <!-- FOOTER TOP -->
        <div class="row footer-top">
            <div class="container">
            <?php          
                //FOOTER ROW #1
                echo wp_kses_post(hostcluster_footer_row1());
                //FOOTER ROW #2
                echo wp_kses_post(hostcluster_footer_row2());
                //FOOTER ROW #3
                echo wp_kses_post(hostcluster_footer_row3());
             ?>
            </div>
        </div>

        <!-- FOOTER BOTTOM -->
        <div class="row footer-div-parent">
            <div class="footer">
            	<p class="copyright text-center">
                    <?php if ( class_exists( 'ReduxFrameworkPlugin' ) ) { ?>
                        <?php echo wp_kses_post(hostcluster('mt_footer_text')); ?>
                    <?php }else{ ?>
                        <?php echo esc_html__('Copyright 2018 by ModelTheme. All Rights Reserved.', 'hostcluster'); ?>
                    <?php } ?>
                </p>
            </div>
        </div>
    </footer>
</div>



<?php wp_footer(); ?>
</body>
</html>