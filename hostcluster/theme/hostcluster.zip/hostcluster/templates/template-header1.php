<header class="header1">

  <?php if ( class_exists( 'ReduxFrameworkPlugin' ) ) { ?>
  <div class="top-header">
    <div class="container">
      <div class="row">
    	    <div class="col-md-6 col-sm-6">
    	    	<div class="header-infos">
    			  <!-- <div class="header-infos-sub"> -->
    			    <?php if(hostcluster('mt_divider_header_info_links_status') == true){ ?>
    			      <!-- HEADER INFO 1 -->
    			      <div class="text-center header-info-group">
    			        <div class="pull-left">
                    <?php if(hostcluster('mt_divider_header_info_link_login')){  ?>
                      <a href="<?php echo esc_url(hostcluster('mt_divider_header_info_link_login')); ?>"><?php esc_html_e('Login','hostcluster') ?></a>
                    <?php } ?>
    			        </div>
                  <div class="header-info-labels pull-left">
                    <?php if(hostcluster('mt_divider_header_info_link_register')){  ?>
                      <a href="<?php echo esc_url(hostcluster('mt_divider_header_info_link_register')); ?>"><?php esc_html_e('Register','hostcluster') ?></a>
                    <?php } ?>
                  </div>
                  <div class="header-info-labels pull-left">
                    <?php if(hostcluster('mt_divider_header_info_link_help')){  ?>
                      <a href="<?php echo esc_url(hostcluster('mt_divider_header_info_link_help')); ?>"><?php esc_html_e('Help','hostcluster') ?></a>
                    <?php } ?>
                  </div>
    			      </div>
    			      <!-- // HEADER INFO 1 -->
    			    <?php } ?>
    				  <!-- </div> -->
    				</div>   
    		  </div>
          <div class="navbar-collapse actions collapse col-md-6 col-sm-6">
              <div class="header-infos">
                <?php if(hostcluster('mt_divider_header_info_links_status') == true){ ?>
                  <!-- HEADER INFO 1 -->
                  <div class="text-center header-info-group">
                    <div class="header-info-labels pull-right">
                      <?php if(hostcluster('mt_divider_header_info_link_live_chat')){  ?>
                        <a href="<?php echo esc_url(hostcluster('mt_divider_header_info_link_live_chat')); ?>">
                          <span class="fa fa-bullseye" aria-hidden="true"></span>
                          <?php esc_html_e('LIVE CHAT','hostcluster') ?></a>
                      <?php } ?>
                    </div>
                    <div class="pull-right">
                      <?php if(hostcluster('mt_contact_phone')){  ?>
                        <a  href="<?php echo esc_url('tel:'.hostcluster('mt_contact_phone')); ?>">
                          <span class="fa fa-headphones" aria-hidden="true"></span>
                          <?php echo hostcluster('mt_contact_phone'); ?></a>
                      <?php } ?>
                    </div>
                  </div>
                  <!-- // HEADER INFO 1 -->
                <?php } ?> 
              </div>                     
          </div>
	      <!-- NAV ACTIONS -->
      </div>
    </div>
   </div>
  <?php } ?>


  <!-- BOTTOM BAR -->
  <nav class="navbar navbar-default logo-infos" id="modeltheme-main-head">
    <div class="container">
      <div class="row">

          <!-- LOGO -->
          <div class="navbar-header col-md-3">
            <!-- NAVIGATION BURGER MENU -->
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <?php if ( class_exists( 'ReduxFrameworkPlugin' ) ) { ?>
              <?php if(hostcluster('mt_logo','url')){ ?>
                <h1 class="logo">
                    <a href="<?php echo esc_url(get_site_url()); ?>">
                        <img src="<?php echo esc_url(hostcluster('mt_logo','url')); ?>" alt="<?php echo esc_attr(get_bloginfo()); ?>" />
                    </a>
                </h1>
              <?php }else{ ?>
                <h1 class="logo no-logo">
                    <a href="<?php echo esc_url(get_site_url()); ?>">
                      <?php echo esc_html(get_bloginfo()); ?>
                    </a>
                </h1>
              <?php } ?>
            <?php }else{ ?>
              <h1 class="logo no-logo">
                  <a href="<?php echo esc_url(get_site_url()); ?>">
                    <?php echo esc_html(get_bloginfo()); ?>
                  </a>
              </h1>
            <?php } ?>
          </div>

          <!-- NAV MENU -->
          <div id="navbar" class="navbar-collapse collapse col-md-9">
            <ul class="menu nav navbar-nav pull-right nav-effect nav-menu">
              <?php
                if ( has_nav_menu( 'primary' ) ) {
                  $defaults = array(
                    'menu'            => '',
                    'container'       => false,
                    'container_class' => '',
                    'container_id'    => '',
                    'menu_class'      => 'menu',
                    'menu_id'         => '',
                    'echo'            => true,
                    'fallback_cb'     => false,
                    'before'          => '',
                    'after'           => '',
                    'link_before'     => '',
                    'link_after'      => '',
                    'items_wrap'      => '%3$s',
                    'depth'           => 0,
                    'walker'          => ''
                  );

                  $defaults['theme_location'] = 'primary';

                  wp_nav_menu( $defaults );
                }else{
                  echo '<p class="no-menu text-right">';
                    echo esc_html__('Primary navigation menu is missing. Add one from ', 'hostcluster');
                    echo '<a href="'.esc_url(get_admin_url() . 'nav-menus.php').'"><strong>'.esc_html__(' Appearance -> Menus','hostcluster').'</strong></a>';
                  echo '</p>';
                }
              ?>
                <?php if(hostcluster('mt_header_fixed_sidebar_menu_status') == true) { ?>
                  <!-- MT BURGER -->
                  <li class="mt-nav-burger-li" id="mt-nav-burger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                  </li>
                <?php } ?>
            </ul>
          </div>
      </div>
    </div>
  </nav>
</header>
