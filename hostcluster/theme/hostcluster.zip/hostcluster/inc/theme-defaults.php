<?php
/**
||-> Defining Default datas
*/
function hostcluster_init_function( $key = null ){
	// Variable Initialization
    $hostcluster_init = [];
    /* Blog Variant
    Choose from: blogloop-v5 */
    $hostcluster_init['blog_variant'] = 'blogloop-v5';
    /* Header Variant 
    Choose from: header1, header2 */
    $hostcluster_init['header_variant'] = 'header1';
    /* Footer Variant 
    Choose from: footer1, footer2 */
    $hostcluster_init['footer_variant'] = 'footer1';
    /* Header Navigation Hover
    Choose from: navstyle-v1, navstyle-v2, navstyle-v3, navstyle-v4, navstyle-v5, navstyle-v6, navstyle-v7, navstyle-v8 */
    $hostcluster_init['header_nav_hover'] = 'navstyle-v7';
    /* Header Navigation Submenus Variant
    Choose from: nav-submenu-style1, nav-submenu-style2 */
    $hostcluster_init['header_nav_submenu_variant'] = 'nav-submenu-style2';
    /* Sidebar Widgets Defaults
    Choose from: widgets_v1, widgets_v2 */
    $hostcluster_init['sidebar_widgets_variant'] = 'widgets_v1';
    /* 404 Template Variant
    Choose from: page_404_v1_center, page_404_v2_left */
    $hostcluster_init['page_404_template_variant'] = 'page_404_v1_center';
    /* Default Styling
    Set a HEXA Color Code */
    $hostcluster_init['fallback_primary_color'] = '#6773dd'; // Primary Color
    $hostcluster_init['fallback_primary_color_hover'] = '#6f83e9'; // Primary Color - Hover
    $hostcluster_init['fallback_main_texts'] = '#252525'; // Main Texts Color
    $hostcluster_init['fallback_semitransparent_blocks'] = 'rgba(155, 89, 182, 0.7)'; // Semitransparent Blocks
    // The Condition
    if ( is_null($key) ){
        return $hostcluster_init;
    } else if ( array_key_exists($key, $hostcluster_init) ) {
        return $hostcluster_init[$key];
    }
}
class hostcluster_init_class{
    public function hostcluster_get_blog_variant(){
        return hostcluster_init_function('blog_variant');
    }
    public function hostcluster_get_header_variant(){
        return hostcluster_init_function('header_variant');
    }
    public function hostcluster_get_footer_variant(){
        return hostcluster_init_function('footer_variant');
    }
    public function hostcluster_get_header_nav_hover(){
        return hostcluster_init_function('header_nav_hover');
    }
    public function hostcluster_get_header_nav_submenu_variant(){
        return hostcluster_init_function('header_nav_submenu_variant');
    }
    public function hostcluster_get_sidebar_widgets_variant(){
        return hostcluster_init_function('sidebar_widgets_variant');
    }
    public function hostcluster_get_page_404_template_variant(){
        return hostcluster_init_function('page_404_template_variant');
    }
    public function hostcluster_get_fallback_primary_color(){
        return hostcluster_init_function('fallback_primary_color');
    }
    public function hostcluster_get_fallback_primary_color_hover(){
        return hostcluster_init_function('fallback_primary_color_hover');
    }
    public function hostcluster_get_fallback_main_texts(){
        return hostcluster_init_function('fallback_main_texts');
    }
    public function hostcluster_get_fallback_semitransparent_blocks(){
        return hostcluster_init_function('fallback_semitransparent_blocks');
    }
    // Blog Loop Variant
    public function hostcluster_blogloop_variant(){
        if ( !class_exists( 'ReduxFrameworkPlugin' ) ) {
            $theme_init = new hostcluster_init_class;
            return $theme_init->hostcluster_get_blog_variant();
        }
    }
    // Navstyle Variant
    public function hostcluster_navstyle_variant(){
    	if ( !class_exists( 'ReduxFrameworkPlugin' ) ) {
			$theme_init = new hostcluster_init_class;
    		return $theme_init->hostcluster_get_header_nav_hover();
    	}
    }
}
?>