<?php

/**

||-> Shortcode: Search Domain

*/
function modeltheme_search_domain_shortcode($params, $content) {
    extract( shortcode_atts( 
        array(
            'whmcs_link'                      => '',
            'whmcs_input_placeholder_text'    => '',
            'whmcs_button_text'               => '',
            'whmcs_domains_text'              => '',
            'animation'                       => '',
        ), $params ) ); 
    $content = '';
    $content .= '<form action="'.$whmcs_link.'" method="get" id="hostclustersearch" class="wow '.$animation.'">';
        $content .= '<div class="row hostcluster-row">';
            $content .= '<div class="col-sm-8">';
                $content .= '<input type="hidden" name="ccce" value="cart">';
                $content .= '<input type="hidden" name="a" value="add">';
                $content .= '<input type="hidden" name="domain" value="register">';
                $content .= '<input class="form-control" name="query" type="text" placeholder="'.$whmcs_input_placeholder_text.'" required="">';
            $content .= '</div>';
            
            $content .= '<div class="col-sm-2 select-box">';
                $content .= '<select class="form-control" name="">';
                    $domains_values = $whmcs_domains_text;
                    $domains = explode(", ", $domains_values);
                    if(!empty($domains)) {
                        foreach($domains as $domain) {
                            $content .= '<option>'.$domain.'</option>';
                        }
                    } else {
                        $content .= '<option></option>';
                    }
                $content .= '</select>';
            $content .= '</div>';
            
            $content .= '<div class="col-sm-2">';
                $content .= '<button class="btn submit-search-domain" type="submit">'.$whmcs_button_text.'</button>';
            $content .= '</div>';
        $content .= '</div>';
    $content .= '</form>';
    return $content;
}
add_shortcode('search_domain', 'modeltheme_search_domain_shortcode');



/**

||-> Map Shortcode in Visual Composer with: vc_map();

*/
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

    require_once __DIR__ . '/../vc-shortcodes.inc.arrays.php';

    vc_map( 
        array(
            "name" => esc_attr__("MT - Search Domain", 'modeltheme'),
            "base" => "search_domain",
            "category" => esc_attr__('MT: ModelTheme', 'modeltheme'),
            "icon" => "smartowl_shortcode",
            "params" => array(
                array(
                    "group" => "Options",
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_attr__( "WHMCS Site Link", 'modeltheme' ),
                    "param_name" => "whmcs_link",
                    "value" => "",
                    "description" => ""
                ),
                array(
                    "group" => "Options",
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_attr__( "WHMCS Input placeholder text", 'modeltheme' ),
                    "param_name" => "whmcs_input_placeholder_text",
                    "value" => "",
                    "description" => ""
                ),
                array(
                    "group" => "Options",
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_attr__( "WHMCS Button text", 'modeltheme' ),
                    "param_name" => "whmcs_button_text",
                    "value" => "",
                    "description" => ""
                ),
                array(
                    "group" => "Options",
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_attr__( "WHMCS Domains, ex: .com, .eu, .info", 'modeltheme' ),
                    "param_name" => "whmcs_domains_text",
                    "value" => "",
                    "description" => ""
                ),
                array(
                    "group" => "Animation",
                    "type" => "dropdown",
                    "heading" => esc_attr__("Animation", 'modeltheme'),
                    "param_name" => "animation",
                    "std" => '',
                    "holder" => "div",
                    "class" => "",
                    "description" => "",
                    "value" => $animations_list
                ), 
                
            )
        )
    );
}