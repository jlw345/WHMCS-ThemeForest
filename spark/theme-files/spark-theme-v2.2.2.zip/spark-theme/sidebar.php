<?php  
	// If the sidebar is active
	if( is_active_sidebar( 'spark_sidebar' ) ) {
		dynamic_sidebar('spark_sidebar'); 		
	}
	