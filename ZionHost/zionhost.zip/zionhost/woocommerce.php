<?php
/**
 * The default woocommerce template of this theme
 */
get_header(); ?>
  <section class="header-section">
    <div class="page_header" <?php if(zionhost_get_option('zionhost_page_header_img') != '') { ?>style="background: rgba(0, 0, 0, 0) url('<?php echo esc_url( zionhost_get_option('zionhost_page_header_img') ); ?>') no-repeat scroll center top;"<?php } ?>>
      <div class="container">
        <h2 class="align_center pagetitle"><?php woocommerce_page_title(); ?></h2>
        <?php if (function_exists('woocommerce_breadcrumb')) woocommerce_breadcrumb(); ?>
      </div>
    </div>
  </section>
  <!-- end page header -->
  <div class="clearfix"></div>
  
  <section class="common_section section41">
    <div class="container">
	<?php if(zionhost_get_option('zionhost_woocommerce_sidebar_switch') == '2') { ?>
			<!--WooCommerce Sidebar-->
			<?php if ( is_active_sidebar( 'zionhost_woocommerce_sidebar' ) ) { ?>
            <aside class="sidebar col-md-3 col-sm-4 col-bordered-left" style="margin-left: 0; padding-left: 0;">
                    <!--widget area-->
                    <?php dynamic_sidebar( 'zionhost_woocommerce_sidebar' ); ?>
                    <!--End widget area-->
			<hr class="visible-xs lg">
            </aside>
			<?php } ?>
            <!--End WooCommerce Sidebar-->
			<?php } ?>
		<div class="<?php if(zionhost_get_option('zionhost_woocommerce_sidebar_switch') == '1') { ?>col-md-8 left-padd0<?php } elseif(zionhost_get_option('zionhost_woocommerce_sidebar_switch') == '2') { ?>col-md-8 fl-right<?php } else { ?>col-md-12 left-padd0<?php } ?>">
				<?php woocommerce_content(); ?>
        
      </div>
	  <?php if(zionhost_get_option('zionhost_woocommerce_sidebar_switch') == '1') { ?>
			<!--WooCommerce Sidebar-->
			<?php if ( is_active_sidebar( 'zionhost_woocommerce_sidebar' ) ) { ?>
            <aside class="sidebar col-md-3 col-sm-4 col-md-offset-1 col-bordered">
			 <hr class="visible-xs lg">
                    <!--widget area-->
                    <?php dynamic_sidebar( 'zionhost_woocommerce_sidebar' ); ?>
                    <!--End widget area-->
            </aside>
			<?php } ?>
            <!--End WooCommerce Sidebar-->
			<?php } ?>
    </div>
  </section>
			
			
  
<!-- end section 1 -->
<div class="clearfix"></div>
  <?php if(zionhost_get_option('checkbox_hide_below') == '1') { ?>
  <section class="section11">
    <div class="container">
      <div class="text">
        <h4 class="white-text"><?php echo zionhost_get_option('zionhost_page_bottom_caction'); ?></h4>
      </div>
      <div data-anim-delay="200" data-anim-type="swing" class="readmore animate-in"><a class="btn linebtn one" href="<?php echo esc_url( zionhost_get_option('zionhost_page_bottom_caction_bu') ); ?>"><?php echo zionhost_get_option('zionhost_page_bottom_caction_bl'); ?></a> </div>
    </div>
  </section>
  <!-- end section 6 -->
  <div class="clearfix"></div>
  <?php } ?>
<!--MAIN CONTENT END-->
<?php get_footer(); ?>