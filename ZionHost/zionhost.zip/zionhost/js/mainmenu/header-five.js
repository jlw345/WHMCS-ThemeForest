(function($) {
  "use strict";
var a = $(".scrollto_sticky").offset().top;

<!-- background color for sticky --> 
$(document).scroll(function(){
    if($(this).scrollTop() > (a + 90))
    {   
       $('.scrollto_sticky').css({"background":"#151515"});
    } else {
       $('.scrollto_sticky').css({"background":"transparent"});
    }
});
})(jQuery);