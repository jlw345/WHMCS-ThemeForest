<?php
/*************************
Start Popular Posts widget
*************************/
class zionhost_popular_Widget extends WP_Widget {

       function __construct() {
    parent::__construct(
      'zionhost_popular_Widget', // Base ID
      esc_html__('Zionhost -Latest Posts Widget', 'zionhost'), // Name
      array( 'description' => esc_html__( 'Displays the Most Recent Posts with image', 'zionhost' ), ) // Args
    );
  }
/* Front-end display of widget. */
public function widget( $args, $instance ) {

		  $zionhost_imgpath = get_template_directory_uri(); ?>
					<div class="sidebar_latest_posts" style="margin-top:40px">
						<h5 class="uppercase mb_zero"><?php _e('Latest Posts', 'zionhost'); ?></h5>
                                    <?php			
										$args = array(
										'posts_per_page'   => 3,
										'orderby'          => 'post_date',
										'order'            => 'DESC',
										'post_type'        => 'post',
										'post_status'      => 'publish',
										); 

										$ft_latestpost = new WP_Query( $args );
										if ($ft_latestpost->have_posts()) :
										while($ft_latestpost->have_posts()) : $ft_latestpost->the_post() ;
										global $post;
										?>
									<div class="post_holder">
										<?php if ( has_post_thumbnail() ) { ?>
										<div class="img"><?php echo get_the_post_thumbnail( $post->ID, array( 90, 90) ); ?></div>
										<?php } else { ?>
										<div class="img"><img class="img_size1" style="width: 90px; height: 90px;" alt="" src="<?php echo esc_url( $zionhost_imgpath ); ?>/images/avatars/thumbnail.png"></div>
										<?php } ?>
										<div class="text"> <a href="<?php the_permalink(); ?>">
										  <h6><?php the_title(); ?></h6>
										  </a>
										  <div> <span><?php _e('By', 'zionhost'); ?> <?php the_author(); ?></span> </div>
										</div>
									</div>
										<?php endwhile; ?>
										<?php endif; ?>
                    </div>                 
	  <?php						
}
}//end of class

// register popular_Widget widget
function zionhost_register_popular_Widget() {
  register_widget( 'zionhost_popular_Widget' );
}
add_action( 'widgets_init', 'zionhost_register_popular_Widget' );