<?php
// **********************************************************************// 
// ! Customizing number of products in shop page
// **********************************************************************//
	add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 9;' ), 20 );
	
// **********************************************************************// 
// ! Supports post thumbnails and post formats
// **********************************************************************// 
add_theme_support( 'post-thumbnails' );
add_theme_support( 'post-formats', array( 'video' ) );
add_theme_support( 'custom-logo', array(
   'height'      => 35,
   'width'       => 200,
   'flex-width' => true,
) );
function zionhost_the_custom_logo() {
   if ( function_exists( 'the_custom_logo' ) ) {
      the_custom_logo();
   }
}
// **********************************************************************// 
// ! Rss feeds, Custom Background and Title Tag theme supports
// **********************************************************************// 
add_theme_support( 'automatic-feed-links' );
add_theme_support('custom-background', array(
        'default-color' => '#ffffff',
    ));
add_theme_support( 'custom-header', array(
		'default-text-color'     => '#000'
	) );
add_theme_support( 'title-tag' );
function zionhost_add_editor_styles() {
    add_editor_style( 'css/webfonts/webfonts.css' );
}
add_action( 'admin_init', 'zionhost_add_editor_styles' );

// **********************************************************************// 
// ! This theme uses wp_nav_menu() for Main Menu
// **********************************************************************// 
register_nav_menus( array(
		'zionhost_primary_menu'=> esc_html__('Main Menu', 'zionhost'),
		'zionhost_menu_footer_one'=> esc_html__('Footer Menu One', 'zionhost'),
		'zionhost_menu_footer_two'=> esc_html__('Footer Menu Two', 'zionhost')
) );

// **********************************************************************// 
// ! Custom Walker for wp_nav_menu()
// **********************************************************************//
class zionhost_walker_nav_menu extends Walker_Nav_Menu {

private $blog_sidebar_pos = "";
// add classes to ul sub-menus
function start_lvl( &$output, $depth = 0, $args = Array() ) {
    // depth dependent classes
    $indent = ( $depth > 0  ? str_repeat( "\t", $depth ) : '' ); // code indent
    $display_depth = ( $depth + 1); // because it counts the first submenu as 0
    $classes = array(
        'dropdown-menu',
        ( $display_depth % 2  ? 'menu-odd' : 'menu-even' ),
        ( $display_depth >=2 ? '' : '' ),
        'menu-depth-' . $display_depth
        );
    $class_names = implode( ' ', $classes );
  
    // build html
	
	$output .= "\n" . $indent . '<ul class="' . $class_names . '">' . "\n";
}
  
// add main/sub classes to li's and links
 function start_el( &$output, $item, $depth = 0, $args = Array(), $id = 0 ) {
    global $wp_query;
    $indent = ( $depth > 0 ? str_repeat( "\t", $depth ) : '' ); // code indent
  
    // depth dependent classes
	$depth_classes = array(
        ( $depth == 0 ? 'dropdown' : '' ),
        ( $depth >=2 ? 'sub-sub-menu-item' : '' ),
        ( $depth % 2 ? 'menu-item-odd' : 'menu-item-even' ),
        'menu-item-depth-' . $depth
    );
    $depth_class_names = esc_attr( implode( ' ', $depth_classes ) );
  
    // passed classes
    $classes = empty( $item->classes ) ? array() : (array) $item->classes;
    $class_names = esc_attr( implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) ) );
  
    // build html
    $output .= $indent . '<li id="nav-menu-item-'. $item->ID . '" class="' . $depth_class_names . ' ' . $class_names . '">';
  
    // link attributes
    $attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
    $attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
    $attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
    $attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';
    $attributes .= ' class="menu-link ' . ( $depth > 0 ? 'sub-menu-link' : 'dropdown-toggle' ) . '"';

	if( 'zionhost_mega_menu' == $item->object ){
				$item_output = $args->before;
				$megamenu_item = get_post( $item->object_id );
				$item_output .= '<div class="yamm-content"><div class="row list-unstyled">' . apply_filters( 'the_content', $megamenu_item->post_content ) . '</div></div>';
	}else{
	$item_output = sprintf( '%1$s<a%2$s>%3$s%4$s%5$s</a>%6$s',
        $args->before,
        $attributes,
        $args->link_before,
        apply_filters( 'the_title', $item->title, $item->ID ),
        $args->link_after,
        $args->after
    );
	}
  
    // build html
    $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args, $id );
}
} //End Walker_Nav_Menu

// **********************************************************************// 
// ! Add breadcrumbs
// **********************************************************************//
function zionhost_wordpress_breadcrumbs() {
 
  $delimiter = '<i>/</i>';
  $name = 'Home'; //text for the 'Home' link
  $currentBefore = '<span class="current">';
  $currentAfter = '</span>';
 
  if ( !is_home() && !is_front_page() || is_paged() ) {
 
    echo '<div class="pagenation">';
 
    global $post;
    $home = home_url();
    echo '<a href="' . $home . '">' . $name . '</a> ' . $delimiter . ' ';
 
    if ( is_category() ) {
      global $wp_query;
      $cat_obj = $wp_query->get_queried_object();
      $thisCat = $cat_obj->term_id;
      $thisCat = get_category($thisCat);
      $parentCat = get_category($thisCat->parent);
      if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));
      echo $currentBefore . 'Archive by category &#39;';
      single_cat_title();
      echo '&#39;' . $currentAfter;
 
    } elseif ( is_day() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
      echo $currentBefore . get_the_time('d') . $currentAfter;
 
    } elseif ( is_month() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo $currentBefore . get_the_time('F') . $currentAfter;
 
    } elseif ( is_year() ) {
      echo $currentBefore . get_the_time('Y') . $currentAfter;
 
    } elseif ( is_single() ) {
      $cat = get_the_category(); $cat = (isset($cat[0]) ? $cat[0] : null);
      echo is_wp_error( $cat_parents = get_category_parents($cat, TRUE, '' . $delimiter . '') ) ? '' : $cat_parents;
      echo $currentBefore;
      the_title();
      echo $currentAfter;
 
    } elseif ( is_page() && !$post->post_parent ) {
      echo $currentBefore;
      the_title();
      echo $currentAfter;
 
    } elseif ( is_page() && $post->post_parent ) {
      $parent_id  = $post->post_parent;
      $breadcrumbs = array();
      while ($parent_id) {
        $page = get_page($parent_id);
        $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
        $parent_id  = $page->post_parent;
      }
      $breadcrumbs = array_reverse($breadcrumbs);
      foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
      echo $currentBefore;
      the_title();
      echo $currentAfter;
 
    } elseif ( is_search() ) {
      echo $currentBefore . 'Search results for &#39;' . get_search_query() . '&#39;' . $currentAfter;
 
    } elseif ( is_tag() ) {
      echo $currentBefore . 'Posts tagged &#39;';
      single_tag_title();
      echo '&#39;' . $currentAfter;
 
    } elseif ( is_author() ) {
       global $author;
      $userdata = get_userdata($author);
      echo $currentBefore . 'Articles posted by ' . $userdata->display_name . $currentAfter;
 
    } elseif ( is_404() ) {
      echo $currentBefore . 'Error 404' . $currentAfter;
    }
 
    if ( get_query_var('paged') ) {
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
      echo __('Page', 'zionhost') . ' ' . get_query_var('paged');
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
    }
 
    echo '</div>';
 
  }
}
/// Breadcrumbs End ///

// **********************************************************************// 
// ! Register Sidebars
// **********************************************************************//
if ( ! function_exists( 'zionhost_widgets_init' ) ) {
	function zionhost_widgets_init() {

		register_sidebar( array(
		'name' => esc_html__( 'Sidebar', 'zionhost' ),
		'id' => 'zionhost_sidebar',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div><div class="clearfix"></div>',
		'before_title' => '<h5 class="padd_bott5 uppercase">',
		'after_title' => '</h5>',
	) );
	}
}
add_action( 'widgets_init', 'zionhost_widgets_init' );

// **********************************************************************// 
// ! Get Global Variables
// **********************************************************************//
function zionhost_get_global_post() {
    global $post;
    if ( 
        ! $post instanceof \WP_Post
    ) {
        return false;
    }
    return $post;
}

function zionhost_get_global_wpquery() {
    global $wp_query;
    return $wp_query;
}

// **********************************************************************// 
// ! Custom Pagination
// **********************************************************************//
function zionhost_custom_pagination() {
	global $wp_query;

	$big = 999999999; // need an unlikely integer
		
	echo paginate_links( array(
		'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		'format' => '?paged=%#%',
		'current' => max( 1, get_query_var('paged') ),
		'total' => $wp_query->max_num_pages,
		'show_all'     => false,
		'end_size'     => 1,
		'mid_size'     => 2,
		'prev_next'    => true,
		'prev_text'    => '<i class="fa fa-angle-left"></i>',
		'next_text'    => '<i class="fa fa-angle-right"></i>',
		'type'         => 'list',
		'add_args'     => false,
		'add_fragment' => ''
	) );
}

// **********************************************************************// 
// ! Excerpt Limit
// **********************************************************************//
function zionhost_excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).'...';
  } else {
    $excerpt = implode(" ",$excerpt);
  }	
  $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
  return $excerpt;
}

if ( ! function_exists( 'zionhost_excerpt_length' ) ) {
	function zionhost_excerpt_length( $length ) {
	return 65;
	}
}
add_filter( 'excerpt_length', 'zionhost_excerpt_length', 999 );

// **********************************************************************// 
// ! Set Content Width
// **********************************************************************// 
if (!isset($content_width)) { $content_width = 750; }

// **********************************************************************// 
// ! Display Comments section
// **********************************************************************//
if ( ! function_exists( 'zionhost_comment' ) ) {
/**
 * Template for comments and pingbacks.
 *
 * To override this walker in a child theme without modifying the comments template
 * simply create your own zionhost_comment(), and that function will be used instead.
 *
 * Used as a callback by wp_list_comments() for displaying the comments.
 */
	function zionhost_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;

	global $post;
	?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
	<div class="img"><?php echo get_avatar($comment, 120); ?></div>
            <div class="text">
              <h4 class="lessmar"><?php comment_author(); ?> </h4>
              <p class="padd_bot1"><?php comment_date('d M, Y') ?></p>
              <?php comment_text()?>
            </div>
	<!-- #comment-## -->

	<?php
	}
}

/*******************
Comment form styling
*******************/
if ( ! function_exists( 'zionhost_modify_comment_fields' ) ) {
	function zionhost_modify_comment_fields($fields) {

    $fields['fields'] = '<div class="row"><div class="col col-6"><label class="label al_left">'.esc_html__("Name", 'zionhost').'</label>
                      <label class="input"><input type="text" id="author" name="author"';
	$n_value = '';
	$e_value = '';

	$fields['fields'] .= ' value="'.esc_attr($n_value).'" aria-required="true" /></label></div>
						  <div class="col col-6">';
    $fields['fields'] .= '<label class="label al_left">'.esc_html__("E-mail", 'zionhost').'</label>
							<label class="input"><input type="email" id="email" name="email" value="'.esc_attr($e_value).'" aria-required="true" /></label></div></div>';
	//$fields['fields'] .= '<div style="display:none;"><input type="text" id="url" class="form-control" name="url" placeholder="'.esc_html__("Website", 'zionhost').'" value="'.esc_attr($w_value).'" aria-required="false" /></div>';
	return $fields;
	}
}

add_filter('comment_form_defaults', 'zionhost_modify_comment_fields');//Name, Email and Website fields customization filter

if ( ! function_exists( 'zionhost_comment_field' ) ) {
	function zionhost_comment_field($arg) {
  
	$arg['comment_field'] = '
								<label class="label al_left">'.esc_html__("Message", 'zionhost').'</label>
								<label class="textarea"><textarea name="comment" id="" rows="4"></textarea></label>
							 ';    
	return $arg;
	}
}
add_filter('comment_form_defaults', 'zionhost_comment_field');//Text area customization filter


function zionhost_comment_form_submit_button($button) {
	$button =
		'<footer>
            <button class="button seven" name="submit" type="submit" id="[args:id_submit]" value="[args:label_submit]">'.esc_html__("Submit comment", 'zionhost').'</button>
         </footer>' .
		get_comment_id_fields();
	return $button;
}
add_filter('comment_form_submit_button', 'zionhost_comment_form_submit_button');//Submit button customization filter

function zionhost_move_comment_field_to_bottom( $fields ) {
$comment_field = $fields['comment'];
unset( $fields['comment'] );
$fields['comment'] = $comment_field;

return $fields;
}
add_filter( 'comment_form_fields', 'zionhost_move_comment_field_to_bottom' );//move the comment text field to the bottom