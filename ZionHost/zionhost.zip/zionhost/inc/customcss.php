<?php
function zionhost_styles_custom() {
?>

<!-- Custom CSS Codes
========================================================= -->
<?php
	// **********************************************************************// 
// ! Customizing number of columns in shop page
// **********************************************************************//
	if(zionhost_get_option('zionhost_woocommerce_sidebar_switch') != '3') {
	add_filter( 'loop_shop_columns', 'wc_loop_shop_columns', 1, 10 );
	/*
	* Return a new number of maximum columns for shop archives
	* @param int Original value
	* @return int New number of columns
	*/
	function wc_loop_shop_columns( $number_columns ) {
	return 3;
	}
	} else {
	add_filter( 'loop_shop_columns', 'wc_loop_shop_columns', 1, 10 );
	/*
	* Return a new number of maximum columns for shop archives
	* @param int Original value
	* @return int New number of columns
	*/
	function wc_loop_shop_columns( $number_columns ) {
	return 4;
	}
	}
	?>
<style id="custom-style">
	/* Logo ------------------------------------------------------------------------ */
	<?php if(zionhost_get_option('header_styles') == '1') { ?>
	@media only screen and (min-width: 480px) and (max-width: 639px) {
	.logo.nosmash {
    float: left;
    width: 48%;
	}
	}
	@media only screen and (max-width: 479px) {
	.logo.nosmash {
	width: 80%;
    margin: auto;
	}
	}
	<?php } if(zionhost_get_option('header_styles') != '1') { ?>
	@media only screen and (max-width: 639px) {
	.logo {
	float: none;
	padding: 10px 0 0 0;
	}
	.navbar-toggle{
	margin-top: 0 !important;
	}
	}
	<?php } ?>
	<?php if(zionhost_get_option('header_styles') == '5') { ?>
	.logo {
    padding: 20px 0 0 0;
	}
	@media only screen and (max-width: 479px){
	.logo {
    width: 80%;
	}
	}
	@media only screen and (max-width: 639px) {
	.logo {
	padding: 10px 0 0 0;
	margin: auto;
	}
	}
	@media only screen and (min-width: 767px) and (max-width: 998px) {
	.navbar-toggle{
	margin-top: 30px !important;
	}
	}
	<?php } if(zionhost_get_option('header_styles') == '4') { ?>
	.navbar-default .navbar-nav.five>li>a:hover{
	color: #000 !important;
	}
	<?php } ?>
	/* Boxed ------------------------------------------------------------------------ */
	.site_wrapper {
	background: #fff none repeat scroll 0 0;
	}
	<?php if(zionhost_get_option('zionhost_site_width') == '1') { ?>
	.wrapper_boxed {
		max-width: 1210px;
		margin: 0 auto;
	}
	.vc_row {
		margin-left: -35px;
		margin-right: -35px;
	}
	.top_nav ul.left li, .top_nav ul.right-nav li {
    border-left: 0px solid #2c2c2c;
	}
	.footer.seven {
    margin: 0;
	}
	<?php } // **********************************************************************// 
// ! Customizing number of columns in shop page
// **********************************************************************// ?>
	<?php if(zionhost_get_option('zionhost_woocommerce_sidebar_switch') != '3') { ?>
	.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{
	width: 30%;
	margin: 0 3% 2.992em 0;
	}
	 @media only screen and (max-width: 639px) {
	 .woocommerce ul.products li.product, .woocommerce-page ul.products li.product{
	width: 100%;
	margin: auto;
	}
	 }
	<?php } ?>
	<?php if(zionhost_get_option('checkbox_hide_below') == '1') { ?>
	.footer-cross {
		padding-top: 0;
	}
	<?php } ?>
	
	<?php echo zionhost_get_option('textarea_csscode'); //Load Custom CSS from Theme-Options ?>
	
</style>
<?php if(zionhost_get_option('zionhost_site_width') == '1') { ?>
<?php if(zionhost_get_option('zionhost_bg_Pattern') == '1') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-default.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '2') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-one.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '3') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-two.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '4') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-three.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '5') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-four.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '6') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-five.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '7') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-six.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '8') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-seven.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '9') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-eight.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '10') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-nine.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '11') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-ten.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '12') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-eleven.css" />
<?php } if(zionhost_get_option('zionhost_bg_Pattern') == '13') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri().'/css'; ?>/bg-patterns/pattern-twelve.css" />
<?php } }?>
<?php }
add_action( 'wp_head', 'zionhost_styles_custom', 100 );
?>