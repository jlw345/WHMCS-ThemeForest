<?php
function zionhost_scripts_basic() {  

	/* ------------------------------------------------------------------------ */
	/* Enqueue Scripts */
	/* ------------------------------------------------------------------------ */
	/* Pre-Loader */
	if(zionhost_get_option('zionhost_preloader') == '1') {
	wp_enqueue_script('zionhost-pre-loader', get_template_directory_uri() . '/js/universal/pageloader.js', array( 'jquery' ), '1.0.0', true);
	}
	/* Custom */
	wp_enqueue_script('zionhost-main', get_template_directory_uri() . '/js/universal/zionhost-main.js', array( 'jquery' ), '1.0.0', true);
	/* Animations */
	if(zionhost_get_option('zionhost_site_animations') == '1') {
	wp_enqueue_script('zionhost-animations', get_template_directory_uri() . '/js/animations/animations.min.js', array( 'jquery' ), '1.0.0', true);
	}
	wp_enqueue_script('zionhost-appear', get_template_directory_uri() . '/js/animations/appear.min.js', array( 'jquery' ), '1.0.0', true);
	/* Form */
	wp_enqueue_script('zionhost-form-validate', get_template_directory_uri() . '/js/form/jquery.validate.min.js', array( 'jquery' ), '1.0.0', true);
	/* Scroll to fixed sticky */
	if ( is_admin_bar_showing() ) {
	wp_enqueue_script('zionhost-scrolltofixed-admin', get_template_directory_uri() . '/js/mainmenu/jquery-scrolltofixed-admin.js', array( 'jquery' ), '1.0.0', true);
	} else {
	wp_enqueue_script('zionhost-scrolltofixed', get_template_directory_uri() . '/js/mainmenu/jquery-scrolltofixed.js', array( 'jquery' ), '1.0.0', true);
	}
	wp_enqueue_script('zionhost-ScrollToFixed_custom', get_template_directory_uri() . '/js/mainmenu/ScrollToFixed_custom.js', array( 'jquery' ), '1.0.0', true);
	/* Cubeportfolio */
	wp_enqueue_script('zionhost-cubeportfolio', get_template_directory_uri() . '/js/cubeportfolio/jquery.cubeportfolio.min.js', array( 'jquery' ), '1.0.0', true);
	if (zionhost_get_option('portfolio_columns') == '4') {
	wp_enqueue_script('zionhost-cubeportfolio-main6', get_template_directory_uri() . '/js/cubeportfolio/main6.js', array( 'jquery' ), '1.0.0', true);
	} if (zionhost_get_option('portfolio_columns') == '3') {
	wp_enqueue_script('zionhost-cubeportfolio-main5', get_template_directory_uri() . '/js/cubeportfolio/main5.js', array( 'jquery' ), '1.0.0', true);
	}
	wp_enqueue_script('zionhost-cubeportfolio-three', get_template_directory_uri() . '/js/cubeportfolio/main-two-col.js', array( 'jquery' ), '1.0.0', true);
	/* Menu */
	wp_enqueue_script('zionhost-bootstrap', get_template_directory_uri() . '/js/mainmenu/bootstrap.min.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('zionhost-customeUI', get_template_directory_uri() . '/js/mainmenu/customeUI.js', array( 'jquery' ), '1.0.0', true);
	if (zionhost_get_option('header_styles') == '5') {
	wp_enqueue_script('header-five', get_template_directory_uri() . '/js/mainmenu/header-five.js', array( 'jquery' ), '1.0.0', true);
	}
	/* Tabs */
	wp_enqueue_script('zionhost-tabs', get_template_directory_uri() . '/js/tabs/assets/js/responsive-tabs.min.js', array( 'jquery' ), '1.0.0', true);
	/* Accordion */
	wp_enqueue_script('zionhost-smk-accordion', get_template_directory_uri() . '/js/accordion/smk-accordion.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('zionhost-accordion-custom', get_template_directory_uri() . '/js/accordion/custom.js', array( 'jquery' ), '1.0.0', true);
	/* Fixied Sticky */
	wp_enqueue_script('zionhost-menusticky', get_template_directory_uri() . '/js/mainmenu/sticky.js', array( 'jquery' ), '1.0.0', true);
	/* Owl-carousel */
	wp_enqueue_script('zionhost-owl-carousel', get_template_directory_uri() . '/js/owl-carousel/owl.carousel.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('zionhost-owl-new', get_template_directory_uri() . '/js/universal/owl-new.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('zionhost-owl-custom', get_template_directory_uri() . '/js/owl-carousel/custom.js', array( 'jquery' ), '1.0.0', true);
	/* Scroll Up */
	wp_enqueue_script('zionhost-totop', get_template_directory_uri() . '/js/scrolltotop/totop.js', array( 'jquery' ), '1.0.0', true);
	/* Parallax bg */
	wp_enqueue_script('zionhost-parallax', get_template_directory_uri() . '/js/parallax-background/parallax.js', array( 'jquery' ), '1.0.0', true);

	if ( is_singular() ) {
		wp_enqueue_script( 'comment-reply' );
	}
	wp_localize_script( 'zionhost-main', 'prefix_object_name', array(
		'error_while_ajax_request' => esc_html__( 'Error while ajax request', 'zionhost' ),
		'thank_you_your_email_has_been_sent' => esc_html__( 'Thank you, your email has been sent', 'zionhost' ),
		'please_try_again' => esc_html__( 'Please, fill in the required fields correctly!', 'zionhost' )
	) );
}
add_action( 'wp_enqueue_scripts', 'zionhost_scripts_basic' ); 

function zionhost_styles_basic()  {  
	
	/* ------------------------------------------------------------------------ */
	/* Enqueue Stylesheets */
	/* ------------------------------------------------------------------------ */
	/* Fonts */
	wp_enqueue_style( 'zionhost-fonts', get_template_directory_uri() . '/css/webfonts/webfonts.css');
	/* CSS STYLES */
	wp_enqueue_style( 'zionhost-reset', get_template_directory_uri() . '/css/reset.css');
	wp_enqueue_style( 'zionhost-stylesheet', get_template_directory_uri() . '/style.css'); // Main Stylesheet
	wp_enqueue_style( 'zionhost-background', get_template_directory_uri() . '/css/background.css');
	wp_enqueue_style( 'zionhost-font-awesome', get_template_directory_uri() . '/css/font-awesome/css/font-awesome.min.css');
	/* responsive-leyouts */
	wp_enqueue_style( 'zionhost-responsive-leyouts', get_template_directory_uri() . '/css/responsive-leyouts.css');
	/* menu */
	wp_enqueue_style( 'zionhost-menu-sticky', get_template_directory_uri() . '/js/mainmenu/sticky.css');
	wp_enqueue_style( 'zionhost-menu-bootstrap', get_template_directory_uri() . '/js/mainmenu/bootstrap.min.css');
	wp_enqueue_style( 'zionhost-menu-demo', get_template_directory_uri() . '/js/mainmenu/demo.css');
	wp_enqueue_style( 'zionhost-menu', get_template_directory_uri() . '/js/mainmenu/menu.css');
	/* cubeportfolio */
	wp_enqueue_style( 'zionhost-cubeportfolio', get_template_directory_uri() . '/js/cubeportfolio/cubeportfolio.min.css');
	/* animations */
	wp_enqueue_style( 'zionhost-animations', get_template_directory_uri() . '/js/animations/css/animations.min.css');
	/* responsive-tabs */
	wp_enqueue_style( 'zionhost-tabs', get_template_directory_uri() . '/js/tabs/assets/css/responsive-tabs.css');
	wp_enqueue_style( 'zionhost-tabs7', get_template_directory_uri() . '/js/tabs/assets/css/responsive-tabs7.css');
	/* owl-carousel */
	wp_enqueue_style( 'zionhost-owl-carousel', get_template_directory_uri() . '/js/owl-carousel/owl.carousel.css');
	wp_enqueue_style( 'zionhost-owl-theme', get_template_directory_uri() . '/js/owl-carousel/owl.theme.css');
	wp_enqueue_style( 'zionhost-owl-transitions', get_template_directory_uri() . '/js/owl-carousel/owl.transitions.css');
	/* accordion */
	wp_enqueue_style( 'zionhost-smk-accordion', get_template_directory_uri() . '/js/accordion/smk-accordion.css');
	/* progressbar */
	wp_enqueue_style( 'zionhost-progressbar', get_template_directory_uri() . '/js/progressbar/ui.progress-bar.css');
	/* forms */
	wp_enqueue_style( 'zionhost-forms', get_template_directory_uri() . '/js/form/css/sky-forms.css');
	/* color-options */
	if(zionhost_get_option('ten_colors') == '1') {
	wp_enqueue_style( 'zionhost-blue', get_template_directory_uri() . '/css/colors/blue.css');
	} if(zionhost_get_option('ten_colors') == '2') {
	wp_enqueue_style( 'zionhost-red', get_template_directory_uri() . '/css/colors/red.css');
	} if(zionhost_get_option('ten_colors') == '3') {
	wp_enqueue_style( 'zionhost-orange', get_template_directory_uri() . '/css/colors/orange.css');
	} if(zionhost_get_option('ten_colors') == '4') {
	wp_enqueue_style( 'zionhost-olive', get_template_directory_uri() . '/css/colors/olive.css');
	} if(zionhost_get_option('ten_colors') == '5') {
	wp_enqueue_style( 'zionhost-green', get_template_directory_uri() . '/css/colors/green.css');
	} if(zionhost_get_option('ten_colors') == '6') {
	wp_enqueue_style( 'zionhost-pink', get_template_directory_uri() . '/css/colors/pink.css');
	} if(zionhost_get_option('ten_colors') == '7') {
	wp_enqueue_style( 'zionhost-violet', get_template_directory_uri() . '/css/colors/violet.css');
	} if(zionhost_get_option('ten_colors') == '8') {
	wp_enqueue_style( 'zionhost-sea', get_template_directory_uri() . '/css/colors/sea.css');
	} if(zionhost_get_option('ten_colors') == '9') {
	wp_enqueue_style( 'zionhost-lightblue', get_template_directory_uri() . '/css/colors/lightblue.css');
	} if(zionhost_get_option('ten_colors') == '10') {
	wp_enqueue_style( 'zionhost-lightgreen', get_template_directory_uri() . '/css/colors/lightgreen.css');
	}
	
}  
add_action( 'wp_enqueue_scripts', 'zionhost_styles_basic', 1 );
?>