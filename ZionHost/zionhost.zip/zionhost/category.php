<?php
/**
 * The template for displaying Category pages
 */
get_header(); ?>
  <section class="header-section">
    <div class="page_header" <?php if(zionhost_get_option('zionhost_page_header_img') != '') { ?>style="background: rgba(0, 0, 0, 0) url('<?php echo esc_url( zionhost_get_option('zionhost_page_header_img') ); ?>') no-repeat scroll center top;"<?php } ?>>
      <div class="container">
        <h2 class="align_center pagetitle">
							<?php echo esc_html_e( 'Category Archives', 'zionhost' ); ?>
		</h2>
        <?php if (function_exists('zionhost_wordpress_breadcrumbs')) zionhost_wordpress_breadcrumbs(); ?>
      </div>
    </div>
  </section>
  <!-- end page header -->
  <div class="clearfix"></div>
 
	<section class="section41">
		<div class="container">
      <?php if(zionhost_get_option('blog_sidebar_pos') == '2') { ?>
	  <!--Sidebar-->
			<?php get_sidebar(); ?>
	  <!--Sidebar end-->
			<?php } ?>
			<div class="<?php if(zionhost_get_option('blog_sidebar_pos') == '1') { ?>content_left<?php } ?><?php if(zionhost_get_option('blog_sidebar_pos') == '2') { ?>content_right<?php } ?>">
				<?php $counter = 1; ?>
				<?php if (have_posts()) :  while (have_posts()) : the_post(); 
					$zionhost_global_post = zionhost_get_global_post();
					$postid = $zionhost_global_post->ID;
					$get_image = esc_url( wp_get_attachment_url( get_post_thumbnail_id($postid) ) ); 
				?>
				<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
				<?php if ($counter == 1) { ?>
				<div class="one_full">
				<?php } elseif ($counter == 2) { ?>
				<div class="one_full animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
				<?php } elseif ($counter == 3) { ?>
				<div class="one_full animate-in" data-anim-type="fade-in-down" data-anim-delay="200">
				<?php } elseif ($counter == 4) { ?>
				<div class="one_full animate-in" data-anim-type="fade-in-down" data-anim-delay="300">
				<?php } elseif ($counter == 5) { ?>
				<div class="one_full animate-in" data-anim-type="fade-in-down" data-anim-delay="400">
				<?php } elseif ($counter == 6) { ?>
				<div class="one_full animate-in" data-anim-type="fade-in-down" data-anim-delay="500">
				<?php } elseif ($counter == 7) { ?>
				<div class="one_full animate-in" data-anim-type="fade-in-down" data-anim-delay="600">
				<?php } elseif ($counter == 8) { ?>
				<div class="one_full animate-in" data-anim-type="fade-in-down" data-anim-delay="700">
				<?php } elseif ($counter == 9) { ?>
				<div class="one_full animate-in" data-anim-type="fade-in-down" data-anim-delay="800">
				<?php } elseif ($counter == 10) { ?>
				<div class="one_full animate-in" data-anim-type="fade-in-down" data-anim-delay="1000">
				<?php } ?>					
					<?php if ( has_post_thumbnail()) : ?>
					<div class="post_img">
					  <div class="overley"></div>
					  <div class="date"> <span><?php echo get_the_time('d'); ?></span><?php echo get_the_time('M, Y'); ?> </div>
					  <div class="date comments"> <span><?php echo get_comments_number(); ?></span><?php esc_html_e('Comments', 'zionhost'); ?> </div>
					  <img class="img-size1" alt="" src="<?php echo esc_url( $get_image ); ?>">
					</div>
					<?php endif; ?>
					<a href="<?php the_permalink();?>">
					<h3 class="uppercase <?php if ( has_post_thumbnail()) : ?>padd_top2<?php endif; ?>"><?php the_title(); ?></h3>
					</a>
				   <div class="post_info"> <span><i class="fa fa-folder-open-o"></i> <?php esc_html_e('Categories', 'zionhost'); ?> / <?php the_category( ', ' ); ?></span> <?php if ( has_tag() ) { ?><span><i class="fa fa-tags"></i> <?php the_tags(); ?></span><?php } ?><span><i class="fa fa-user"></i> <?php esc_html_e('By', 'zionhost'); ?> <?php the_author(); ?> </span> </div>
					<?php if ( has_post_format( 'video' ) ) : ?>
					<?php the_content(); ?>
					<?php else: ?>
					<?php the_excerpt(); ?>
					<?php endif; ?>

					<div class="readmore"><a href="<?php the_permalink();?>" class="btn linebtn"><?php esc_html_e('Read more', 'zionhost'); ?></a></div>
				</div>
				</div>
				<?php if (($wp_query->current_post +1) != ($wp_query->post_count)) { ?>
				<div class="clearfix margin_top7"></div>
				<?php } else { ?>
				<div></div>
				<?php } ?>	
				<?php $counter++; ?>
				<?php endwhile; endif; ?>			
				<!--end item-->

				<div class="divider_dashed2"></div>
				<div class="bl_pagenation_holder one">
					<!--Pagination-->
					<?php zionhost_custom_pagination(); ?>
					<!--End Pagination-->
				</div>				
			</div>
      <?php if(zionhost_get_option('blog_sidebar_pos') == '1') { ?>
	  <!--Sidebar-->
			<?php get_sidebar(); ?>
	  <!--Sidebar end-->
	  <?php } ?>
		</div>
	</section> 

<!-- end section 1 -->
<div class="clearfix"></div>
  <?php if(zionhost_get_option('checkbox_hide_below') == '1') { ?>
  <section class="section11">
    <div class="container">
      <div class="text">
        <h4 class="white-text"><?php echo zionhost_get_option('zionhost_page_bottom_caction'); ?></h4>
      </div>
      <div data-anim-delay="200" data-anim-type="swing" class="readmore animate-in"><a class="btn linebtn one" href="<?php echo esc_url( zionhost_get_option('zionhost_page_bottom_caction_bu') ); ?>"><?php echo zionhost_get_option('zionhost_page_bottom_caction_bl'); ?></a> </div>
    </div>
  </section>
  <!-- end section 6 -->
  <div class="clearfix"></div>
  <?php } ?>
<!--MAIN CONTENT END-->
<?php get_footer(); ?>