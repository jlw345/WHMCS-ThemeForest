<?php
/**
 * 404 page
 */
get_header(); ?>
  <section class="header-section">
    <div class="page_header" <?php if(zionhost_get_option('zionhost_page_header_img') != '') { ?>style="background: rgba(0, 0, 0, 0) url('<?php echo esc_url( zionhost_get_option('zionhost_page_header_img') ); ?>') no-repeat scroll center top;"<?php } ?>>
      <div class="container">
        <h2 class="align_center pagetitle"><?php esc_html_e('404', 'zionhost'); ?></h2>
        <?php if (function_exists('zionhost_wordpress_breadcrumbs')) zionhost_wordpress_breadcrumbs(); ?>
      </div>
    </div>
  </section>
  <!-- end page header -->
  <div class="clearfix"></div>
  
  <section class="common_section">
    <div class="container">
      <div class="error_holder">
        <h1 class="uppercase title cyan"><?php esc_html_e('404', 'zionhost'); ?></h1>
        <br>
        <h2 class="uppercase"><?php esc_html_e('Oops... Page Not Found!', 'zionhost'); ?></h2>
        <p><?php esc_html_e('Sorry the Page Could not be Found here. Try using the button below to go to main page of the site', 'zionhost'); ?></p>
        <br>
        <br>
        <br>
        <div class="newsletter two">
          <form id="sky-form" class="sky-form">
            <div class="get-btn">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn darkbox"><?php esc_html_e('Go Home', 'zionhost'); ?></a>
			</div>
          </form>
        </div>
      </div>
    </div>
  </section>
<!-- end section 1 -->
<div class="clearfix"></div>
  <?php if(zionhost_get_option('checkbox_hide_below') == '1') { ?>
  <section class="section11">
    <div class="container">
      <div class="text">
        <h4 class="white-text"><?php echo zionhost_get_option('zionhost_page_bottom_caction'); ?></h4>
      </div>
      <div data-anim-delay="200" data-anim-type="swing" class="readmore animate-in"><a class="btn linebtn one" href="<?php echo esc_url( zionhost_get_option('zionhost_page_bottom_caction_bu') ); ?>"><?php echo zionhost_get_option('zionhost_page_bottom_caction_bl'); ?></a> </div>
    </div>
  </section>
  <!-- end section 6 -->
  <div class="clearfix"></div>
  <?php } ?>
<!--MAIN CONTENT END-->
<?php get_footer(); ?>