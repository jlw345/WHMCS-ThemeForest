<?php
if ( ( is_404() ) || ( is_search() ) ) {
$crossed_footer = 'straight';
} else {
$zionhost_post = zionhost_get_global_wpquery();
$postid = $zionhost_post->post->ID;
$crossed_footer = get_post_meta($postid, 'footer_key', true);
}
if( !defined('ZIONHOST_CONTACT_PATH') )
	define( 'ZIONHOST_CONTACT_PATH', get_template_directory_uri() . '/subscribe/' );
?>
<!-- COPY START FROM THIS LINE TO PLACE THIS INTO THE FOOTER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
<footer class="<?php if( ( $crossed_footer == 'straight' ) || ( $crossed_footer == '' ) ){ ?> footer-cross<?php } ?>">
<div class="footer <?php if( $crossed_footer == 'crossed' ) { ?>seven<?php } ?>">
<?php if( $crossed_footer == 'crossed' ) { ?><div class="crossed_shape"></div><?php } ?>
    <div class="container">
      <div <?php if(zionhost_get_option('footer_newsletter') == '3') { ?>class="fe-col animate-in"<?php } else { ?>class="one_fourth animate-in"<?php } ?> data-anim-type="fade-in-right" data-anim-delay="100">
        <?php if(zionhost_get_option('footer_newsletter') == '3') { ?>
		<h4 class="white footer-h4"><?php esc_html_e('About Company', 'zionhost'); ?></h4>
		<?php } else { ?>
		<h4 class="white"><?php esc_html_e('About Company', 'zionhost'); ?></h4>
		<?php } ?>
        <div class="title_line"></div>
        <p><?php echo zionhost_get_option('cosonix_about_info'); ?></p>
        <div class="clearfix margin_top1"></div>
        <ul class="faddress">
		<?php if(zionhost_get_option('cosonix_address_info') != '') { ?>
        <li><i class="fa fa-map-marker fa-lg"></i>&nbsp;&nbsp;<?php echo zionhost_get_option('cosonix_address_info'); ?></li>
		<?php } if(zionhost_get_option('cosonix_phn_number') != '') { ?>
        <li><i class="fa fa-phone"></i>&nbsp;&nbsp;<?php echo zionhost_get_option('cosonix_phn_number'); ?></li>
		<?php } if(zionhost_get_option('cosonix_email_id') != '') { ?>
        <li><a href="mailto:<?php echo zionhost_get_option('cosonix_email_id'); ?>"><i class="fa fa-envelope"></i>&nbsp;&nbsp;<?php echo zionhost_get_option('cosonix_email_id'); ?></a></li>
        <?php } ?>
		</ul>
      </div>
      <!--end item-->
      
      <div <?php if(zionhost_get_option('footer_newsletter') == '3') { ?>class="fe-col animate-in"<?php } else { ?>class="one_fourth animate-in"<?php } ?> data-anim-type="fade-in-right" data-anim-delay="200">
        <?php if(zionhost_get_option('footer_newsletter') == '3') { ?><h4 class="white footer-h4"><?php } else { ?><h4 class="white"><?php } if(zionhost_get_option('cosonix_useful_links') != '') { ?><?php echo zionhost_get_option('cosonix_useful_links'); ?><?php } else { ?><?php esc_html_e('Useful Links', 'zionhost'); ?><?php } ?></h4>
        <div class="title_line"></div>
        <ul class="listitem">
							<?php
								wp_nav_menu(array(
								'theme_location' 	=>'zionhost_menu_footer_one', 'container' => '', 'items_wrap' => '%3$s', 'before' => '<i class="fa fa-angle-right"></i>&nbsp;',
								)); 
							?>
        </ul>
      </div>
      <!--end item-->
      
	  <div <?php if(zionhost_get_option('footer_newsletter') == '3') { ?>class="fe-col animate-in"<?php } else { ?>class="one_fourth animate-in"<?php } ?> data-anim-type="fade-in-right" data-anim-delay="300">
        <?php if(zionhost_get_option('footer_newsletter') == '3') { ?><h4 class="white footer-h4"><?php } else { ?><h4 class="white"><?php } if(zionhost_get_option('cosonix_legal_links') != '') { ?><?php echo zionhost_get_option('cosonix_legal_links'); ?><?php } else { ?><?php esc_html_e('Legal and Help', 'zionhost'); ?><?php } ?></h4>
        <div class="title_line"></div>
		<ul class="listitem">
							<?php
								wp_nav_menu(array(
								'theme_location' 	=>'zionhost_menu_footer_two', 'container' => '', 'items_wrap' => '%3$s', 'before' => '<i class="fa fa-angle-right"></i>&nbsp;',
								)); 
							?>
        </ul>
      </div>
      <!--end item--> 

      <?php if(zionhost_get_option('footer_newsletter') == '1') { ?>
	  <div class="one_fourth last animate-in" data-anim-type="fade-in-right" data-anim-delay="400">
        <h4 class="white"><?php esc_html_e('Recent Posts', 'zionhost'); ?></h4>
        <div class="title_line"></div>
        <div class="clearfix margin_top1"></div>
		
        <ul class="postlist">
		<?php			
										$zionhost_imgpath = get_template_directory_uri();
										$args = array(
										'posts_per_page'   => 2,
										'orderby'          => 'post_date',
										'order'            => 'DESC',
										'post_type'        => 'post',
										'post_status'      => 'publish',
										); 

										$footer_latestpost = new WP_Query( $args );
										if ($footer_latestpost->have_posts()) :
										while($footer_latestpost->have_posts()) : $footer_latestpost->the_post() ;
										?>
        <li class="footerli">
		<?php if ( has_post_thumbnail() ) { ?>
		<div class="img_left3"><?php echo get_the_post_thumbnail( $post->ID, array( 68, 72) ); ?></div>
		<?php } else { ?>
        <img class="img_left3 footerli-image" alt="" src="<?php echo esc_url( $zionhost_imgpath ); ?>/images/avatars/thumbnail.png">
		<?php } ?>
        <a class="footerli-a" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></br>
		<?php echo wp_html_excerpt (get_the_content( $post->ID ), 15); ?><?php esc_html_e(' - By', 'zionhost'); ?> <?php the_author(); ?> / <?php echo get_the_time('M, Y'); ?>
        </li>
										<?php endwhile; ?>
										<?php endif; ?>
        </ul>
        <?php if(zionhost_get_option('footer_styles') == '1') { ?>
		<div class="clearfix margin_top2"></div>
        
        <ul class="social_icons animate-in" data-anim-type="fade-in-right" data-anim-delay="400">
          <?php if(zionhost_get_option('social_facebook') != '') { ?>
		  <li><a href="<?php echo esc_url( zionhost_get_option('social_facebook') ); ?>"><i class="fa fa-facebook"></i></a></li>
		  <?php } if(zionhost_get_option('social_twitter') != '') { ?>
          <li><a href="<?php echo esc_url( zionhost_get_option('social_twitter') ); ?>"><i class="fa fa-twitter"></i></a></li>
		  <?php } if(zionhost_get_option('social_googleplus') != '') { ?>
          <li><a href="<?php echo esc_url( zionhost_get_option('social_googleplus') ); ?>"><i class="fa fa-google-plus"></i></a></li>
		  <?php } if(zionhost_get_option('social_linkedin') != '') { ?>
          <li><a href="<?php echo esc_url( zionhost_get_option('social_linkedin') ); ?>"><i class="fa fa-linkedin"></i></a></li>
		  <?php } if(zionhost_get_option('social_instagram') != '') { ?>
		  <li><a href="<?php echo esc_url( zionhost_get_option('social_instagram') ); ?>"><i class="fa fa-instagram"></i></a></li>
		  <?php } if(zionhost_get_option('social_flckr') != '') { ?>
          <li class="last"><a href="<?php echo esc_url( zionhost_get_option('social_flckr') ); ?>"><i class="fa fa-flickr"></i></a></li>
		  <?php } ?>
        </ul>
		<?php } ?>
      </div>
	  <?php } ?>
	  <?php if(zionhost_get_option('footer_newsletter') == '2') { ?>
	  <div class="one_fourth last animate-in" data-anim-type="fade-in-right" data-anim-delay="400">
        <h4 class="white"><?php esc_html_e('Subscribe Newsletter', 'zionhost'); ?></h4>
        <div class="title_line"></div>
        <p><?php esc_html_e('Subscribe to our email newsletter for', 'zionhost'); ?> <br>
		<?php esc_html_e('useful tips and valuable resources.', 'zionhost'); ?></p>
        <div class="clearfix margin_top1"></div>
        
        <div class="newsletter">
		  <?php if(zionhost_get_option('ft_aweber_listid') != '') { ?>
		  <form method="post" action="https://www.aweber.com/scripts/addlead.pl">
			<input type="hidden" name="redirect" value="<?php esc_url( zionhost_get_option('aweber_redirectpage') ) ?>" />
			<input type="hidden" name="meta_redirect_onlist" value="<?php esc_url( zionhost_get_option('aweber_redirectpage_old') ) ?>" />
			<input type="hidden" name="meta_message" value="1" /> 
			<input type="hidden" name="meta_required" value="email" />
			<input type="text" name="email" class="email_input" id="samplees" placeholder="<?php esc_html_e('Enter your E-mail...', 'zionhost') ?>" value="" />
            <input type="submit" class="email_submit" value="<?php esc_html_e('Subscribe', 'zionhost');?>" name="submit">
          </form>
		  <?php } elseif (zionhost_get_option('mailchimp_apikey') != ''){ ?>
		  <form id="footer_signup" action="<?php echo CONTACT_PATH . 'subscribe.php' ?>" method="post">
							<input class="email_input" name="email" id="email" placeholder="<?php esc_html_e('Enter your E-mail...', 'zionhost') ?>" type="email"/>
							<input class="email_submit" value="<?php esc_html_e('Subscribe', 'zionhost');?>" type="submit"/>
						</form>
		  <?php } else { ?>
		  <form method="post" action="#">
			<input type="hidden" name="redirect" value="<?php esc_url( zionhost_get_option('aweber_redirectpage') ) ?>" />
			<input type="hidden" name="meta_redirect_onlist" value="<?php esc_url( zionhost_get_option('aweber_redirectpage_old') ) ?>" />
			<input type="hidden" name="meta_message" value="1" /> 
			<input type="hidden" name="meta_required" value="email" />
			<input type="text" name="email" class="email_input" id="samplees" placeholder="<?php esc_html_e('Enter your E-mail...', 'zionhost') ?>" value="" />
            <input type="submit" class="email_submit" value="<?php esc_html_e('Subscribe', 'zionhost');?>" name="submit">
          </form>
		  <?php } ?>		  
        </div>
		<div id="footer_response" class="margin_top2"></div>
        
        <?php if(zionhost_get_option('footer_styles') == '1') { ?>
		<div class="clearfix margin_top2"></div>
        
        <ul class="social_icons animate-in" data-anim-type="fade-in-right" data-anim-delay="400">
          <?php if(zionhost_get_option('social_facebook') != '') { ?>
		  <li><a href="<?php echo esc_url( zionhost_get_option('social_facebook') ); ?>"><i class="fa fa-facebook"></i></a></li>
		  <?php } if(zionhost_get_option('social_twitter') != '') { ?>
          <li><a href="<?php echo esc_url( zionhost_get_option('social_twitter') ); ?>"><i class="fa fa-twitter"></i></a></li>
		  <?php } if(zionhost_get_option('social_googleplus') != '') { ?>
          <li><a href="<?php echo esc_url( zionhost_get_option('social_googleplus') ); ?>"><i class="fa fa-google-plus"></i></a></li>
		  <?php } if(zionhost_get_option('social_linkedin') != '') { ?>
          <li><a href="<?php echo esc_url( zionhost_get_option('social_linkedin') ); ?>"><i class="fa fa-linkedin"></i></a></li>
		  <?php } if(zionhost_get_option('social_instagram') != '') { ?>
		  <li><a href="<?php echo esc_url( zionhost_get_option('social_instagram') ); ?>"><i class="fa fa-instagram"></i></a></li>
		  <?php } if(zionhost_get_option('social_flckr') != '') { ?>
          <li class="last"><a href="<?php echo esc_url( zionhost_get_option('social_flckr') ); ?>"><i class="fa fa-flickr"></i></a></li>
		  <?php } ?>
        </ul>
		<?php } ?>
      </div>
	  <?php } ?>
      <!--end item--> 
      
    </div>
  </div>
<!--end footer-->
  <?php if(zionhost_get_option('footer_styles') == '1') { ?>
  <div class="copyrights">
    <div class="container">
      <div class="one_half"><span><?php if(zionhost_get_option('copy_text') != '') { ?><?php echo zionhost_get_option('copy_text'); ?><?php } else { ?><?php esc_html_e('Copyright - 2016 yourdomian. All rights reserved.', 'zionhost'); ?><?php } ?></span></div>
      <?php if((zionhost_get_option('express_logo_url') != '') || (zionhost_get_option('master_logo_url') != '') || (zionhost_get_option('visa_logo_url') != '') || (zionhost_get_option('paypal_logo_url') != '') || (zionhost_get_option('mastero_logo_url') != '')) { ?>
	  <div class="one_half last">
        <div class="payments"><span><?php esc_html_e('Payments We Accept', 'zionhost'); ?></span> <img src="<?php echo zionhost_get_option('express_logo_url'); ?>" alt=""> <img src="<?php echo zionhost_get_option('master_logo_url'); ?>" alt=""> <img src="<?php echo zionhost_get_option('visa_logo_url'); ?>" alt=""> <img src="<?php echo zionhost_get_option('paypal_logo_url'); ?>" alt=""> <img src="<?php echo zionhost_get_option('mastero_logo_url'); ?>" alt=""></div>
      </div>
	  <?php } ?>
    </div>
  </div>
  <?php } if(zionhost_get_option('footer_styles') == '2') { ?>
  <div class="copyrights one">
	<div class="container socil-media">
	<h2 class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100"><?php esc_html_e('Social Media', 'zionhost'); ?></h2>
	<div class="social-list animate-in" data-anim-type="fade-in-up" data-anim-delay="200">
		<ul class="social_icons">
          <?php if(zionhost_get_option('social_facebook') != '') { ?>
		  <li><a href="<?php echo esc_url( zionhost_get_option('social_facebook') ); ?>"><i class="fa fa-facebook"></i></a></li>
		  <?php } if(zionhost_get_option('social_twitter') != '') { ?>
          <li><a href="<?php echo esc_url( zionhost_get_option('social_twitter') ); ?>"><i class="fa fa-twitter"></i></a></li>
		  <?php } if(zionhost_get_option('social_googleplus') != '') { ?>
          <li><a href="<?php echo esc_url( zionhost_get_option('social_googleplus') ); ?>"><i class="fa fa-google-plus"></i></a></li>
		  <?php } if(zionhost_get_option('social_linkedin') != '') { ?>
          <li><a href="<?php echo esc_url( zionhost_get_option('social_linkedin') ); ?>"><i class="fa fa-linkedin"></i></a></li>
		  <?php } if(zionhost_get_option('social_instagram') != '') { ?>
		  <li><a href="<?php echo esc_url( zionhost_get_option('social_instagram') ); ?>"><i class="fa fa-instagram"></i></a></li>
		  <?php } if(zionhost_get_option('social_flckr') != '') { ?>
          <li class="last"><a href="<?php echo esc_url( zionhost_get_option('social_flckr') ); ?>"><i class="fa fa-flickr"></i></a></li>
		  <?php } ?>
        </ul>
	</div>
	</div>

	<div class="container">
      <div class="one_half"><span><?php if(zionhost_get_option('copy_text') != '') { ?><?php echo zionhost_get_option('copy_text'); ?><?php } else { ?><?php esc_html_e('Copyright - 2016 yourdomian. All rights reserved.', 'zionhost'); ?><?php } ?></span></div>
      <?php if((zionhost_get_option('express_logo_url') != '') || (zionhost_get_option('master_logo_url') != '') || (zionhost_get_option('visa_logo_url') != '') || (zionhost_get_option('paypal_logo_url') != '') || (zionhost_get_option('mastero_logo_url') != '')) { ?>
	  <div class="one_half last">
        <div class="payments"><span><?php esc_html_e('Payments We Accept', 'zionhost'); ?></span> <img src="<?php echo zionhost_get_option('express_logo_url'); ?>" alt=""> <img src="<?php echo zionhost_get_option('master_logo_url'); ?>" alt=""> <img src="<?php echo zionhost_get_option('visa_logo_url'); ?>" alt=""> <img src="<?php echo zionhost_get_option('paypal_logo_url'); ?>" alt=""> <img src="<?php echo zionhost_get_option('mastero_logo_url'); ?>" alt=""></div>
      </div>
	  <?php } ?>
    </div>
  </div>
  <?php } ?>
<!--end copyrights--> 
</footer>
<!-- COPY END TILL THIS LINE TO PLACE THIS INTO THE FOOTER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
<?php
wp_reset_query();
?>
</div>
<?php if(zionhost_get_option('zionhost_site_width') == '1') { ?>
</div>
<?php } ?>
<!--end sitewraper--> 

<a href="#" class="scrollup"></a> 
<!-- end scroll to top of the page-->
<?php
if (zionhost_get_option('mailchimp_apikey') != ''){
get_template_part( 'subscribe/mailchimp_validation' );
} 
?>
	<?php
		/* Always have wp_footer() just before the closing </body>
		* tag of your theme, or you will break many plugins, which
		* generally use this hook to reference JavaScript files.
		*/

		wp_footer();	
	?>
</body>
</html>