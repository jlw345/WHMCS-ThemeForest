<?php
/**
 * The template for displaying Comments.
 */

if ( post_password_required() )
	return;
?>


	<?php // You can start editing here -- including this comment! ?>

	<?php if ( have_comments() ) : ?>
		<br>
		<h4><?php comments_number(esc_html__('There Is No Comment Yet', 'zionhost'), esc_html__('There Is 1 Comment', 'zionhost'), esc_html__('There Are % Comments', 'zionhost') );?></h4>					
				<ul>
					<?php wp_list_comments( array( 'callback' => 'zionhost_comment', 'style' => 'ul' ) ); ?>
				</ul><!-- .commentlist -->
				<div class="clearfix"></div>
				<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : // are there comments to navigate through ?>
				<div class="bl_pagenation_holder one">
					<ul class="page-numbers">
					  <li><?php esc_url( previous_comments_link( '<i class="fa fa-angle-left"></i>' ) ) ?></li>
					  <li><?php esc_url( next_comments_link( '<i class="fa fa-angle-right"></i>', 0 ) ) ?></li>
					</ul>
                </div>
				<?php endif; ?>
				<?php
				/* If there are no comments and comments are closed, let's leave a note.
				 * But we only want the note on posts and pages that had comments in the first place.
				 */
				if ( ! comments_open() ) : ?>
					<h4 class="margin_top2"><?php esc_html_e( 'Comments are closed.' , 'zionhost' ); ?></h4>
				<?php endif; ?>
			 
	<?php endif; // have_comments() ?>
	<?php if ( comments_open() ) : ?>
		<div class="clearfix"></div>
		<div class="review_form_holders">
            <div class="cforms">
				<div class="sky-form">
			<?php comment_form(array(
			'title_reply' => 'Post A Comment',
			)); ?>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	<?php endif; ?>
