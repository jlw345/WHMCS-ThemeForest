<?php
/**
 * Template name: Contact
 */
if( !defined('ZIONHOST_CONTACT_PATH') )
	define( 'ZIONHOST_CONTACT_PATH', get_template_directory_uri() . '/subscribe/' );
get_header(); ?>
  <section class="header-section">
    <div class="page_header" <?php if(zionhost_get_option('zionhost_page_header_img') != '') { ?>style="background: rgba(0, 0, 0, 0) url('<?php echo esc_url( zionhost_get_option('zionhost_page_header_img') ); ?>') no-repeat scroll center top;"<?php } ?>>
      <div class="container">
        <h2 class="align_center pagetitle"><?php esc_html_e('Contact Us', 'zionhost'); ?></h2>
        <?php if (function_exists('zionhost_wordpress_breadcrumbs')) zionhost_wordpress_breadcrumbs(); ?>
      </div>
    </div>
  </section>
  <!-- end page header -->
  <div class="clearfix"></div>
 
<section class="common_section">
<div class="container">
	<div class="one_third">
<div class="address_info">
<h4 class="uppercase"><strong><?php esc_html_e('Address Info', 'zionhost'); ?></strong></h4>
	  <?php if(zionhost_get_option('cosonix_address_info') != '') { ?>
	  <div class="address-info animate-in" data-anim-delay="200" data-anim-type="bounce-in-down">
      <div class="icon"><i class="fa fa-map-marker fa-lg"></i></div>
      <div class="text-info">
      <h2><?php esc_html_e('Reach Us', 'zionhost'); ?></h2>
      <?php echo zionhost_get_option('cosonix_address_info'); ?>
      </div>
      </div>
	  <?php } if(zionhost_get_option('cosonix_phn_number') != '') { ?>
      
      <div class="address-info animate-in" data-anim-delay="300" data-anim-type="bounce-in-down">
      <div class="icon"><i class="fa fa-phone"></i></div>
      <div class="text-info">
      <h2><?php esc_html_e('Call Us', 'zionhost'); ?></h2>
      <?php echo zionhost_get_option('cosonix_phn_number'); ?>
      </div>
      </div>
      <?php } if(zionhost_get_option('cosonix_email_id') != '') { ?>
      <div class="address-info animate-in" data-anim-delay="400" data-anim-type="bounce-in-down">
      <div class="icon"><i class="fa fa-envelope"></i></div>
      <div class="text-info">
      <h2><?php esc_html_e('Mail Us', 'zionhost'); ?></h2>
      <?php echo zionhost_get_option('cosonix_email_id'); ?>
      </div>
      </div>
	  <?php } ?>
        </div><!-- end section -->  
	  </div>
      
      <div class="two_third wid98 last animate-in" data-anim-delay="200" data-anim-type="bounce-in-down">
      
	<form action="<?php echo ZIONHOST_CONTACT_PATH . 'contact-form.php' ?>" method="get" id="contact-form" class="sky-form">
          <h4><strong><?php esc_html_e('send us a message', 'zionhost');?></strong></h4>
          <fieldset>
            <div class="row">
              <section class="col col-6">
                <label class="label"><?php esc_html_e('Name', 'zionhost');?></label>
                <label class="input"> <i class="icon-append fa fa-user"></i>
                  <input type="text" name="contact-name" id="contact-name">
                </label>
              </section>
              <section class="col col-6">
                <label class="label"><?php esc_html_e('E-mail', 'zionhost');?></label>
                <label class="input"> <i class="icon-append fa fa-envelope-o"></i>
                  <input type="email" name="contact-email" id="contact-email">
                </label>
              </section>
            </div>
            <section>
              <label class="label"><?php esc_html_e('Subject', 'zionhost');?></label>
              <label class="input"> <i class="icon-append fa fa-tags"></i>
                <input type="text" name="contact-subject" id="contact-subject">
              </label>
            </section>
            <section>
              <label class="label"><?php esc_html_e('Message', 'zionhost');?></label>
              <label class="textarea"> <i class="icon-append fa fa-comment"></i>
                <textarea rows="4" name="contact-msg" id="contact-msg"></textarea>
              </label>
            </section>
			<input type="hidden" name="contact-submit" id="contact-submit" value="true" />
          </fieldset>
          <footer>
            <button name="submit" id="submit" type="submit" class="button"><?php esc_html_e('Send message', 'zionhost');?></button>
          </footer>
          <span class="spinner spinner-style"><?php esc_html_e('Sending...', 'zionhost');?></span>
		  <div id="contactsMsgs"></div>
        </form>
      </div><!-- end section --> 
  </div>
</section> 
<!-- end section 1 -->
<div class="clearfix"></div>

 
<section class="common_section">
<div class="one_full">
<?php if(zionhost_get_option('zionhost_google_map') != '') { ?>
<div class="content-container embed-container maps">
<?php echo zionhost_get_option('zionhost_google_map'); ?>
</div>
<?php } else { ?>
<div class="content-container embed-container maps no-display">
</div>
<?php } ?>
</div>
</section>
<!-- end section 1 -->
<div class="clearfix"></div>
  <?php if(zionhost_get_option('checkbox_hide_below') == '1') { ?>
  <section class="section11">
    <div class="container">
      <div class="text">
        <h4 class="white-text"><?php echo zionhost_get_option('zionhost_page_bottom_caction'); ?></h4>
      </div>
      <div data-anim-delay="200" data-anim-type="swing" class="readmore animate-in"><a class="btn linebtn one" href="<?php echo esc_url( zionhost_get_option('zionhost_page_bottom_caction_bu') ); ?>"><?php echo zionhost_get_option('zionhost_page_bottom_caction_bl'); ?></a> </div>
    </div>
  </section>
  <!-- end section 6 -->
  <div class="clearfix"></div>
  <?php } ?>
<!--MAIN CONTENT END-->
<?php get_footer(); ?>