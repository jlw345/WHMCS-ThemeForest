<!doctype html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html <?php language_attributes(); ?> class="no-js">
<!--<![endif]-->
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	
	<!-- Favicon -->
	<?php if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ) { ?>
    <link rel="shortcut icon" href="<?php echo zionhost_get_option('cosonix_favicon'); ?>">
	<?php } ?>
	
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php if(zionhost_get_option('zionhost_preloader') == '1') { ?>
<div class="preloader">
  <div class="preloader_status"></div>
</div>
<?php } ?>
<!-- end page loader -->
<?php if(zionhost_get_option('zionhost_site_width') == '1') { ?>
<div class="wrapper_boxed">
<?php } ?>
<div class="site_wrapper"> 
  
  <?php if(zionhost_get_option('header_styles') == '1') { ?>
  <!-- header style 1-->
  <header> 
    <!-- COPY START FROM THIS LINE TO PLACE THIS INTO THE HEADER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
    <!-- Top header bar -->
	<?php if(zionhost_get_option('top_bar_section') == '1') { ?>
    <div id="topHeader">
      <div class="wrapper">
        <div class="top_nav">
          <div class="container">
            <ul class="left">
              <?php if(zionhost_get_option('flag_images') == '1') { ?>
			  <li><?php if(zionhost_get_option('flag_img1') != '') { ?>
				<a href="<?php echo esc_url( zionhost_get_option('flag_img1_url') ); ?>"><img src="<?php echo zionhost_get_option('flag_img1'); ?>" alt=""></a><?php } else { ?><a href=""><img src="<?php echo esc_url( get_template_directory_uri() ).'/images/'; ?>flag-1.png" alt=""></a>
				<?php } if(zionhost_get_option('flag_img2') != '') { ?>
				<a href="<?php echo esc_url( zionhost_get_option('flag_img2_url') ); ?>"><img src="<?php echo zionhost_get_option('flag_img2'); ?>" alt=""></a><?php } else { ?><a href=""><img src="<?php echo esc_url( get_template_directory_uri() ).'/images/'; ?>flag-2.png" alt=""></a>
				<?php } if(zionhost_get_option('flag_img3') != '') { ?>
				<a href="<?php echo esc_url( zionhost_get_option('flag_img3_url') ); ?>"><img src="<?php echo zionhost_get_option('flag_img3'); ?>" alt=""></a><?php } else { ?><a href=""><img src="<?php echo esc_url( get_template_directory_uri() ).'/images/'; ?>flag-3.png" alt=""></a>
				<?php } if(zionhost_get_option('flag_img4') != '') { ?>
				<a href="<?php echo esc_url( zionhost_get_option('flag_img4_url') ); ?>"><img src="<?php echo zionhost_get_option('flag_img4'); ?>" alt=""></a><?php } else { ?><a href=""><img src="<?php echo esc_url( get_template_directory_uri() ).'/images/'; ?>flag-4.png" alt=""></a>
				<?php } if(zionhost_get_option('flag_img5') != '') { ?>
				<a href="<?php echo esc_url( zionhost_get_option('flag_img5_url') ); ?>"><img src="<?php echo zionhost_get_option('flag_img5'); ?>" alt="" class="last"></a><?php } else { ?><a href=""><img src="<?php echo esc_url( get_template_directory_uri() ).'/images/'; ?>flag-5.png" alt="" class="last"></a>
				<?php } ?>
			  </li>
			  <?php } ?>
              <?php if(zionhost_get_option('social_facebook') != '') { ?>
			  <li><a href="<?php echo esc_url( zionhost_get_option('social_facebook') ); ?>"><i class="fa fa-facebook"></i></a></li>
			  <?php } if(zionhost_get_option('social_twitter') != '') { ?>
			  <li><a href="<?php echo esc_url( zionhost_get_option('social_twitter') ); ?>"><i class="fa fa-twitter"></i></a></li>
			  <?php } if(zionhost_get_option('social_googleplus') != '') { ?>
			  <li><a href="<?php echo esc_url( zionhost_get_option('social_googleplus') ); ?>"><i class="fa fa-google-plus"></i></a></li>
			  <?php } if(zionhost_get_option('social_linkedin') != '') { ?>
			  <li class="last"><a href="<?php echo esc_url( zionhost_get_option('social_linkedin') ); ?>"><i class="fa fa-linkedin"></i></a></li>
			  <?php } ?>
            </ul>
            <ul class="right-nav">
			  <?php if(zionhost_get_option('login_register') == '1') { ?>
              <?php if(zionhost_get_option('cosonix_login') != '') { ?>
			  <li><a href="<?php echo esc_url( zionhost_get_option('cosonix_login') ); ?>"><i class="fa fa-user"></i> <?php echo esc_attr( zionhost_get_option('cosonix_login_label') ); ?></a></li><?php } else { ?>
			  <li><a href="#"><i class="fa fa-user"></i> <?php esc_html_e('Login', 'zionhost'); ?></a></li>
              <?php } if(zionhost_get_option('cosonix_register') != '') { ?>
			  <li><a href="<?php echo esc_url( zionhost_get_option('cosonix_register') ); ?>"><i class="fa fa-user"></i> <?php echo esc_attr( zionhost_get_option('cosonix_register_label') ); ?></a></li><?php } else { ?>
			  <li><a href="#"><i class="fa fa-user"></i> <?php esc_html_e('Register', 'zionhost'); ?></a></li> <?php } ?>
			  <?php } if(zionhost_get_option('cosonix_phn_number') != '') { ?>
              <li class="phoneno"><i class="fa fa-phone"></i> <a href="tel:<?php echo zionhost_get_option('cosonix_phn_number'); ?>"><?php echo zionhost_get_option('cosonix_phn_number'); ?></a></li>
			  <?php } if(zionhost_get_option('cosonix_email_id') != '') { ?>
              <li class="last"><a href="mailto:<?php echo zionhost_get_option('cosonix_email_id'); ?>"><i class="fa fa-envelope-o"></i> <?php esc_html_e('E-mail Us', 'zionhost'); ?></a></li>
			  <?php } ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
	<?php } ?>
    <!-- end top navigation -->
    
    <div class="scrollto_sticky">
      <div class="container"> 
        
        <!-- Logo -->
        <div class="logo nosmash">
			<?php if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) : ?>
				<?php zionhost_the_custom_logo(); ?>
			  <?php else: ?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<img alt="logo" src="<?php if(zionhost_get_option('logo_url') != '') { ?><?php echo esc_url( zionhost_get_option('logo_url') ); ?><?php } else { ?><?php echo esc_url( get_template_directory_uri() ).'/images/'; ?>logo.png<?php } ?>" />
			</a>
			<?php endif; ?>
		</div>
        
        <!-- Menu -->
        <div class="menu_main new_floating">
          <div class="navbar yamm navbar-default new_m_bottom">
              <div class="navbar-header">
                <div class="navbar-toggle .navbar-collapse .pull-right " data-toggle="collapse" data-target="#navbar-collapse-1"  > <span><?php esc_html_e('Menu', 'zionhost'); ?></span>
                  <button type="button" > <i class="fa fa-bars"></i></button>
                </div>
              </div>
              <div id="navbar-collapse-1" class="navbar-collapse collapse pull-right">
				<?php
				if (has_nav_menu('zionhost_primary_menu')) {
                wp_nav_menu( array(
					'theme_location'    => 'zionhost_primary_menu',
					'container'     => 'nav',
					'container_id'      => '',
					'conatiner_class'   => '',
					'menu_class'        => 'nav navbar-nav menu-even', 
					'echo'          => true,
					'items_wrap'        => '<ul id="%1$s" class="%2$s">%3$s</ul>',
					'depth'         => 10, 
					'walker'        => new zionhost_walker_nav_menu
				) );
				}
				?>
              </div>
          </div>
        </div>
        <!-- end menu --> 
      </div>
    </div>
	<!-- COPY END TILL THIS LINE TO PLACE THIS INTO THE HEADER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
  </header>
  <?php } if(zionhost_get_option('header_styles') == '2') { ?>
  <!-- header style 2-->
  <header> 
    <!-- COPY START FROM THIS LINE TO PLACE THIS INTO THE HEADER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
    <div id="topHeader">
      <div class="wrapper">
        <div class="top_nav top_nav2">
          <div class="container">
		   <!-- Logo -->
		   <div class="logo two left" <?php if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) : ?>style="padding: 16px 0; margin: 0;"<?php endif; ?>><?php if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) : ?>
				<?php zionhost_the_custom_logo(); ?>
			  <?php else: ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php if(zionhost_get_option('logo_url') != '') { ?><?php echo esc_url( zionhost_get_option('logo_url') ); ?><?php } else { ?><?php echo esc_url( get_template_directory_uri() ).'/images/'; ?>logo-black.png<?php } ?>" alt="logo" /></a><?php endif; ?></div>

            <ul class="right-nav one">
			  <?php if(zionhost_get_option('login_register') == '1') { ?>
              <?php if(zionhost_get_option('cosonix_login') != '') { ?>
			  <li><a href="<?php echo esc_url( zionhost_get_option('cosonix_login') ); ?>"><i class="fa fa-user"></i> <?php echo esc_attr( zionhost_get_option('cosonix_login_label') ); ?></a></li><?php } else { ?>
			  <li><a href="#"><i class="fa fa-user"></i> <?php esc_html_e('Login', 'zionhost'); ?></a></li>
              <?php } if(zionhost_get_option('cosonix_register') != '') { ?>
			  <li><a href="<?php echo esc_url( zionhost_get_option('cosonix_register') ); ?>"><i class="fa fa-user"></i> <?php echo esc_attr( zionhost_get_option('cosonix_register_label') ); ?></a></li><?php } else { ?>
			  <li><a href="#"><i class="fa fa-user"></i> <?php esc_html_e('Register', 'zionhost'); ?></a></li> <?php } ?>
			  <?php } if(zionhost_get_option('cosonix_phn_number') != '') { ?>
              <li class="phoneno"><i class="fa fa-phone"></i> <?php echo zionhost_get_option('cosonix_phn_number'); ?></li>
			  <?php } if(zionhost_get_option('cosonix_email_id') != '') { ?>
              <li class="last"><a href="mailto:<?php echo zionhost_get_option('cosonix_email_id'); ?>"><i class="fa fa-envelope-o"></i> <?php esc_html_e('E-mail Us', 'zionhost'); ?></a></li>
			  <?php } ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
    
	<div class="scrollto_sticky three">
      <div class="container"> 
        
        <!-- Menu -->
        <div class="menu_main menu_main3">
          <div class="navbar yamm navbar-default">
              <div class="navbar-header">
                <div class="navbar-toggle .navbar-collapse .pull-right " data-toggle="collapse" data-target="#navbar-collapse-1"  > <span><?php esc_html_e('Menu', 'zionhost'); ?></span>
                  <button type="button" > <i class="fa fa-bars"></i></button>
                </div>
              </div>
              <div id="navbar-collapse-1" class="navbar-collapse collapse pull-right">
				<?php
				if (has_nav_menu('zionhost_primary_menu')) {
                wp_nav_menu( array(
					'theme_location'    => 'zionhost_primary_menu',
					'container'     => 'nav',
					'container_id'      => '',
					'conatiner_class'   => '',
					'menu_class'        => 'nav navbar-nav three menu-even', 
					'echo'          => true,
					'items_wrap'        => '<ul id="%1$s" class="%2$s">%3$s</ul>',
					'depth'         => 10, 
					'walker'        => new zionhost_walker_nav_menu
				) );
				}
				?>
				<ul class="social_icons one left">
				  <?php if(zionhost_get_option('social_facebook') != '') { ?>
				  <li><a href="<?php echo esc_url( zionhost_get_option('social_facebook') ); ?>"><i class="fa fa-facebook"></i></a></li>
				  <?php } if(zionhost_get_option('social_twitter') != '') { ?>
				  <li><a href="<?php echo esc_url( zionhost_get_option('social_twitter') ); ?>"><i class="fa fa-twitter"></i></a></li>
				  <?php } if(zionhost_get_option('social_googleplus') != '') { ?>
				  <li><a href="<?php echo esc_url( zionhost_get_option('social_googleplus') ); ?>"><i class="fa fa-google-plus"></i></a></li>
				  <?php } if(zionhost_get_option('social_linkedin') != '') { ?>
				  <li class="last"><a href="<?php echo esc_url( zionhost_get_option('social_linkedin') ); ?>"><i class="fa fa-linkedin"></i></a></li>
				  <?php } ?>
				</ul>
              </div>
          </div>
        </div>
        <!-- end menu --> 
      </div>
    </div>
	<!-- COPY END TILL THIS LINE TO PLACE THIS INTO THE HEADER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
  </header>
  <?php } if(zionhost_get_option('header_styles') == '3') { ?>
  <!-- header style 3-->
  <header> 
    <!-- COPY START FROM THIS LINE TO PLACE THIS INTO THE HEADER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
    <div id="topHeader">
      <div class="wrapper">
        <div class="top_nav top_nav2">
          <div class="container">
		   <!-- Logo -->
		   <div class="logo two left" <?php if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) : ?>style="padding: 16px 0; margin: 0;"<?php endif; ?>><?php if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) : ?>
				<?php zionhost_the_custom_logo(); ?>
			  <?php else: ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php if(zionhost_get_option('logo_url') != '') { ?><?php echo esc_url( zionhost_get_option('logo_url') ); ?><?php } else { ?><?php echo esc_url( get_template_directory_uri() ).'/images/'; ?>logo-black.png<?php } ?>" alt="logo" /></a><?php endif; ?></div>

            <ul class="right-nav one">
			  <?php if(zionhost_get_option('login_register') == '1') { ?>
              <?php if(zionhost_get_option('cosonix_login') != '') { ?>
			  <li><a href="<?php echo esc_url( zionhost_get_option('cosonix_login') ); ?>"><i class="fa fa-user"></i> <?php echo esc_attr( zionhost_get_option('cosonix_login_label') ); ?></a></li><?php } else { ?>
			  <li><a href="#"><i class="fa fa-user"></i> <?php esc_html_e('Login', 'zionhost'); ?></a></li>
              <?php } if(zionhost_get_option('cosonix_register') != '') { ?>
			  <li><a href="<?php echo esc_url( zionhost_get_option('cosonix_register') ); ?>"><i class="fa fa-user"></i> <?php echo esc_attr( zionhost_get_option('cosonix_register_label') ); ?></a></li><?php } else { ?>
			  <li><a href="#"><i class="fa fa-user"></i> <?php esc_html_e('Register', 'zionhost'); ?></a></li> <?php } ?>
			  <?php } if(zionhost_get_option('cosonix_phn_number') != '') { ?>
              <li class="phoneno"><i class="fa fa-phone"></i> <?php echo zionhost_get_option('cosonix_phn_number'); ?></li>
			  <?php } if(zionhost_get_option('cosonix_email_id') != '') { ?>
              <li class="last"><a href="mailto:<?php echo zionhost_get_option('cosonix_email_id'); ?>"><i class="fa fa-envelope-o"></i> <?php esc_html_e('E-mail Us', 'zionhost'); ?></a></li>
			  <?php } ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
    
	<div class="scrollto_sticky four">
      <div class="container"> 
        
        <!-- Menu -->
        <div class="menu_main menu_main3">
          <div class="navbar yamm navbar-default">
              <div class="navbar-header">
                <div class="navbar-toggle .navbar-collapse .pull-right " data-toggle="collapse" data-target="#navbar-collapse-1"  > <span><?php esc_html_e('Menu', 'zionhost'); ?></span>
                  <button type="button" > <i class="fa fa-bars"></i></button>
                </div>
              </div>
              <div id="navbar-collapse-1" class="navbar-collapse collapse pull-right">
				<?php
				if (has_nav_menu('zionhost_primary_menu')) {
                wp_nav_menu( array(
					'theme_location'    => 'zionhost_primary_menu',
					'container'     => 'nav',
					'container_id'      => '',
					'conatiner_class'   => '',
					'menu_class'        => 'nav navbar-nav three four menu-even', 
					'echo'          => true,
					'items_wrap'        => '<ul id="%1$s" class="%2$s">%3$s</ul>',
					'depth'         => 10, 
					'walker'        => new zionhost_walker_nav_menu
				) );
				}
				?>
				<ul class="social_icons one left">
				  <?php if(zionhost_get_option('social_facebook') != '') { ?>
				  <li><a href="<?php echo esc_url( zionhost_get_option('social_facebook') ); ?>"><i class="fa fa-facebook"></i></a></li>
				  <?php } if(zionhost_get_option('social_twitter') != '') { ?>
				  <li><a href="<?php echo esc_url( zionhost_get_option('social_twitter') ); ?>"><i class="fa fa-twitter"></i></a></li>
				  <?php } if(zionhost_get_option('social_googleplus') != '') { ?>
				  <li><a href="<?php echo esc_url( zionhost_get_option('social_googleplus') ); ?>"><i class="fa fa-google-plus"></i></a></li>
				  <?php } if(zionhost_get_option('social_linkedin') != '') { ?>
				  <li class="last"><a href="<?php echo esc_url( zionhost_get_option('social_linkedin') ); ?>"><i class="fa fa-linkedin"></i></a></li>
				  <?php } ?>
				</ul>
              </div>
          </div>
        </div>
        <!-- end menu --> 
      </div>
    </div>
	<!-- COPY END TILL THIS LINE TO PLACE THIS INTO THE HEADER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
  </header>
  <?php } if(zionhost_get_option('header_styles') == '4') { ?>
  <!-- header style 4-->
  <header> 
    <!-- COPY START FROM THIS LINE TO PLACE THIS INTO THE HEADER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
    <div id="topHeader">
      <div class="wrapper">
        <div class="top_nav top_nav2 top_nav3">
          <div class="container">
		   <!-- Logo -->
		   <div class="logo two left" <?php if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) : ?>style="padding: 16px 0; margin: 0;"<?php endif; ?>><?php if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) : ?>
				<?php zionhost_the_custom_logo(); ?>
			  <?php else: ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php if(zionhost_get_option('logo_url') != '') { ?><?php echo esc_url( zionhost_get_option('logo_url') ); ?><?php } else { ?><?php echo esc_url( get_template_directory_uri() ).'/images/'; ?>logo.png<?php } ?>" alt="logo" /></a><?php endif; ?></div>

            <ul class="right-nav one">
			  <?php if(zionhost_get_option('login_register') == '1') { ?>
              <?php if(zionhost_get_option('cosonix_login') != '') { ?>
			  <li><a href="<?php echo esc_url( zionhost_get_option('cosonix_login') ); ?>"><i class="fa fa-user"></i> <?php echo esc_attr( zionhost_get_option('cosonix_login_label') ); ?></a></li><?php } else { ?>
			  <li><a href="#"><i class="fa fa-user"></i> <?php esc_html_e('Login', 'zionhost'); ?></a></li>
              <?php } if(zionhost_get_option('cosonix_register') != '') { ?>
			  <li><a href="<?php echo esc_url( zionhost_get_option('cosonix_register') ); ?>"><i class="fa fa-user"></i> <?php echo esc_attr( zionhost_get_option('cosonix_register_label') ); ?></a></li><?php } else { ?>
			  <li><a href="#"><i class="fa fa-user"></i> <?php esc_html_e('Register', 'zionhost'); ?></a></li> <?php } ?>
			  <?php } if(zionhost_get_option('cosonix_phn_number') != '') { ?>
              <li class="phoneno"><i class="fa fa-phone"></i> <?php echo zionhost_get_option('cosonix_phn_number'); ?></li>
			  <?php } if(zionhost_get_option('cosonix_email_id') != '') { ?>
              <li class="last"><a href="mailto:<?php echo zionhost_get_option('cosonix_email_id'); ?>"><i class="fa fa-envelope-o"></i> <?php esc_html_e('E-mail Us', 'zionhost'); ?></a></li>
			  <?php } ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
    
	<div class="scrollto_sticky five">
      <div class="container"> 
        
        <!-- Menu -->
        <div class="menu_main menu_main3">
          <div class="navbar yamm navbar-default">
              <div class="navbar-header">
                <div class="navbar-toggle .navbar-collapse .pull-right " data-toggle="collapse" data-target="#navbar-collapse-1"  > <span><?php esc_html_e('Menu', 'zionhost'); ?></span>
                  <button type="button" > <i class="fa fa-bars"></i></button>
                </div>
              </div>
              <div id="navbar-collapse-1" class="navbar-collapse collapse pull-right">
				<?php
				if (has_nav_menu('zionhost_primary_menu')) {
                wp_nav_menu( array(
					'theme_location'    => 'zionhost_primary_menu',
					'container'     => 'nav',
					'container_id'      => '',
					'conatiner_class'   => '',
					'menu_class'        => 'nav navbar-nav three five menu-even', 
					'echo'          => true,
					'items_wrap'        => '<ul id="%1$s" class="%2$s">%3$s</ul>',
					'depth'         => 10, 
					'walker'        => new zionhost_walker_nav_menu
				) );
				}
				?>
				<ul class="social_icons two three left">
				  <?php if(zionhost_get_option('social_facebook') != '') { ?>
				  <li><a href="<?php echo esc_url( zionhost_get_option('social_facebook') ); ?>"><i class="fa fa-facebook"></i></a></li>
				  <?php } if(zionhost_get_option('social_twitter') != '') { ?>
				  <li><a href="<?php echo esc_url( zionhost_get_option('social_twitter') ); ?>"><i class="fa fa-twitter"></i></a></li>
				  <?php } if(zionhost_get_option('social_googleplus') != '') { ?>
				  <li><a href="<?php echo esc_url( zionhost_get_option('social_googleplus') ); ?>"><i class="fa fa-google-plus"></i></a></li>
				  <?php } if(zionhost_get_option('social_linkedin') != '') { ?>
				  <li class="last"><a href="<?php echo esc_url( zionhost_get_option('social_linkedin') ); ?>"><i class="fa fa-linkedin"></i></a></li>
				  <?php } ?>
				</ul>
              </div>
          </div>
        </div>
        <!-- end menu --> 
      </div>
    </div>
	<!-- COPY END TILL THIS LINE TO PLACE THIS INTO THE HEADER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
  </header>
  <?php } if(zionhost_get_option('header_styles') == '5') { ?>
  <!-- header style 5-->
  <header> 
    <!-- COPY START FROM THIS LINE TO PLACE THIS INTO THE HEADER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
    
	<div class="scrollto_sticky eight">
      <div class="container"> 
        
        <!-- Logo -->
		   <div class="logo" <?php if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) : ?>style="padding: 16px 0; margin: 0;"<?php endif; ?>><?php if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) : ?>
				<?php zionhost_the_custom_logo(); ?>
			  <?php else: ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php if(zionhost_get_option('logo_url') != '') { ?><?php echo esc_url( zionhost_get_option('logo_url') ); ?><?php } else { ?><?php echo esc_url( get_template_directory_uri() ).'/images/'; ?>logo-white.png<?php } ?>" alt="logo" /></a><?php endif; ?></div>
			  
		<!-- Menu -->
        <div class="menu_main">
          <div class="navbar yamm navbar-default">
              <div class="navbar-header">
                <div class="navbar-toggle .navbar-collapse .pull-right " data-toggle="collapse" data-target="#navbar-collapse-1"  > <span><?php esc_html_e('Menu', 'zionhost'); ?></span>
                  <button type="button" > <i class="fa fa-bars"></i></button>
                </div>
              </div>
              <div id="navbar-collapse-1" class="navbar-collapse collapse pull-right">
				<?php
				if (has_nav_menu('zionhost_primary_menu')) {
                wp_nav_menu( array(
					'theme_location'    => 'zionhost_primary_menu',
					'container'     => 'nav',
					'container_id'      => '',
					'conatiner_class'   => '',
					'menu_class'        => 'nav navbar-nav eight menu-even', 
					'echo'          => true,
					'items_wrap'        => '<ul id="%1$s" class="%2$s">%3$s</ul>',
					'depth'         => 10, 
					'walker'        => new zionhost_walker_nav_menu
				) );
				}
				?>
              </div>
          </div>
        </div>
        <!-- end menu --> 
      </div>
    </div>
	<!-- COPY END TILL THIS LINE TO PLACE THIS INTO THE HEADER.TPL OF WHMCS Zionhost-alt TEMPLATE -->
  </header>
  <div style="margin-bottom: -90px;"></div>
  <?php } ?>
<div class="clearfix"></div>