<?php
function zionhost_get_global_themedata() {
    global $zionhost_theme_data;
    return $zionhost_theme_data;
}
$zionhost_themes_data = zionhost_get_global_themedata();
$zionhost_themes_data = wp_get_theme( get_stylesheet_directory() . '/style.css' );

/* -----------------------------------------------------------------------------
 * Definations
 * -------------------------------------------------------------------------- */
if( !defined('ZIONHOST_ADMIN_PATH') )
	define( 'ZIONHOST_ADMIN_PATH', get_template_directory() . '/framework/admin/' );
if( !defined('ZIONHOST_INIT_PATH') )
	define( 'ZIONHOST_INIT_PATH', get_template_directory() . '/framework/' );
if( !defined('ZIONHOST_INCLUDE_PATH') )
	define( 'ZIONHOST_INCLUDE_PATH', get_template_directory() . '/inc/' );
if( !defined('ZIONHOST_LANGUAGE_PATH') )
	define( 'ZIONHOST_LANGUAGE_PATH', get_template_directory() . '/languages/' );

require_once( ZIONHOST_INIT_PATH . 'init.php' );