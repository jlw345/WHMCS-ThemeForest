<?php

/* -----------------------------------------------------------------------------
 * Helper Function
 * -------------------------------------------------------------------------- */
function zionhost_get_option( $opt_name, $default = null ) {
	global $Redux_Options;
	return $Redux_Options->get( $opt_name, $default );
}
/* -----------------------------------------------------------------------------
 * Load Custom Fields
 * -------------------------------------------------------------------------- */
require_once( ZIONHOST_ADMIN_PATH . 'custom-fields/field_font_upload/field_upload.php' );
require_once( ZIONHOST_ADMIN_PATH . 'custom-fields/field_typography.php' );
require_once( ZIONHOST_ADMIN_PATH . 'custom-fields/field_section_info.php' );
require_once( ZIONHOST_ADMIN_PATH . 'custom-fields/field_sidebar_select.php' );
require_once( ZIONHOST_ADMIN_PATH . 'custom-fields/field_color_scheme.php' );
require_once( ZIONHOST_ADMIN_PATH . 'custom-fields/field_slider.php' );
require_once( ZIONHOST_ADMIN_PATH . 'custom-fields/field_slides.php' );
/* -----------------------------------------------------------------------------
 * Initial Redux Framework
 * -------------------------------------------------------------------------- */


if(!class_exists('Redux_Options')) {
	//define('Redux_OPTIONS_URL', site_url('path the options folder'));
	require_once( ZIONHOST_ADMIN_PATH . 'options/defaults.php' );
}
/*
 *
 * Most of your editing will be done in this section.
 *
 * Here you can override default values, uncomment args and change their values.
 * No $args are required, but they can be over ridden if needed.
 *
 */
function zionhost_setup_framework_options() {
	$args = array();

	$args['std_show'] = true; // If true, it shows the std value

	// Set the class for the dev mode tab icon.
	// This is ilicered unless $args['icon_type'] = 'iconfont'
	// Default: null
	$args['dev_mode_icon_class'] = 'icon-large';

	// Setup custom links in the footer for share icons
	$args['share_icons']['twitter'] = array(
		'link' => 'http://twitter.com/ghost1227',
		'title' => esc_html__('Follow me on Twitter', 'zionhost'),
		'img' => Redux_OPTIONS_URL . 'img/social/Twitter.png'
	);
	$args['share_icons']['linked_in'] = array(
		'link' => 'http://www.linkedin.com/profile/view?id=52559281',
		'title' => esc_html__('Find me on LinkedIn', 'zionhost'),
		'img' => Redux_OPTIONS_URL . 'img/social/LinkedIn.png'
	);

	// Set the class for the import/export tab icon.
	// This is ilicered unless $args['icon_type'] = 'iconfont'
	// Default: null
	$args['import_icon_class'] = 'icon-large';

	// Set a custom option name. Don't forget to replace spaces with underscores!
	$args['opt_name'] = 'zionhost_theme_options';

	// Set a custom title for the options page.
	// Default: Options
	$args['menu_title'] = esc_html__('Theme Options', 'zionhost');

	// Set a custom page title for the options page.
	// Default: Options
	$args['page_title'] = esc_html__('Theme Options', 'zionhost');

	// Set a custom page slug for options page (wp-admin/themes.php?page=***).
	// Default: redux_options
	$args['page_slug'] = 'redux_options';

	// Set the menu type. Set to "menu" for a top level menu, or "submenu" to add below an existing item.
	// Default: menu
	$args['page_type'] = 'menu';

	// Set the parent menu.
	// Default: themes.php
	$args['page_parent'] = 'themes.php';

	// Set the icon type. Set to "iconfont" for Font Awesome, or "image" for traditional.
	// Redux no longer ships with standard icons!
	// Default: iconfont
	//$args['icon_type'] = 'image';
	$args['dev_mode_icon_type'] = 'iconfont';
	$args['import_icon_type'] = 'iconfont';
	$allowed_html_array = array(
    'p' => array(),
    'h4' => array(),
	'strong' => array(),
	);
	$args['intro_text'] = wp_kses( __( '<h4>Theme Settings Information for Zionhost Theme</h4>', 'zionhost' ), $allowed_html_array );

	$sections = array();
	
	//section for General-logo, favicon, ratina, custom css
	$sections[] = array(
						'icon_type' => 'iconfont',
						'icon' => 'globe',
						'icon_class' => 'icon-large',
						'title' => esc_html__('General', 'zionhost'),
						'desc' => wp_kses( __('<p class="description">This is the general options.</p>', 'zionhost'), $allowed_html_array ),
						'fields' => array(
										    array(
												'id' => 'logo_url',
												'type' => 'upload',
												'title' => esc_html__('Upload Main Logo', 'zionhost'),
												'sub_desc' => esc_html__('This is the main logo', 'zionhost'),
											),
											
											array(
												'id' => 'cosonix_favicon',
												'type' => 'upload',
												'title' => esc_html__('Upload Favicon', 'zionhost'),
												'sub_desc' => esc_html__('This is favicon. Upload 64x64 favicon icon.', 'zionhost'),
											),
											
											array(
												'id' => 'header_styles',
												'type' => 'radio',
												'title' => esc_html__('Website Header Styles', 'zionhost'), 
												'sub_desc' => esc_html__('Choose a Header Style for your Website', 'zionhost'),
												'options' => array('1' => 'Header Style 1', '2' => 'Header Style 2', '3' => 'Header Style 3', '4' => 'Header Style 4', '5' => 'Header Style 5'), // Must provide key => value pairs for radio options
												'std' => '1'
											),
											
											array(
												'id' => 'zionhost_woocommerce_sidebar_switch',
												'type' => 'radio',
												'title' => esc_html__('WooCommerce Pages Sidebar', 'zionhost'),
												'options' => array('1' => 'Right Sidebar', '2' => 'Left Sidebar', '3' => 'No Sidebar'), // Must provide key => value pairs for radio options
												'std' => '1'
											),
											
											array(
												'id' => 'zionhost_site_animations',
												'type' => 'checkbox_hide_below',
												'title' => esc_html__('Switch On/Off Animations', 'zionhost'), 
												'desc' => esc_html__('Switch On/Off Fade-In Effects Animations', 'zionhost'),
												'switch' => true,
												'std' => '1' // 1 = checked | 0 = unchecked
											),
											
											array(
												'id' => 'zionhost_site_width',
												'type' => 'checkbox_hide_below',
												'title' => esc_html__('Switch On for Boxed Style', 'zionhost'), 
												'sub_desc' => esc_html__('Want to disable Full-Width and enable Boxed Style for your website?', 'zionhost'),
												'desc' => esc_html__('Check this if you want to have Boxed Style', 'zionhost'),
												'switch' => true,
												'std' => '0' // 1 = checked | 0 = unchecked
											),
											
											array(
												'id' => 'zionhost_bg_Pattern',
												'type' => 'radio',
												'title' => esc_html__('Choose Background Pattern', 'zionhost'), 
												'options' => array('1' => 'Default', '2' => 'Pattern - 1', '3' => 'Pattern - 2', '4' => 'Pattern - 3', '5' => 'Pattern - 4', '6' => 'Pattern - 5', '7' => 'Pattern - 6', '8' => 'Pattern - 7', '9' => 'Pattern - 8', '10' => 'Pattern - 9', '11' => 'Pattern - 10', '12' => 'Pattern - 11', '13' => 'Pattern - 12'), // Must provide key => value pairs for radio options
												'std' => '1'
											),
											
											array(
												'id' => 'ten_colors',
												'type' => 'radio',
												'title' => esc_html__('Website Ready-Made Colors', 'zionhost'), 
												'sub_desc' => esc_html__('Choose a Global Color for your Website', 'zionhost'),
												'options' => array('1' => 'Blue', '2' => 'Red', '3' => 'Orange', '4' => 'Olive', '5' => 'Green', '6' => 'Pink', '7' => 'Violet', '8' => 'Sea', '9' => 'Light Blue', '10' => 'Light Green'), // Must provide key => value pairs for radio options
												'std' => '1'
											),																						
											
											array( 
												"title" => esc_html__("Custom CSS", 'zionhost'),
												"sub_desc" => esc_html__("Advanced CSS options. Paste your CSS code and it will override existing code style.", 'zionhost'),
												"id" => "textarea_csscode",
												"std" => "",
												"type" => "textarea"
											),

										)
	);
	
		//section for Social icon url
	$sections[] = array(
					'icon_type' => 'iconfont',
					'icon' => 'group',
					'icon_class' => 'icon-large',
					'title' => esc_html__('Social Media', 'zionhost'),
					'desc' => wp_kses( __('<p class="description">This is options for setting up the social media of website. Do not forget to use http:// for any social urls.</p>', 'zionhost'), $allowed_html_array ),
					'fields' => array(
                                                    array(
																'id' => 'social_facebook',
																'type' => 'text',
																'title' => esc_html__('Facebook URL', 'zionhost'), 
																'sub_desc' => esc_html__('The URL to your account page', 'zionhost'),
																'std' => '',
													),
													
													array(
                                                                'id' => 'social_twitter',
                                                                'type' => 'text',
                                                                'title' => esc_html__('Twitter URL', 'zionhost'),
                                                                'sub_desc' => esc_html__('The URL to your account page', 'zionhost'),
                                                                'std' => '',
                                                    ),
													
													array(
                                                                'id' => 'social_linkedin',
                                                                'type' => 'text',
                                                                'title' => esc_html__('Linkedin URL', 'zionhost'),
                                                                'sub_desc' => esc_html__('The URL to your account page', 'zionhost'),
                                                                'std' => '',
                                                    ),

													array(
																'id' => 'social_googleplus',
																'type' => 'text',
																'title' => esc_html__('GooglePlus URL', 'zionhost'), 
																'sub_desc' => esc_html__('The URL to your account page', 'zionhost'),
																'std' => '',
													),

													array(
																'id' => 'social_instagram',
																'type' => 'text',
																'title' => esc_html__('Instagram URL', 'zionhost'), 
																'sub_desc' => esc_html__('The URL to your account page', 'zionhost'),
																'std' => '',
													),													
													
													array(
																'id' => 'social_flckr',
																'type' => 'text',
																'title' => esc_html__('Flicker URL', 'zionhost'), 
																'sub_desc' => esc_html__('The URL to your account page', 'zionhost'),
																'std' => '',
													),
							)
				);
		
		//section for top bar
	$sections[] = array(
					'icon_type' => 'iconfont',
					'icon' => 'eye-open',
					'icon_class' => 'icon-large',
					'title' => esc_html__('Top Bar', 'zionhost'),
					'desc' => wp_kses( __('<p class="description">This is options for setting up the top bar of your website.</p>', 'zionhost'), $allowed_html_array ),
					'fields' => array(
                                            array(
												'id' => 'top_bar_section',
												'type' => 'checkbox',
												'title' => esc_html__('Top Bar Section', 'zionhost'),
												'sub_desc' => esc_html__('Show/Hide Top Bar Section.', 'zionhost'),
												'switch' => true,
												'std' => '1' // 1 = checked | 0 = unchecked
											),
											
											array(
												'id' => 'flag_images',
												'type' => 'checkbox',
												'title' => esc_html__('Flag Images for Translated Pages', 'zionhost'),
												'sub_desc' => esc_html__('Show/Hide Flag Images.', 'zionhost'),
												'switch' => true,
												'std' => '1' // 1 = checked | 0 = unchecked
											),
											
											array(
												'id' => 'flag_img1',
												'type' => 'upload',
												'title' => esc_html__('Upload Flag Image - 1', 'zionhost'),
												'sub_desc' => esc_html__('This is flag image for Multilingual service. Upload 16x10 flag image.', 'zionhost'),
											),
											
											array(
												'id' => 'flag_img1_url',
												'type' => 'text',
												'title' => esc_html__('The URL of Above Language Translated Page', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'flag_img2',
												'type' => 'upload',
												'title' => esc_html__('Upload Flag Image - 2', 'zionhost'),
												'sub_desc' => esc_html__('This is flag image for Multilingual service. Upload 16x10 flag image.', 'zionhost'),
											),
											
											array(
												'id' => 'flag_img2_url',
												'type' => 'text',
												'title' => esc_html__('The URL of Above Language Translated Page', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'flag_img3',
												'type' => 'upload',
												'title' => esc_html__('Upload Flag Image - 3', 'zionhost'),
												'sub_desc' => esc_html__('This is flag image for Multilingual service. Upload 16x10 flag image.', 'zionhost'),
											),
											
											array(
												'id' => 'flag_img3_url',
												'type' => 'text',
												'title' => esc_html__('The URL of Above Language Translated Page', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'flag_img4',
												'type' => 'upload',
												'title' => esc_html__('Upload Flag Image - 4', 'zionhost'),
												'sub_desc' => esc_html__('This is flag image for Multilingual service. Upload 16x10 flag image.', 'zionhost'),
											),
											
											array(
												'id' => 'flag_img4_url',
												'type' => 'text',
												'title' => esc_html__('The URL of Above Language Translated Page', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'flag_img5',
												'type' => 'upload',
												'title' => esc_html__('Upload Flag Image - 5', 'zionhost'),
												'sub_desc' => esc_html__('This is flag image for Multilingual service. Upload 16x10 flag image.', 'zionhost'),
											),
											
											array(
												'id' => 'flag_img5_url',
												'type' => 'text',
												'title' => esc_html__('The URL of Above Language Translated Page', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'login_register',
												'type' => 'checkbox',
												'title' => esc_html__('Login and Register Link', 'zionhost'),
												'sub_desc' => esc_html__('Show/Hide Login and Register Link.', 'zionhost'),
												'switch' => true,
												'std' => '1' // 1 = checked | 0 = unchecked
											),
											
											array(
												'id' => 'cosonix_login',
												'type' => 'text',
												'title' => esc_html__('User Login Page URL', 'zionhost'), 
												'sub_desc' => esc_html__('The URL to user login page. Example: http://yourdomain.com/wp-login.php', 'zionhost'),
												'std' => '',
											),
											
											array(
												'id' => 'cosonix_login_label',
												'type' => 'text',
												'title' => esc_html__('Login Text', 'zionhost'),
												'std' => '',
											),
											
											array(
												'id' => 'cosonix_register',
												'type' => 'text',
												'title' => esc_html__('User Registration Page URL', 'zionhost'), 
												'sub_desc' => esc_html__('The URL to user registration page. Example: http://yourdomain.com/wp-login.php?action=register', 'zionhost'),
												'std' => '',
											),
											
											array(
												'id' => 'cosonix_register_label',
												'type' => 'text',
												'title' => esc_html__('Register Text', 'zionhost'),
												'std' => '',
											),
							)
				);
				
		//section for page
					$sections[] = array(
							'icon_type' => 'iconfont',
							'icon' => 'cogs',
							'icon_class' => 'icon-large',
							'title' => esc_html__('Page Settings', 'zionhost'),
							'desc' => wp_kses( __('<p class="description">General Page Settings</p>', 'zionhost'), $allowed_html_array ),
							'fields' => array(
																						
											array(
												'id' => 'zionhost_preloader',
												'type' => 'checkbox',
												'title' => esc_html__('On/Off Page Loader GIF', 'zionhost'),
												'sub_desc' => esc_html__('On/Off Page Loader GIF', 'zionhost'),
												'switch' => true,
												'std' => '1' // 1 = checked | 0 = unchecked
											),
											
											array(
												'id' => 'zionhost_page_header_img',
												'type' => 'upload',
												'title' => esc_html__('Page Header Background Image', 'zionhost'),
												'sub_desc' => esc_html__('Upload Header Background Image of General Pages and Posts', 'zionhost'),
											),
											
											array(
												'id' => 'checkbox_hide_below',
												'type' => 'checkbox_hide_below',
												'title' => esc_html__('Call to Action Above Footer', 'zionhost'), 
												'sub_desc' => esc_html__('Want to use a call to action bar immediately above the footer?', 'zionhost'),
												'desc' => esc_html__('Check this if you want to use a call to action bar immediately above the footer', 'zionhost'),
												'switch' => true,
												'std' => '0' // 1 = checked | 0 = unchecked
											),
											
											array(
												'id' => 'zionhost_page_bottom_caction',
												'type' => 'text',
												'title' => esc_html__('Call to Action Text', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'zionhost_page_bottom_caction_bl',
												'type' => 'text',
												'title' => esc_html__('Call to Action Button Label', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'zionhost_page_bottom_caction_bu',
												'type' => 'text',
												'title' => esc_html__('Call to Action Button URL', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'portfolio_columns',
												'type' => 'radio',
												'title' => esc_html__('Portfolio Columns', 'zionhost'),
												'options' => array('4' => 'Four Columns', '3' => 'Three Columns'), // Must provide key => value pairs for radio options
												'std' => '4'
											),
											
											array(
												'id' => 'blog_sidebar_pos',
												'type' => 'radio',
												'title' => esc_html__('Blog Sidebar Position', 'zionhost'),
												'options' => array('1' => 'Right Sidebar', '2' => 'Left Sidebar'), // Must provide key => value pairs for radio options
												'std' => '1'
											),
											
											array(
												'id' => 'blog_author',
												'type' => 'checkbox',
												'title' => esc_html__('Blog Post Author Section', 'zionhost'),
												'sub_desc' => esc_html__('On/Off blog post author section in single post page.', 'zionhost'),
												'switch' => true,
												'std' => '0' // 1 = checked | 0 = unchecked
											),																						
							)
						);

		//section for aweber
					$sections[] = array(
							'icon_type' => 'iconfont',
							'icon' => 'cog',
							'icon_class' => 'icon-large',
							'title' => esc_html__('MailChimp/Aweber', 'zionhost'),
							'desc' => wp_kses( __('<p class="description">MailChimp and Aweber settings for subscriber forms of Zionhost</p>', 'zionhost'), $allowed_html_array ),
							'fields' => array(

													array(
																'id' => 'mailchimp_apikey',
																'type' => 'text',
																'title' => esc_html__('MailChimp API Key', 'zionhost'), 
																'sub_desc' => esc_html__('The unique API Key of your MailChimp account', 'zionhost'),
																'std' => '',
													),
													array(
																'id' => 'mailchimp_listid',
																'type' => 'text',
																'title' => esc_html__('MailChimp List ID', 'zionhost'), 
																'sub_desc' => esc_html__('The unique List ID of your MailChimp account', 'zionhost'),
																'std' => '',
													),
													array(
																'id' => '123',
																'type' => 'info',
																'desc' => wp_kses( __('<p class="description">If you want to use Aweber instead of MailChimp use the settings below and keep the above MailChimp fields empty.</p>', 'zionhost'), $allowed_html_array )
													),
													array(
																'id' => 'zionhost_shortcodes_aweber_listid',
																'type' => 'text',
																'title' => esc_html__('Aweber List ID', 'zionhost'), 
																'sub_desc' => esc_html__('The unique List ID of Aweber account', 'zionhost'),
																'std' => '',
													),
													array(
																'id' => 'aweber_redirectpage',
																'type' => 'text',
																'title' => esc_html__('Redirect Page URL', 'zionhost'), 
																'sub_desc' => esc_html__('Redirect page url after submission of Aweber form', 'zionhost'),
																'std' => '',
													),
													array(
																'id' => 'aweber_redirectpage_old',
																'type' => 'text',
																'title' => esc_html__('Redirect Page URL for already subscribed users', 'zionhost'), 
																'sub_desc' => esc_html__('Redirect page url for already subscribed users of Aweber', 'zionhost'),
																'std' => '',
													),
							)
						);
						
		//section for Footer
					$sections[] = array(
							'icon_type' => 'iconfont',
							'icon' => 'columns',
							'icon_class' => 'icon-large',
							'title' => esc_html__('Footer/Contact', 'zionhost'),
							'desc' => wp_kses( __('<p class="description">This is options for Footer and Contact.</p>', 'zionhost'), $allowed_html_array ),
							'fields' => array(
											
											array(
												'id' => 'footer_styles',
												'type' => 'radio',
												'title' => esc_html__('Website Footer Styles', 'zionhost'), 
												'sub_desc' => esc_html__('Choose a Footer Style for your Website', 'zionhost'),
												'options' => array('1' => 'Footer Style 1', '2' => 'Footer Style 2'), // Must provide key => value pairs for radio options
												'std' => '1'
											),
											
											array(
												'id' => 'copy_text',
												'type' => 'textarea',
												'title' => esc_html__('Copyright Text', 'zionhost'),
												'sub_desc' => esc_html__('Enter your Copyright text here', 'zionhost'),
												'std' => '',
											),
											
											array(
												'id' => 'cosonix_about_info',
												'type' => 'textarea',
												'title' => esc_html__('About Company Text', 'zionhost'),
												'sub_desc' => esc_html__('Enter your company info here', 'zionhost'),
												'std' => '',
											),
											
											array(
												'id' => 'cosonix_address_info',
												'type' => 'text',
												'title' => esc_html__('Your Company Address', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'cosonix_phn_number',
												'type' => 'text',
												'title' => esc_html__('Your Contact Phone Number', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'cosonix_email_id',
												'type' => 'text',
												'title' => esc_html__('Your Contact Email ID', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),

											array(
												'id' => 'cosonix_useful_links',
												'type' => 'text',
												'title' => esc_html__('Quick Links Heading - 1', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'cosonix_legal_links',
												'type' => 'text',
												'title' => esc_html__('Quick Links Heading - 2', 'zionhost'), 
												'sub_desc' => '',
												'std' => '',
											),

											array(
												'id' => 'footer_newsletter',
												'type' => 'radio',
												'title' => esc_html__('Fourth Column', 'zionhost'), 
												'sub_desc' => esc_html__('Choose what should be in the fourth column', 'zionhost'),
												'options' => array('1' => 'Recent Posts', '2' => 'Subscribe Newsletter', '3' => 'None'), // Must provide key => value pairs for radio options
												'std' => '1'
											),

											array(
												'id' => 'express_logo_url',
												'type' => 'upload',
												'title' => esc_html__('Upload American Express Logo', 'zionhost'),
												'sub_desc' => esc_html__('Upload American Express logo if you accept American Express Payment', 'zionhost'),
											),
											
											array(
												'id' => 'master_logo_url',
												'type' => 'upload',
												'title' => esc_html__('Upload Master Card Logo', 'zionhost'),
												'sub_desc' => esc_html__('Upload Master Card logo if you accept Master Card Payment', 'zionhost'),
											),
											
											array(
												'id' => 'visa_logo_url',
												'type' => 'upload',
												'title' => esc_html__('Upload Visa Card Logo', 'zionhost'),
												'sub_desc' => esc_html__('Upload Visa Card logo if you accept Visa Card Payment', 'zionhost'),
											),
											
											array(
												'id' => 'paypal_logo_url',
												'type' => 'upload',
												'title' => esc_html__('Upload Paypal Logo', 'zionhost'),
												'sub_desc' => esc_html__('Upload Paypal logo if you accept Paypal Payment', 'zionhost'),
											),
											
											array(
												'id' => 'mastero_logo_url',
												'type' => 'upload',
												'title' => esc_html__('Upload Maestro Logo', 'zionhost'),
												'sub_desc' => esc_html__('Upload Maestro logo if you accept Maestro Payment', 'zionhost'),
											),
											
											array(
												'id' => 'zionhost_google_map',
												'type' => 'text',
												'title' => esc_html__('Google Map URL', 'zionhost'), 
												'sub_desc' => 'Input google map url here if you want to use google map in the Contact Us page.',
												'std' => '',
											),
											
							)
						);					

                        

	$tabs = array();

		$theme_data = wp_get_theme();
		$item_uri = $theme_data->get('ThemeURI');
		$description = $theme_data->get('Description');
		$author = $theme_data->get('Author');
		$author_uri = $theme_data->get('AuthorURI');
		$version = $theme_data->get('Version');
		$tags = $theme_data->get('Tags');

	
	$item_info = '<div class="redux-opts-section-desc">';
	$item_info .= '<p class="redux-opts-item-data description item-uri">' . wp_kses( __('<strong>Theme URL:</strong> ', 'zionhost'), $allowed_html_array ) . '<a href="' . esc_url( $item_uri ) . '" target="_blank">' . $item_uri . '</a></p>';
	$item_info .= '<p class="redux-opts-item-data description item-author">' . wp_kses( __('<strong>Author:</strong> ', 'zionhost'), $allowed_html_array ) . ($author_uri ? '<a href="' . esc_url( $author_uri ) . '" target="_blank">' . $author . '</a>' : $author) . '</p>';
	$item_info .= '<p class="redux-opts-item-data description item-version">' . wp_kses( __('<strong>Version:</strong> ', 'zionhost'), $allowed_html_array ) . $version . '</p>';
	$item_info .= '<p class="redux-opts-item-data description item-description">' . $description . '</p>';
	$item_info .= '<p class="redux-opts-item-data description item-tags">' . wp_kses( __('<strong>Tags:</strong> ', 'zionhost'), $allowed_html_array ) . implode(', ', $tags) . '</p>';
	$item_info .= '</div>';

	global $Redux_Options;
	$Redux_Options = new Redux_Options($sections, $args, $tabs);
}
add_action('init', 'zionhost_setup_framework_options', 0);