<?php
/**
 * The default page template of this theme
 */
get_header(); ?>
  <section class="header-section">
    <div class="page_header" <?php if(zionhost_get_option('zionhost_page_header_img') != '') { ?>style="background: rgba(0, 0, 0, 0) url('<?php echo esc_url( zionhost_get_option('zionhost_page_header_img') ); ?>') no-repeat scroll center top;"<?php } ?>>
      <div class="container">
        <h2 class="align_center pagetitle"><?php if (have_posts()) :  while (have_posts()) : the_post(); $zionhost_global_post = zionhost_get_global_post(); $postid = $zionhost_global_post->ID; ?><?php echo wp_html_excerpt (get_the_title($postid), 20); ?>...<?php endwhile; ?><?php endif; ?></h2>
        <?php if (function_exists('zionhost_wordpress_breadcrumbs')) zionhost_wordpress_breadcrumbs(); ?>
      </div>
    </div>
  </section>
  <!-- end page header -->
  <div class="clearfix"></div>
  
  <section class="common_section section41">
    <div class="container">
		<?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
      <h2><?php the_title(); ?></h2>
		<?php the_content(); ?>
		<?php endwhile; ?><?php endif; ?>
    <div id="comments">
		<?php comments_template( '', true ); ?>
	</div>
    </div>
  </section>
  
<!-- end section 1 -->
<div class="clearfix"></div>
  <?php if(zionhost_get_option('checkbox_hide_below') == '1') { ?>
  <section class="section11">
    <div class="container">
      <div class="text">
        <h4 class="white-text"><?php echo zionhost_get_option('zionhost_page_bottom_caction'); ?></h4>
      </div>
      <div data-anim-delay="200" data-anim-type="swing" class="readmore animate-in"><a class="btn linebtn one" href="<?php echo esc_url( zionhost_get_option('zionhost_page_bottom_caction_bu') ); ?>"><?php echo zionhost_get_option('zionhost_page_bottom_caction_bl'); ?></a> </div>
    </div>
  </section>
  <!-- end section 6 -->
  <div class="clearfix"></div>
  <?php } ?>
<!--MAIN CONTENT END-->
<?php get_footer(); ?>