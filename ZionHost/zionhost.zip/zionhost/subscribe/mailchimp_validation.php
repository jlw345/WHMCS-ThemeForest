<?php
$subscribefile = ZIONHOST_CONTACT_PATH . 'subscribe.php';
$subscribefile_newsletter = ZIONHOST_CONTACT_PATH . 'subscribe-newsletter.php';
?>
<script type="text/javascript">
		jQuery(document).ready(function($) {
			// jQuery Validation
			$("#nesletter").validate({
				// if valid, post data via AJAX
				submitHandler: function() {
					var subscribefile_newsletter="<?php echo esc_url( $subscribefile_newsletter ); ?>";
					$.post(subscribefile_newsletter, { name: $("fname").val(), email: $("#email").val() }, function(data) {
						$('#newsletter_response').html(data);
					});
				},
				// all fields are required
				rules: {
					fname: {
						required: false
					},
					email: {
						required: false,
						email: false
					}
				}
			});
		});
</script>

<script type="text/javascript">
		jQuery(document).ready(function($) {
			// jQuery Validation
			$("#footer_signup").validate({
				// if valid, post data via AJAX
				submitHandler: function() {
					var subscribefile="<?php echo esc_url( $subscribefile ); ?>";
					$.post(subscribefile, { email: $("#email").val() }, function(data) {
						$('#footer_response').html(data);
					});
				},
				// all fields are required
				rules: {
					email: {
						required: true,
						email: true
					}
				}
			});
		});
</script>