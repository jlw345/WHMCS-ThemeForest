<form id="searchform" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" role="search">
<div>
<label class="screen-reader-text" for="s"><?php esc_html_e('Search', 'zionhost'); ?></label>
<input id="s" type="text" placeholder="<?php esc_html_e('Search Here', 'zionhost'); ?>" class="serch_input" name="s" value="">
<input id="searchsubmit" type="submit" value="<?php esc_html_e('Submit', 'zionhost'); ?>">
</div>
</form>