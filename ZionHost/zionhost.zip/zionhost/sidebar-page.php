            <!--Right Sidebar-->
			<?php if ( is_active_sidebar( 'zionhost_sidebar' ) ) { ?>
            <div class="right_sidebar sidebar-page">
                    <!--widget area-->
                    <?php dynamic_sidebar( 'zionhost_sidebar' ); ?>
                    <!--End widget area-->
            </div>
			<?php } ?>
            <!--End Right Sidebar-->