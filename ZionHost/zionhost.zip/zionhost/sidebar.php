            <!--Right Sidebar-->
			<?php if ( is_active_sidebar( 'zionhost_sidebar' ) ) { ?>
            <div class="<?php if(zionhost_get_option('blog_sidebar_pos') == '1') { ?>right_sidebar<?php } ?><?php if(zionhost_get_option('blog_sidebar_pos') == '2') { ?>left_sidebar<?php } ?>">
                    <!--widget area-->
                    <?php dynamic_sidebar( 'zionhost_sidebar' ); ?>
                    <!--End widget area-->
            </div>
			<?php } ?>
            <!--End Right Sidebar-->