	Welcome to king-theme community!
	
	- You are using the ArkaHost wordpress theme from king-theme.com
	- This theme is a premium and and sold only on ThemeForest.net
	- If you have any question or trouble while using this theme, please go to our help center http://help.king-theme.com
	
	* * * * *
		
	Thank You for choosing us!