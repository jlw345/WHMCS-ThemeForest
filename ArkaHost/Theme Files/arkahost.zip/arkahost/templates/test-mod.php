<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $post, $more, $king;

//get_header();

do_action('test_mod');

//get_footer();
?>
