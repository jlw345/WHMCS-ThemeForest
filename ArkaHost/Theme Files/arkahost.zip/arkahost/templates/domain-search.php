<?php

?>

<form action="" method="get">
	<input type="text" onblur="if (this.value == '') {this.value = 'Enter your Domain Name here...';}" onfocus="if(this.value == 'Enter your Domain Name here...') {this.value = '';}" value="Enter your Domain Name here..." id="samplees" name="samplees" class="inp1">
	<input type="submit" class="inpubmit" value="Search" name="" />
</form>