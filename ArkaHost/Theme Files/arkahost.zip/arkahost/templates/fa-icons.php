<div class="one_fourth">
    
        <i class="fa fa-adjust"></i> fa-adjust
        <br>
        <i class="fa fa-anchor"></i> fa-anchor
        
        <br>
        <i class="fa fa-archive"></i> fa-archive
        
        <br>
        <i class="fa fa-area-chart"></i> fa-area-chart
            
        <br>
        <i class="fa fa-arrows"></i> fa-arrows
            
        <br>
        <i class="fa fa-arrows-h"></i> fa-arrows-h
            
        <br>
        <i class="fa fa-arrows-v"></i> fa-arrows-v
            
        <br>
        <i class="fa fa-asterisk"></i> fa-asterisk
            
        <br>
        <i class="fa fa-at"></i> fa-at
            
        <br>
        <i class="fa fa-automobile"></i> fa-automobile <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-ban"></i> fa-ban
            
        <br>
        <i class="fa fa-bank"></i> fa-bank <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-bar-chart"></i> fa-bar-chart
            
        <br>
        <i class="fa fa-bar-chart-o"></i> fa-bar-chart-o <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-barcode"></i> fa-barcode
            
        <br>
        <i class="fa fa-bars"></i> fa-bars
            
        <br>
        <i class="fa fa-beer"></i> fa-beer
            
        <br>
        <i class="fa fa-bell"></i> fa-bell
            
        <br>
        <i class="fa fa-bell-o"></i> fa-bell-o
                        
        <br>
        <i class="fa fa-bolt"></i> fa-bolt
            
        <br>
        <i class="fa fa-bomb"></i> fa-bomb
            
        <br>
        <i class="fa fa-book"></i> fa-book
            
        <br>
        <i class="fa fa-bookmark"></i> fa-bookmark
            
        <br>
        <i class="fa fa-bookmark-o"></i> fa-bookmark-o
            
        <br>
        <i class="fa fa-briefcase"></i> fa-briefcase
            
        <br>
        <i class="fa fa-bug"></i> fa-bug
            
        <br>
        <i class="fa fa-building"></i> fa-building
            
        <br>
        <i class="fa fa-building-o"></i> fa-building-o
            
        <br>
        <i class="fa fa-bullhorn"></i> fa-bullhorn
            
        <br>
        <i class="fa fa-bullseye"></i> fa-bullseye
            
        <br>
        <i class="fa fa-bus"></i> fa-bus
            
        <br>
        <i class="fa fa-cab"></i> fa-cab <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-calculator"></i> fa-calculator
            
        <br>
        <i class="fa fa-calendar"></i> fa-calendar
            
        <br>
        <i class="fa fa-calendar-o"></i> fa-calendar-o
            
        <br>
        <i class="fa fa-camera"></i> fa-camera
            
        <br>
        <i class="fa fa-camera-retro"></i> fa-camera-retro
            
        <br>
        <i class="fa fa-car"></i> fa-car
            
        <br>
        <i class="fa fa-caret-square-o-down"></i> fa-caret-square-o-down
            
        <br>
        <i class="fa fa-caret-square-o-left"></i> fa-caret-square-o-left
            
        <br>
        <i class="fa fa-caret-square-o-right"></i> fa-caret-square-o-right
            
        <br>
        <i class="fa fa-caret-square-o-up"></i> fa-caret-square-o-up
            
        <br>
        <i class="fa fa-cc"></i> fa-cc
            
        <br>
        <i class="fa fa-certificate"></i> fa-certificate
            
        <br>
        <i class="fa fa-check"></i> fa-check
            
        <br>
        <i class="fa fa-check-circle"></i> fa-check-circle
            
        <br>
        <i class="fa fa-check-circle-o"></i> fa-check-circle-o
            
        <br>
        <i class="fa fa-check-square"></i> fa-check-square
            
        <br>
        <i class="fa fa-check-square-o"></i> fa-check-square-o
            
        <br>
        <i class="fa fa-child"></i> fa-child
            
        <br>
        <i class="fa fa-circle"></i> fa-circle
            
        <br>
        <i class="fa fa-circle-o"></i> fa-circle-o
        
        <br>
        <i class="fa fa-arrows-alt"></i> fa-arrows-alt
        
        <br>
        <i class="fa  fa-backward"></i> fa-backward
        
        <br>
        <i class="fa  fa-compress"></i> fa-compress
        
        <br>
        <i class="fa  fa-eject"></i> fa-eject
        
        <br>
        <i class="fa  fa-expand"></i> fa-expand
        
        <br>
        <i class="fa  fa-fast-backward"></i> fa-fast-backward
        
        <br>
        <i class="fa  fa-fast-forward"></i> fa-fast-forward
        
        <br>
        <i class="fa  fa-forward"></i> fa-forward
        
        <br>
        <i class="fa  fa-pause"></i> fa-pause
        
        <br>
        <i class="fa  fa-play"></i> fa-play
        
        <br>
        <i class="fa  fa-play-circle"></i> fa-play-circle
        
        <br>
        <i class="fa  fa-play-circle-o"></i> fa-play-circle-o
        
        <br>
        <i class="fa  fa-step-backward"></i> fa-step-backward
        
        <br>
        <i class="fa  fa-step-forward"></i> fa-step-forward
        
        <br>
        <i class="fa  fa-stop"></i> fa-stop
        
        <br>
        <i class="fa  fa-youtube-play"></i> fa-youtube-play
        
        <br>     
        <i class="fa fa-adn"></i> fa-adn
        
        <br>     
        <i class="fa fa-android"></i> fa-android
        
        <br>     
        <i class="fa fa-angellist"></i> fa-angellist
        
        <br>     
        <i class="fa fa-apple"></i> fa-apple
        
        <br>     
        <i class="fa fa-behance"></i> fa-behance
        
        <br>     
        <i class="fa fa-behance-square"></i> fa-behance-square
        
        <br>     
        <i class="fa fa-bitbucket"></i> fa-bitbucket
        
        <br>     
        <i class="fa fa-bitbucket-square"></i> fa-bitbucket-square
        
        <br>     
        <i class="fa fa-bitcoin"></i> fa-bitcoin <span class="text-muted">(alias)</span>
        
        <br>     
        <i class="fa fa-btc"></i> fa-btc
        
        <br>     
        <i class="fa fa-cc-amex"></i> fa-cc-amex
        
        <br>     
        <i class="fa fa-cc-discover"></i> fa-cc-discover
        
        <br>     
        <i class="fa fa-cc-mastercard"></i> fa-cc-mastercard
        
        <br>     
        <i class="fa fa-cc-paypal"></i> fa-cc-paypal
        
        <br>     
        <i class="fa fa-cc-stripe"></i> fa-cc-stripe
        
        <br>     
        <i class="fa fa-cc-visa"></i> fa-cc-visa
        
        <br>     
        <i class="fa fa-codepen"></i> fa-codepen
        
        <br>     
        <i class="fa fa-css3"></i> fa-css3
        
        <br>     
        <i class="fa fa-delicious"></i> fa-delicious
        
        <br>     
        <i class="fa fa-deviantart"></i> fa-deviantart
        
        <br>     
        <i class="fa fa-digg"></i> fa-digg
        
        <br>     
        <i class="fa fa-dribbble"></i> fa-dribbble
        
        <br>     
        <i class="fa fa-dropbox"></i> fa-dropbox
        
        <br>     
        <i class="fa fa-drupal"></i> fa-drupal
        
        <br>     
        <i class="fa fa-empire"></i> fa-empire
        
        <br>     
        <i class="fa fa-facebook"></i> fa-facebook
        
        <br>     
        <i class="fa fa-facebook-square"></i> fa-facebook-square
        
        <br>     
        <i class="fa fa-flickr"></i> fa-flickr
        
        <br>     
        <i class="fa fa-foursquare"></i> fa-foursquare
        
        <br>     
        <i class="fa fa-ge"></i> fa-ge <span class="text-muted">(alias)</span>
        
        <br>     
        <i class="fa fa-git"></i> fa-git
        
        <br>     
        <i class="fa fa-git-square"></i> fa-git-square
        
        <br>     
        <i class="fa fa-github"></i> fa-github
        
        <br>     
        <i class="fa fa-github-alt"></i> fa-github-alt
        
        <br>     
        <i class="fa fa-github-square"></i> fa-github-square
        
        <br>     
        <i class="fa fa-gittip"></i> fa-gittip
        
        <br>     
        <i class="fa fa-google"></i> fa-google
        
        <br>     
        <i class="fa fa-google-plus"></i> fa-google-plus
        
        <br>     
        <i class="fa fa-google-plus-square"></i> fa-google-plus-square
        
        <br>     
        <i class="fa fa-google-wallet"></i> fa-google-wallet
        
        <br>     
        <i class="fa fa-hacker-news"></i> fa-hacker-news
        
        <br>     
        <i class="fa fa-html5"></i> fa-html5
        
        <br>     
        <i class="fa fa-instagram"></i> fa-instagram
        
        <br>      
        <i class="fa fa-ioxhost"></i> fa-ioxhost
        
        <br>     
        <i class="fa fa-joomla"></i> fa-joomla
        
        <br>     
        <i class="fa fa-jsfiddle"></i> fa-jsfiddle
        
        <br>     
        <i class="fa fa-lastfm"></i> fa-lastfm
        
        <br>
        <i class="fa fa-warning"></i> fa-warning <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-wheelchair"></i> fa-wheelchair
            
        <br>
        <i class="fa fa-wifi"></i> fa-wifi
            
        <br>
        <i class="fa fa-wrench"></i> fa-wrench
        
        
    </div>
<div class="one_fourth">
    
        <i class="fa fa-circle-o-notch"></i> fa-circle-o-notch
        
        <br>
        <i class="fa fa-circle-thin"></i> fa-circle-thin
        
        <br>
        <i class="fa fa-clock-o"></i> fa-clock-o
        
        <br>
        <i class="fa fa-close"></i> fa-close <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-cloud"></i> fa-cloud
        
        <br>
        <i class="fa fa-cloud-download"></i> fa-cloud-download
        
        <br>
        <i class="fa fa-cloud-upload"></i> fa-cloud-upload
        
        <br>
        <i class="fa fa-code"></i> fa-code
        
        <br>
        <i class="fa fa-code-fork"></i> fa-code-fork
        
        <br>
        <i class="fa fa-coffee"></i> fa-coffee
        
        <br>
        <i class="fa fa-cog"></i> fa-cog
        
        <br>
        <i class="fa fa-cogs"></i> fa-cogs
        
        <br>
        <i class="fa fa-comment"></i> fa-comment
        
        <br>
        <i class="fa fa-comment-o"></i> fa-comment-o
        
        <br>
        <i class="fa fa-comments"></i> fa-comments
        
        <br>
        <i class="fa fa-comments-o"></i> fa-comments-o
        
        <br>
        <i class="fa fa-compass"></i> fa-compass
        
        <br>
        <i class="fa fa-copyright"></i> fa-copyright
        
        <br>
        <i class="fa fa-credit-card"></i> fa-credit-card
        
        <br>
        <i class="fa fa-crop"></i> fa-crop
        
        <br>
        <i class="fa fa-crosshairs"></i> fa-crosshairs
        
        <br>
        <i class="fa fa-cube"></i> fa-cube
        
        <br>
        <i class="fa fa-cubes"></i> fa-cubes
        
        <br>
        <i class="fa fa-cutlery"></i> fa-cutlery
        
        <br>
        <i class="fa fa-dashboard"></i> fa-dashboard <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-database"></i> fa-database
        
        <br>
        <i class="fa fa-desktop"></i> fa-desktop
        
        <br>
        <i class="fa fa-dot-circle-o"></i> fa-dot-circle-o
        
        <br>
        <i class="fa fa-download"></i> fa-download
        
        <br>
        <i class="fa fa-edit"></i> fa-edit <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-ellipsis-h"></i> fa-ellipsis-h
        
        <br>
        <i class="fa fa-ellipsis-v"></i> fa-ellipsis-v
        
        <br>
        <i class="fa fa-envelope"></i> fa-envelope
        
        <br>
        <i class="fa fa-envelope-o"></i> fa-envelope-o
        
        <br>
        <i class="fa fa-envelope-square"></i> fa-envelope-square
        
        <br>
        <i class="fa fa-eraser"></i> fa-eraser
        
        <br>
        <i class="fa fa-exchange"></i> fa-exchange
        
        <br>
        <i class="fa fa-exclamation"></i> fa-exclamation
        
        <br>
        <i class="fa fa-exclamation-circle"></i> fa-exclamation-circle
        
        <br>
        <i class="fa fa-exclamation-triangle"></i> fa-exclamation-triangle
        
        <br>
        <i class="fa fa-external-link"></i> fa-external-link
        
        <br>
        <i class="fa fa-external-link-square"></i> fa-external-link-square
        
        <br>
        <i class="fa fa-eye"></i> fa-eye
        
        <br>
        <i class="fa fa-eye-slash"></i> fa-eye-slash
        
        <br>
        <i class="fa fa-eyedropper"></i> fa-eyedropper
        
        <br>
        <i class="fa fa-fax"></i> fa-fax
        
        <br>
        <i class="fa fa-female"></i> fa-female
        
        <br>
        <i class="fa fa-fighter-jet"></i> fa-fighter-jet
        
        <br>
        <i class="fa fa-file-archive-o"></i> fa-file-archive-o
        
        <br>
        <i class="fa fa-file-audio-o"></i> fa-file-audio-o
        
        <br>
        <i class="fa fa-file-code-o"></i> fa-file-code-o
        
        <br>
        <i class="fa fa-file-excel-o"></i> fa-file-excel-o
        
        <br>
        <i class="fa fa-file-image-o"></i> fa-file-image-o
        
        <br>
        <i class="fa fa-file-movie-o"></i> fa-file-movie-o <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-file-pdf-o"></i> fa-file-pdf-o
        
        <br>
        <i class="fa fa-file-photo-o"></i> fa-file-photo-o <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-file-picture-o"></i> fa-file-picture-o <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-file-powerpoint-o"></i> fa-file-powerpoint-o
        
        <br>
        <i class="fa fa-file-sound-o"></i> fa-file-sound-o <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-file-video-o"></i> fa-file-video-o
        
        <br>
        <i class="fa fa-file-word-o"></i> fa-file-word-o
        
        <br>
        <i class="fa fa-file-zip-o"></i> fa-file-zip-o <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-film"></i> fa-film
        
        <br>
        <i class="fa fa-filter"></i> fa-filter
        
        <br>
        <i class="fa fa-fire"></i> fa-fire
        
        <br>
        <i class="fa fa-fire-extinguisher"></i> fa-fire-extinguisher
        
        <br>
        <i class="fa fa-flag"></i> fa-flag
        
        <br>
        <i class="fa fa-flag-checkered"></i> fa-flag-checkered
        
        <br>
        <i class="fa fa-flag-o"></i> fa-flag-o
        
        <br>
        <i class="fa fa-flash"></i> fa-flash <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-flask"></i> fa-flask
        
        <br>
        <i class="fa fa-folder"></i> fa-folder
        
        <br>
        <i class="fa fa-folder-o"></i> fa-folder-o
        
        <br>
        <i class="fa fa-folder-open"></i> fa-folder-open

        <br>     
        <i class="fa fa-pinterest-square"></i> fa-pinterest-square
        
        <br>     
        <i class="fa fa-qq"></i> fa-qq
        
        <br>     
        <i class="fa fa-ra"></i> fa-ra <span class="text-muted">(alias)</span>
        
        <br>     
        <i class="fa fa-rebel"></i> fa-rebel
        
        <br>     
        <i class="fa fa-reddit"></i> fa-reddit
        
        <br>     
        <i class="fa fa-reddit-square"></i> fa-reddit-square
        
        <br>     
        <i class="fa fa-renren"></i> fa-renren
        
        <br>     
        <i class="fa fa-share-alt"></i> fa-share-alt
        
        <br>     
        <i class="fa fa-share-alt-square"></i> fa-share-alt-square
        
        <br>     
        <i class="fa fa-skype"></i> fa-skype
        
        <br>     
        <i class="fa fa-slack"></i> fa-slack
        
        <br>     
        <i class="fa fa-slideshare"></i> fa-slideshare
        
        <br>     
        <i class="fa fa-soundcloud"></i> fa-soundcloud
        
        <br>     
        <i class="fa fa-spotify"></i> fa-spotify
        
        <br>     
        <i class="fa fa-stack-exchange"></i> fa-stack-exchange
        
        <br>     
        <i class="fa fa-stack-overflow"></i> fa-stack-overflow
        
        <br>     
        <i class="fa fa-steam"></i> fa-steam
        
        <br>     
        <i class="fa fa-steam-square"></i> fa-steam-square
        
        <br>     
        <i class="fa fa-stumbleupon"></i> fa-stumbleupon
        
        <br>     
        <i class="fa fa-stumbleupon-circle"></i> fa-stumbleupon-circle
        
        <br>     
        <i class="fa fa-tencent-weibo"></i> fa-tencent-weibo
        
        <br>     
        <i class="fa fa-trello"></i> fa-trello
        
        <br>     
        <i class="fa fa-tumblr"></i> fa-tumblr
        
        <br>     
        <i class="fa fa-tumblr-square"></i> fa-tumblr-square
        
        <br>     
        <i class="fa fa-twitch"></i> fa-twitch
        
        <br>     
        <i class="fa fa-twitter"></i> fa-twitter
        
        <br>     
        <i class="fa fa-twitter-square"></i> fa-twitter-square
        
        <br>     
        <i class="fa fa-vimeo-square"></i> fa-vimeo-square
        
        <br>     
        <i class="fa fa-vine"></i> fa-vine
        
        <br>     
        <i class="fa fa-vk"></i> fa-vk
        
        <br>     
        <i class="fa fa-wechat"></i> fa-wechat <span class="text-muted">(alias)</span>
        
        <br>     
        <i class="fa fa-weibo"></i> fa-weibo
        
        <br>     
        <i class="fa fa-weixin"></i> fa-weixin
        
        <br>     
        <i class="fa fa-windows"></i> fa-windows
        
        <br>     
        <i class="fa fa-wordpress"></i> fa-wordpress
        
        <br>     
        <i class="fa fa-xing"></i> fa-xing
        
        <br>     
        <i class="fa fa-xing-square"></i> fa-xing-square
        
        <br>     
        <i class="fa fa-yahoo"></i> fa-yahoo
        
        <br>     
        <i class="fa fa-yelp"></i> fa-yelp
        
        <br>     
        <i class="fa fa-youtube"></i> fa-youtube
        
        <br>     
        <i class="fa fa-youtube-play"></i> fa-youtube-play
        
        <br>     
        <i class="fa fa-youtube-square"></i> fa-youtube-square
		
        <br>
        <i class="fa fa-volume-down"></i> fa-volume-down
            
        <br>
        <i class="fa fa-volume-off"></i> fa-volume-off
            
        <br>
        <i class="fa fa-volume-up"></i> fa-volume-up
            

        

    </div>
<div class="one_fourth">
    
        <i class="fa fa-folder-open-o"></i> fa-folder-open-o
            
        <br>
        <i class="fa fa-frown-o"></i> fa-frown-o
            
        <br>
        <i class="fa fa-futbol-o"></i> fa-futbol-o
            
        <br>
        <i class="fa fa-gamepad"></i> fa-gamepad
            
        <br>
        <i class="fa fa-gavel"></i> fa-gavel
            
        <br>
        <i class="fa fa-gear"></i> fa-gear <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-gears"></i> fa-gears <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-gift"></i> fa-gift
            
        <br>
        <i class="fa fa-glass"></i> fa-glass
            
        <br>
        <i class="fa fa-globe"></i> fa-globe
            
        <br>
        <i class="fa fa-graduation-cap"></i> fa-graduation-cap
            
        <br>
        <i class="fa fa-group"></i> fa-group <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-hdd-o"></i> fa-hdd-o
            
        <br>
        <i class="fa fa-headphones"></i> fa-headphones
            
        <br>
        <i class="fa fa-heart"></i> fa-heart
            
        <br>
        <i class="fa fa-heart-o"></i> fa-heart-o
            
        <br>
        <i class="fa fa-history"></i> fa-history
            
        <br>
        <i class="fa fa-home"></i> fa-home
            
        <br>
        <i class="fa fa-image"></i> fa-image <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-inbox"></i> fa-inbox
            
        <br>
        <i class="fa fa-info"></i> fa-info
            
        <br>
        <i class="fa fa-info-circle"></i> fa-info-circle
            
        <br>
        <i class="fa fa-institution"></i> fa-institution <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-key"></i> fa-key
            
        <br>
        <i class="fa fa-keyboard-o"></i> fa-keyboard-o
            
        <br>
        <i class="fa fa-language"></i> fa-language
            
        <br>
        <i class="fa fa-laptop"></i> fa-laptop
            
        <br>
        <i class="fa fa-leaf"></i> fa-leaf
            
        <br>
        <i class="fa fa-legal"></i> fa-legal <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-lemon-o"></i> fa-lemon-o
            
        <br>
        <i class="fa fa-level-down"></i> fa-level-down
            
        <br>
        <i class="fa fa-level-up"></i> fa-level-up
            
        <br>
        <i class="fa fa-life-bouy"></i> fa-life-bouy <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-life-buoy"></i> fa-life-buoy <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-life-ring"></i> fa-life-ring
            
        <br>
        <i class="fa fa-life-saver"></i> fa-life-saver <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-lightbulb-o"></i> fa-lightbulb-o
            
        <br>
        <i class="fa fa-line-chart"></i> fa-line-chart
            
        <br>
        <i class="fa fa-location-arrow"></i> fa-location-arrow
            
        <br>
        <i class="fa fa-lock"></i> fa-lock
            
        <br>
        <i class="fa fa-magic"></i> fa-magic
            
        <br>
        <i class="fa fa-magnet"></i> fa-magnet
            
        <br>
        <i class="fa fa-mail-forward"></i> fa-mail-forward <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-mail-reply"></i> fa-mail-reply <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-mail-reply-all"></i> fa-mail-reply-all <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-male"></i> fa-male
            
        <br>
        <i class="fa fa-map-marker"></i> fa-map-marker
            
        <br>
        <i class="fa fa-meh-o"></i> fa-meh-o
            
        <br>
        <i class="fa fa-microphone"></i> fa-microphone
            
        <br>
        <i class="fa fa-microphone-slash"></i> fa-microphone-slash
            
        <br>
        <i class="fa fa-minus"></i> fa-minus
            
        <br>
        <i class="fa fa-minus-circle"></i> fa-minus-circle
            
        <br>
        <i class="fa fa-minus-square"></i> fa-minus-square
            
        <br>
        <i class="fa fa-minus-square-o"></i> fa-minus-square-o
            
        <br>
        <i class="fa fa-mobile"></i> fa-mobile
            
        <br>
        <i class="fa fa-mobile-phone"></i> fa-mobile-phone <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-money"></i> fa-money
            
        <br>
        <i class="fa fa-moon-o"></i> fa-moon-o
            
        <br>
        <i class="fa fa-mortar-board"></i> fa-mortar-board <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-music"></i> fa-music
            
        <br>
        <i class="fa fa-navicon"></i> fa-navicon <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-angellist"></i> fa-angellist
        
        <br>
        <i class="fa fa-area-chart"></i> fa-area-chart
        
        <br>
        <i class="fa fa-at"></i> fa-at
        
        <br>
        <i class="fa fa-bell-slash"></i> fa-bell-slash
        
        <br>
        <i class="fa fa-bell-slash-o"></i> fa-bell-slash-o
        
        <br>
        <i class="fa fa-bicycle"></i> fa-bicycle
        
        <br>
        <i class="fa fa-binoculars"></i> fa-binoculars
        
        <br>
        <i class="fa fa-birthday-cake"></i> fa-birthday-cake
        
        <br>
        <i class="fa fa-bus"></i> fa-bus
        
        <br>
        <i class="fa fa-calculator"></i> fa-calculator
        
        <br>
        <i class="fa fa-cc"></i> fa-cc
        
        <br>
        <i class="fa fa-cc-amex"></i> fa-cc-amex
        
        <br>
        <i class="fa fa-cc-discover"></i> fa-cc-discover
        
        <br>
        <i class="fa fa-cc-mastercard"></i> fa-cc-mastercard
        
        <br>
        <i class="fa fa-cc-paypal"></i> fa-cc-paypal
        
        <br>
        <i class="fa fa-cc-stripe"></i> fa-cc-stripe
        
        <br>
        <i class="fa fa-cc-visa"></i> fa-cc-visa
        
        <br>
        <i class="fa fa-copyright"></i> fa-copyright
        
        <br>
        <i class="fa fa-eyedropper"></i> fa-eyedropper
        
        <br>
        <i class="fa fa-futbol-o"></i> fa-futbol-o
        
        <br>
        <i class="fa fa-google-wallet"></i> fa-google-wallet
        
        <br>
        <i class="fa fa-ils"></i> fa-ils
        
        <br>
        <i class="fa fa-ioxhost"></i> fa-ioxhost
        
        <br>
        <i class="fa fa-lastfm"></i> fa-lastfm
        
        <br>
        <i class="fa fa-lastfm-square"></i> fa-lastfm-square
        
        <br>
        <i class="fa fa-line-chart"></i> fa-line-chart
        
        <br>
        <i class="fa fa-meanpath"></i> fa-meanpath
        
        <br>
        <i class="fa fa-newspaper-o"></i> fa-newspaper-o
        
        <br>
        <i class="fa fa-paint-brush"></i> fa-paint-brush
        
        <br>
        <i class="fa fa-paypal"></i> fa-paypal
        
        <br>
        <i class="fa fa-pie-chart"></i> fa-pie-chart
        
        <br>
        <i class="fa fa-plug"></i> fa-plug
        
        <br>
        <i class="fa fa-shekel"></i> fa-shekel <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-sheqel"></i> fa-sheqel <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-slideshare"></i> fa-slideshare
        
        <br>
        <i class="fa fa-soccer-ball-o"></i> fa-soccer-ball-o <span class="text-muted">(alias)</span>
        
        <br>
        <i class="fa fa-toggle-off"></i> fa-toggle-off
        
        <br>
        <i class="fa fa-toggle-on"></i> fa-toggle-on
        
        <br>
        <i class="fa fa-trash"></i> fa-trash
        
        <br>
        <i class="fa fa-tty"></i> fa-tty
        
        <br>
        <i class="fa fa-twitch"></i> fa-twitch
        
        <br>
        <i class="fa fa-wifi"></i> fa-wifi
        
        <br>
        <i class="fa fa-yelp"></i> fa-yelp
		
        <br>     
        <i class="fa fa-lastfm-square"></i> fa-lastfm-square
        
        <br>     
        <i class="fa fa-linkedin"></i> fa-linkedin
        
        <br>     
        <i class="fa fa-linkedin-square"></i> fa-linkedin-square
        
        <br>     
        <i class="fa fa-linux"></i> fa-linux
        
        <br>     
        <i class="fa fa-maxcdn"></i> fa-maxcdn
        
        <br>     
        <i class="fa fa-meanpath"></i> fa-meanpath
        
        <br>     
        <i class="fa fa-openid"></i> fa-openid
        
        <br>     
        <i class="fa fa-pagelines"></i> fa-pagelines
        
        <br>     
        <i class="fa fa-paypal"></i> fa-paypal
        
        <br>     
        <i class="fa fa-pied-piper"></i> fa-pied-piper
        
        <br>     
        <i class="fa fa-pied-piper-alt"></i> fa-pied-piper-alt
        
        <br>     
        <i class="fa fa-pinterest"></i> fa-pinterest
        
        <br>
        <i class="fa fa-users"></i> fa-users
            
        <br>
        <i class="fa fa-video-camera"></i> fa-video-camera
                    
        <br>
        <i class="fa fa-user"></i> fa-user
        
        
    </div>
	<div class="one_fourth last">
    
        <i class="fa fa-newspaper-o"></i> fa-newspaper-o
            
        <br>
        <i class="fa fa-paint-brush"></i> fa-paint-brush
            
        <br>
        <i class="fa fa-paper-plane"></i> fa-paper-plane
            
        <br>
        <i class="fa fa-paper-plane-o"></i> fa-paper-plane-o
            
        <br>
        <i class="fa fa-paw"></i> fa-paw
            
        <br>
        <i class="fa fa-pencil"></i> fa-pencil
            
        <br>
        <i class="fa fa-pencil-square"></i> fa-pencil-square
            
        <br>
        <i class="fa fa-pencil-square-o"></i> fa-pencil-square-o
            
        <br>
        <i class="fa fa-phone"></i> fa-phone
            
        <br>
        <i class="fa fa-phone-square"></i> fa-phone-square
            
        <br>
        <i class="fa fa-photo"></i> fa-photo <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-picture-o"></i> fa-picture-o
            
        <br>
        <i class="fa fa-pie-chart"></i> fa-pie-chart
            
        <br>
        <i class="fa fa-plane"></i> fa-plane
            
        <br>
        <i class="fa fa-plug"></i> fa-plug
            
        <br>
        <i class="fa fa-plus"></i> fa-plus
            
        <br>
        <i class="fa fa-plus-circle"></i> fa-plus-circle
            
        <br>
        <i class="fa fa-plus-square"></i> fa-plus-square
            
        <br>
        <i class="fa fa-plus-square-o"></i> fa-plus-square-o
            
        <br>
        <i class="fa fa-power-off"></i> fa-power-off
            
        <br>
        <i class="fa fa-print"></i> fa-print
            
        <br>
        <i class="fa fa-puzzle-piece"></i> fa-puzzle-piece
            
        <br>
        <i class="fa fa-qrcode"></i> fa-qrcode
            
        <br>
        <i class="fa fa-question"></i> fa-question
            
        <br>
        <i class="fa fa-question-circle"></i> fa-question-circle
            
        <br>
        <i class="fa fa-quote-left"></i> fa-quote-left
            
        <br>
        <i class="fa fa-quote-right"></i> fa-quote-right
            
        <br>
        <i class="fa fa-random"></i> fa-random
            
        <br>
        <i class="fa fa-recycle"></i> fa-recycle
            
        <br>
        <i class="fa fa-refresh"></i> fa-refresh
            
        <br>
        <i class="fa fa-remove"></i> fa-remove <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-reorder"></i> fa-reorder <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-reply"></i> fa-reply
            
        <br>
        <i class="fa fa-reply-all"></i> fa-reply-all
            
        <br>
        <i class="fa fa-retweet"></i> fa-retweet
            
        <br>
        <i class="fa fa-road"></i> fa-road
            
        <br>
        <i class="fa fa-rocket"></i> fa-rocket
            
        <br>
        <i class="fa fa-rss"></i> fa-rss
            
        <br>
        <i class="fa fa-rss-square"></i> fa-rss-square
            
        <br>
        <i class="fa fa-search"></i> fa-search
            
        <br>
        <i class="fa fa-search-minus"></i> fa-search-minus
            
        <br>
        <i class="fa fa-search-plus"></i> fa-search-plus
            
        <br>
        <i class="fa fa-send"></i> fa-send <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-send-o"></i> fa-send-o <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-share"></i> fa-share
            
        <br>
        <i class="fa fa-share-alt"></i> fa-share-alt
            
        <br>
        <i class="fa fa-share-alt-square"></i> fa-share-alt-square
            
        <br>
        <i class="fa fa-share-square"></i> fa-share-square
            
        <br>
        <i class="fa fa-share-square-o"></i> fa-share-square-o
            
        <br>
        <i class="fa fa-shield"></i> fa-shield
            
        <br>
        <i class="fa fa-shopping-cart"></i> fa-shopping-cart
            
        <br>
        <i class="fa fa-sign-in"></i> fa-sign-in
            
        <br>
        <i class="fa fa-sign-out"></i> fa-sign-out
            
        <br>
        <i class="fa fa-signal"></i> fa-signal
            
        <br>
        <i class="fa fa-sitemap"></i> fa-sitemap
            
        <br>
        <i class="fa fa-sliders"></i> fa-sliders
            
        <br>
        <i class="fa fa-smile-o"></i> fa-smile-o
            
        <br>
        <i class="fa fa-soccer-ball-o"></i> fa-soccer-ball-o <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-sort"></i> fa-sort
            
        <br>
        <i class="fa fa-sort-alpha-asc"></i> fa-sort-alpha-asc
            
        <br>
        <i class="fa fa-sort-alpha-desc"></i> fa-sort-alpha-desc
            
        <br>
        <i class="fa fa-sort-amount-asc"></i> fa-sort-amount-asc
            
        <br>
        <i class="fa fa-sort-amount-desc"></i> fa-sort-amount-desc
            
        <br>
        <i class="fa fa-sort-asc"></i> fa-sort-asc
            
        <br>
        <i class="fa fa-sort-desc"></i> fa-sort-desc
            
        <br>
        <i class="fa fa-sort-down"></i> fa-sort-down <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-sort-numeric-asc"></i> fa-sort-numeric-asc
            
        <br>
        <i class="fa fa-sort-numeric-desc"></i> fa-sort-numeric-desc
            
        <br>
        <i class="fa fa-sort-up"></i> fa-sort-up <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-space-shuttle"></i> fa-space-shuttle
            
        <br>
        <i class="fa fa-spinner"></i> fa-spinner
            
        <br>
        <i class="fa fa-spoon"></i> fa-spoon
            
        <br>
        <i class="fa fa-square"></i> fa-square
            
        <br>
        <i class="fa fa-square-o"></i> fa-square-o
            
        <br>
        <i class="fa fa-star"></i> fa-star
            
        <br>
        <i class="fa fa-star-half"></i> fa-star-half
            
        <br>
        <i class="fa fa-star-half-empty"></i> fa-star-half-empty <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-star-half-full"></i> fa-star-half-full <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-star-half-o"></i> fa-star-half-o
            
        <br>
        <i class="fa fa-star-o"></i> fa-star-o
            
        <br>
        <i class="fa fa-suitcase"></i> fa-suitcase
            
        <br>
        <i class="fa fa-sun-o"></i> fa-sun-o
            
        <br>
        <i class="fa fa-support"></i> fa-support <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-tablet"></i> fa-tablet
            
        <br>
        <i class="fa fa-tachometer"></i> fa-tachometer
            
        <br>
        <i class="fa fa-tag"></i> fa-tag
            
        <br>
        <i class="fa fa-tags"></i> fa-tags
            
        <br>
        <i class="fa fa-tasks"></i> fa-tasks
            
        <br>
        <i class="fa fa-taxi"></i> fa-taxi
            
        <br>
        <i class="fa fa-terminal"></i> fa-terminal
            
        <br>
        <i class="fa fa-thumb-tack"></i> fa-thumb-tack
            
        <br>
        <i class="fa fa-thumbs-down"></i> fa-thumbs-down
            
        <br>
        <i class="fa fa-thumbs-o-down"></i> fa-thumbs-o-down
            
        <br>
        <i class="fa fa-thumbs-o-up"></i> fa-thumbs-o-up
            
        <br>
        <i class="fa fa-thumbs-up"></i> fa-thumbs-up
            
        <br>
        <i class="fa fa-ticket"></i> fa-ticket
            
        <br>
        <i class="fa fa-times"></i> fa-times
            
        <br>
        <i class="fa fa-times-circle"></i> fa-times-circle
            
        <br>
        <i class="fa fa-times-circle-o"></i> fa-times-circle-o
            
        <br>
        <i class="fa fa-tint"></i> fa-tint
            
        <br>
        <i class="fa fa-toggle-down"></i> fa-toggle-down <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-toggle-left"></i> fa-toggle-left <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-toggle-off"></i> fa-toggle-off
            
        <br>
        <i class="fa fa-toggle-on"></i> fa-toggle-on
            
        <br>
        <i class="fa fa-toggle-right"></i> fa-toggle-right <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-toggle-up"></i> fa-toggle-up <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-trash"></i> fa-trash
            
        <br>
        <i class="fa fa-trash-o"></i> fa-trash-o
            
        <br>
        <i class="fa fa-tree"></i> fa-tree
            
        <br>
        <i class="fa fa-trophy"></i> fa-trophy
            
        <br>
        <i class="fa fa-truck"></i> fa-truck
            
        <br>
        <i class="fa fa-tty"></i> fa-tty
            
        <br>
        <i class="fa fa-umbrella"></i> fa-umbrella
            
        <br>
        <i class="fa fa-university"></i> fa-university
            
        <br>
        <i class="fa fa-unlock"></i> fa-unlock
            
        <br>
        <i class="fa fa-unlock-alt"></i> fa-unlock-alt
            
        <br>
        <i class="fa fa-unsorted"></i> fa-unsorted <span class="text-muted">(alias)</span>
            
        <br>
        <i class="fa fa-upload"></i> fa-upload

    </div>