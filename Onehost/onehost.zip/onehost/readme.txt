Onehost - One Page Responsive Hosting WordPress Theme
------------------------------

Onehost is a Modern Multipurpose and OnePage WordPress Theme. This theme is suited for any type of website, hosting or personal or business use. The Landing Page is designed with modern look and feel while keeping in mind to make it user friendly and eye catching so that people using it can get the best out of their website.


Changelog
---------
Version 1.3.9:
- Update: Visual Composer 5.4.2.
- Update: Revolution Slider 5.4.6.2.

Version 1.3.8:
- Update: Visual Composer 5.1.1.
- Update: Revolution Slider 5.4.3.1.

Version 1.3.7:
- Update: Visual Composer 5.1.
- Update: Revolution Slider 5.4.1.

Version 1.3.6:
- Fix: The Header always visible on top page
- Fix: Can't scroll to section of the page when click to menu item

Version 1.3.5:
- Update: Visual Composer 5.0.1
- Update: Revolution Slider 5.3.1.5
- Update: Support WHMCS 7 with template six
- Fix: Can't hide title are and the title in blog page.

Version 1.3.4:
- Fix: Error get_row_css_class is deprecated since version 4.2

Version 1.3.3:
- Update: Visual Composer 5.0

Version 1.3.2:
- Update: Add new option allow choose testimonials by category in Testimonials element.
- Update: Responsive all sliders template.
- Update: Child theme.
- Fix: Style of ThemeOptions.

Version 1.3.1:
- Update: Visual Composer 4.12
- Update: Revolution Slider

Version 1.3:
- Update: Visual Composer 4.11
- Update: Revolution Slider

Version 1.2:
- Update: Visual Composer 4.9.2
- Fix: missing style after importing slider

Version 1.1:
- Update: Visual Composer 4.9
- Update: Revolution Slider 5.1.4

Version 1.0.9:
- New: add new WHMCS page template to support WHMCS 6
- Update: Update Visual Composer plugin

Version 1.0.8:
- Update: Update Visual Composer plugin
- Update Revolution Slider plugin

Version 1.0.7:
- New: add new WHMCS page template
- Update: Update Visual Composer plugin
- Update Revolution Slider plugin

Version 1.0.6:
- New: add new Section Title 2 shortcode that allows to use html for description
- Update: Compatible with Visual Composer 4.6.2 plugin
- Update: Update Visual Composer plugin
- Fix: Can't change description in Section Title shortcode

Version 1.0.5:
- Update: Compatible with Visual Composer 4.6.1 plugin
- Update: Update Visual Composer plugin

Version 1.0.4:
- Update: Update Visual Composer plugin

Version 1.0.3:
- Update: Display background image instead of background video when view on mobile devices
- Update: Update Visual Composer plugin to the latest version
- Fix: Mobile menu is difficent to select

Version 1.0.2:
- Fix small bugs about CSS
- Update Visual Composer plugin
- Update Revolution Slider plugin

Version 1.0.1:
- Update plugins

Version 1.0:
- First release
