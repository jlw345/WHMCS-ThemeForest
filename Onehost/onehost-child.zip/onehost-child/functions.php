<?php
add_action( 'wp_enqueue_scripts', 'onehost_child_enqueue_scripts', 20 );

function onehost_child_enqueue_scripts() {
    wp_dequeue_style( 'onehost' );
    wp_enqueue_style( 'onehost-style', get_template_directory_uri() . '/style.css', array( 'google-fonts', 'bootstrap', 'onehost-icons') );
    wp_enqueue_style( 'onehost-child-style', get_stylesheet_uri() );
}
