<?php 
/**
* @version: 1.9
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/
if ( is_active_sidebar( 'ordomain_woosidebar' ) ) :
?>
<div class="col-md-4 blog-page-sidebar">
    <?php dynamic_sidebar('ordomain_woosidebar'); ?>
</div>
<!-- Blog Sidebar Area End -->