        <!-- Footer Area Start -->
        <div id="footer">

                <?php 
                // footer widgets
                if( ordomain_opt('ord_footer_weiget_disabled') != '2' ) {
                    echo get_template_part('ord-part/widgets');   
                }
                // footer top
                if( ordomain_opt('ord_footer_top_disabled') != '2' ){
                    echo get_template_part('ord-part/footer-top');   
                }
                
                ?>

            <!-- Copyright Start -->
            <div class="copyright">
                <div class="container">
                <?php 
                // allowhtml 
                $allowhtml = array(
                    'a' => array(
                        'href' => array()
                    ),
                    'span' => array()
                );
                
                if( ordomain_opt('ord_copyright_text') ){
                    echo '<p>'.wp_kses( ordomain_opt('ord_copyright_text'), $allowhtml ).'</p>';
                }
                ?>
                    
                </div>
            </div>
            <!-- Copyright End -->
        </div>
        <!-- Footer Area End -->
        <!-- Back To Top Button Start -->
        <div class="back-to-top">
            <button><i class="fa fa-angle-up"></i></button>
        </div>
        <!-- Back To Top Button End -->
    </div>
    <!-- Wrapper End -->

<?php wp_footer(); ?>
</body>
</html>