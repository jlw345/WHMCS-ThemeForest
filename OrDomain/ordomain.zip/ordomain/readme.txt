=== OrDomain ===
Contributors: ThemeLooks
Requires at least: WordPress 4.1
Tested : WordPress 4.6.1-trunk
Version: 1.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: two-columns, left-sidebar, right-sidebar, flexible-header, accessibility-ready, custom-background, custom-colors, custom-header, custom-menu, theme-options, editor-style, featured-images, microformats, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready
Text Domain: ordomain

== Description ==
OrDomain is a Responsive WHMCS Hosting WordPress Theme designed for All kinds of Domain and Hosting Business.

* Mobile-first, Responsive Layout
* Custom Colors
* Custom Header
* Social Links
* Menu Description
* Post Formats
* WHMCS Support
* The GPL v2.0 or later license. :) Use it to make something cool.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in OrDomain in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
5. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Copyright ==
gpu


http://themelooks.com/demo/ordomain/wordpress/ordomain/



