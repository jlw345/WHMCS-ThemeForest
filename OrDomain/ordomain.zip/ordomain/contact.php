<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
* 
* Template Name: contact page 
*
*/


get_header();
?>
<div id="contact">
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="contact-address">
                    <?php 
                    // Contact Address Area
                    if( ordomain_opt('ord_contact_title') ){
                       echo '<h2>'.esc_html( ordomain_opt('ord_contact_title') ).'</h2>'; 
                    }
                    
                    // address
                    if( ordomain_opt('ord_contact_info') || ordomain_opt('ord_email') || ordomain_opt('ord_phone_number') ){
                        
                        echo '<address>';
                            // address info
                            if( ordomain_opt('ord_contact_info') ){
                                echo '<p><i class="fa fa-home"></i>'.' '.'<span>'.esc_html( ordomain_opt('ord_contact_info') ).'</span></p>';
                            }
                            
                            // email
                            if( ordomain_opt('ord_email') ){
                                echo '<p><i class="fa fa-envelope"></i>'.' '.'<span>'.esc_html( ordomain_opt('ord_email') ).'</span></p>';
                            }
                            
                            // phone number
                            if( ordomain_opt('ord_phone_number') ){
                                echo '<p><i class="fa fa-phone"></i>'.' '.'<span>'.esc_html( ordomain_opt('ord_phone_number') ).'</span></p>';
                            }
                            
                            // fax
                            if( ordomain_opt('ord_fax') ){
                                echo '<p><i class="fa fa-fax"></i>'.' '.'<span>'.esc_html( ordomain_opt('ord_fax') ).'</span></p>';
                            }
                             
                        echo '</address>';  
                    }

                    // Contact Social Links
                    ordomain_social_media(
                        array(
                            'wrp_class' => 'contact-social-links'
                        )
                    );
                    ?>
                </div>
            </div>
            <div class="col-sm-8 contact-form">
                <?php 
                if( ordomain_opt('ord_contact_form') ){
                        echo do_shortcode( ordomain_opt('ord_contact_form') );
                }
                ?>

            </div>
        </div>
    </div>
</div>
<!-- Contact Area End -->
<?php 
// Contact Actions Start
if( ordomain_opt('ord_contact_action_disabled') ):
?>
<div id="contactActions">
    <div class="container">
        <div class="row">
            <?php 
            if( ordomain_opt('ord_contactActions') ):
                foreach( ordomain_opt('ord_contactActions') as $action ):
            ?>
            <div class="col-sm-3">
                <div class="ca-holder">
                    <?php 
                    // icon
                    if( $action['icon'] ){
                        echo '<div class="ca-icon"><i class="fa '.esc_html( $action['icon'] ).'"></i></div>';
                    }
                    
                    // email 
                    if( $action['title'] ){
                        echo '<h4 class="ca-text">'.esc_html( $action['title'] ).'</h4>';
                    }
                    
                    // description
                    if( $action['description'] ){
                        echo '<p class="sum">'.esc_html( $action['description'] ).'</p>';
                    }
                    
                    // button
                    if( $action['url'] && $action['progress'] ){
                       echo '<a href="'.esc_url( $action['url'] ).'" class="btn btn-custom">'.esc_html( $action['progress'] ).'</a>'; 
                    }
                    ?> 
                </div>
            </div>
            <?php 
                endforeach;
            endif;
            ?>

        </div>
    </div>
</div>
<?php 
endif;
?>

<?php 
// MAP Area
if( ordomain_opt('ord_map_disabled') ){
    
    echo '<div id="map1"></div>';
}
?>

<?php
get_footer();
?>