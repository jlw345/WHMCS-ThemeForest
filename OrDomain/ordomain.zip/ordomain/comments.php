<?php
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

if ( post_password_required() ) {
    return;
}
?>

    <?php if ( have_comments() ) : ?>
    
        <h2 class="post-comments-title">
            <?php printf( _nx( '1 Comment', '%1$s Comments', get_comments_number(), 'comments title', 'ordomain' ), number_format_i18n( get_comments_number() ) ); ?>
        </h2>
        <?php the_comments_navigation(); ?>

        <ul>
            <?php
                wp_list_comments( array(
                    'style'       => 'ul',
                    'short_ping'  => true,
                    'avatar_size' => 70,
                    'callback'    => 'ordomain_comment_callback'
                ) );
            ?>
        </ul><!-- .comment-list -->

        <?php the_comments_navigation(); ?>

    <?php endif; // Check for have_comments(). ?>

    <?php
        // If comments are closed and there are comments, let's leave a little note, shall we?
        if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
    ?>
        <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'ordomain' ); ?></p>
    <?php endif; ?>
    
<div class="post-comment-form">
    <div class="post-comment-form-group">
        <?php
            $commenter = wp_get_current_commenter();
            $req = get_option( 'require_name_email' );
            $aria_req = ( $req ? "required='required'" : '' );
            $fields =  array(
              'author' =>'<div class="row"><div class="col-md-4"><input class="form-control" type="text" name="author" placeholder="Name" value="'. esc_attr( $commenter['comment_author'] ).'" id="commenterName" '.$aria_req.'></div>',
              'email' =>'<div class="col-md-4"><input class="form-control" type="text" placeholder="Email" name="email"  value="' . esc_attr(  $commenter['comment_author_email'] ) .'" id="commenterEmail" '.$aria_req.'></div>',
              'url' =>'<div class="col-md-4"><input class="form-control" type="text" placeholder="Website"  name="url" value="'. esc_attr( $commenter['comment_author_url'] ) .'" id="commenterWebsite"></div></div>',
            );
                    
            $args=array(
            'comment_field'         =>'<div class="row"><div class="col-md-12"><textarea class="form-control" rows= "6"  name="comment" placeholder="Comments"></textarea></div></div>',
            'id_form'               => 'postCommentForm',
            'title_reply_before'    => '<h2 class="post-comments-title">',
            'title_reply_after'     => '</h2>',
            'class_submit'          => 'form-control submit-btn',
            'fields'                => $fields,

            );
         
            comment_form( $args );
        ?>
    </div>
</div>
<!-- .comments-area -->