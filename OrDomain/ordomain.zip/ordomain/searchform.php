<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

?>
<div class="f0f--search-bar">
    <form action="<?php echo home_url('/'); ?>" method="get">
        <div class="input-group">
            <input type="text" name="s" placeholder="Search" class="form-control">
            <span class="input-group-addon">
                <button type="submit"><i class="fa fa-search"></i></button>
            </span>
        </div>
    </form>
</div>