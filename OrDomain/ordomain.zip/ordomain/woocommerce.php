<?php 
/**
* @version: 1.9
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

get_header();
?>
<div id="blogPage">
    <div class="container">
        <div class="row">            
            <?php 
            // sidebar left
			ordomain_woo_left_sidebar();
            
            // blog container
            if( ordomain_opt('ord_woo_sidebar') != '1' ){
                echo '<div class="col-md-8 blog-page-content">';
            }else{
               echo '<div class="col-md-12 blog-page-content">'; 
            }
            
					// WooCommerce Content Area
					if( have_posts() ){
						woocommerce_content();
					}else{
						get_template_part( 'templates/content', 'none' );
					}
            echo '</div>';

            // sidebar right
            ordomain_woo_right_sidebar();
            
            ?>
            <!-- Blog Sidebar Area End -->
        </div>
    </div>
</div>
<?php
get_footer();