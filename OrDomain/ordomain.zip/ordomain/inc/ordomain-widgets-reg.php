<?php
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

function ordomain_widgets_init() {
	
    // sidebar widgets register
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', 'ordomain' ),
        'id'            => 'ordomain_sidebar',
        'description'   => '',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
	
    // sidebar Woo widgets register
    register_sidebar( array(
        'name'          => esc_html__( 'Woo Sidebar', 'ordomain' ),
        'id'            => 'ordomain_woosidebar',
        'description'   => '',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    
    // Footer widgets one register
    register_sidebar( array(
        'name'          => esc_html__( 'Footer widgets one', 'ordomain' ),
        'id'            => 'ord_footer_widget_one',
        'description'   => '',
        'before_widget' => '<div class="useful-links">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="title">',
        'after_title'   => '</h4>',
    ) );
    
    // Footer widgets two register
    register_sidebar( array(
        'name'          => esc_html__( 'Footer widgets two', 'ordomain' ),
        'id'            => 'ord_footer_widget_two',
        'description'   => '',
        'before_widget' => '<div class="useful-links">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="title">',
        'after_title'   => '</h4>',
    ) );
    
    // Footer widgets three register
    register_sidebar( array(
        'name'          => esc_html__( 'Footer widgets three', 'ordomain' ),
        'id'            => 'ord_footer_widget_three',
        'description'   => '',
        'before_widget' => '<div class="useful-links">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="title">',
        'after_title'   => '</h4>',
    ) );
    
    // Footer widgets four register
    register_sidebar( array(
        'name'          => esc_html__( 'Footer widgets four', 'ordomain' ),
        'id'            => 'ord_footer_widget_four',
        'description'   => '',
        'before_widget' => '<div class="useful-links">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="title">',
        'after_title'   => '</h4>',
    ) );
    
}
add_action( 'widgets_init', 'ordomain_widgets_init' );
