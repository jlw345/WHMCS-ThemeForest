<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

// unlimited color
add_action( 'wp_enqueue_scripts', 'ordomain_unlimited_color' );
function ordomain_unlimited_color(){
    
    wp_enqueue_style( 'custom-style', get_template_directory_uri() . '/css/custom-style.css');
    
    $mainColor = ordomain_opt( 'unlimited-color' );
    $secondColor = ordomain_opt( 'unlimited-btn-color' );
    
    $slideTextColor = ordomain_meta_callback( 'slider_textcolor' );
    $slidbgcolor = ordomain_meta_callback( 'sliderbg_color' );
    
    if( ordomain_meta_callback('sliderbg_overlay') != 'global' ){
        
        $overlaycolor   = ordomain_meta_callback( 'slider_overlaycolor' );
        $overlayopacity = ordomain_meta_callback( 'slider_overlayopacity' );
    }else{
        $color = ordomain_opt( 'ord_allHeader_overlaycolor' );
        $overlaycolor   = $color['background-color'];
        $overlayopacity = ordomain_opt( 'ord_allHeader_overlayopacity' );
    }
    

/* COLOR */
$color ="
#navigation a.navbar-brand span,
.banner-content .title h2,
.service-slider .content ul li i.fa,
.pageHslider-item-content ul li i.fa,
#pageHeader .breadcrumb-holder .breadcrumb li a:hover,
.extensions input:checked + label,
.feature-item .icon,
.feature-item:hover .heading,
.post-content .title a,
.post-content .meta a:hover,
.post-content .meta a:focus,
.post-content .footer a:hover,
.post-content .footer a:focus,
.copyright p a,
.team-item:hover figcaption .name a,
.team-social-links ul li a:hover,
.team-social-links ul li a:focus,
.blog-page-sidebar .widget ul li a:hover,
.blog-page-sidebar .widget .tagcloud a:hover,
.post-item-content blockquote,
.post-item-content li,
.full-post .category-link:hover,
.full-post:hover a.btn-custom:hover,
.full-post .post-author-metadata a:hover,
.full-post .tags li a:hover,
.comment-thumb a,
#cancel-comment-reply-link,
.contact-address address p i.fa,
.ca-icon i.fa,
#vpsSlider2 .ui-slider-handle,
.vps-slider-stage .stage h4,
.contact-bar a:hover,
.contact-bar a:focus,
.contact-bar .social-icons .nav li a:hover,
.contact-bar .social-icons .nav li a:focus,
.domain--addons ul li:hover h3,
.domain--addons ul li i.fa,
.banner-primary .extensions input:checked + label,
.about-description a,
.calendar_wrap table a,
.comment-respond .logged-in-as a:hover,
body.page .about-desc-content blockquote,
.link-color--child a:hover,
.link-color--child a:focus,
.products > .product > a:hover > h2,
.product .summary .woocommerce-review-link,
.product .summary a:hover,
.woocommerce-message a.button:hover,
.woocommerce-MyAccount-navigation > ul > li.is-active > a,
.woocommerce .star-rating span:before,
.woocommerce p.stars a,
.products > .product > a.added_to_cart:hover {
	color: {$mainColor};
}";

/* BACKGROUND-COLOR */
$bgColor = "
.bg-blue,
.btn-custom.btn-blue,
.back-to-top button,
.section-title h2:before,
#preloader,
.service-slider .price-tag:before,
.pricing-tab-filter .nav > li > a:hover,
.pricing-tab-filter .nav > li > a:focus,
.pricing-tab-filter .nav > li.active > a,
.pricing-table .head .price,
.pricing-table .head .price:before,
.footer-widgets .title:before,
#open-switcher,
#close-switcher,
.pricing-details-item .heading h3,
#domainPricing table thead,
.timeline-footer,
.a-pricing-item .head,
.blog-page-sidebar .widget-title:before,
#blogPage .post-meta .comments,
.post-social-links li a:hover,
.contact-address h2:before,
.contact-social-links li a:hover,
#vpsSlider2:before,
#vpsSlider2 .ui-slider-range,
#vpsPricing .action a.order-link,
#domainSearchForm .input-group-addon .form-control,
#navigation .navbar-toggle .icon-bar,
.woocommerce a.button,
.woocommerce a.button.alt,
.woocommerce button.button,
.woocommerce button.button.alt,
.woocommerce input.button,
.woocommerce input.button.alt,
.woocommerce #respond input#submit,
.price_slider .ui-slider-range,
.price_slider .ui-slider-handle,
.woocommerce-product-search input[type='submit'],
.woocommerce span.onsale,
.woocommerce .woocommerce-pagination > .page-numbers > li > span.current,
.woocommerce .woocommerce-pagination > .page-numbers > li > a.current,
.woocommerce div.product .woocommerce-tabs ul.tabs li.active {
	background-color: {$mainColor};
}";

$hovColor = "
.btn-custom.btn-blue:hover,
.btn-custom.btn-blue:focus,
#vpsPricing .action a.order-link:hover,
#vpsPricing .action a.order-link:focus,
#domainSearchForm .input-group-addon .form-control:hover,
.woocommerce a.button:hover,
.woocommerce a.button.alt:hover,
.woocommerce button.button:hover,
.woocommerce button.button.alt:hover,
.woocommerce input.button:hover,
.woocommerce input.button.alt:hover,
.woocommerce #respond input#submit:hover,
.woocommerce-product-search input[type='submit']:hover,
.woocommerce span.onsale:hover,
.woocommerce input.button:disabled:hover,
.woocommerce input.button:disabled[disabled]:hover {
    background-color: {$secondColor};
}";

/* BORDER-COLOR */
$bordderColor ="
#navigation .navbar .nav > li > a:hover,
#navigation .navbar .nav > li > a:focus,
#navigation .navbar .nav > li.active > a,
#navigation .navbar .nav > li.open > a,
#navigation .navbar .nav .dropdown-menu > li > a:hover,
#navigation .navbar .nav .dropdown-menu > li > a:focus,
#navigation .navbar .nav .dropdown-menu > li.active > a,
.post-item-content blockquote,
.post-social-links li a:hover,
.contact-social-links li a:hover,
body.page .about-desc-content blockquote,
.woocommerce .woocommerce-pagination > .page-numbers > li > span.current,
.woocommerce .woocommerce-pagination > .page-numbers > li > a.current,
.woocommerce div.product .woocommerce-tabs ul.tabs li.active {
	border-color: {$mainColor};
}";

$tableColor = "
.pricing-table .head,
.pricing-item:hover .head,
.pricing-item.active .head {
    border-bottom-color: {$mainColor};
}";

/*------------------------------------*\
    Slider Color
\*------------------------------------*/
$sliderbg = "
    #service.service-primary{
        background-color: {$slidbgcolor};
    }
    #pageHslider{
        background-color: {$slidbgcolor};
    }
    #pageHeader{
        background-color: {$slidbgcolor};
    }
    .service-slider .content p,
    .pageHslider-item-content p{
       color: {$slideTextColor};
    }
    .bg--overlay::before {
        background-color: {$overlaycolor};
        opacity: {$overlayopacity};
    }

";
/*------------------------------------*\
    SECONDARY COLOR
\*------------------------------------*/
/* COLOR */
$slideColor ="
.text-green,
.section-title h2,
.counter-holder i.fa,
.pageHslider-item-content h2,
.pageHslider-item-content p i.fa,
#vpsSlider .ui-slider-handle,
#pageHeader .breadcrumb-holder .breadcrumb>.active,
#loginForm p.help-block a:hover {
color: {$mainColor};
}";

$copyColor ="
.copyright p a:hover,
.post-content .title a:hover,
.post-content .title a:focus {
    color:  {$secondColor};
}";

/* BACKGROUND-COLOR */
$bgColor2 = "
.bg-green,
.btn-green,
.pageHslider-item-content .price a,
.pageHslider-slider .owl-dot.active,
.pricing-table .body .buy-now .btn,
.accordion .panel-heading a,
#service .bx-pager-link.active,
#service .bx-pager-link:hover,
#service .bx-pager-link:focus,
.pricing-details-item.body .content .action-btn .btn,
#vpsPricing .action a.deatils-link,
#vpsSlider .ui-slider-range,
#dedicatedPricing table .btn,
.btn-custom,
.faq-categories ul li a:hover,
.faq-categories ul li.active a,
#loginForm .submit-button,
.f0f--search-bar .input-group-addon,
#f0f a.btn,
a.comment-reply,
.comment-respond .form-control.submit-btn,
#contactForm .submit-button,
.blog-page--pagination .pagination > li.active > span,
#dedicatedPricing table thead,
.dedicated-pricing-tab-filter .nav > li > a:hover,
.dedicated-pricing-tab-filter .nav > li.active > a {
    background-color: {$mainColor};
}";

$hoverbgColor = "
.btn-green:hover,
.btn-green:focus,
.pageHslider-item-content .price a:hover,
.pageHslider-item-content .price a:focus,
.pricing-table .body .buy-now .btn:hover,
.pricing-table .body .buy-now .btn:focus,
.pricing-details-item.body .content .action-btn .btn:hover,
.pricing-details-item.body .content .action-btn .btn:focus,
#vpsPricing .action a.deatils-link:hover,
#vpsPricing .action a.deatils-link:focus,
#dedicatedPricing table .btn:hover,
#dedicatedPricing table .btn:focus,
.btn-custom:hover,
.btn-custom:focus,
#loginForm .submit-button:hover,
.affiliate-signup-btn-holder a:hover,
.affiliate-signup-btn-holder a:focus,
.f0f--search-bar .input-group-addon:hover,
#f0f a.btn:hover,
#f0f a.btn:focus,
#blogPage .post-content a.read-more-btn:hover,
#blogPage .post-content a.read-more-btn:focus,
a.comment-reply:hover,
a.comment-reply:focus,
.comment-respond .form-control.submit-btn:hover,
#contactForm .submit-button:hover,
.ca-holder a.btn:hover,
.ca-holder a.btn:focus,
.back-to-top button:hover,
.blog-page--pagination .pagination > li > a:hover,
.blog-page--pagination .pagination > li > a:focus,
.blog-page--pagination .pagination > li > span:hover,
.blog-page--pagination .pagination > li.active > span {
background-color: {$secondColor};
}";

/* BORDER-COLOR */
$borderColor ="
#service .bx-pager-link,
.vps-item-feature-name,
.blog-page--pagination .pagination > li.active > span,
.pricing-item:hover .head.border-green,
.pricing-item.active .head.border-green,
.blog-page--pagination .pagination > li > a:hover,
.blog-page--pagination .pagination > li > a:focus,
.blog-page--pagination .pagination > li > span:hover,
.blog-page--pagination .pagination > li.active > span {
border-color:  {$mainColor};
}";

$acountColor ="
.aCounter-text {
    border-bottom-color: {$mainColor};
}";

$triangle ="
.triangle-down-green:before {
    border-top-color: {$mainColor};
}";

$faq ="
.faq-categories ul li a:before {
    border-left-color: {$mainColor};
}";

$pricingItem ="
.a-pricing-item .head {
    border-bottom-color: {$secondColor};
}";

/*------------------------------------*\
    WHMCS BRIDGE
\*------------------------------------*/
/* COLOR */
$whmcsColor ="
.whmcs-template-ordomain div.header-lined h1,
.whmcs-template-ordomain .header-lined .breadcrumb a,
.whmcs-template-ordomain .announcement-single h2 a,
.whmcs-template-ordomain .announcement-single h3 a,
.whmcs-template-ordomain .sidebar i.icon-rss,
.whmcs-template-ordomain .whmcs-credit-text a {
color: {$mainColor};
}";

/* BACKGROUND COLOR */
$whmcsBg ="
body.page-template-template-whmcs #navigation .navbar-toggle .icon-bar,
.whmcs-template-five .navbar,
.whmcs-template-five .navbar .dropdown-menu > li > a:hover,
.whmcs-template-five #order-boxes .header-lined-order h1,
.whmcs-template-ordomain .navbar-main,
.whmcs-template-ordomain .navbar-main .navbar-nav > li > a:hover,
.whmcs-template-ordomain .navbar-main .navbar-nav > li > a:focus,
.whmcs-template-ordomain .navbar-main .navbar-nav > .open > a,
.whmcs-template-ordomain .navbar-main .navbar-nav > .open > a:hover,
.whmcs-template-ordomain .navbar-main .navbar-nav > .open > a:focus,
.whmcs-template-ordomain .navbar-main .dropdown-menu > li > a:hover,
.whmcs-template-ordomain .dropdown-menu > li > a:focus,
.whmcs-template-ordomain a.label,
.whmcs-template-ordomain a.label:hover,
.whmcs-template-ordomain a.label:focus,
.whmcs-template-ordomain #home-banner .btn,
.whmcs-template-ordomain div.home-shortcuts,
.whmcs-template-ordomain #order-standard_cart .header-lined h1,
.whmcs-template-ordomain .sidebar a.list-group-item.active,
.whmcs-template-ordomain .product-selection-sidebar a.list-group-item.active {
background-color: {$mainColor};
}";

/* BACKGROUND AND BORDER COLOR */
$whmcsbgbo = "
.whmcs-template-five input.btn,
.whmcs-template-five input.btn:hover,
.whmcs-template-five input.btn:focus,
.whmcs-template-five input.btn:active:hover,
.whmcs-template-five input.btn:active:focus,
.whmcs-template-five #order-boxes .btn,
.whmcs-template-five #order-boxes a.list-group-item.active,
.whmcs-template-ordomain .main-content a.btn,
.whmcs-template-ordomain input.btn,
.whmcs-template-ordomain #order-standard_cart button.btn-primary,
.whmcs-template-ordomain #order-standard_cart div.view-cart-items-header,
.whmcs-template-ordomain #order-standard_cart div.order-summary,
.whmcs-template-ordomain #order-standard_cart .suggested-domains .panel-heading {
background-color: {$mainColor};
    border-color: {$mainColor};
}";

/* BORDER COLOR */
$whmBor = "
.whmcs-template-ordomain #order-standard_cart div.view-cart-items,
.whmcs-template-ordomain #order-standard_cart .suggested-domains .panel-heading {
border-color: {$mainColor};
}";

/* BORDER TOP COLOR */
$whmcsBorTop = "
.whmcs-template-five #order-boxes .header-lined-order h1:after,
.whmcs-template-ordomain #order-standard_cart .header-lined h1:after {
    border-top-color: {$mainColor};
}";

/**********************/
/****Section Option****/
/*********************/

// service 
$bgcolor            = ordomain_meta_callback( 'service-bgcolor' );
$iconColor          = ordomain_meta_callback( 'service_iconcolor' );
$serviceOvColor     = ordomain_meta_callback( 'service_overlaycolor' );
$serviceOvOpacity   = ordomain_meta_callback( 'service_overlayopacity' );
$titleColor         = ordomain_meta_callback( 'service_titlecolor' );
$TextColor          = ordomain_meta_callback( 'service_textcolor' );

// Counter 
$Countbgcolor            = ordomain_meta_callback( 'counter-bgcolor' );
$CountOvColor            = ordomain_meta_callback( 'counter_overlaycolor' );
$CountOvOpacity          = ordomain_meta_callback( 'counter_overlayopacity' );
$CounticonColor          = ordomain_meta_callback( 'counter_iconcolor' );
$CounttitleColor         = ordomain_meta_callback( 'counter_secttitlecolor' );
$CountTextColor          = ordomain_meta_callback( 'counter_textcolor' );

$Testibgcolor          = ordomain_meta_callback( 'testimonial-bgcolor' );
$TestiOvColor          = ordomain_meta_callback( 'testimonial_overlaycolor' );
$TestiOvOpacity        = ordomain_meta_callback( 'testimonial_overlayopacity' );
$TestiTextColor        = ordomain_meta_callback( 'testimonial_textcolor' );
$SectTextColor         = ordomain_meta_callback( 'testimonial_secttitlecolor' );
$nameTextColor         = ordomain_meta_callback( 'testimonial_texttwocolor' );

$subscribebgcolor      = ordomain_meta_callback( 'subscribe-bgcolor' );
$subscribeOvColor      = ordomain_meta_callback( 'subscribe_overlaycolor' );
$subscribeOvOpacity    = ordomain_meta_callback( 'subscribe_overlayopacity' );
$subscribeTextColor    = ordomain_meta_callback( 'subscribe_textcolor' );
$subscribebtnTextColor = ordomain_meta_callback( 'subscribe_btntextcolor' );

$blogbgcolor    = ordomain_meta_callback( 'blog-bgcolor' );
$blogOvColor    = ordomain_meta_callback( 'blog_overlaycolor' );
$blogOvOpacity  = ordomain_meta_callback( 'blog_overlayopacity' );
$blogSectTextColor  = ordomain_meta_callback( 'blog_textcolor' );
$blogSubTitleColor  = ordomain_meta_callback( 'blog_subtitlecolor' );

$homeDomCheckcolor  = ordomain_meta_callback( 'homeDomCheck-bgcolor' );
$homeDomCheckOvColor  = ordomain_meta_callback( 'homeDomCheck_overlaycolor' );
$homeDomCheckOvOpacity  = ordomain_meta_callback( 'homeDomCheck_overlayopacity' );
$homeDomCheckSectTextColor  = ordomain_meta_callback( 'homeDomCheck_SectTitlecolor' );
$homeDomCheckFetuTitleColor  = ordomain_meta_callback( 'homeDomCheck_FeatureTitlecolor' );
$homeDomCheckTextColor  = ordomain_meta_callback( 'homeDomCheck_textcolor' );
$homeDomCheckIconColor  = ordomain_meta_callback( 'homeDomCheck_Iconcolor' );
$homeDomCheckextnameColor  = ordomain_meta_callback( 'homeDomCheck_extnamecolor' );
$homeDomCheckextBoxColor  = ordomain_meta_callback( 'homeDomCheck_extboxcolor' );
$homeDomCheckextpriceColor  = ordomain_meta_callback( 'homeDomCheck_extpricecolor' );

$faqbgcolor    = ordomain_meta_callback( 'faq-bgcolor' );
$faqOvColor    = ordomain_meta_callback( 'faq_overlaycolor' );
$faqOvOpacity  = ordomain_meta_callback( 'faq_overlayopacity' );
$faqTextColor  = ordomain_meta_callback( 'faq_SectTitlecolor' );
$faqSubtitleColor  = ordomain_meta_callback( 'faq_SubTitlecolor' );
$faqbordcolor  = ordomain_meta_callback( 'faq_bordercolor' );

$extraFeaturebgcolor  = ordomain_meta_callback( 'extrafeature-bgcolor' );
$extraFeatureOvColor  = ordomain_meta_callback( 'extrafeature_overlaycolor' );
$extraFeatureOvOpacity  = ordomain_meta_callback( 'extrafeature_overlayopacity' );
$extraFeatureTextColor  = ordomain_meta_callback( 'extrafeature_SectTitlecolor' );
$extraFeatureSubtitleColor  = ordomain_meta_callback( 'extrafeature_SubTitlecolor' );
$extraFeatureBordColor  = ordomain_meta_callback( 'extrafeature_bordercolor' );
$extraFeatureColor  = ordomain_meta_callback( 'extrafeature_textcolor' );
$extraFeatureIconColor  = ordomain_meta_callback( 'extrafeature_Iconcolor' );
$extraFeatureIconBordColor  = ordomain_meta_callback( 'extrafeature_Iconbordcolor' );
$extraFeatureContBordColor  = ordomain_meta_callback( 'extrafeature_Contbordcolor' );

$teambgColor   = ordomain_meta_callback( 'team-bgcolor' );
$teamOvColor   = ordomain_meta_callback( 'team_overlaycolor' );
$teamOvOpt     = ordomain_meta_callback( 'team_overlayopacity' );
$teamSectTitle = ordomain_meta_callback( 'team_SectTitlecolor' );
$teamsubTitle  = ordomain_meta_callback( 'team_SubTitlecolor' );
$teamSocColor  = ordomain_meta_callback( 'team_socIconcolor' );
$teamNameColor  = ordomain_meta_callback( 'team_Namecolor' );
$teamroleColor  = ordomain_meta_callback( 'team_roleColor' );
$teambordColor  = ordomain_meta_callback( 'team_bordColor' );

$historybgColor    = ordomain_meta_callback( 'history-bgcolor' );
$historyOVbgColor  = ordomain_meta_callback( 'history_overlaycolor' );
$historyOvopct     = ordomain_meta_callback( 'history_overlayopacity' );
$historySectTitle  = ordomain_meta_callback( 'history_SectTitlecolor' );
$historySubTitle   = ordomain_meta_callback( 'history_SubTitlecolor' );
$historyYearColor  = ordomain_meta_callback( 'history_yearcolor' );
$timelineColor     = ordomain_meta_callback( 'history_timelineColor' );

$aPricingbgColor   = ordomain_meta_callback( 'affPricing-bgcolor' );
$aPricingOvColor   = ordomain_meta_callback( 'affPricing_overlaycolor' );
$aPricingOvOpt     = ordomain_meta_callback( 'affPricing_overlayopacity' );
$aPricingTextColor = ordomain_meta_callback( 'affPricing_textcolor' );
$aPricingbtnTextColor = ordomain_meta_callback( 'affPricing_btntextcolor' );
$aPricingbordColor = ordomain_meta_callback( 'affPricing_borderColor' );

$afeatureBgColor    = ordomain_meta_callback( 'afeature-bgcolor' );
$afeatureTextColor  = ordomain_meta_callback( 'afeature_textcolor' );
$afeatureTitleColor = ordomain_meta_callback( 'afeature_titlecolor' );
$afeatureIconColor  = ordomain_meta_callback( 'afeature_Iconcolor' );
$afeatureOvColor    = ordomain_meta_callback( 'afeature_overlaycolor' );
$afeatureOvOpt      = ordomain_meta_callback( 'afeature_overlayopacity' );
$afeatureSectTitle  = ordomain_meta_callback( 'afeature_sectTitlecolor' );
$afeatureSubTitle   = ordomain_meta_callback( 'afeature_subTitlecolor' );
$afeatureNumColor   = ordomain_meta_callback( 'afeature_numcolor' );

$affcounterbgColor  = ordomain_meta_callback( 'affcounter-bgcolor' );
$affcounterTextColor  = ordomain_meta_callback( 'affcounter_textcolor' );
$affcounterDividerColor  = ordomain_meta_callback( 'affcounter_dividercolor' );
$aCounterOvcolor  = ordomain_meta_callback( 'affcounter_overlaycolor' );
$aCounterOvOpct  = ordomain_meta_callback( 'affcounter_overlayopacity' );

$hostpricebgColor  = ordomain_meta_callback( 'hosting-bgcolor' );
$hostpriceOvColor  = ordomain_meta_callback( 'hosting_overlaycolor' );
$hostpriceOvOpct   = ordomain_meta_callback( 'hosting_overlayopacity' );
$hostpricesubTitle = ordomain_meta_callback( 'hosting_subtitlecolor' );
$hostpriceSectTitle = ordomain_meta_callback( 'hosting_sectTitlecolor' );

$domPricbgColor = ordomain_meta_callback( 'domain-bgcolor' );
$domPricOvColor = ordomain_meta_callback( 'domain_overlaycolor' );
$domPricOvOpct  = ordomain_meta_callback( 'domain_overlayopacity' );
$domPricsectTitlecolor  = ordomain_meta_callback( 'domain_sectTitlecolor' );
$domPricsubTitlecolor  = ordomain_meta_callback( 'domain_subtitlecolor' );

$domextslidbgColor  = ordomain_meta_callback( 'domExtSlid-bgcolor' );
$domextslidColor    = ordomain_meta_callback( 'domExtSlid_textcolor' );
$domextslidboxColor = ordomain_meta_callback( 'domExtSlid_pboxbgcolor' );
$domextslidboxTextColor = ordomain_meta_callback( 'domExtSlid_pboxTextcolor' );

$flatBgColor = ordomain_meta_callback( 'flatContent-bgcolor' );
$flatOvbgColor = ordomain_meta_callback( 'flatContent_overlaycolor' );
$flatOVOpacityColor = ordomain_meta_callback( 'flatContent_overlayopacity' );
$flatColor = ordomain_meta_callback( 'flatContent_textcolor' );
$flatsectTitleColor = ordomain_meta_callback( 'flatContent_titlecolor' );
$flatSubTitleColor = ordomain_meta_callback( 'flatContent_Subcolor' );

$flatBgColorOne = ordomain_meta_callback( 'flatContentone-bgcolor' );
$flatOvbgColorOne = ordomain_meta_callback( 'flatContentone_overlaycolor' );
$flatOVOpacityColorOne = ordomain_meta_callback( 'flatContentone_overlayopacity' );
$flatColorOne = ordomain_meta_callback( 'flatContentone_textcolor' );
$flatsectTitleColorOne = ordomain_meta_callback( 'flatContentone_titlecolor' );
$flatSubTitleColorOne = ordomain_meta_callback( 'flatContentone_Subcolor' );

$bulkdombgcolor = ordomain_meta_callback( 'bulkdom-bgcolor' );
$bulkdomovcolor = ordomain_meta_callback( 'bulkdom_overlaycolor' );
$bulkdomovOpct  = ordomain_meta_callback( 'bulkdom_overlayopacity' );
$bulkdomcontBox = ordomain_meta_callback( 'bulkdom_cboxbgcolor' );
$bulkdomcontColor = ordomain_meta_callback( 'bulkdom_cboxTextcolor' );
$bulkdomribColor = ordomain_meta_callback( 'bulkdom_ribTextcolor' );
$bulkdomSearTextColor = ordomain_meta_callback( 'bulkdom_searchbtnTextcolor' );

$contactActionbgColor = ordomain_meta_callback( 'contactAction-bgcolor' );
$contactActionOvColor = ordomain_meta_callback( 'contactAction_overlaycolor' );
$contactActionOvOpact = ordomain_meta_callback( 'contactAction_overlayopacity' );
$contactActionTextColor = ordomain_meta_callback( 'contactAction_textcolor' );
$contactActionSectTitleColor = ordomain_meta_callback( 'contactAction_SectTitlecolor' );
$contactActionSubTitleColor = ordomain_meta_callback( 'contactAction_SubTitlecolor' );

$dedicatPricTBgColor = ordomain_meta_callback( 'dedicPriceTab-bgcolor' );
$dedicatPricTSubTextColor = ordomain_meta_callback( 'dedicPriceTab_Subtitlecolor' );
$dedicatPricTTitleColor = ordomain_meta_callback( 'dedicPriceTab_titlecolor' );
$dedicatPricTOvColor = ordomain_meta_callback( 'dedicPriceTab_overlaycolor' );
$dedicatPricTOvOpact = ordomain_meta_callback( 'dedicPriceTab_overlayopacity' );
$dedicatPricTTextColor = ordomain_meta_callback( 'dedicPriceTab_textColor' );

$dedicatPricbgColor = ordomain_meta_callback( 'dedicate-bgcolor' );
$dedicatPricBordColor = ordomain_meta_callback( 'dedicate-bordcolor' );
$dedicatPricOvColor = ordomain_meta_callback( 'dedicate_overlaycolor' );
$dedicatPricOvOpt = ordomain_meta_callback( 'dedicate_overlayopacity' );
$dedicatPricSectTitle = ordomain_meta_callback( 'dedicate_sectTitlecolor' );
$dedicatPricSubTitle = ordomain_meta_callback( 'dedicate_subtitlecolor' );
$dedicatPrictblthead = ordomain_meta_callback( 'dedicate_textcolor' );

$sectionOpt = "
    #feature {
        background-color: {$bgcolor};
    }
    #feature.bg--overlay:before {
        background-color: {$serviceOvColor};
        opacity: {$serviceOvOpacity};
    }
    #feature .icon .fa {
        color: {$iconColor};
    }
    #feature .feature-item .desc {
        color: {$TextColor};
    }
    #feature .feature-item .heading,
    #feature .section-title p {
        color: {$titleColor};
    }
    
    #counter {
        background-color: {$Countbgcolor};
    }
    #counter.bg--overlay:before {
        background-color: {$CountOvColor};
        opacity: {$CountOvOpacity};  
    }
    #counter .counter-holder,
    #counter .section-title p {
        color: {$CountTextColor};
    }
    #counter .section-title h2 {
        color: {$CounttitleColor};
    }
    #counter .counter-holder i.fa {
        color: {$CounticonColor};
    }
    
    
    #feedback {
        background-color: {$Testibgcolor};
    }
    #feedback.bg--overlay:before {
        background-color: {$TestiOvColor};
        opacity: {$TestiOvOpacity};  
    }
    #feedback .feedback-comment p {
        color: {$TestiTextColor};
    }
    #feedback .section-title h2 {
        color: {$SectTextColor};
    }
    #feedback .feedback-info,
    #feedback .section-title p {
        color: {$nameTextColor};
    }    
    
    #subscribe {
        background-color: {$subscribebgcolor};
    }
    #subscribe.bg--overlay:before {
        background-color: {$subscribeOvColor};
        opacity: {$subscribeOvOpacity};  
    }
    #subscribe h2 {
        color: {$subscribeTextColor};
    }
    #subscribeForm .submit-button {
        color: {$subscribebtnTextColor};
    }
    
    #blog {
        background-color: {$blogbgcolor};
    }
    #blog.bg--overlay:before {
        background-color: {$blogOvColor};
        opacity: {$blogOvOpacity};  
    }
    #blog .section-title h2 {
        color: {$blogSectTextColor};
    }
    #blog .section-title p {
        color: {$blogSubTitleColor};
    }  
    
    #banner {
        background-color: {$homeDomCheckcolor};
    }
    #banner.bg--overlay:before {
        background-color: {$homeDomCheckOvColor};
        opacity: {$homeDomCheckOvOpacity};  
    }
    #banner .domain--addons h2 {
        color: {$homeDomCheckSectTextColor};
    }
    #banner .domain--addons p {
        color: {$homeDomCheckTextColor};
    }
    #banner .domain--addons ul li i.fa {
        color: {$homeDomCheckIconColor};
    }
    .domain--addons ul li h3 {
        color: {$homeDomCheckFetuTitleColor};
    }
    .banner-primary .ext--name {
        color: {$homeDomCheckextnameColor};
    }
    #banner .ext--price:before {
        background-color: {$homeDomCheckextBoxColor};
    }
    .banner-primary .ext--price {
        color: {$homeDomCheckextpriceColor};
    }
    #faq {
        background-color: {$faqbgcolor};
        border-color: {$faqbordcolor};
    }
    #faq.bg--overlay:before {
        background-color: {$faqOvColor};
        opacity: {$faqOvOpacity};  
    }
    #faq .section-title h2 {
        color: {$faqTextColor};
    }
    #faq .section-title p {
        color: {$faqSubtitleColor};
    }
    
    #extraFeature {
        background-color: {$extraFeaturebgcolor};
        border-color: {$extraFeatureBordColor};
    }
    #extraFeature.bg--overlay:before {
        background-color: {$extraFeatureOvColor};
        opacity: {$extraFeatureOvOpacity};  
    }
    #extraFeature .section-title h2 {
        color: {$extraFeatureTextColor};
    }
    #extraFeature .section-title p {
        color: {$extraFeatureSubtitleColor};
    }
    #extraFeature,
    #extraFeature .title,
    #extraFeature .desc {
        color: {$extraFeatureColor};
    }
    #extraFeature .extra-feature-content .item .icon i.fa {
        color: {$extraFeatureIconColor};
    }
    #extraFeature .extra-feature-content .item .icon {
        border-color: {$extraFeatureIconBordColor};
    }
    #extraFeature .extra-feature-content .item {
        border-color: {$extraFeatureContBordColor};
    }
    #team {
        background-color: {$teambgColor};
        border-color: {$teambordColor};
    }
    #team.bg--overlay:before {
        background-color: {$teamOvColor};
        opacity: {$teamOvOpt};
    }
    #team .section-title h2 {
        color: {$teamSectTitle};
    }
    #team .section-title p {
        color: {$teamSocColor};
    }
    .team-social-links ul li a {
        color: {$teamSocColor};
    }
    .team-item figcaption .name {
        color: {$teamNameColor};
    }
    #team .team-item figcaption .role {
        color: {$teamroleColor};
    }
    
    #history {
        background-color: {$historybgColor};
    }
    #history.bg--overlay:before {
        background-color: {$historyOVbgColor};
        opacity: {$historyOvopct};
    }
    #history .section-title h2 {
        color: {$historySectTitle};
    }
    #history .section-title p {
        color: {$historySubTitle};
    }
    #history .timeline-footer p {
        color: {$historyYearColor};
    }
    .timeline > li > .timeline-badge {
        color: {$timelineColor};
    }
    .timeline:before{
        background-color: {$timelineColor};
    }
    
    #aPricing {
        background-color: {$aPricingbgColor};
    }
    #aPricing.bg--overlay:before {
        background-color: {$aPricingOvColor};
        opacity: {$aPricingOvOpt};
    }
    .a-pricing-item .head .title,
    .a-pricing-item .head .price {
        color: {$aPricingTextColor};
    }
    .affiliate-signup-btn-holder .btn-custom{
        color: {$aPricingbtnTextColor};
    }
    .a-pricing-item .head {
        border-bottom-color: {$aPricingbordColor};
    }
    
    #afeature {
        background-color: {$afeatureBgColor};
    }
    #afeature .section-title h2{
        color: {$afeatureSectTitle};
    }
    #afeature .section-title p{
        color: {$afeatureSubTitle};
    }
    #afeature.bg--overlay:before{
        background-color: {$afeatureOvColor};
        opacity: {$afeatureOvOpt};
    }
    #afeature .feature-item .desc {
        color: {$afeatureTextColor};
    }
    .feature-item .heading {
        color: {$afeatureTitleColor};
    }
    #afeature .feature-item .icon {
        color: {$afeatureIconColor};
    }
    .feature-item:before {
        color: {$afeatureNumColor};
    }
    
    #aCounter {
        background-color: {$affcounterbgColor};
    }
    #aCounter.bg--overlay:before{
        background-color: {$aCounterOvcolor};
        opacity: {$aCounterOvOpct};
    }
    .aCounter-holder .aCounter-text,
    .aCounter-number-holder,
    .aCounter-number-holder .counter-number {
        color: {$affcounterTextColor};
    }
    .aCounter-text {
        border-bottom-color: {$affcounterDividerColor};
    }
    #pricing {
        background-color: {$hostpricebgColor};
    }
    #pricing.bg--overlay:before {
        background-color: {$hostpriceOvColor};
        opacity: {$hostpriceOvOpct};
    }
    #pricing .section-title p,
    #pricing.bg-img .section-title p {
        color: {$hostpricesubTitle};
    }
    #pricing .section-title h2 {
         color: {$hostpriceSectTitle};
    }
    
    #domainPricing {
         background-color: {$domPricbgColor};
    }    
    #domainPricing.bg--overlay:before {
        background-color: {$domPricOvColor};
        opacity: {$domPricOvOpct};
    }
    #domainPricing .section-title h2 {
        color: {$domPricsectTitlecolor};
    }
    #domainPricing .section-title p {
        color: {$domPricsubTitlecolor};
    }
    #domainExt {
        background-color: {$domextslidbgColor};
    }
    .triangle-down-green:before {
        border-top-color: {$domextslidbgColor};
    }
    #domainExt .ext--name {
        color: {$domextslidColor};
    }
    #domainExt .ext--price:before {
        background-color: {$domextslidboxColor};
    }
    #domainExt .ext--price{
        color: {$domextslidboxTextColor};
    }
    #flat_content {
        background-color: {$flatBgColor};
        color: {$flatColor};
    }
    #flat_content.bg--overlay:before {
        background-color: {$flatOvbgColor};
        opacity: {$flatOVOpacityColor};
    }
    #flat_content .section-title h2 {
        color: {$flatsectTitleColor};
    }
    #flat_content .section-title p {
        color: {$flatSubTitleColor};
    }
    #flat_contentone {
        background-color: {$flatBgColorOne};
        color: {$flatColorOne};
    }
    #flat_contentone.bg--overlay:before {
        background-color: {$flatOvbgColorOne};
        opacity: {$flatOVOpacityColorOne};
    }
    #flat_contentone .section-title h2 {
        color: {$flatsectTitleColorOne};
    }
    #flat_contentone .section-title p {
        color: {$flatSubTitleColorOne};
    }
    #banner.bulkdom {
        background-color: {$bulkdombgcolor};
    }
    #banner.bulkdom.bg--overlay:before{
        background-color: {$bulkdomovcolor};
        opacity: {$bulkdomovOpct};
    }
    .bulkdom .banner-content:before {
        background-color: {$bulkdomcontBox};
    }
    .banner-content .text-black {
        color:{$bulkdomcontColor};
    }
    .ribbon.text-white{
        color: {$bulkdomribColor};
    }
    #bulkDomainSearchForm .submit-btn {
        color: {$bulkdomSearTextColor};
    }
    
    #contactActionsgolb{
        background-color: {$contactActionbgColor};
    }
    #contactActionsgolb.bg--overlay:before{
        background-color: {$contactActionOvColor};
        opacity: {$contactActionOvOpact};
    }
    #contactActionsgolb .ca-holder p,
    #contactActionsgolb .ca-text{
        color: {$contactActionTextColor};
    }
    #contactActionsgolb .section-title h2 {
        color: {$contactActionSectTitleColor};
    }
    #contactActionsgolb .section-title p {
        color: {$contactActionSubTitleColor};
    }
    
    #dedicatedPricing.dedicatedPricing-tab {
        background-color: {$dedicatPricTBgColor};
    }
    #dedicatedPricing.dedicatedPricing-tab .section-title p{
        color: {$dedicatPricTSubTextColor};
    }
    #dedicatedPricing.dedicatedPricing-tab .section-title h2 {
        color: {$dedicatPricTTitleColor};
    }
    #dedicatedPricing.dedicatedPricing-tab.bg--overlay:before {
        background-color: {$dedicatPricTOvColor};
        opacity: {$dedicatPricTOvOpact};
    }
    #dedicatedPricing.dedicatedPricing-tab table thead,
    #dedicatedPricing.dedicatedPricing-tab .btn.btn-custom,
    .dedicated-pricing-tab-filter .nav > li.active > a {
        color: {$dedicatPricTTextColor};
    }
    #dedicatedPricing {
        background-color: {$dedicatPricbgColor};
        border-color: {$dedicatPricBordColor};
    }
    #dedicatedPricing.bg--overlay:before {
        background-color: {$dedicatPricOvColor};
        opacity: {$dedicatPricOvOpt};
    }
    #dedicatedPricing .section-title p {
        color: {$dedicatPricSubTitle};
    }
    #dedicatedPricing .section-title h2 {
        color: {$dedicatPricSectTitle};
    }
    #dedicatedPricing table thead,
    #dedicatedPricing .btn.btn-custom {
        color: {$dedicatPrictblthead};
    }
";


wp_add_inline_style( 'custom-style', $color );
wp_add_inline_style( 'custom-style', $bgColor );
wp_add_inline_style( 'custom-style', $hovColor );
wp_add_inline_style( 'custom-style', $bordderColor );
wp_add_inline_style( 'custom-style', $tableColor );
wp_add_inline_style( 'custom-style', $slideColor );
wp_add_inline_style( 'custom-style', $copyColor );
wp_add_inline_style( 'custom-style', $bgColor2 );
wp_add_inline_style( 'custom-style', $hoverbgColor );
wp_add_inline_style( 'custom-style', $borderColor );
wp_add_inline_style( 'custom-style', $acountColor );
wp_add_inline_style( 'custom-style', $triangle );
wp_add_inline_style( 'custom-style', $faq );
wp_add_inline_style( 'custom-style', $pricingItem );
wp_add_inline_style( 'custom-style', $whmcsColor );
wp_add_inline_style( 'custom-style', $whmcsBg );
wp_add_inline_style( 'custom-style', $whmcsbgbo );
wp_add_inline_style( 'custom-style', $whmBor );
wp_add_inline_style( 'custom-style', $whmcsBorTop );
wp_add_inline_style( 'custom-style', $sliderbg );
wp_add_inline_style( 'custom-style', $sectionOpt );


}