<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

// ordomain theme option callback
function ordomain_opt( $id = null, $url = null ){
    global $ordomain_opt;
    
    if( $id && $url ){
        
        if( isset( $ordomain_opt[$id][$url] ) && $ordomain_opt[$id][$url] ){
            return $ordomain_opt[$id][$url];    
        }
        
        
    }else{
        if( isset( $ordomain_opt[$id] ) && $ordomain_opt[$id]  ){
            
            return $ordomain_opt[$id] ;   
        }
        
    }
   
}

// ordomain theme logo
function ordomain_theme_logo() {

    // escaping allow html
    $allowhtml = array(
        'a'    => array( 
            'href' => array()
        ),
        'span' => array(),
        'i'    => array( 
            'class' => array() 
        )
    );
    // site logo
    if( !ordomain_opt('ord_site_title') && ordomain_opt('ord_site_logo', 'url' )  ){
        return '<a href="'.esc_url( home_url('/') ).'" class="navbar-brand"><div class="vc-parent"><div class="vc-child"><img src="'.esc_url( ordomain_opt('ord_site_logo', 'url' ) ).'" alt="logo" /></div></div></a>';
         
    }elseif( ordomain_opt('ord_site_title') ){
        return '<a href="'.esc_url( home_url('/') ).'" class="navbar-brand"><div class="vc-parent"><div class="vc-child">'.wp_kses( ordomain_opt('ord_site_title'), $allowhtml ).'</div></div></a>';   
    }else{
        return;
    }
  
}

//blog post comments 
if ( ! function_exists( 'ordomain_posted_comments' ) ) {
    function ordomain_posted_comments(){
        
        $comments_num = get_comments_number();
        if( comments_open() ){
            if( $comments_num == 0 ){
                $comments = esc_html__('No Comments','ordomain');
            } elseif ( $comments_num > 1 ){
                $comments= $comments_num . esc_html__(' Comments','ordomain');
            } else {
                $comments = esc_html__('1 Comment','ordomain');
            }
            $comments = '<a href="' . esc_url( get_comments_link() ) . '">'. $comments .'</a>';
        } else {
            $comments = esc_html__('Comments are closed','ordomain');
        }
        
        return $comments;
    }
}
// blog thumb area
function ordomain_blog_thumb() {
    if( has_post_thumbnail() ):
?>
    <div class="post-image">
        <?php the_post_thumbnail( 'full', array( 'class'=>'img-responsive') ); ?>
    </div> 
<?php
    endif;
}

//audio format iframe match 
function ordomain_iframe_match(){   
    $audio_content = ordomain_embedded_media( array('audio', 'iframe') );
    $iframe_match = preg_match("/\iframe\b/i",$audio_content, $match);
    return $iframe_match;
}

//Post embedded media
function ordomain_embedded_media( $type = array() ){
    $content = do_shortcode( apply_filters( 'the_content', get_the_content() ) );
    $embed = get_media_embedded_in_content( $content, $type );
        
    if( in_array( 'audio' , $type) ):
    
        if( count( $embed ) > 0 ){
            $output = str_replace( '?visual=true', '?visual=false', $embed[0] );
        }else{
           $output = str_replace( '?visual=true', '?visual=false', $embed );
        }
        
    else:
        if( count( $embed ) > 0 ){
            $output = $embed[0];
        }else{
           $output = $embed; 
        }
        
    endif;
    
    return $output;

    
}


// blog post date permalink
function ordomain_blog_date_permalink(){
    $year  = get_the_time('Y'); 
    $month_link = get_the_time('m');
    $day   = get_the_time('d');

    $link = get_day_link( $year, $month_link, $day);
    
    return $link; 
}
 
// blog excerpt & meta
function ordomain_blog_excerptMeta() {
?>
    <div class="post-meta clearfix">
        <div class="date">
            <a href="<?php echo esc_url( ordomain_blog_date_permalink() ); ?>">
                <i class="fa fa-calendar"></i><?php echo esc_html( get_the_date('M-d') ); ?>
            </a>
        </div> 
        <div class="comments">
            <?php echo ordomain_posted_comments(); ?>
        </div>
    </div>

    <div class="post-content">
        <h2 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <div class="summery">
        <?php echo  ordomain_excerpt_length( ordomain_opt('ord_blog_postExcerpt') ); ?>
        </div>
        
        <?php
            wp_link_pages( array(
            'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'ordomain' ) . '</span>',
            'after'       => '</div>',
            'link_before' => '<span>',
            'link_after'  => '</span>',
            'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'ordomain' ) . ' </span>%',
            'separator'   => '<span class="screen-reader-text">, </span>',
            ) );
            
        ?>
        
        <a href="<?php the_permalink(); ?>" class="read-more-btn btn btn-custom"><?php esc_html_e( 'read more', 'ordomain' ); ?></a>
    </div>
<?php
} 

//blog post categories 

if ( ! function_exists( 'ordomain_posts_categories' ) ) {
    function ordomain_posts_categories(){
        $categories = get_the_category ();
        
        if($categories){
        echo '<p>';
            $cat="";
            $cat.='<span class="post-category-text">'.esc_html__('CATEGORY:','ordomain').'</span>';
            foreach($categories as $category){
                
            $cat.='<a href="'.esc_url( get_category_link( $category->term_id ) ).'" class="category-link">'.esc_html( $category->name ).'</a>'.' ';
            }
            echo wp_kses_post( $cat );
        echo '</p>';
        }
    }
}

// Blog right sidebar
function ordomain_blog_right_sidebar(){
    
    $sidebar = ordomain_opt('ord_blog_sidebar');
    
    switch ( $sidebar ){
        
        case '3' : get_sidebar();
            break;
        case '1' :
                #...
            break;
        default :
            get_sidebar();
            break;
  
            
    }
      
}

// WooCommerce right sidebar
function ordomain_woo_right_sidebar(){
    
    $sidebar = ordomain_opt('ord_woo_sidebar');
    
    switch ( $sidebar ){
        
        case '3' : get_sidebar('woo');
            break;
        case '1' :
                #...
            break;
        default :
            get_sidebar('woo');
            break;
  
            
    }
      
}

// Blog left sidebar  
function ordomain_blog_left_sidebar(){
    
    if( '2' == ordomain_opt('ord_blog_sidebar') ){
       get_sidebar(); 
    } 
} 

// WooCommerce left sidebar  
function ordomain_woo_left_sidebar(){
    
    if( '2' == ordomain_opt('ord_woo_sidebar') ){
       get_sidebar( 'woo' ); 
    } 
} 

//front section blog post categories 

if ( ! function_exists( 'ordomain_front_posts_categories' ) ) {
    function ordomain_front_posts_categories(){
        $categories = get_the_category ();
        
        if($categories){
            $cat="";
            foreach($categories as $category){
            $cat.='<a href="'.esc_url( get_category_link( $category->term_id ) ).'">'.esc_html( $category->name ).'</a>'.' ';
            
            }
            echo wp_kses_post( $cat );
        }
    }
}

// blog post tag 

if ( ! function_exists( 'ordomain_posts_tag' ) ) :
function ordomain_posts_tag(){
    $posttags= get_the_tags();
    $tag = "";
    $tag .= "<ul>";
    if($posttags){
        $tag .= "<li><strong>".esc_html__('Tags:','ordomain')."</strong></li>";
        foreach($posttags as $posttag){
            $tag .= '<li><a href="'.esc_url( get_tag_link($posttag->term_id) ).'">'.esc_html( $posttag->name ).'</a></li>';
        }
    }
    $tag .= "</ul>";
    echo wp_kses_post( $tag );
}
endif;

// Blog Excerpt Length
if ( ! function_exists( 'ordomain_excerpt_length' ) ) :
function ordomain_excerpt_length( $limit=30 ) {
	
	$excerpt = explode( ' ', get_the_excerpt() );
	
	if ( count( $excerpt ) >= $limit ) {
		array_pop( $excerpt );
		$exc_slice = array_slice( $excerpt, 0, $limit );
		$excerpt = implode( " ", $exc_slice ).' ...';
	} else {
		$exc_slice = array_slice( $excerpt, 0, $limit );
		$excerpt = implode( " ", $exc_slice );
	}
	
	$excerpt ='<p>'. preg_replace('`\[[^\]]*\]`','',$excerpt).'</p>';
	return $excerpt;
}
endif;


// ordomain comment template callback
function ordomain_comment_callback( $comment, $args, $depth ) {
    
      if ( 'div' === $args['style'] ) {
        $tag       = 'div';
        $add_below = 'comment';
    } else {
        $tag       = 'li';
        $add_below = 'div-comment';
    }
    ?>
    <<?php echo esc_attr( $tag ) ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?> id="comment-<?php comment_ID() ?>">
    <?php if ( 'div' != $args['style'] ) : ?>
        <div id="div-comment-<?php comment_ID() ?>" class="comment-body single-comment ">
    <?php endif; ?>
    <div class="comment-thumb">
    
        <a href="#" class="pull-left">
            <?php if ( $args['avatar_size'] != 0 ) echo get_avatar( $comment, $args['avatar_size'] ); ?>
        </a>
        
        <?php if ( $comment->comment_approved == '0' ) : ?>
             <em class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'ordomain' ); ?></em>
              <br />
        <?php endif; ?>
        
        <div class="comment-meta pull-left">
            <?php printf( __( '<span class="comment-author-name">%s</span> says:', 'ordomain' ), get_comment_author_link() ); ?>
            <?php edit_comment_link( esc_html__( '(Edit)', 'ordomain' ), '  ', '' ); ?>
            <div class="date"><?php printf( __('%1$s at %2$s', 'ordomain'), get_comment_date(),  get_comment_time() ); ?></div>
        </div>
    </div>
    <div class="comment-content">
        <div class="comment-text">
            <?php comment_text(); ?>
        </div>
    </div>  

    <?php comment_reply_link(array_merge( $args, array( 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']) ) ); ?>
 
    <?php if ( 'div' != $args['style'] ) : ?>
    </div>
    <?php endif; ?>
    <?php  
}

//  add class comment reply link
add_filter('comment_reply_link', 'ordomain_replace_reply_link_class');
function ordomain_replace_reply_link_class( $class ){
    $class = str_replace("class='comment-reply-link", "class='comment-reply btn btn-sm", $class);
    return $class;
}

// comments textarea top to  bottom .
add_filter( 'comment_form_fields', 'ordomain_move_comment_field_to_bottom' );
function ordomain_move_comment_field_to_bottom( $fields ) {
    $comment_field = $fields['comment'];
    unset( $fields['comment'] );
    $fields['comment'] = $comment_field;
    return $fields;
}

// ordomain custom meta callback
function ordomain_meta_callback( $id = '' ){
    
    $value = get_post_meta( get_the_ID(), '_ord_'.$id, true );
    
    return $value;
}
// ordomain extension slider callback
function ordomain_extension_slider( $args = array() ){
    
    echo '<div class="extension-slider owl-carousel text-center text-white" data-items="5">';
    if( $args ){
        foreach( $args as $arg ){
            if( $arg ){
                echo '<div class="item">';
                    echo '<p class="ext--name">'.esc_html( $arg['_ord_extension_name'] ).'</p>';
                    echo '<p class="ext--price">'.esc_html( $arg['_ord_extension_price'] ).'<span>'.esc_html( $arg['_ord_extension_duration'] ).'</span></p>';
                echo '</div>';  
            }
        }  
    }
    echo '</div>';
}

// section heading callback

function ordomain_section_heading( $args = array() ){

    $secsubtitle = ordomain_meta_callback( $args['subtitle'] );
    $sectitle = ordomain_meta_callback( $args['title'] );
    
    if( $secsubtitle || $sectitle ){
        
        echo '<div class="section-title">';
            if( $secsubtitle ){
                echo '<p>'.esc_html( $secsubtitle ).'</p>';
            }
            if( $sectitle ){
                echo '<h2>'.esc_html( $sectitle ).'</h2>'; 
            }
        echo '</div>';   
    }
}

// section background callback
function ordomain_section_bg( $imgUrl = '' ) {                                               

    return 'data-bg-img="'.esc_url( ordomain_meta_callback( $imgUrl ) ).'"';
    
}

// ordomain subscribe ajax callback function
add_action( 'wp_ajax_ordomain_subscribe_ajax', 'ordomain_subscribe_ajax' );
add_action( 'wp_ajax_nopriv_ordomain_subscribe_ajax', 'ordomain_subscribe_ajax' );

function ordomain_subscribe_ajax(){
    
    $apiKey = ordomain_opt('ord_subscribe_apikey');
    $listid = ordomain_opt('ord_subscribe_listid'); 
    
    $api = new MCAPI( $apiKey );
 
    $merge_vars = array('FNAME'=>'', 'LNAME'=>'');


        $retval = $api->listSubscribe( $listid, $_POST['subscribe_email'], $merge_vars, 'html', false, true );

        if ($api->errorCode){
            echo '<div class="alert alert-danger" role="alert">'.esc_html( 'Sorry something wrong. Please try again.' ).'</div>';

        } else {
            echo '<div class="alert alert-success" role="alert">'.esc_html('Thank you, you have been added to our mailing list.').'</div>';
        }
        die();    

    
}

/**
 * vps pricing slider
 *
 */

//  vps pricing slider localize script
add_action('wp_enqueue_scripts','ordomain_localize_script');
function ordomain_localize_script(){

$x = '123';

wp_localize_script( 'ordomain-main', 'ajaxvps', array(
	'ajaxurl' => admin_url( 'admin-ajax.php' ),
	'vpscontent' => $x
    
    ));

}

// vps pricing ajax callback 
add_action('wp_ajax_vpspricing_ajax', 'ordomain_vpspricing_ajax');
add_action('wp_ajax_nopriv_vpspricing_ajax', 'ordomain_vpspricing_ajax');
function ordomain_vpspricing_ajax(){
    
    $args = array(
        'post_type' => 'vpsslide',
        'posts_per_page' => -1,
        'order' => 'ASC'
    );
    
    $loop = new WP_Query( $args );
    
    $packge = array();
  
    if( $loop->have_posts() ){
        
        while( $loop->have_posts() ){
           $loop->the_post();
           
          $packge[] = array(
                ordomain_meta_callback('vpspricing_content'),
                ordomain_meta_callback('vpspricing_buy_url'), 
                ordomain_meta_callback('vpspricing_price') 
          ); 
 
        }
    }
   
    $data = json_encode( $packge ) ;
    echo wp_kses_post( $data );
    die();

}

/**
 * MAP 
 */

add_action('wp_enqueue_scripts','ordomain_map_localize_script');
function ordomain_map_localize_script(){

$x = '123';

wp_localize_script( 'ordomain-main', 'ajaxmap', array(
	'ajaxurl' => admin_url( 'admin-ajax.php' ),
	'mapcontent' => esc_html( $x )
    
    ));

}

// map ajax callback 
add_action('wp_ajax_map_ajax', 'ordomain_map_ajax');
add_action('wp_ajax_nopriv_map_ajax', 'ordomain_map_ajax');
function ordomain_map_ajax(){
    
    $locations = array( 
                    array( 
                        'lat'  => ordomain_opt( 'ord_map_lat' ),
                        'lng'  => ordomain_opt( 'ord_map_lng' ),
                        'zoom' => ordomain_opt( 'ord_map_zoom' ) 
                    ),
                    array( 
                        'locs' => ordomain_opt( 'ord_datacenterLocations' ) 
                    ) 
                );

    $data = json_encode( $locations );
    echo wp_kses_post( $data );
    
    die();
}

// wp kses allow html
function ordomain_wp_kses_allow( $data = '' ){
    
    $allow = array(
        'a' => array(
            'href' => array(),
            'target' => array()
        ),
        'span' => array(),
        'br'   => array(),
        'strong'   => array(),
    
    
    );
    
    return wp_kses( $data, $allow );
    
}
// is blog
function is_blog() {
    
	return ( ((is_archive()) || (is_author()) || (is_category()) || (is_home()) || (is_single()) || (is_tag()) || (is_search())  ) ) ? true : false ;
}
// image alt tag
function ordomain_image_alt( $url = '' ){

    if( $url != '' ){
        // attachment id by url 
        $attachmentid = attachment_url_to_postid( esc_url( $url ) );
       // attachment alt tag 
        $image_alt = get_post_meta( esc_html( $attachmentid ) , '_wp_attachment_image_alt', true );
        
        if( $image_alt ){
            return $image_alt ;
        }else{
            $filename = pathinfo( esc_url( $url ) );
    
            $alt = str_replace( '-', ' ', $filename['filename'] );
            
            return $alt;
        }
   
    }else{
       return; 
    }

}

// Woocommerce Check
if ( ! function_exists( 'is_ordomain_woocommerce_activated' ) ) {
	function is_ordomain_woocommerce_activated() {
		if ( class_exists( 'woocommerce' ) ) { return true; } else { return false; }
	}
}


/**
 * woo_hide_page_title
 *
 * Removes the "shop" title on the main shop page
*/

add_filter( 'woocommerce_show_page_title' , 'ordomain_hide_woo_page_title' );
function ordomain_hide_woo_page_title() {
	
	if( ordomain_opt('ord_woo_shoptitle_switch') == false ){
		return false;
	}else{
		return true;
	}
	
}

// Shop Page Product per page 
add_filter( 'loop_shop_per_page', 'ordomain_loop_shop_per_page', 20 );
function ordomain_loop_shop_per_page( $cols ) {

  // Return the number of products you wanna show per page.
  
	if( ordomain_opt( 'ord_woo_product_number' ) ){
		$num = ordomain_opt( 'ord_woo_product_number' );
	}else{
		$num = 10;
	}
  
  $cols = esc_html( $num );
  return $cols;
}

// ---------------------------------------------
// Display Only 3 Cross Sells instead of default 4
 
add_filter( 'woocommerce_cross_sells_total', 'ord_change_cross_sells_product_no' );
  
function ord_change_cross_sells_product_no( $columns ) {
return 2;
}