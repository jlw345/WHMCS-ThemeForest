<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

// custom meta taxonomy option
function ordomain_get_term_options( $field ) {
    $args = $field->args( 'get_terms_args' );
    $args = is_array( $args ) ? $args : array();

    $args = wp_parse_args( $args, array( 'taxonomy' => 'category' ) );

    $taxonomy = $args['taxonomy'];

    $terms = (array) cmb2_utils()->wp_at_least( '4.5.0' )
        ? get_terms( $args )
        : get_terms( $taxonomy, $args );

    // Initate an empty array
    $term_options = array();
    if ( ! empty( $terms ) ) {
        foreach ( $terms as $term ) {
            $term_options[ $term->term_id ] = $term->name;
        }
    }

    return $term_options;

}


/**************************/
/*** Drag  & Drop ***/
/**************************/

// custom meta drag and drop

//enqueue the admin scripts / styles for the related pages functionality
function ordomain_enqueue_dndMeta_scripts_and_styles(){
    
	wp_enqueue_style('admin-dnd-styles',  get_template_directory_uri() . '/css/dnd-styles.css');
    
	wp_enqueue_script('releated-pages-admin-script', get_template_directory_uri() . '/js/dnd-scripts.js', array('jquery','jquery-ui-droppable','jquery-ui-draggable', 'jquery-ui-sortable'), true);
    
	wp_enqueue_script('ord-admin', get_template_directory_uri() . '/js/ord-admin.js', array('jquery'), true );
}
if( is_admin() ){
  add_action('admin_enqueue_scripts','ordomain_enqueue_dndMeta_scripts_and_styles'); 
}



//Add a meta box to the 'pages' post type
function ordomain_dnd_meta_box_to_pages() {
	
	add_meta_box(
		'page_layout_meta_box', //unique ID
		esc_html__( 'Seaction Layout', 'ordomain' ), //Name shown in the backend
		'ordomain_display_dnd_pages_meta_box', //function to output the meta box
		'page', //post type this box will attach to
		'normal', //position (side,advanced, normal etc)
		'high' //priority (high, default, low etc)
	);

}
add_action('add_meta_boxes','ordomain_dnd_meta_box_to_pages');


//defines the output for our pages meta box
function ordomain_display_dnd_pages_meta_box( $post ){
//create nonce
wp_nonce_field('pages_meta_box','pages_meta_box_nonce');
	
//collect related pages (if we already have some)
$sections_ids = get_post_meta( $post->ID, '_ord_sections_ids', true);

$sections = array(

    'services'              => esc_html__('Services', 'ordomain' ),
    'counter'               => esc_html__('Counter', 'ordomain' ),
    'testimonial'           => esc_html__('Testimonial', 'ordomain' ),
    'team'                  => esc_html__('Team', 'ordomain' ),
    'subscribe'             => esc_html__('Subscribe', 'ordomain' ),
    'flat-content'          => esc_html__('Flat Content', 'ordomain' ),
    'flat-content-one'      => esc_html__('Flat Content One', 'ordomain' ),
    'blog'                  => esc_html__('Blog', 'ordomain' ),
    'faq'                   => esc_html__('Faq', 'ordomain' ),
    'faq-tab'               => esc_html__('Faq Tab', 'ordomain' ),
    'vps-slide'              => esc_html__('VPS Slide', 'ordomain' ),
    'history'               => esc_html__('History', 'ordomain' ),
    'affiliate-features'    => esc_html__('Affiliate Features', 'ordomain' ),
    'affiliate-counter'     => esc_html__('Affiliate Counter', 'ordomain' ),
    'affiliate-price'       => esc_html__('Affiliate Price', 'ordomain' ),
    'affiliate-action'      => esc_html__('Contact Action', 'ordomain' ),
    'home-domain-checker'   => esc_html__('Home Domain Checker', 'ordomain' ),
    'bulkdomainchecker'     => esc_html__('Bulk Domain Checker', 'ordomain' ),
    'domain-and-hosting-feature'    => esc_html__('Domain and Hosting Feature', 'ordomain' ),
    'hosting-price'         => esc_html__('Hosting Price', 'ordomain' ),
    'pricing-tab'           => esc_html__('Pricing Tab', 'ordomain' ),
    'domain-price'          => esc_html__('Domain Price', 'ordomain' ),
    'dedicate-price'        => esc_html__('Dedicated Price', 'ordomain' ),
    'dedicated-price-tab'   => esc_html__('Dedicated Price Tab', 'ordomain' ),
    'domain-extension'      => esc_html__('Domain Extension', 'ordomain' ),
    'extra-feature'         => esc_html__('Extra Feature', 'ordomain' ),
    'multiLocationMap'      => esc_html__('Multi Location Map', 'ordomain' )
    
);

//if we have pages to display
if( $sections ){
	echo '<div class="related_pages">';
	
		//left container (all pages)
		echo '<div class="left_container">';
            echo '<p>'.esc_html__( 'Listed below are the section.', 'ordomain' ).'</p>';
			echo '<p>'.esc_html__( 'Drag these to the other container to add them as page section', 'ordomain' ).'</p>';
            
			//loop through all pages
			foreach( $sections as $key => $id ){

				echo '<div class="page_item" id="'.esc_attr( $key ).'" data-page-id="' . esc_attr( $key ) . '">';
				echo 	'<div class="page_title">' . esc_html( $id ) . '</div>';
				echo 	'<div class="remove_item">'.esc_html__( 'Remove', 'ordomain' ).'</div>';
				echo '</div>';
			}
		echo '</div>';
		//end left container
		
		//Right container
		echo '<div class="right_container">';
        
		echo '<p>'.esc_html__( 'Drag section from the left container onto this container', 'ordomain' ).'</p>';
        
		//if we have previous saved related pages
		if( !empty( $sections_ids ) ){
            
			$sections_ids_array = json_decode( $sections_ids );
            
			foreach( $sections_ids_array as $sections_id ){
                
				//page information
                $section_name = str_replace( '-',' ', $sections_id );
                
				echo '<div class="page_item" id="'.esc_attr( $sections_id ).'" data-page-id="' . esc_attr( $sections_id ) . '">';
				echo 	'<div class="page_title">' . esc_html( $section_name ) . '</div>';
				echo 	'<div class="remove_item active">'.esc_html__( 'Remove', 'ordomain' ).'</div>';
				echo 	'<input type="hidden" name="related_pages[]" value="' . esc_attr( $sections_id ) . '"/>';
				echo '</div>';
			}
		}
		echo 	'<div class="droppable-helper"></div>';
		echo '</div>';
		
	echo '<div class="clearfix"></div>';
	echo '</div>';
}
	
}



//save our related pages meta information for pages
function ordomain_save_meta_information_for_page( $post_id ){
	
	//test for existence of nonce
	if( !isset( $_POST['pages_meta_box_nonce'] ) ){
		return $post_id;
	}
	//verify nonce
	if( !wp_verify_nonce( $_POST['pages_meta_box_nonce'],'pages_meta_box' ) ){
		return $post_id;
	}
	//if not autosaving
	if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE){
		return $post_id;
	}
	//check permissions
	if( !current_user_can( 'edit_page',$post_id ) ){
		return $post_id;
	}
	

	//SAFE to save data, let's go
	$sections_value = '';
	//collect related pages (if set)
	if( isset( $_POST['related_pages'] ) ){
        
		$sections_ids_array = $_POST['related_pages'];
        
		$sections_value = json_encode( $sections_ids_array );
	}
	
	//update post meta
	update_post_meta( $post_id, '_ord_sections_ids', $sections_value );

}
add_action( 'save_post_page', 'ordomain_save_meta_information_for_page' );

// preloader callback
function ordomain_preloader(){
    
    echo '<div id="preloader">';
        echo '<div class="preloader--bounce">';
            echo '<div class="preloader-bouncer--1"></div>';
            echo '<div class="preloader-bouncer--2"></div>';
        echo '</div>';
    echo '</div>';
}

// social media
if ( ! function_exists( 'ordomain_social' ) ) {
	function ordomain_social( $args = array() ){

		$default = array(
			'wrapper_before' 	=> '',
			'wrapper_after' 	=> '',
			'after_ul_start' 	=> '',
			'ul_class'  		=> '',
			'li_class'  		=> '',
			'a_class'     		=> ''
		);

		$class = wp_parse_args( $args, $default );

		if( $class['ul_class'] ){
		   $ul_class = 'class="'.esc_attr( $class['ul_class'] ).'"';
		}else{
		   $ul_class = ''; 
		}

		if( $class['li_class'] ){
			$li_class = 'class="'.esc_attr( $class['li_class'] ).'"';
		}else{
		   $li_class = ''; 
		}
		// 
		if( $class['a_class'] ){
		  $aclass = 'class="'.esc_attr( $class['a_class'] ).'"';
		}else{
		   $aclass = ''; 
		}
		// After ul start
		if( $class['after_ul_start'] ){
		  $after_ul_start = $class['after_ul_start'];
		}else{
		   $after_ul_start = ''; 
		}

		// Social Media Icon

		$icons = array(
			
			array(
				'url'  => ordomain_opt('ordomain_facebook_link'),
				'icon' => 'fa fa-facebook',
			),
			array(
				'url'  => ordomain_opt('ordomain_twitter_link'),
				'icon' => 'fa fa-twitter',
			),
			array(
				'url'  => ordomain_opt('ordomain_google_link'),
				'icon' => 'fa fa-google-plus',
			),
			array(
				'url'  => ordomain_opt('ordomain_youtube_link'),
				'icon' => 'fa fa-youtube',
			),
			array(
				'url'  => ordomain_opt('ordomain_instagram_link'),
				'icon' => 'fa fa-instagram',
			),
			array(
				'url'  => ordomain_opt('ordomain_vimeo_link'),
				'icon' => 'fa fa-vimeo',
			),
			array(
				'url'  => ordomain_opt('ordomain_linkedin_link'),
				'icon' => 'fa fa-linkedin',
			),
			array(
				'url'  => ordomain_opt('ordomain_linkedin_link'),
				'icon' => 'fa fa-rss',
			),
			array(
				'url'  => ordomain_opt('ordomain_behance_link'),
				'icon' => 'fa fa-behance',
			),
			array(
				'url'  => ordomain_opt('ordomain_pinterest_link'),
				'icon' => 'fa fa-pinterest-p',
			),
			array(
				'url'  => ordomain_opt('ordomain_dribbble_link'),
				'icon' => 'fa fa-dribbble',
			),
			array(
				'url'  => ordomain_opt('ordomain_github_link'),
				'icon' => 'fa fa-github-alt',
			)

		);

		// Array Filtering 
		$findUrlKey = array_column( $icons, 'url' );
		$filterEmpty = array_filter( $findUrlKey );
		//
		$html  = '';
		
		if( count( $filterEmpty ) > 0 ){
			
			// Wrapper Before Block
			if( $class['wrapper_before'] && $class['wrapper_after'] ){
				$html .= wp_kses_post( $class['wrapper_before'] );
			}

				foreach( $icons as $icon ){

				
					if( !empty( $icon['url'] ) && !empty( $icon['icon'] ) ){

						$html .= '<li><a href="'.esc_url( $icon['url'] ).'" '.wp_kses_post( $aclass ).' target="_blank"><i class="'.esc_attr( $icon['icon'] ).'"></i></a></li>';

					}
					
				}
					
			// Wrapper After Block
			if( $class['wrapper_before'] && $class['wrapper_after'] ){
				$html .= wp_kses_post( $class['wrapper_after'] );
			}
		
		}
		
		return $html;

	}
}
