<?php
/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB2 directory)
 *
 * Be sure to replace all instances of 'yourprefix_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category YourThemeOrPlugin
 * @package  Demo_CMB2
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/WebDevStudios/CMB2
 */

/**
 * Get the bootstrap! If using the plugin from wordpress.org, REMOVE THIS!
 */

if ( file_exists( get_template_directory() . '/cmb2/init.php' ) ) {
    require_once get_template_directory() . '/cmb2/init.php';
} elseif ( file_exists( get_template_directory() . '/CMB2/init.php' ) ) {
    require_once get_template_directory() . '/CMB2/init.php';
}

/**
 * Conditionally displays a metabox when used as a callback in the 'show_on_cb' cmb2_box parameter
 *
 * @param  CMB2 object $cmb CMB2 object
 *
 * @return bool             True if metabox should show
 */
function ordomain_show_if_front_page( $cmb ) {
    // Don't show this metabox if it's not the front page template
    if ( $cmb->object_id !== get_option( 'page_on_front' ) ) {
        return false;
    }
    return true;
}

/**
 * Conditionally displays a field when used as a callback in the 'show_on_cb' field parameter
 *
 * @param  CMB2_Field object $field Field object
 *
 * @return bool                     True if metabox should show
 */
function ordomain_hide_if_no_cats( $field ) {
    // Don't show this field if not in the cats category
    if ( ! has_tag( 'cats', $field->object_id ) ) {
        return false;
    }
    return true;
}

/**
 * Conditionally displays a message if the $post_id is 2
 *
 * @param  array             $field_args Array of field parameters
 * @param  CMB2_Field object $field      Field object
 */
function ordomain_before_row_if_2( $field_args, $field ) {
    if ( 2 == $field->object_id ) {
        echo '<p>Testing <b>"before_row"</b> parameter (on $post_id 2)</p>';
    } else {
        echo '<p>Testing <b>"before_row"</b> parameter (<b>NOT</b> on $post_id 2)</p>';
    }
}


add_action( 'cmb2_admin_init', 'ordomain_custom_meta_fields' );
/**
 * Hook in and add a demo metabox. Can only happen on the 'cmb2_admin_init' or 'cmb2_init' hook.
 */
 
function ordomain_custom_meta_fields() {
    $prefix = '_ord_';
    $prefixtype = '_ordtype_';
    
    /**
    * page Page layout metabox field type included
    */
    $ord_meta = new_cmb2_box( array(
        'id'            => $prefix . 'page_layout_section',
        'title'         => __( 'Page layout', 'ordomain' ),
        'context' => 'side',
        'priority' => 'high',
        'object_types'  => array( 'page' ),
        //'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' )

    ) );
    
    $ord_meta->add_field( array(
        'name'    => __( 'Page Layout', 'ordomain' ),
        'desc'    => 'set page layout container,fullwide or both',
        'id'      => $prefix .'custom_page_layout',
        'type'    => 'multicheck',
        'options' => array(
            '1' => 'Container',
            '2' => 'Fullwidth',
            ),
    ) );
    
        
    // Slider/ page Header section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefixtype . 'sliderPageheader_section',
        'title'        => __( 'Slider/Page Header section', 'ordomain' ),
        'priority'     => 'high',
        'object_types' => array( 'page' ),
        'closed'       => true

    ) );
    
    $ord_meta->add_field( array(
        'name'    => __( 'Slider/Page Header Active', 'ordomain' ),
        'id'      => $prefix. 'slide_header_active',
        'type'    => 'radio_inline',
        'options' => array(
            'slider_vr1'    => __( 'Slider Version 1', 'ordomain' ),
            'slider_vr2'    => __( 'Slider Version 2', 'ordomain' ),
            'page_header'   => __( 'Page Header', 'ordomain' ),
            'none'          => __( 'None', 'ordomain' ),
        ),
        'default' => 'page_header',
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Breadcrumb Settings', 'ordomain' ),
        'id'   => $prefix. 'sliderbg_breadcrumbglob',
        'classes' => 'header-breadcrumb',
        'type' => 'radio_inline',
        'desc' => __( 'Set page breadcrumb settings.', 'ordomain' ),
        'options' => array(
            'page'   => 'Page Settings',
            'global' => 'Global Settings',
        )
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Breadcrumb Show/ Hide', 'ordomain' ),
        'id'   => $prefix. 'sliderbg_breadcrumbon',
        'classes' => 'header-breadcrumb header-breadcrumbsect',
        'type' => 'radio_inline',
        'options' => array(
            'show'   => 'show',
            'hide' => 'hide',
        )
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background Image', 'ordomain' ),
        'id'   => $prefix. 'sliderbg_img',
        'classes' => 'header-none',
        'type' => 'file',
        'desc' => 'Use background image slide or page header'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Background Color', 'ordomain' ),
        'id'   => $prefix. 'sliderbg_color',
        'classes' => 'header-none',
        'type' => 'colorpicker',
        'desc' => 'Use background color slide or page header'
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Text Color', 'ordomain' ),
        'id'   => $prefix. 'slider_textcolor',
        'classes' => 'header-none',
        'type' => 'colorpicker',
        'desc' => 'Change slider text color.'
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Overlay', 'ordomain' ),
        'id'   => $prefix. 'sliderbg_overlay',
        'classes' => 'header-none',
        'type' => 'radio_inline',
        'desc' => 'Check the radio button "on" to active the overlay. If you want to use global overlay then make sure you have selected the "Common Page Header Overlay" chackbox from the theme options.',
        'options' => array(
            'on'     => 'ON',
            'global' => 'Global',
            'none'   => 'None',
        )
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Overlay Color', 'ordomain' ),
        'id'   => $prefix. 'slider_overlaycolor',
        'classes' => 'header-none',
        'type' => 'colorpicker',
        'desc' => 'Change slider text color.'
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Opacity', 'ordomain' ),
        'id'   => $prefix. 'slider_overlayopacity',
        'classes' => 'header-none',
        'type' => 'text_small',
        'desc' => 'Change overlay opacity.'
    ) );

    $ord_meta->add_field( array(
        'name' => __( 'Video Background', 'ordomain' ),
        'id'   => $prefix. 'sliderbg_video',
        'classes' => 'similar-slider',
        'type' => 'text',
        'desc' => 'Set Video background. Use only youtube video id. Video background work in slider version 1. If you don\'t want video background then keep this field empty. '
    ) );

    $ord_meta->add_field( array(
        'name' => __( 'Slider Speed', 'ordomain' ),
        'id'   => $prefix. 'slider_speed',
        'classes' => 'similar-slider',
        'type' => 'text_small',
        'desc' => __( 'Set slide transition duration ( in ms default 800 ). ', 'ordomain' )
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Pause Speed', 'ordomain' ),
        'id'   => $prefix. 'slider_pause',
        'classes' => 'similar-slider',
        'type' => 'text_small',
        'desc' => __( 'Set The amount of time (in ms) between each auto transition ( default 4000, It\'s not work slider version 2 ). ', 'ordomain' ),
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Slider Loop', 'ordomain' ),
        'id'   => $prefix. 'slider_loop',
        'classes' => 'similar-slider',
        'type' => 'checkbox',
        'desc' => __( '. ', 'ordomain' ),
    ) );
    
    
    // Slider group field
    $group_field_id = $ord_meta->add_field( array(
        'id'          => $prefix .'slider_contents',
        'type'        => 'group',
        'classes' => 'similar-slider',
        'description' => __( 'If you use slider set this', 'ordomain' ),
        'options'     => array(
            'group_title'   => __( 'Slider {#}', 'ordomain' ), 
            'add_button'    => __( 'Add Slider', 'ordomain' ),
            'remove_button' => __( 'Remove Slider', 'ordomain' ),
            'closed'     => true, // true to have the groups closed by default
        ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Image', 'ordomain' ),
        'id'   => $prefix. 'slider_img',
        'type' => 'file'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Price Tag text', 'ordomain' ),
        'id'   => $prefix. 'Pricetag_text',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Price Tag Price', 'ordomain' ),
        'id'   => $prefix. 'Pricetag_Price',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Price Tag Duration', 'ordomain' ),
        'id'   => $prefix. 'Pricetag_duration',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix. 'slid_subTitle',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix. 'slid_title',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Content', 'ordomain' ),
        'id'   => $prefix. 'slid_editor',
        'type' => 'textarea',
        'desc' => 'Allow br, span, strong, a.',
        'options' => array(
            'media_buttons' => false,
        )
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'List Content', 'ordomain' ),
        'id'   => $prefix. 'slid_listcontent',
        'type' => 'text',
        'repeatable' => true,
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Button', 'ordomain' ),
        'id'   => $prefix. 'slid_button',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Button Link', 'ordomain' ),
        'id'   => $prefix. 'slid_buttonLink',
        'type' => 'text'
    ) );
    
    
    // Dedicated price tab 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'dedicated-price-tab_section',
        'title'        => __( 'Dedicated Pricing Tab', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );  
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'dedicPriceTab_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) );    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'dedicPriceTab_secttitle',
        'classes' => 'dedicPriceTab-content',
        'type' => 'text',
    ) );    
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'dedicPriceTab_sectsubtitle',
        'classes' => 'dedicPriceTab-content',
        'type' => 'text',
    ) );
	$ord_meta->add_field(  array(
		'name'    => 'Pricing Tab Category',
		'id'      => $prefix.'dedicPriceTab_cat',
		'type'    => 'multicheck',
		'options' => 'ordomain_get_term_options',
		'get_terms_args' => array(
			'taxonomy'   => 'dedicate_categories',
			'hide_empty' => false,
			),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ordomain' ),
		'desc' => esc_html__( 'Set background image', 'ordomain' ),
		'id'   => $prefix . 'dedicPriceTab_bgimg',
        'classes' => 'dedicPriceTab-media',
		'type' => 'file',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'dedicPriceTab-bgcolor',
        'classes' => 'dedicPriceTab-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'dedicPriceTab_overlay',
        'classes' => 'dedicPriceTab-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'dedicPriceTab_overlaycolor',
        'classes' => 'dedicPriceTab-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'dedicPriceTab_overlayopacity',
        'classes' => 'dedicPriceTab-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set title color', 'ordomain' ),
        'classes' => 'dedicPriceTab-media',
		'id'   => $prefix . 'dedicPriceTab_titlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set sub title color', 'ordomain' ),
        'classes' => 'dedicPriceTab-media',
		'id'   => $prefix . 'dedicPriceTab_Subtitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'dedicPriceTab-media',
		'id'   => $prefix . 'dedicPriceTab_textColor',
		'type' => 'colorpicker',
	) );
    // Vps Slide tab 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'vps-slide_section',
        'title'        => __( 'Vps Slide', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) ); 
    $ord_meta->add_field( array(
		'name' => sprintf( __( 'There has no settings options. All Settings set from <a href="%s" target="_blank">Ordomain options</a> and <a href="%s" target="_blank">vps slide</a> post type.', 'ordomain' ), admin_url('admin.php?page=OrDomainChild&tab=3'), admin_url('edit.php?post_type=vpsslide') ),
        'classes' => 'dnh_divaider',
		'id'   => $prefix . 'vps_info',
		'type' => 'title',
	) );    
    // Faq tab 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'faq-tab_section',
        'title'        => __( 'Faq Tab', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );  
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Heading', 'ordomain' ),
		'desc' => esc_html__( 'Set faq tab section heading', 'ordomain' ),
        'classes' => 'faqTab-content',
		'id'   => $prefix . 'faqTab_heading',
		'type' => 'text',
	) );
    $ord_meta->add_field( array(
		'name' => sprintf( __( 'No Need Content Settings from here. Content come from <a href="%s" target="_blank">faq post type</a> automatically.', 'ordomain' ), admin_url('edit.php?post_type=faq') ),
        'classes' => 'dnh_divaider',
		'id'   => $prefix . 'faqTab_info',
		'type' => 'title',
	) );
    // Service section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'services_section',
        'title'        => __( 'Services Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'services_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) );
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'services_secttitle',
        'classes' => 'service-content',
        'type' => 'text',
    ) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'services_subtitle',
        'classes' => 'service-content',
        'type' => 'text',
    ) );
    
    // group field
    $group_field_id = $ord_meta->add_field( array(
        'id'          => $prefix .'services_contents',
        'type'        => 'group',
        'description' => __( 'Set services section content', 'ordomain' ),
        'classes' => 'service-content',
        'options'     => array(
            'group_title'   => __( 'Services Content {#}', 'ordomain' ), 
            'add_button'    => __( 'Add Service', 'ordomain' ),
            'remove_button' => __( 'Remove Service', 'ordomain' ),
            'closed'     => true, // true to have the groups closed by default
        ),
    ) );
    
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Service Title', 'ordomain' ),
        'id'   => $prefix. 'service_title',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Select Icon Type', 'ordomain' ),
        'id'   => $prefix. 'service_icon_type',
        'type' => 'radio_inline',
        'options' => array(
            'icon'  => 'Icon',
            'image' => 'Image Icon'
        ),
        'default' => 'icon',
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Service Icon', 'ordomain' ),
        'id'   => $prefix. 'service_icon',
        'type' => 'text',
        'desc' => sprintf( __('Use <a href="%s" target="_blank">Font Awesome</a> icon like( fa-bath ). If you don\'t like to use image as icon you can use Font Awesome icon.','ordomain'), 'http://fontawesome.io/icons/' )
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Service Image Icon', 'ordomain' ),
        'id'   => $prefix. 'service_imgicon',
        'type' => 'file'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Service Description', 'ordomain' ),
        'id'   => $prefix. 'service_description',
        'type' => 'textarea'
    ) );
    
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Image', 'ordomain' ),
		'desc' => esc_html__( 'Set background image', 'ordomain' ),
		'id'   => $prefix . 'service_bgimg',
        'classes' => 'service-media',
		'type' => 'file',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'service-bgcolor',
        'classes' => 'service-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'service_overlay',
        'classes' => 'service-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'service_overlaycolor',
        'classes' => 'service-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'service_overlayopacity',
        'classes' => 'service-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set title color', 'ordomain' ),
        'classes' => 'service-media',
		'id'   => $prefix . 'service_titlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'service-media',
		'id'   => $prefix . 'service_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Icon Color', 'ordomain' ),
		'desc' => esc_html__( 'Set icon color', 'ordomain' ),
        'classes' => 'service-media',
		'id'   => $prefix . 'service_iconcolor',
		'type' => 'colorpicker',
	) );
    
    // Flat Content section meta
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'flat-content_section',
        'title'        => __( 'Flat Content', 'ordomain' ),
        'object_types' => array( 'page' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'flat_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) );
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'flatContent_secttitle',
        'classes' => 'flatContent-content',
        'type' => 'text',
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'flatContent_subtitle',
        'classes' => 'flatContent-content',
        'type' => 'text',
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Content', 'ordomain' ),
        'id'   => $prefix . 'flatContent_content',
        'classes' => 'flatContent-content',
        'type' => 'wysiwyg',
        'options' => array(
            'wpautop' => true,
        )
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background Image', 'ordomain' ),
        'id'   => $prefix . 'flatContent_bgimg',
        'classes' => 'flatContent-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'flatContent-bgcolor',
        'classes' => 'flatContent-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'flatContent_overlay',
        'classes' => 'flatContent-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'flatContent_overlaycolor',
        'classes' => 'flatContent-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'flatContent_overlayopacity',
        'classes' => 'flatContent-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section title color', 'ordomain' ),
        'classes' => 'flatContent-media',
		'id'   => $prefix . 'flatContent_titlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set sub title color', 'ordomain' ),
        'classes' => 'flatContent-media',
		'id'   => $prefix . 'flatContent_Subcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'flatContent-media',
		'id'   => $prefix . 'flatContent_textcolor',
		'type' => 'colorpicker',
	) );
    
    
    // Flat one Content section meta
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'flat-content-one_section',
        'title'        => __( 'Flat One Content', 'ordomain' ),
        'object_types' => array( 'page' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'flatone_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) );
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'flatContentone_secttitle',
        'classes' => 'flatContentone-content',
        'type' => 'text',
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'flatContentone_subtitle',
        'classes' => 'flatContentone-content',
        'type' => 'text',
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Content', 'ordomain' ),
        'id'   => $prefix . 'flatContentone_content',
        'classes' => 'flatContentone-content',
        'type' => 'wysiwyg',
        'options' => array(
            'wpautop' => true,
        )
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background Image', 'ordomain' ),
        'id'   => $prefix . 'flatContentone_bgimg',
        'classes' => 'flatContentone-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'flatContentone-bgcolor',
        'classes' => 'flatContentone-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'flatContentone_overlay',
        'classes' => 'flatContentone-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'flatContentone_overlaycolor',
        'classes' => 'flatContentone-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'flatContentone_overlayopacity',
        'classes' => 'flatContentone-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section title color', 'ordomain' ),
        'classes' => 'flatContentone-media',
		'id'   => $prefix . 'flatContentone_titlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set sub title color', 'ordomain' ),
        'classes' => 'flatContentone-media',
		'id'   => $prefix . 'flatContentone_Subcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'flatContentone-media',
		'id'   => $prefix . 'flatContentone_textcolor',
		'type' => 'colorpicker',
	) );
    
    // Affiliate section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'affiliate-features_section',
        'title'        => __( 'Affiliate Feature', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'affiliateFeature_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content' => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'affiliateFeature_secttitle',
        'classes' => 'afeature-content',
        'type' => 'text',
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'affiliateFeature_subtitle',
        'classes' => 'afeature-content',
        'type' => 'text',
    ) );
    // group field
    $group_field_id = $ord_meta->add_field( array(
        'id'          => $prefix .'affiliateFeature_contents',
        'type'        => 'group',
        'classes' => 'afeature-content',
        'description' => __( 'Set affiliate feature section content', 'ordomain' ),
        'options'     => array(
            'group_title'   => __( 'Services Content {#}', 'ordomain' ), 
            'add_button'    => __( 'Add Service', 'ordomain' ),
            'remove_button' => __( 'Remove Service', 'ordomain' ),
            'closed'     => true, // true to have the groups closed by default
        ),
    ) );
    
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Title', 'ordomain' ),
        'id'   => $prefix. 'affiliateFeature_title',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Select Icon Type', 'ordomain' ),
        'id'   => $prefix. 'affiliateFeature_icon_type',
        'type' => 'radio_inline',
        'options' => array(
            'icon'  => 'Icon',
            'image' => 'Image Icon'
        ),
        'default' => 'icon',
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Icon', 'ordomain' ),
        'id'   => $prefix. 'affiliateFeature_icon',
        'type' => 'text',
        'desc' => sprintf( __('Use <a href="%s" target="_blank">Font Awesome</a> icon like( fa-bath ). If you don\'t like to use image as icon you can use Font Awesome icon.','ordomain'), 'http://fontawesome.io/icons/' )
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Image Icon', 'ordomain' ),
        'id'   => $prefix. 'affiliateFeature_imgicon',
        'type' => 'file'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Description', 'ordomain' ),
        'id'   => $prefix. 'affiliateFeature_description',
        'type' => 'textarea'
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'afeature_background',
        'classes' => 'afeature-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'afeature-bgcolor',
        'classes' => 'afeature-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'afeature_overlay',
        'classes' => 'afeature-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'afeature_overlaycolor',
        'classes' => 'afeature-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'afeature_overlayopacity',
        'classes' => 'afeature-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section title color', 'ordomain' ),
        'classes' => 'afeature-media',
		'id'   => $prefix . 'afeature_sectTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Sub Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section sub title color', 'ordomain' ),
        'classes' => 'afeature-media',
		'id'   => $prefix . 'afeature_subTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set title color', 'ordomain' ),
        'classes' => 'afeature-media',
		'id'   => $prefix . 'afeature_titlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'afeature-media',
		'id'   => $prefix . 'afeature_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Icon Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'afeature-media',
		'id'   => $prefix . 'afeature_Iconcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Number Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background number color', 'ordomain' ),
        'classes' => 'afeature-media',
		'id'   => $prefix . 'afeature_numcolor',
		'type' => 'colorpicker',
	) );
    
    // counter section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'counter_section',
        'title'        => __( 'Counter Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'counter_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'counter_subtitle',
        'classes' => 'counter-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'counter_secttitle',
        'classes' => 'counter-content',
        'type' => 'text',
    ) );
    

    // group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'counter_contents',
    'type'        => 'group',
    'classes' => 'counter-content',
    'description' => __( 'Set counter section content', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'Counter Content {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Counter', 'ordomain' ),
        'remove_button' => __( 'Remove Counter', 'ordomain' ),
        'closed'     => true, // true to have the groups closed by default
    ),
    ) );
    
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Counter Title', 'ordomain' ),
        'id'   => $prefix. 'counter_title',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Select Icon Type', 'ordomain' ),
        'id'   => $prefix. 'counter_icon_type',
        'type' => 'radio_inline',
        'options' => array(
            'icon'  => 'Icon',
            'image' => 'Image Icon'
        ),
        'default' => 'icon',
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Counter Icon', 'ordomain' ),
        'id'   => $prefix. 'counter_icon',
        'type' => 'text',
        'desc' => sprintf( __('Use <a href="%s" target="_blank">Font Awesome</a> icon like( fa-bath ). If you don\'t like to use image as icon you can use Font Awesome icon.','ordomain'), 'http://fontawesome.io/icons/' )
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Counter Image Icon', 'ordomain' ),
        'id'   => $prefix. 'counter_imgicon',
        'type' => 'file'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Counter Number', 'ordomain' ),
        'id'   => $prefix. 'counter_number',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'counter_background',
        'classes' => 'counter-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'counter-bgcolor',
        'classes' => 'counter-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'counter_overlay',
        'classes' => 'counter-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'counter_overlaycolor',
        'classes' => 'counter-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'counter_overlayopacity',
        'classes' => 'counter-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'counter-media',
		'id'   => $prefix . 'counter_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section title color', 'ordomain' ),
        'classes' => 'counter-media',
		'id'   => $prefix . 'counter_secttitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Icon Color', 'ordomain' ),
		'desc' => esc_html__( 'Set icon color', 'ordomain' ),
        'classes' => 'counter-media',
		'id'   => $prefix . 'counter_iconcolor',
		'type' => 'colorpicker',
	) );
    
    // testimonial section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'testimonial_section',
        'title'        => __( 'Testimonial Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'testimonial_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) );   
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'testimonial_subtitle',
        'classes' => 'testimonial-counter',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'testimonial_secttitle',
        'classes' => 'testimonial-counter',
        'type' => 'text',
    ) );
    
    // group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'testimonial_contents',
    'type'        => 'group',
    'description' => __( 'Set testimonial section content', 'ordomain' ),
    'classes' => 'testimonial-counter',
    'options'     => array(
        'group_title'   => __( 'Testimonial Content {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Testimonial', 'ordomain' ),
        'remove_button' => __( 'Remove Testimonial', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Name', 'ordomain' ),
        'id'   => $prefix. 'testimonial_name',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Company', 'ordomain' ),
        'id'   => $prefix. 'testimonial_company',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Picture', 'ordomain' ),
        'id'   => $prefix. 'testimonial_img',
        'type' => 'file'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Description', 'ordomain' ),
        'id'   => $prefix. 'testimonial_desc',
        'type' => 'textarea'
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'testimonial_background',
        'classes' => 'testimonial-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'testimonial-bgcolor',
        'classes' => 'testimonial-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'testimonial_overlay',
        'classes' => 'testimonial-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'testimonial_overlaycolor',
        'classes' => 'testimonial-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'testimonial_overlayopacity',
        'classes' => 'testimonial-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'testimonial-media',
		'id'   => $prefix . 'testimonial_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section title color', 'ordomain' ),
        'classes' => 'testimonial-media',
		'id'   => $prefix . 'testimonial_secttitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text two Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text two color', 'ordomain' ),
        'classes' => 'testimonial-media',
		'id'   => $prefix . 'testimonial_texttwocolor',
		'type' => 'colorpicker',
	) );
    
    
    
    // subscribe section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'subscribe_section',
        'title'        => __( 'Subscribe Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'subscribe_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'subscribe_secttitle',
        'classes' => 'subscribe-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'subscribe_background',
        'classes' => 'subscribe-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'subscribe-bgcolor',
        'classes' => 'subscribe-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'subscribe_overlay',
        'classes' => 'subscribe-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'subscribe_overlaycolor',
        'classes' => 'subscribe-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'subscribe_overlayopacity',
        'classes' => 'subscribe-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'subscribe-media',
		'id'   => $prefix . 'subscribe_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Button Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'subscribe-media',
		'id'   => $prefix . 'subscribe_btntextcolor',
		'type' => 'colorpicker',
	) );
    
    // Blog section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'blog_section',
        'title'        => __( 'Blog Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'blog_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'blog_subtitle',
        'classes' => 'blog-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'blog_secttitle',
        'classes' => 'blog-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'blog_background',
        'classes' => 'blog-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'blog-bgcolor',
        'classes' => 'blog-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'blog_overlay',
        'classes' => 'blog-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'blog_overlaycolor',
        'classes' => 'blog-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'blog_overlayopacity',
        'classes' => 'blog-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section text color', 'ordomain' ),
        'classes' => 'blog-media',
		'id'   => $prefix . 'blog_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set sub text color', 'ordomain' ),
        'classes' => 'blog-media',
		'id'   => $prefix . 'blog_subtitlecolor',
		'type' => 'colorpicker',
	) );
    
    
    // Home Page Domain checker section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'home-domain-checker_section',
        'title'        => __( 'Home Domain Checker Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'homeDomCheck_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'home_dom_check_subtitle',
        'classes' => 'homeDomCheck-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'home_dom_check_secttitle',
        'classes' => 'homeDomCheck-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'WHMCS URL', 'ordomain' ),
        'id'   => $prefix . 'home_domCheck_whmcsurl',
        'classes' => 'homeDomCheck-content',
        'type' => 'text',
    ) );
        
    // extension radio group field
    
    $ord_meta->add_field( array(
        'name' => __( 'Extension', 'ordomain' ),
        'id'   => $prefix. 'extension_radion',
        'classes' => 'homeDomCheck-content',
        'type' => 'text',
        'description' => 'Write extension without . like com, net etc. ',
        'repeatable' => true
    ) );
    
    // extension  radio group field end
    
    // extension slid group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'extension_slider',
    'type'        => 'group',
    'description' => __( 'Set extension slider', 'ordomain' ),
    'classes' => 'homeDomCheck-content',
    'options'     => array(
        'group_title'   => __( 'Extension {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Extension', 'ordomain' ),
        'remove_button' => __( 'Remove Extension', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Name', 'ordomain' ),
        'id'   => $prefix. 'extension_name',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Price', 'ordomain' ),
        'id'   => $prefix. 'extension_price',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Duration', 'ordomain' ),
        'id'   => $prefix. 'extension_duration',
        'type' => 'text'
    ) );
    // extension group field end
    
    $ord_meta->add_field( array(
        'name' => __( 'Features Title', 'ordomain' ),
        'id'   => $prefix . 'homeDomCheck_featureTitle',
        'classes' => 'homeDomCheck-content',
        'type' => 'text',
    ) );
    
    // Features group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'homeDomCheck_features',
    'type'        => 'group',
    'description' => __( 'Set Features', 'ordomain' ),
    'classes' => 'homeDomCheck-content',
    'options'     => array(
        'group_title'   => __( 'Features {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Feature', 'ordomain' ),
        'remove_button' => __( 'Remove Feature', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Name', 'ordomain' ),
        'id'   => $prefix. 'homeDomCheck_features_name',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Select Icon Type', 'ordomain' ),
        'id'   => $prefix. 'homeDomCheck_icon_type',
        'type' => 'radio_inline',
        'options' => array(
            'icon'  => 'Icon',
            'image' => 'Image Icon',
        ),
        'default' => 'icon',
        
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Icon', 'ordomain' ),
        'id'   => $prefix. 'homeDomCheck_features_icon',
        'type' => 'text',
        'desc' => sprintf( __('Use <a href="%s" target="_blank">Font Awesome</a> icon like( fa-bath ). If you don\'t like to use image as icon you can use Font Awesome icon.','ordomain'), 'http://fontawesome.io/icons/' )
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Image Icon', 'ordomain' ),
        'id'   => $prefix. 'homeDomCheck_features_imgicon',
        'type' => 'file',
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Description', 'ordomain' ),
        'id'   => $prefix. 'homeDomCheck_features_desc',
        'type' => 'text'
    ) );
    // Features group field end
    
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'home_dom_check_background',
        'classes' => 'homeDomCheck-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'homeDomCheck-bgcolor',
        'classes' => 'homeDomCheck-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'homeDomCheck_overlay',
        'classes' => 'homeDomCheck-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'homeDomCheck_overlaycolor',
        'classes' => 'homeDomCheck-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'homeDomCheck_overlayopacity',
        'classes' => 'homeDomCheck-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set title color', 'ordomain' ),
        'classes' => 'homeDomCheck-media',
		'id'   => $prefix . 'homeDomCheck_SectTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Featue Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set feature title color', 'ordomain' ),
        'classes' => 'homeDomCheck-media',
		'id'   => $prefix . 'homeDomCheck_FeatureTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'homeDomCheck-media',
		'id'   => $prefix . 'homeDomCheck_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Icon Color', 'ordomain' ),
		'desc' => esc_html__( 'Set icon color', 'ordomain' ),
        'classes' => 'homeDomCheck-media',
		'id'   => $prefix . 'homeDomCheck_Iconcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Extension Name Color', 'ordomain' ),
		'desc' => esc_html__( 'Set slide extension name color', 'ordomain' ),
        'classes' => 'homeDomCheck-media',
		'id'   => $prefix . 'homeDomCheck_extnamecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Extension Box Color', 'ordomain' ),
		'desc' => esc_html__( 'Set slide extension box background color', 'ordomain' ),
        'classes' => 'homeDomCheck-media',
		'id'   => $prefix . 'homeDomCheck_extboxcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Extension Price Color', 'ordomain' ),
		'desc' => esc_html__( 'Set slide extension orice color', 'ordomain' ),
        'classes' => 'homeDomCheck-media',
		'id'   => $prefix . 'homeDomCheck_extpricecolor',
		'type' => 'colorpicker',
	) );
    
    
    
    // Faq section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'faq_section',
        'title'        => __( 'FAQ Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'faq_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'faq_subtitle',
        'classes'    => 'faq-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'faq_secttitle',
        'classes'    => 'faq-content',
        'type' => 'text',
    ) );
        
    $ord_meta->add_field( array(
    'name'       => 'Faq Category',
    'desc'       => 'Set Faq category.',
    'classes'    => 'faq-content',
    'id'             => $prefix . 'faq_taxonoy',
    'type'           => 'select',
    // Use a callback to avoid performance hits on pages where this field is not displayed (including the front-end).
    'options_cb'     => 'ordomain_get_term_options',
    // Same arguments you would pass to `get_terms`.
    'get_terms_args' => array(
        'taxonomy'   => 'faq_categories',
        'hide_empty' => false,
        ),
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'faq_background',
        'classes' => 'faq-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'faq-bgcolor',
        'classes' => 'faq-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Border Color', 'ordomain' ),
		'desc' => esc_html__( 'Set border color', 'ordomain' ),
        'classes' => 'faq-media',
		'id'   => $prefix . 'faq_bordercolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'faq_overlay',
        'classes' => 'faq-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'faq_overlaycolor',
        'classes' => 'faq-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'faq_overlayopacity',
        'classes' => 'faq-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section text color', 'ordomain' ),
        'classes' => 'faq-media',
		'id'   => $prefix . 'faq_SectTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set sub text color', 'ordomain' ),
        'classes' => 'faq-media',
		'id'   => $prefix . 'faq_SubTitlecolor',
		'type' => 'colorpicker',
	) );
    
    // Extra Feature section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'extra-feature_section',
        'title'        => __( 'Extra Feature Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'extrafeature_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content'  => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'extrafeature_subtitle',
        'classes' => 'extrafeature-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'extrafeature_secttitle',
        'classes' => 'extrafeature-content',
        'type' => 'text',
    ) );
 
    $ord_meta->add_field( array(
        'name' => __( 'Feature Image', 'ordomain' ),
        'id'   => $prefix . 'extrafeature_image',
        'classes' => 'extrafeature-content',
        'type' => 'file',
    ) );
    
    // Feature group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'extrafeature_contents',
    'classes' => 'extrafeature-content',
    'type'        => 'group',
    'description' => __( 'Add Feature', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'Feature {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Feature', 'ordomain' ),
        'remove_button' => __( 'Remove Feature', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix. 'extfeature_title',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Description', 'ordomain' ),
        'id'   => $prefix. 'extfeature_desc',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Select Icon Type', 'ordomain' ),
        'id'   => $prefix. 'extfeature_icon_type',
        'type' => 'radio_inline',
        'options' => array(
            'icon'  => 'Icon',
            'image' => 'Image Icon'
        ),
        'default' => 'icon',
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Icon', 'ordomain' ),
        'id'   => $prefix. 'extfeature_icon',
        'type' => 'text',
        'desc' => sprintf( __('Use <a href="%s" target="_blank">Font Awesome</a> icon like( fa-bath ). If you don\'t like to use image as icon you can use Font Awesome icon.','ordomain'), 'http://fontawesome.io/icons/' )
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Image Icon', 'ordomain' ),
        'id'   => $prefix. 'extfeature_imgicon',
        'type' => 'file'
    ) );
    // extension group field end
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'extrafeature_background',
        'classes' => 'extrafeature-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'extrafeature-bgcolor',
        'classes' => 'extrafeature-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Border Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section border color', 'ordomain' ),
        'classes' => 'extrafeature-media',
		'id'   => $prefix . 'extrafeature_bordercolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'extrafeature_overlay',
        'classes' => 'extrafeature-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'extrafeature_overlaycolor',
        'classes' => 'extrafeature-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'extrafeature_overlayopacity',
        'classes' => 'extrafeature-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section text color', 'ordomain' ),
        'classes' => 'extrafeature-media',
		'id'   => $prefix . 'extrafeature_SectTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set sub title color', 'ordomain' ),
        'classes' => 'extrafeature-media',
		'id'   => $prefix . 'extrafeature_SubTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'extrafeature-media',
		'id'   => $prefix . 'extrafeature_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Icon Color', 'ordomain' ),
		'desc' => esc_html__( 'Set icon color', 'ordomain' ),
        'classes' => 'extrafeature-media',
		'id'   => $prefix . 'extrafeature_Iconcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Icon Border Color', 'ordomain' ),
		'desc' => esc_html__( 'Set icon border color', 'ordomain' ),
        'classes' => 'extrafeature-media',
		'id'   => $prefix . 'extrafeature_Iconbordcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Content Border Color', 'ordomain' ),
		'desc' => esc_html__( 'Set content border color', 'ordomain' ),
        'classes' => 'extrafeature-media',
		'id'   => $prefix . 'extrafeature_Contbordcolor',
		'type' => 'colorpicker',
	) );
    
    // Team section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'team_section',
        'title'        => __( 'Teams Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'team_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content' => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'team_subtitle',
        'classes' => 'team-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'team_secttitle',
        'classes' => 'team-content',
        'type' => 'text',
    ) );
    
    // Team group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'team_contents',
    'type'        => 'group',
    'classes' => 'team-content',
    'description' => __( 'Add Team', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'Team Member {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Team Member', 'ordomain' ),
        'remove_button' => __( 'Remove Team Member', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Member Name', 'ordomain' ),
        'id'   => $prefix. 'teamMmember_name',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Designation', 'ordomain' ),
        'id'   => $prefix. 'teamMember_designation',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Picture', 'ordomain' ),
        'id'   => $prefix. 'teamMember_pic',
        'type' => 'file'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Facebook URL', 'ordomain' ),
        'id'   => $prefix. 'teamMember_fb',
        'type' => 'text_url'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Twitter URL', 'ordomain' ),
        'id'   => $prefix. 'teamMember_twit',
        'type' => 'text_url'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Google Plus URL', 'ordomain' ),
        'id'   => $prefix. 'teamMember_gp',
        'type' => 'text_url'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Linkedin URL', 'ordomain' ),
        'id'   => $prefix. 'teamMember_lkd',
        'type' => 'text_url'
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'team_background',
        'classes' => 'team-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'team-bgcolor',
        'classes' => 'team-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Border Color', 'ordomain' ),
		'desc' => esc_html__( 'Set border color', 'ordomain' ),
        'classes' => 'team-media',
		'id'   => $prefix . 'team_bordColor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'team_overlay',
        'classes' => 'team-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'team_overlaycolor',
        'classes' => 'team-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'team_overlayopacity',
        'classes' => 'team-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section text color', 'ordomain' ),
        'classes' => 'team-media',
		'id'   => $prefix . 'team_SectTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set sub title color', 'ordomain' ),
        'classes' => 'team-media',
		'id'   => $prefix . 'team_SubTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'team-media',
		'id'   => $prefix . 'team_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Name Color', 'ordomain' ),
		'desc' => esc_html__( 'Set name color', 'ordomain' ),
        'classes' => 'team-media',
		'id'   => $prefix . 'team_Namecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Designation Color', 'ordomain' ),
		'desc' => esc_html__( 'Set Designation color', 'ordomain' ),
        'classes' => 'team-media',
		'id'   => $prefix . 'team_roleColor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Social Icon Color', 'ordomain' ),
		'desc' => esc_html__( 'Set social icon color', 'ordomain' ),
        'classes' => 'team-media',
		'id'   => $prefix . 'team_socIconcolor',
		'type' => 'colorpicker',
	) );
    
    
    // Team group field end
    
    
    // history section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'history_section',
        'title'        => __( 'History Section', 'ordomain' ),
        'priority'     => 'low',
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'history_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content' => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'history_subtitle',
        'classes' => 'history-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'history_secttitle',
        'classes' => 'history-content',
        'type' => 'text',
    ) );
        
    // History group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'history_contents',
    'type'        => 'group',
    'classes' => 'history-content',
    'description' => __( 'Add History Content', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'History {#}', 'ordomain' ), 
        'add_button'    => __( 'Add History', 'ordomain' ),
        'remove_button' => __( 'Remove History', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'History', 'ordomain' ),
        'id'   => $prefix. 'history_content',
        'type' => 'textarea',
        'desc' => 'Allow span,strong,br,a tag.',
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Year', 'ordomain' ),
        'id'   => $prefix. 'history_year',
        'type' => 'text'
    ) );

    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'history_background',
        'classes' => 'history-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'history-bgcolor',
        'classes' => 'history-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Time Line Color', 'ordomain' ),
		'desc' => esc_html__( 'Set time line color', 'ordomain' ),
        'classes' => 'history-media',
		'id'   => $prefix . 'history_timelineColor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'history_overlay',
        'classes' => 'history-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'history_overlaycolor',
        'classes' => 'history-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'history_overlayopacity',
        'classes' => 'history-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section text color', 'ordomain' ),
        'classes' => 'history-media',
		'id'   => $prefix . 'history_SectTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set sub title color', 'ordomain' ),
        'classes' => 'history-media',
		'id'   => $prefix . 'history_SubTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Year Color', 'ordomain' ),
		'desc' => esc_html__( 'Set year color', 'ordomain' ),
        'classes' => 'history-media',
		'id'   => $prefix . 'history_yearcolor',
		'type' => 'colorpicker',
	) );

    
    // History group field end
    
    // Affiliate pricing section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'affiliate-price_section',
        'title'        => __( 'Affiliate Pricing Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'affPricing_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content' => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'affPricing_subtitle',
        'classes' => 'affPricing-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'affPricing_secttitle',
        'classes' => 'affPricing-content',
        'type' => 'text',
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Button Text', 'ordomain' ),
        'id'   => $prefix . 'affPricing_btntext',
        'classes' => 'affPricing-content',
        'type' => 'text',
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Button URL', 'ordomain' ),
        'id'   => $prefix . 'affPricing_btnurl',
        'classes' => 'affPricing-content',
        'type' => 'text_url',
    ) );
        
    // Affiliate Price group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'affPricing_contents',
    'type'        => 'group',
    'classes' => 'affPricing-content',
    'description' => __( 'Add Affiliate Price', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'Price {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Price', 'ordomain' ),
        'remove_button' => __( 'Remove Price', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix. 'affPricing_title',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Price Tag', 'ordomain' ),
        'id'   => $prefix. 'affPricing_price_tag',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Price', 'ordomain' ),
        'id'   => $prefix. 'affPricing_price',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'affPricing_background',
        'classes' => 'affPricing-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'affPricing-bgcolor',
        'classes' => 'affPricing-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Border Color', 'ordomain' ),
		'desc' => esc_html__( 'Set border color', 'ordomain' ),
        'classes' => 'affPricing-media',
		'id'   => $prefix . 'affPricing_borderColor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'affPricing_overlay',
        'classes' => 'affPricing-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'affPricing_overlaycolor',
        'classes' => 'affPricing-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'affPricing_overlayopacity',
        'classes' => 'affPricing-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'affPricing-media',
		'id'   => $prefix . 'affPricing_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Button Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set Button text color', 'ordomain' ),
        'classes' => 'affPricing-media',
		'id'   => $prefix . 'affPricing_btntextcolor',
		'type' => 'colorpicker',
	) );
    
    // Affiliate Price group field end
    
    // Affiliate Counter section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'affiliate-counter_section',
        'title'        => __( 'Affiliate Counter Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'affcounter_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content' => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'affcounter_subtitle',
        'classes' => 'affcounter-counter',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'affcounter_secttitle',
        'classes' => 'affcounter-counter',
        'type' => 'text',
    ) );    
    
    // Affiliate Counter group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'affcounter_contents',
    'type'        => 'group',
    'classes' => 'affcounter-counter',
    'description' => __( 'Add Affiliate Counter', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'Counter {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Counter', 'ordomain' ),
        'remove_button' => __( 'Remove Counter', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix. 'affcounter_title',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Currency', 'ordomain' ),
        'id'   => $prefix. 'affcounter_curr',
        'type' => 'text'
    ) );     
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Number', 'ordomain' ),
        'id'   => $prefix. 'affcounter_number',
        'type' => 'text'
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'affcounter_background',
        'classes' => 'affcounter-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'affcounter-bgcolor',
        'classes' => 'affcounter-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'affcounter_overlay',
        'classes' => 'affcounter-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'affcounter_overlaycolor',
        'classes' => 'affcounter-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'affcounter_overlayopacity',
        'classes' => 'affcounter-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'affcounter-media',
		'id'   => $prefix . 'affcounter_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Divider Color', 'ordomain' ),
		'desc' => esc_html__( 'Set divider color', 'ordomain' ),
        'classes' => 'affcounter-media',
		'id'   => $prefix . 'affcounter_dividercolor',
		'type' => 'colorpicker',
	) );
    
    // Affiliate Counter group field end
    
    // Contact Action section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'affiliate-action_section',
        'title'        => __( 'Contact Action Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'contactAction_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content' => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'contactAction_subtitle',
        'classes' => 'contactAction-content',
        'type' => 'text',
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix . 'contactAction_secttitle',
        'classes' => 'contactAction-content',
        'type' => 'text',
    ) );    
    
    // Contact Action group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'contactAction_contents',
    'type'        => 'group',
    'classes' => 'contactAction-content',
    'description' => __( 'Add Contact Action Counter', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'Contact {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Contact', 'ordomain' ),
        'remove_button' => __( 'Remove Contact', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Select Icon Type', 'ordomain' ),
        'id'   => $prefix. 'contactAction_icon_type',
        'type' => 'radio_inline',
        'options' => array(
            'icon'  => 'Icon',
            'image' => 'Image Icon'
        ),
        'default' => 'icon',
    ) );      
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Icon', 'ordomain' ),
        'id'   => $prefix. 'contactAction_icon',
        'type' => 'text',
        'desc' => sprintf( __('Use <a href="%s" target="_blank">Font Awesome</a> icon like( fa-bath ). If you don\'t like to use image as icon you can use Font Awesome icon.','ordomain'), 'http://fontawesome.io/icons/' )
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Image Icon', 'ordomain' ),
        'id'   => $prefix. 'contactAction_imgicon',
        'type' => 'file'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix. 'contactAction_title',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Description', 'ordomain' ),
        'id'   => $prefix. 'contactAction_desc',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Button Text', 'ordomain' ),
        'id'   => $prefix. 'contactAction_btntext',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Button URL', 'ordomain' ),
        'id'   => $prefix. 'contactAction_btnurl',
        'type' => 'text_url'
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'contactAction_background',
        'classes' => 'contactAction-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'contactAction-bgcolor',
        'classes' => 'contactAction-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'contactAction_overlay',
        'classes' => 'contactAction-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'contactAction_overlaycolor',
        'classes' => 'contactAction-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'contactAction_overlayopacity',
        'classes' => 'contactAction-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color', 'ordomain' ),
        'classes' => 'contactAction-media',
		'id'   => $prefix . 'contactAction_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section title color', 'ordomain' ),
        'classes' => 'contactAction-media',
		'id'   => $prefix . 'contactAction_SectTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section sub title color', 'ordomain' ),
        'classes' => 'contactAction-media',
		'id'   => $prefix . 'contactAction_SubTitlecolor',
		'type' => 'colorpicker',
	) );

    // Contact Action group field end
    
    // Hosting Pricing Table section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'hosting-price_section',
        'title'        => __( 'Hosting Pricing Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'hosting_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content' => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix . 'hosting_secttitle',
        'classes' => 'hosting-content',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'hosting_sectsubtitle',
        'classes' => 'hosting-content',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Column Set', 'ordomain' ),
        'id'   => $prefix . 'pricing_col',
        'classes' => 'hosting-content',
        'type' => 'select',
        'options' => array(
            '4' => 'column 3',
            '3' => 'column 4'
        )
    ) );
    
    $ord_meta->add_field( array(
    'name'       => 'Hosting Category',
    'desc'           => 'Set hosting table category.',
    'id'             => $prefix . 'hosting_taxonoy',
    'classes' => 'hosting-content',
    'type'           => 'select',
    // Use a callback to avoid performance hits on pages where this field is not displayed (including the front-end).
    'options_cb'     => 'ordomain_get_term_options',
    // Same arguments you would pass to `get_terms`.
    'get_terms_args' => array(
        'taxonomy'   => 'hosting_categories',
        'hide_empty' => false,
        ),
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'hosting_bg',
        'classes' => 'hosting-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'hosting-bgcolor',
        'classes' => 'hosting-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'hosting_overlay',
        'classes' => 'hosting-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'hosting_overlaycolor',
        'classes' => 'hosting-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'hosting_overlayopacity',
        'classes' => 'hosting-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section title color', 'ordomain' ),
        'classes' => 'hosting-media',
		'id'   => $prefix . 'hosting_sectTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section subtitle color', 'ordomain' ),
        'classes' => 'hosting-media',
		'id'   => $prefix . 'hosting_subtitlecolor',
		'type' => 'colorpicker',
	) );
    
    
    // Domain Pricing Table section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'domain-price_section',
        'title'        => __( 'Domain Pricing Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'domain_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content' => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix . 'domain_secttitle',
        'classes' => 'domain-content',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'domain_sectsubtitle',
        'classes' => 'domain-content',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
    'name'       => 'Domain Category',
    'desc'           => 'Set domain table category.',
    'classes' => 'domain-content',
    'id'             => $prefix . 'domain_taxonoy',
    'type'           => 'select',
    // Use a callback to avoid performance hits on pages where this field is not displayed (including the front-end).
    'options_cb'     => 'ordomain_get_term_options',
    // Same arguments you would pass to `get_terms`.
    'get_terms_args' => array(
        'taxonomy'   => 'domain_categories',
        'hide_empty' => false,
        ),
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'domain_bg',
        'classes' => 'domain-media',
        'type' => 'file',
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'domain-bgcolor',
        'classes' => 'domain-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'domain_overlay',
        'classes' => 'domain-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'domain_overlaycolor',
        'classes' => 'domain-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'domain_overlayopacity',
        'classes' => 'domain-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section title color', 'ordomain' ),
        'classes' => 'domain-media',
		'id'   => $prefix . 'domain_sectTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section subtitle color', 'ordomain' ),
        'classes' => 'domain-media',
		'id'   => $prefix . 'domain_subtitlecolor',
		'type' => 'colorpicker',
	) );
    
    
    // Dedicate Pricing Table section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'dedicate-price_section',
        'title'        => __( 'Dedicate Pricing Section', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'dedicate_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content' => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix . 'dedicate_secttitle',
        'classes' => 'dedicate-count',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'dedicate_sectsubtitle',
        'classes' => 'dedicate-count',
        'type' => 'text'
    ) );
        
    $ord_meta->add_field( array(
    'name'       => 'Dedicate Category',
    'desc'           => 'Set dedicate table category.',
    'id'             => $prefix . 'dedicate_taxonoy',
    'type'           => 'select',
    // Use a callback to avoid performance hits on pages where this field is not displayed (including the front-end).
    'options_cb'     => 'ordomain_get_term_options',
    // Same arguments you would pass to `get_terms`.
    'get_terms_args' => array(
        'taxonomy'   => 'dedicate_categories',
        'hide_empty' => false,
        ),
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'dedicate_bg',
        'classes' => 'dedicate-media',
        'type' => 'file'
    ) ); 
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color', 'ordomain' ),
		'id'   => $prefix . 'dedicate-bgcolor',
        'classes' => 'dedicate-media',
		'type' => 'colorpicker',
	) ); 
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Border Color', 'ordomain' ),
		'desc' => esc_html__( 'Set border color', 'ordomain' ),
		'id'   => $prefix . 'dedicate-bordcolor',
        'classes' => 'dedicate-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'dedicate_overlay',
        'classes' => 'dedicate-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'dedicate_overlaycolor',
        'classes' => 'dedicate-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'dedicate_overlayopacity',
        'classes' => 'dedicate-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Section Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section title color', 'ordomain' ),
        'classes' => 'dedicate-media',
		'id'   => $prefix . 'dedicate_sectTitlecolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Sub Title Color', 'ordomain' ),
		'desc' => esc_html__( 'Set section subtitle color', 'ordomain' ),
        'classes' => 'dedicate-media',
		'id'   => $prefix . 'dedicate_subtitlecolor',
		'type' => 'colorpicker',
	) );    
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set table head text and button text color.', 'ordomain' ),
        'classes' => 'dedicate-media',
		'id'   => $prefix . 'dedicate_textcolor',
		'type' => 'colorpicker',
	) );    
    
    // Domain and Hosting Feature section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'domain-and-hosting-feature_section',
        'title'        => __( 'Hosting Features', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    
    // group table fields 
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'dnh_features_tables',
    'type'        => 'group',
    'description' => __( 'Add table section and set content', 'ordomain' ),
    'repeatable'  => true,
    'options'     => array(
        'group_title'   => __( 'Table Section {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Table', 'ordomain' ),
        'remove_button' => __( 'Remove Table', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name'             => __( 'Select Table Style', 'ordomain' ),
        'desc'             => __( 'field description (optional)', 'ordomain' ),
        'id'               => $prefix . 'dnh_table_style',
        'type'             => 'radio_image',
        'options'          => array(
            'style-one'    => __('Style one', 'ordomain'),
            'style-two'    => __('Style Two', 'ordomain'),
            'style-three'  => __('Style Three', 'ordomain'),
        ),
        'images_path'      => get_template_directory_uri(),
        'images'           => array(
            'style-one'    => 'img/Screenshot_1.png',
            'style-two'    => 'img/Screenshot_2.png',
            'style-three'  => 'img/Screenshot_3.png',
        )
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name'      => __( 'Background Color', 'ordomain' ),
        'id'        => $prefix. 'bg_color',
        'type'      => 'select',
        'options'   => array(
            'none' => 'None',
            'bg-whit' => 'White',
            'bg-whitesmoke' => 'White Smoke'
        )
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Section Title', 'ordomain' ),
        'id'   => $prefix. 'dnh_title',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Section Sub Title', 'ordomain' ),
        'id'   => $prefix. 'dnh_subtitle',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Top Title Active', 'ordomain' ),
        'id'   => $prefix. 'dnh_topTitleactive',
        'desc' => 'If you want to show top title desktop and mobile version keep checked. If you want to show only mobile version keep unchecked.',
        'type' => 'checkbox'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name'      => __( 'Set Column', 'ordomain' ),
        'id'        => $prefix. 'dnh_col',
        'type'      => 'select',
        'options'   => array(
            '2' => 'Column 2',
            '3' => 'Column 3',
            '4' => 'Column 4'
        )
    ) );
    //1
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature One', 'ordomain' ),
        'id'   => $prefix. 'dnh_section_divaider1',
        'classes' => 'dnh_divaider',
        'desc' => 'Set Domain or Hosting Table Number One',
        'type' => 'title',
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Left Title', 'ordomain' ),
        'id'   => $prefix. 'dnh_featurelefttitle',
        'desc' => 'If you want to use feature one as feature left title check on. ',
        'type' => 'checkbox'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Top Title', 'ordomain' ),
        'id'   => $prefix. 'dnh_topTitle1',
        'type' => 'text_small'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Add Feature', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_1',
        'type' => 'text',
        'repeatable' => true
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature One Button', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_1_btn',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature One Button URL', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_1btnurl',
        'type' => 'text_url'
    ) );
    
    //2
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Two', 'ordomain' ),
        'id'   => $prefix. 'dnh_section_divaider2',
        'desc' => 'Set Domain or Hosting Table Number Two',
        'classes' => 'dnh_divaider',
        'type' => 'title',
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Top Title', 'ordomain' ),
        'id'   => $prefix. 'dnh_topTitle2',
        'type' => 'text_small'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Add Feature', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_2',
        'type' => 'text',
        'repeatable' => true
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Two Button', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_2_btn',
        'type' => 'text'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Two Button URL', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_2btnurl',
        'type' => 'text_url'
    ) );
    
    // 3
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Three', 'ordomain' ),
        'id'   => $prefix. 'dnh_section_divaider3',
        'desc' => 'Set Domain or Hosting Table Number Three',
        'classes' => 'dnh_divaider',
        'type' => 'title',
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Top Title', 'ordomain' ),
        'id'   => $prefix. 'dnh_topTitle3',
        'type' => 'text_small'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Add Feature', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_3',
        'type' => 'text',
        'repeatable' => true
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Three Button', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_3_btn',
        'type' => 'text'
    ) );

    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Three Button URL', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_3btnurl',
        'type' => 'text_url'
    ) );
    
    // 4
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Four', 'ordomain' ),
        'id'   => $prefix. 'dnh_section_divaider4',
        'desc' => 'Set Domain or Hosting Table Number Three',
        'classes' => 'dnh_divaider',
        'type' => 'title',
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Top Title', 'ordomain' ),
        'id'   => $prefix. 'dnh_topTitle4',
        'type' => 'text_small'
    ) );
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Add Feature', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_4',
        'type' => 'text',
        'repeatable' => true
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Three Button', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_4_btn',
        'type' => 'text'
    ) );

    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature Three Button URL', 'ordomain' ),
        'id'   => $prefix. 'dnh_feature_4btnurl',
        'type' => 'text_url'
    ) );
    
    // Bulk Domain Checker section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'bulkdomainchecker_section',
        'title'        => __( 'Bulk Domain Ckecker', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'bulkdomainchecker_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content' => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'bulk_domain_subtitle',
        'classes' => 'bulkdom-content',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix . 'bulk_domain_title',
        'classes' => 'bulkdom-content',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Description', 'ordomain' ),
        'id'   => $prefix . 'bulk_domain_description',
        'classes' => 'bulkdom-content',
        'type' => 'textarea'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Add Ribbon', 'ordomain' ),
        'id'   => $prefix . 'bulk_domain_ribbon',
        'classes' => 'bulkdom-content',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'WHMCS URL', 'ordomain' ),
        'id'   => $prefix . 'BulkDomCheck_whmcsurl',
        'classes' => 'bulkdom-content',
        'type' => 'text'
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Add Extension', 'ordomain' ),
        'id'   => $prefix . 'bulk_domain_extesion',
        'classes' => 'bulkdom-content',
        'type' => 'text',
        'repeatable' => true
    ) );
    $ord_meta->add_field( array(
        'name' => __( 'Background', 'ordomain' ),
        'id'   => $prefix . 'bulk_domain_bg',
        'classes' => 'bulkdom-media',
        'type' => 'file'
    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color.', 'ordomain' ),
		'id'   => $prefix . 'bulkdom-bgcolor',
        'classes' => 'bulkdom-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay', 'ordomain' ),
		'id'   => $prefix . 'bulkdom_overlay',
        'classes' => 'bulkdom-media',
		'type' => 'checkbox',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Color', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay color', 'ordomain' ),
		'id'   => $prefix . 'bulkdom_overlaycolor',
        'classes' => 'bulkdom-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Overlay Opacity', 'ordomain' ),
		'desc' => esc_html__( 'Set overlay opacity', 'ordomain' ),
		'id'   => $prefix . 'bulkdom_overlayopacity',
        'classes' => 'bulkdom-media',
		'type' => 'text_small',
        'desc' => esc_html__( 'Default opacity 0.5', 'ordomain' ),
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Content Box Color', 'ordomain' ),
		'desc' => esc_html__( 'Set content box background color.', 'ordomain' ),
        'classes' => 'bulkdom-media',
		'id'   => $prefix . 'bulkdom_cboxbgcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color.', 'ordomain' ),
        'classes' => 'bulkdom-media',
		'id'   => $prefix . 'bulkdom_cboxTextcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Ribbon Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set ribbon text color.', 'ordomain' ),
        'classes' => 'bulkdom-media',
		'id'   => $prefix . 'bulkdom_ribTextcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Search Button Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set search button text color.', 'ordomain' ),
        'classes' => 'bulkdom-media',
		'id'   => $prefix . 'bulkdom_searchbtnTextcolor',
		'type' => 'colorpicker',
	) );
    
    // Domain Extension slide 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'domain-extension_section',
        'title'        => __( 'Domain Extension Slider', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Choice Settings Option', 'ordomain' ),
		'id'   => $prefix . 'domextslid_setoption',
		'type' => 'radio_inline',
        'options'    => array(
			'content' => esc_html__( 'Content', 'ordomain' ),
			'media'   => esc_html__( 'Media', 'ordomain' )
		),
        'default' => 'content'
	) ); 
    // extension slid group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'domain_extension_slider',
    'type'        => 'group',
    'classes' => 'domExtSlid-content',
    'description' => __( 'Set extension slider', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'Extension {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Extension', 'ordomain' ),
        'remove_button' => __( 'Remove Extension', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Name', 'ordomain' ),
        'id'   => $prefix. 'domain_extension_name',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Price', 'ordomain' ),
        'id'   => $prefix. 'domain_extension_price',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Duration', 'ordomain' ),
        'id'   => $prefix. 'domain_extension_duration',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set background color.', 'ordomain' ),
		'id'   => $prefix . 'domExtSlid-bgcolor',
        'classes' => 'domExtSlid-media',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set text color.', 'ordomain' ),
        'classes' => 'domExtSlid-media',
		'id'   => $prefix . 'domExtSlid_textcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Price box background Color', 'ordomain' ),
		'desc' => esc_html__( 'Set price box background color.', 'ordomain' ),
        'classes' => 'domExtSlid-media',
		'id'   => $prefix . 'domExtSlid_pboxbgcolor',
		'type' => 'colorpicker',
	) );
    $ord_meta->add_field( array(
		'name' => esc_html__( 'Price box text Color', 'ordomain' ),
		'desc' => esc_html__( 'Set price box text color.', 'ordomain' ),
        'classes' => 'domExtSlid-media',
		'id'   => $prefix . 'domExtSlid_pboxTextcolor',
		'type' => 'colorpicker',
	) );
    
    
    // extension group field end
    
    // Pricing Tab Slide 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefix . 'pricing-tab_section',
        'title'        => __( 'Pricing Tab', 'ordomain' ),
        'object_types' => array( 'page' ),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-custom.php' ),
        'closed'       => true

    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'pricingTab_subTitle',
        'type' => 'text'
    ) ); 
	$ord_meta->add_field( array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix . 'pricingTab_title',
        'type' => 'text'
    ) );
    $ord_meta->add_field(  array(
		'name'    => 'Pricing Tab Category',
		'id'      => $prefix.'pricingTab_cat',
		'type'    => 'multicheck',
		'options' => 'ordomain_get_term_options',
		'get_terms_args' => array(
			'taxonomy'   => 'hosting_categories',
			'hide_empty' => false,
			),
	) );
    
    /***********************
        post type meta
    ***********************/ 
    
    // Doamin pricing meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefixtype . 'doamin_pricing',
        'title'        => __( 'Doamin Pricing Table Setting', 'ordomain' ),
        'object_types' => array( 'domain_pricing' ),
        //'closed'       => true

    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Set Table Heading', 'ordomain' ),
        'id'   => $prefix . 'doaminpricing_heading',
        'type' => 'text',
        'repeatable' => true
    ) );
    
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'doaminpricing_features',
    'type'        => 'group',
    'description' => __( 'Add doamin pricing table features ', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'Feature Table {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Feature', 'ordomain' ),
        'remove_button' => __( 'Remove Feature', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature', 'ordomain' ),
        'id'   => $prefix. 'dompritbl_Feature',
        'type' => 'text',
        'repeatable' => true
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Button Text', 'ordomain' ),
        'id'   => $prefix. 'dompritbl_btnText',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Button URL', 'ordomain' ),
        'id'   => $prefix. 'dompritbl_btnUrl',
        'type' => 'text'
    ) );
    
    // Dedicate pricing meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefixtype . 'dedicate_pricing',
        'title'        => __( 'Dedicate Pricing Table Setting', 'ordomain' ),
        'object_types' => array( 'dedicate_pricing' ),
        //'closed'       => true

    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Set Table Heading', 'ordomain' ),
        'id'   => $prefix . 'dedicate_heading',
        'type' => 'text',
        'repeatable' => true
    ) );
    
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'dedicate_features',
    'type'        => 'group',
    'description' => __( 'Add dedicate pricing table features ', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'Feature Table {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Feature', 'ordomain' ),
        'remove_button' => __( 'Remove Feature', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature', 'ordomain' ),
        'id'   => $prefix. 'dedpritbl_Feature',
        'type' => 'text',
        'repeatable' => true
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Button Text', 'ordomain' ),
        'id'   => $prefix. 'dedpritbl_btnText',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Button URL', 'ordomain' ),
        'id'   => $prefix. 'dedpritbl_btnUrl',
        'type' => 'text'
    ) );
    
    // Faq post type meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefixtype . 'faq',
        'title'        => __( 'FAQ', 'ordomain' ),
        'object_types' => array( 'faq' ),
        //'closed'       => true

    ) );
    
    // FAQ group field
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'faq_contents',
    'type'        => 'group',
    'description' => __( 'Add Faq', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'Faq {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Faq', 'ordomain' ),
        'remove_button' => __( 'Remove Faq', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix. 'faq_title',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Description', 'ordomain' ),
        'id'   => $prefix. 'faq_desc',
        'type' => 'textarea',
        'desc' => 'Allow span, strong, br, a tag.',
    ) );
    // faq group field end
    
    // Hosting pricing table vartical meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefixtype . 'hostingvart_pricing',
        'title'        => __( 'Vartical Hosting Price Table Setting', 'ordomain' ),
        'object_types' => array( 'hosting_price' ),
        //'closed'       => true

    ) );
        
    $group_field_id = $ord_meta->add_field( array(
    'id'          => $prefix .'hostingvart_features',
    'type'        => 'group',
    'description' => __( 'Add doamin pricing table features ', 'ordomain' ),
    'options'     => array(
        'group_title'   => __( 'Feature Table {#}', 'ordomain' ), 
        'add_button'    => __( 'Add Feature', 'ordomain' ),
        'remove_button' => __( 'Remove Feature', 'ordomain' ),
        'closed'        => true, // true to have the groups closed by default
    ),
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Title', 'ordomain' ),
        'id'   => $prefix . 'hostingvart_title',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Description', 'ordomain' ),
        'id'   => $prefix . 'hostingvart_desc',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Sub Title', 'ordomain' ),
        'id'   => $prefix . 'hostingvart_subtitle',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Price', 'ordomain' ),
        'id'   => $prefix . 'hostingvart_price',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Time Period', 'ordomain' ),
        'id'   => $prefix . 'hostingvart_period',
        'type' => 'select',
        'options' => array(
                '/day' => '/day',
                '/mo' => '/mo',
                '/yr' => '/yr'
        )
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Button Text', 'ordomain' ),
        'id'   => $prefix . 'hostingvart_btntxt',
        'type' => 'text'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Button URL', 'ordomain' ),
        'id'   => $prefix . 'hostingvart_url',
        'type' => 'text_url'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Ribbon', 'ordomain' ),
        'id'   => $prefix . 'hostingvart_ribbon',
        'type' => 'checkbox'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Active', 'ordomain' ),
        'id'   => $prefix . 'hostingvart_active',
        'type' => 'checkbox'
    ) );
    
    $ord_meta->add_group_field( $group_field_id, array(
        'name' => __( 'Feature', 'ordomain' ),
        'id'   => $prefix. 'hostingvart_feature',
        'type' => 'text',
        'repeatable' => true
    ) );
    
    // vpspricing section meta 
    $ord_meta = new_cmb2_box( array(
        'id'           => $prefixtype . 'page_vpspricing_meta',
        'title'        => __( 'Vps Pricing Setting', 'ordomain' ),
        'object_types' => array( 'vpsslide' ),
        'closed'       => false

    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Content', 'ordomain' ),
        'id'   => $prefix . 'vpspricing_content',
        'type' => 'text',
        'repeatable' => true
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Price', 'ordomain' ),
        'id'   => $prefix . 'vpspricing_price',
        'type' => 'text'
    ) );
    
    $ord_meta->add_field( array(
        'name' => __( 'Buy Now Button URL', 'ordomain' ),
        'id'   => $prefix . 'vpspricing_buy_url',
        'type' => 'text'
    ) );
     
}
