<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "ordomain_opt";

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    $sampleHTML = '';
    if ( file_exists( get_template_directory() . '/info-html.html' ) ) {
        Redux_Functions::initWpFilesystem();

        global $wp_filesystem;

        $sampleHTML = $wp_filesystem->get_contents( get_template_directory(). '/info-html.html' );
    }


    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'OrDomain Options', 'ordomain' ),
        'page_title'           => esc_html__( 'OrDomain Options', 'ordomain' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */


    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'ordomain' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'ordomain' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'ordomain' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'ordomain' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'ordomain' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */
     
    // Themelooks customize Fields

    // -> START General Fields

    Redux::setSection( $opt_name, array(
        'title'            => __( 'General', 'ordomain' ),
        'id'               => 'ord_general',
        'customizer_width' => '450px',
        'icon'             => 'el el-cog',
        'fields'           => array(
            
            array(
                'id'       => 'ord_display_preloader',
                'type'     => 'switch',
                'title'    => __( 'Display Preloader', 'ordomain' ),
                'subtitle' => __( 'Switch On to Display Preloader', 'ordomain' ),
                'default'  => true,
            ),
            array(
                'id'       => 'ord_enable_breadcrumb',
                'type'     => 'switch',
                'title'    => __( 'Page breadcrumb hide', 'ordomain' ),
                'subtitle' => __( 'Hide breadcrumb from page header.', 'ordomain' ),
                'default'  => '1',
            ),
            array(
                'id'       => 'ord_login_url',
                'type'     => 'text',
                'title'    => __( 'Login URL', 'ordomain' ),
                'subtitle' => __( 'set login url', 'ordomain' ),
                'default'  => '#',
            ),
            array(
                'id'       => 'ord_signup_url',
                'type'     => 'text',
                'title'    => __( 'Signup URL', 'ordomain' ),
                'subtitle' => __( 'set signup url', 'ordomain' ),
                'default'  => '#',
            ),
            array(
                'id'          => 'ord_ordomain_body_fonts',
                'type'        => 'typography', 
                'title'       => __('Body Typography', 'ordomain'),
                'google'      => true, 
                'font-backup' => true,
                'output'      => array( 'body', 'p' ),
                'units'       =>'px',
                'subtitle'    => __('Typography option with each property can be called individually.', 'ordomain'),
                'text-align'  => false,
                'line-height' => false,
                'font-backup' => false,
                'color'       => false,
                'font-size'   => false,
                'subsets'     => false,
                'line-height' => false,
                'default'     => array(
                    'font-family' => 'Roboto', 
                    'google'      => true,
                ),
            ),
            array(
                'id'          => 'ord_ordomain_header_fonts',
                'type'        => 'typography', 
                'title'       => __('Heading Typography', 'ordomain'),
                'google'      => true, 
                'font-backup' => true,
                'output'      => array('h1', 'h2', 'h3', 'h4', 'h5', 'h6', '.whmcs-template-five h1', '.whmcs-template-five h2', '.whmcs-template-five h3', '.whmcs-template-five h4', '.whmcs-template-five h5', '.whmcs-template-five h6' ),
                'units'       => 'px',
                'subtitle'    => __('Typography option with each property can be called individually.', 'ordomain'),
                'text-align'  => false,
                'line-height' => false,
                'font-backup' => false,
                'color'       => false,
                'font-size'   => false,
                'subsets'     => false,
                'line-height' => false,
                'default'     => array(
                    'font-family' => 'Roboto', 
                    'google'      => true,

                ),
            ),

            array(
                'id'       => 'unlimited-color',
                'type'     => 'color',
                'title'    => __('Custom Theme Color', 'ordomain'), 
                'subtitle' => __('Pick a unlimited mian color for the theme (default: #8bc34a).', 'ordomain'),
                'default'  => '#8bc34a',
                'validate' => 'color'
            ),
            array(
                'id'       => 'unlimited-btn-color',
                'type'     => 'color',
                'title'    => __('Secondary Color', 'ordomain'), 
                'subtitle' => __('Pick a unlimited secondary color for the theme hover, link etc (default: #73aa33).', 'ordomain'),
                'default'  => '#73aa33',
                'validate' => 'color'
            ),
         
        )
    ) );
    
    /* End General Fields */


    // -> START Header

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Header', 'ordomain'),
        'id'         => 'ord_header_option',
        'icon'       => 'el el-credit-card',
        'fields'     => array(      

            array(
                'id'       => 'ord_site_logo',
                'type'     => 'media',
                'url'      => true,
                'title'    => __( 'Logo', 'ordomain' ),
                'compiler' => 'true',
                'subtitle' => __( 'Upload your site logo for header Version one (recommendation png format).', 'ordomain' ),
            ),
            array(
                'id'       => 'ord_site_retinalogo',
                'type'     => 'media',
                'url'      => true,
                'title'    => __( 'Retina Version Logo', 'ordomain' ),
                'compiler' => 'true',
                'subtitle' => __( 'Upload your site logo retina version.', 'ordomain' ),
            ),
            array(
                'id'       => 'ord_site_logo_dimensions',
                'type'     => 'dimensions',
                'output'   => array( '#navigation a.navbar-brand' ),
                'units'    => array('em','px','%'),
                'title'    => __('Logo Height', 'ordomain'),
                'subtitle' => __('Set wraper logo height.', 'ordomain'),
                'width'    => false,
            ),
            array(
                'id'             => 'ord_menu_dimensions',
                'type'           => 'spacing',
                'output'         => array('#navigation .navbar .nav > li > a', '#navigation .navbar-toggle'),
                'mode'           => 'padding',
                'units'          => array('em', 'px'),
                'units_extended' => 'false',
                'title'          => __('Menu Links Padding ( top/bottom )', 'ordomain'),
                'subtitle'       => __('Set menu links top/bottom padding.', 'ordomain'),
                'left'           => false,
                'right'          => false,
                'default'            => array(
                    'padding-top'     => '31px',
                    'padding-bottom'  => '24px',
                    'units'           => 'px' 
                )
            ),
            array(
                'id'       => 'ord_site_title',
                'type'     => 'text',
                'validate' => 'html',
                'title'    => __( 'Text Logo', 'ordomain' ),
                'subtitle' => __( 'Write your logo text use as logo ( You can use span tag for text color).', 'ordomain' ),
                'default'  => __( '<span><i class="fa fa-globe"></i> Or</span>Domain','ordomain' ),
            ),
            array(
                'id'       => 'ord_header_tel',
                'type'     => 'text',
                'title'    => __( 'Phone Number', 'ordomain' ),
                'subtitle' => __( 'Set phone number', 'ordomain' ),
                'default'  =>'+4440000000',
            ),
            array(
                'id'       => 'ord_header_email',
                'type'     => 'text',
                'title'    => __( 'Email', 'ordomain' ),
                'subtitle' => __( 'Set email', 'ordomain' ),
                'default'  => 'example@example.com',
            ),
            array(
                'id'       => 'ord_allHeader_bg',
                'type'     => 'media',
                'title'    => __( 'Common Header Background', 'ordomain' ),
                'subtitle' => __( 'Set common header background', 'ordomain' ),
            ),
            array(
                'id'       => 'ord_allHeader_overlay',
                'type'     => 'checkbox',
                'title'    => __( 'Overlay', 'ordomain' ),
                'subtitle' => __( 'Set common page header ovelay', 'ordomain' ),
            ), 
            array(
                'id'       => 'ord_allHeader_overlaycolor',
                'type'     => 'background',
                'title'    => __( 'Overlay Color', 'ordomain' ),
                'subtitle' => __( 'Set common header overlay color', 'ordomain' ),
                'default'  => array(
                    'background-color' => '#ffffff',
                ),
                'background-repeat' => false,
                'background-attachment' => false,
                'background-position' => false,
                'background-image' => false,
                'background-size' => false,
            ), 
            
            array(
                'id' => 'ord_allHeader_overlayopacity',
                'type' => 'slider',
                'title' => __('Overlay Opacity', 'ordomain'),
                'subtitle' => __('Set overlay opacity', 'ordomain'),
                "default" => .5,
                "min" => 0,
                "step" => .1,
                "max" => 1,
                'resolution' => 0.1,
                'display_value' => 'text'
            ),           
            array(
                'id'       => 'ord_header_topmenu',
                'type'     => 'background',
                'output'   => array('.contact-bar'),
                'title'    => __( 'Header Top Background', 'ordomain' ),
                'subtitle' => __( 'Sticky change menu background color', 'ordomain' ),
                'default'  => array(
                    'background-color' => '#ffffff',
                ),
                'background-repeat' => false,
                'background-attachment' => false,
                'background-position' => false,
                'background-image' => false,
                'background-size' => false,
            ),            
            array(
                    'id'       => 'ord_header_topmenulinkcolor',
                    'type'     => 'link_color',
                    'output'   => array( '.contact-bar a', '.contact-bar .social-icons .nav li a' ),
                    'title'    => __('Header Top Link Color', 'ordomain'),
                    'subtitle' => __('Set top header menu link and hover color.', 'ordomain'),
                    'active' => false,
                    'visited'   => false,
                    'default'  => array(
                        'regular'  => '#303030', // blue
                        'hover'    => '#8bc34a', // red
                    )
                ),            
            array(
                'id'       => 'ord_header_menu',
                'type'     => 'background',
                'output'   => array('#navigation .navbar'),
                'title'    => __( 'Menu Background', 'ordomain' ),
                'subtitle' => __( 'Sticky change menu background color', 'ordomain' ),
                'default'  => array(
                    'background-color' => '#ffffff',
                ),
                'background-repeat' => false,
                'background-attachment' => false,
                'background-position' => false,
                'background-image' => false,
                'background-size' => false,
            ), 
            array(
                    'id'       => 'ord_header_menulinkcolor',
                    'type'     => 'link_color',
                    'output'   => array( '#navigation .navbar .nav li a' ),
                    'title'    => __('Menu Links color', 'ordomain'),
                    'subtitle' => __('Set header menu link and hover color.', 'ordomain'),
                    'active'   => false,
                    'visited'  => false,
                    'default'  => array(
                        'regular'  => '#303030', // blue
                        'hover'    => '#8bc34a', // red
                    )
                ),               
            
        ),

    ) );
    
    /* End Header */
                
        
    /*
     *   Vps Pricing section options
     */
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'VPS Pricing', 'ordomain' ),
        'id'         => 'ord_vpspricing',
        'icon'       => 'el el-idea',
        'fields'     => array(

            array(
                'id'       => 'ord_vpsslide_title',
                'type'     => 'text',
                'title'    => __( 'Section Title', 'ordomain' ),
                'default'  => 'VPS Plan',
            ),
            array(
                'id'       => 'ord_vpsslide_subtitle',
                'type'     => 'text',
                'title'    => __( 'Section Sub Title', 'ordomain' ),
                'default'  => 'choose your',
            ),
            array(
                'id'       => 'ord_vpspricing_version',
                'type'     => 'select',
                'title'    => __( 'VPS Slide Version', 'ordomain' ),
                'subtitle' => __( 'Choose vps Slide version', 'ordomain' ),
                'default'  =>'1',
                'options'   => array(
                    '1' => 'Version 1',
                    '2' => 'Version 2',
                ), 
            ),
            // vpspricing version image start
            array( 
                'id'       => 'vpsprice_vrimg_1',
                'type'     => 'image_select',
                'options'  => array(
                    array (
                         'alt'  => 'Image Name 1',
                         'img'  => get_template_directory_uri(). '/img/vps-slider-img/vps1.png',
                    ),
                ),
                'required' => array('ord_vpspricing_version','equals','1'),
            ),
            array( 
                'id'       => 'vpsprice_vrimg_2',
                'type'     => 'image_select',
                'options'  => array(
                    array (
                         'alt'  => 'Image Name 1',
                         'img'  => get_template_directory_uri(). '/img/vps-slider-img/vps2.png',
                    ),
                ),
                'required' => array('ord_vpspricing_version','equals','2'),
            ),
            // vpspricing version image end

            array(
                'id'       => 'ord_vpspricingPackge_time',
                'type'     => 'select',
                'title'    => __( 'Packge Duration', 'ordomain' ),
                'subtitle' => __( 'Set packge duration', 'ordomain' ),
                'options'  => array(
                    '/day' => '/day',
                    '/mo'  => '/mo',
                    '/yr'  => '/yr',
                ),
                'default'  => '/mo'
            ),
            array(
                'id'       => 'ord_vpspricingoffer',
                'type'     => 'text',
                'title'    => __( 'Offer Ribbon', 'ordomain' ),
                'subtitle' => __( 'Set offer ribbon. If you want to don\'t show offer ribbon remove text form field ', 'ordomain' ),
                'default'  => '10% off',
            ),
            array(
                'id'       => 'ord_vpspricingBuybtn_text',
                'type'     => 'text',
                'title'    => __( 'Buy Button Text', 'ordomain' ),
                'subtitle' => __( 'Set buy now button text', 'ordomain' ),
                'default'  => 'Buy Now',
            ),
            array(
                'id'       => 'ord_vpspricingCustombtn_text',
                'type'     => 'text',
                'title'    => __( 'Custom Button Text', 'ordomain' ),
                'subtitle' => __( 'Set custom button text', 'ordomain' ),
                'default'  => 'View Details',
            ),
            array(
                'id'       => 'ord_vpspricingCustombtn_url',
                'type'     => 'text',
                'title'    => __( 'Custom Button URL', 'ordomain' ),
                'subtitle' => __( 'Set custom button url', 'ordomain' ),
                'default'  => '#',
            ),
            
            array(
                'id'          => 'ord_vpspricing_packge',
                'type'        => 'slides',
                'title'       => __( 'Packge', 'ordomain' ),
                'subtitle'    => __( 'Add VPS Pricing Packge.', 'ordomain' ),
                'show'        => array( 
                    'title'          => true,
                    'description'    => false,
                    'progress'       => false,
                    'icon'           => false,
                    'facts-title1'   => false,
                    'facts-title2'   => false,
                    'facts-number-2' => false,
                    'facts-title3'   => false,
                    'facts-number-3' => false,
                    'facts-number'   => false,
                    'url'            => false,
                    'image_upload'   => true,
                ),
                'required'  => array( 'ord_vpspricing_version', 'equals', '2')
            ),
            array(
                'id'          => 'ord_vpspricing_title',
                'type'        => 'slides',
                'title'       => __( 'Title', 'ordomain' ),
                'subtitle'    => __( 'Add VPS Pricing Title.', 'ordomain' ),
                'show'        => array( 
                    'title'          => true,
                    'description'    => false,
                    'progress'       => false,
                    'icon'           => false,
                    'facts-title1'   => false,
                    'facts-title2'   => false,
                    'facts-number-2' => false,
                    'facts-title3'   => false,
                    'facts-number-3' => false,
                    'facts-number'   => false,
                    'url'            => false,
                    'image_upload'   => false,
                ),
            ),
            array(
                'id'       => 'ord_vpsslide_background',
                'type'     => 'background',
                'output'   => array( '#vpsPricing'),
                'title'    => __( 'VPS Slide', 'ordomain' ),
                'subtitle' => __( 'Vps slide section background with image, color, etc.', 'ordomain' ),
                'default'  => array(
                    'background-color' => '#ffffff',
                ),
            ),
            array(
                'id'       => 'ord_vpsslide_color',
                'type'     => 'color',
                'output'   => array( '.vps-item-feature', '.vps-total-price', '#vpsPricing .section-title p'),
                'title'    => __( 'Text Color', 'ordomain' ),
                'subtitle' => __( 'set vps slide text color', 'ordomain' ),
                'default'  => '#FFFFFF',
                'validate' => 'color',
            ),
            array(
                'id'       => 'ord_vpsslide_ribbon_color',
                'type'     => 'color',
                'output'   => array( '.vps-slider-holder .ribbon.text-white'),
                'title'    => __( 'Ribbon Text Color', 'ordomain' ),
                'subtitle' => __( 'set vps slide ribbon text color', 'ordomain' ),
                'default'  => '#FFFFFF',
                'validate' => 'color',
            ),
            array(
                'id'       => 'ord_vpsslide_btn_color',
                'type'     => 'color',
                'output'   => array( '#vpsPricing .action a.order-link', '#vpsPricing .action a.deatils-link'),
                'title'    => __( 'Button Text Color', 'ordomain' ),
                'subtitle' => __( 'set vps slide button text color', 'ordomain' ),
                'default'  => '#FFFFFF',
                'validate' => 'color',
            ),
            
        ),
    ) );
   
     
    /*
    * Login Page URL Options
    */
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Login Page URL', 'ordomain' ),
        'desc'       => __( 'Create login page for WHMCS custom login from dashboard > Pages > add new ( Select template whmcs login page )', 'ordomain' ),
        'id'         => 'ord_login_page',
        'icon'       => 'el el-folder-open',
        'fields'     => array(

            array(
                'id'       => 'ord_loginactionUrl',
                'type'     => 'text',
                'title'    => __( 'Login Action URL', 'ordomain' ),
                'subtitle' => __( 'Set Login form action url', 'ordomain' ),
                'default'  => '#',                
            ),
            array(
                'id'       => 'ord_loginRegisterUrl',
                'type'     => 'text',
                'title'    => __( 'Register Now URL', 'ordomain' ),
                'subtitle' => __( 'Set register now button  url', 'ordomain' ),
                'default'  => '#',                
            ),
            array(
                'id'       => 'ord_loginForgetPasswordUrl',
                'type'     => 'text',
                'title'    => __( 'Forget Password  URL', 'ordomain' ),
                'subtitle' => __( 'Set forget password button  url', 'ordomain' ),
                'default'  => '#',                
            ),
   
        ),
        
    ) );
    
    
    /*
    * Subscribe section options
    */
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Subscribe', 'ordomain' ),
        'id'         => 'ord_subscribe_section',
        'icon'       => 'el el-envelope',
        'fields'     => array(
        
            array(
                'id'       => 'ord_subscribe_apikey',
                'type'     => 'text',
                'title'    => __( 'API Key', 'ordomain' ),
                'subtitle' => __( 'Set mailchimp api key', 'ordomain' )
            ),
            array(
                'id'       => 'ord_subscribe_listid',
                'type'     => 'text',
                'title'    => __( 'List ID', 'ordomain' ),
                'subtitle' => __( 'Set mailchimp list id', 'ordomain' )
            ),
        ),
        
    ) );
    
    /*
    * Data center section options
    */
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Data Center', 'ordomain' ),
        'id'         => 'ord_datacenter_section',
        'icon'  => 'el el-book',
        'fields'     => array(
        
            array(
                'id'          => 'ord_datacenterLocations',
                'type'        => 'slides',
                'title'       => __( 'Data Center Locations', 'ordomain' ),
                'subtitle'    => __( 'Add data center locations.', 'ordomain' ),
                'show'        => array( 
                    'title'          => true,
                    'description'    => false,
                    'progress'       => true,
                    'icon'           => false,
                    'facts-number'   => false,
                    'facts-title1'   => false,
                    'facts-title2'   => false,
                    'facts-number-2' => false,
                    'facts-number-3' => false,
                    'facts-title3'   => false,
                    'url'            => false,
                    'image_upload'   => false,
                ),

            ),

        ),
        
    ) );
    // datacenter locations end

    
    /* End Section Setting Page */
    
    // -> START Blog Page

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Blog', 'ordomain' ),
        'id'         => 'ord_blog_page',
        'icon'  => 'el el-blogger',
        'fields'     => array(
      
        
            array(
                'id'       => 'ord_blog_sidebar',
                'type'     => 'image_select',
                'title'    => __( 'Select blog layout', 'ordomain' ),
                'subtitle' => __( 'Choose your blog sidebar layout ', 'ordomain' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => '1 Column',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    '2' => array(
                        'alt' => '2 Column Left',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    '3' => array(
                        'alt' => '2 Column Right',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    ),

                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'ord_front_blogPost_excerpt',
                'type'     => 'text',
                'title'    => __( 'Front Posts Excerpt', 'ordomain' ),
                'subtitle' => __( 'How many word you want to show per post in blog section', 'ordomain' ),
                'default'  => '30',
            ),
            array(
                'id'       => 'ord_blog_postExcerpt',
                'type'     => 'text',
                'title'    => __( 'Blog Posts Excerpt', 'ordomain' ),
                'subtitle' => __( 'How many word you want to show per post in blog ', 'ordomain' ),
                'default'  =>'30',
            ), 
            array(
                'id'       => 'ord_hide_shareBox',
                'type'     => 'checkbox',
                'title'    => __( 'social share box show/hide', 'ordomain' ),
                'subtitle' => __( 'Uncheck to hide social share-box in single post view', 'ordomain' ),
                'default'  => '1'// 1 = on | 0 = off
            ),          
        ),
    ) );
    
    /* End blog Page */
    
    // -> START WooCommerce Page

    Redux::setSection( $opt_name, array(
        'title'      => __( 'WooCommerce', 'ordomain' ),
        'id'         => 'ord_woo_page',
        'icon'  => 'el el-shopping-cart',
        'fields'     => array(
      
            array(
                'id'       => 'ord_woo_sidebar',
                'type'     => 'image_select',
                'title'    => __( 'Select WooCommerce Page Sidebar', 'ordomain' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => '1 Column',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    '2' => array(
                        'alt' => '2 Column Left',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    '3' => array(
                        'alt' => '2 Column Right',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    ),

                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'ord_woo_product_number',
                'type'     => 'text',
                'title'    => __( 'Product Per Page', 'ordomain' ),
                'default'  =>'10',
            ), 
            array(
                'id'       => 'ord_woo_shoptitle_switch',
                'type'     => 'switch',
                'title'    => __( 'Display Shop Title', 'ordomain' ),
                'subtitle' => __( 'To display shop title switch on.', 'ordomain' ),
                'default'  => true,
            ),			
        ),
    ) );
    
    /* End WooCommerce Page */
    
    // -> START 404 Page

    Redux::setSection( $opt_name, array(
        'title'      => __( '404 Page', 'ordomain' ),
        'id'         => 'ord_404_page',
        'icon'       => 'el el-ban-circle',
        'fields'     => array(
            array(
                'id'       => 'ord_fof_text',
                'type'     => 'text',
                'title'    => __( '404 Text', 'ordomain' ),
                'subtitle' => __( 'Set 404 description text ', 'ordomain' ),
                'default'  => '404',                
            ),
            array(
                'id'       => 'ord_fof_desc',
                'type'     => 'text',
                'title'    => __( '404 Description', 'ordomain' ),
                'subtitle' => __( 'Set 404 description text ', 'ordomain' ),
                'default'  => 'It looks like nothing was found at this location. Maybe try one of the links below or a search?',                
            ),
            array(
                'id'       => 'ord_fof_background',
                'type'     => 'background',
                'output'   => array( '#f0f' ),
                'title'    => __( '404 Background', 'ordomain' ),
                'subtitle' => __( '404 page background with image, color, etc.', 'ordomain' ),
                'default'  => array(
                    'background-color' => '#ffffff',
                ),
            ),
            array(
                'id'       => 'ord_fof_overlay',
                'type'     => 'checkbox',
                'title'    => __( 'Overlay', 'ordomain' ),
                'subtitle' => __( 'Uncheck to remove overlay', 'ordomain' ),
                'default'  => '1'// 1 = on | 0 = off
            ),


        ),
    ) );
    
    /* End 404 Page */
    

    // -> START Contact Page

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Contact', 'ordomain' ),
        'id'         => 'ord_contact_page',
        'icon'  => 'el el-address-book',
        'fields'     => array(
        
            array(
                'id'       => 'ord_contact_title',
                'type'     => 'text',
                'title'    => __( 'Title', 'ordomain' ),
                'subtitle' => __( 'Write your Contact Title', 'ordomain' ),
                'default'  =>'Contact Information',
            ),
            array(
                'id'       => 'ord_contact_info',
                'type'     => 'text',
                'title'    => __( 'Contact Information', 'ordomain' ),
                'subtitle' => __( 'Write your Contact address', 'ordomain' ),
                'default'  =>'1234 12th Avenue NW, East Shawarapara, Dhaka',
            ),
            array(
                'id'       => 'ord_phone_number',
                'type'     => 'text',
                'title'    => __( 'Phone Number', 'ordomain' ),
                'subtitle' => __( 'Add Phone number', 'ordomain' ),
                'default'  =>'(425) 392-2328',
            ),
            array(
                'id'       => 'ord_fax',
                'type'     => 'text',
                'title'    => __( 'Fax', 'ordomain' ),
                'subtitle' => __( 'Add Fax number', 'ordomain' ),
                'default'  =>'(425) 392-2328',
            ),
            array(
                'id'       => 'ord_email',
                'type'     => 'text',
                'title'    => __( 'Email', 'ordomain' ),
                'subtitle' => __( 'Add email address', 'ordomain' ),
                'default'  =>'info@example.com',
            ),
            array(
                'id'       => 'ord_contact_background',
                'type'     => 'background',
                'output'   => array( '.contact-window:before' ),
                'title'    => __( 'Background', 'ordomain' ),
                'subtitle' => __( 'Contact section background with image, color, etc.', 'ordomain' ),
                'default'  => array(
                    'background-color' => '#ffffff',
                ),
            ),
            array(
                'id'       => 'ord_contact_form',
                'type'     => 'editor',
                'title'    => __( 'Contact Form', 'ordomain' ),
                'subtitle' => __( 'Use contact form 7 plugin shortcode', 'ordomain' ),
            ),
            array(
                'id'       => 'ord_contact_action_disabled',
                'type'     => 'switch',
                'title'    => __( 'Contact Action Enabled/Disabled', 'ordomain' ),
                'subtitle' => __( 'If you want to do not show contact action you can Disabled  ', 'ordomain' ),
                'default'  => true,
                'on'       => 'Enabled',
                'off'      => 'Disabled',
            ),
            array(
                'id'          => 'ord_contactActions',
                'type'        => 'slides',
                'title'       => __( 'Contact Action', 'ordomain' ),
                'subtitle'    => __( 'Add contact action', 'ordomain' ),
                'show'        => array( 
                    'title'          => true,
                    'description'    => true,
                    'progress'       => true,
                    'icon'           => true,
                    'facts-number'   => false,
                    'url'            => true,
                    'image_upload'   => false
                ),
                
                'placeholder'   => array(
                        'progress'  => 'Button Text'
                    )
            ),
            array(
                'id'       => 'ord_contactAction_bg',
                'type'     => 'background',
                'output'   => array( '#contactActions' ),
                'title'    => __( 'Background', 'ordomain' ),
                'subtitle' => __( 'Contact action section background with image, color, etc.', 'ordomain' ),
                'default'  => array(
                    'background-color' => '#ffffff',
                ),
            ),
            array(
                'id'       => 'ord_map_disabled',
                'type'     => 'switch',
                'title'    => __( 'Map Enabled/Disabled', 'ordomain' ),
                'subtitle' => __( 'If you want to do not show map you can Disabled  ', 'ordomain' ),
                'default'  => true,
                'on'       => 'Enabled',
                'off'      => 'Disabled',
            ),
            array(
                'id'       => 'ord_map_apikey',
                'type'     => 'text',
                'title'    => __( 'API Key', 'ordomain' ),
                'subtitle' => __( 'Set your google map api key', 'ordomain' )              
            ),
            array(
                'id'       => 'ord_map_lat',
                'type'     => 'text',
                'title'    => __( 'Map Lat', 'ordomain' ),
                'subtitle' => __( 'Set your google map latitude', 'ordomain' ),
                'default'  =>23.790546,
              
            ),
            array(
                'id'       => 'ord_map_lng',
                'type'     => 'text',
                'title'    => __( 'Map Lng', 'ordomain' ),
                'subtitle' => __( 'Set your google map longitude', 'ordomain' ),
                'default'  =>90.375583,
               
            ),
            array(
                'id'       => 'ord_map_zoom',
                'type'     => 'text',
                'title'    => __( 'Map Zoom', 'ordomain' ),
                'subtitle' => __( 'Set your google map zooming', 'ordomain' ),
                'default'  =>16,
           
            ),

            
        ),
    ) );
    
    /* End Contact Page */
    
    
    // -> START Social Media

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Social', 'ordomain' ),
        'id'         => 'ord_social_media',
        'icon'  => 'el el-globe',
        'fields'     => array(
            array(
                'id'       => 'ordomain_facebook_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Facebook', 'ordomain' ),
                'subtitle' => esc_html__( 'Add Facebook URL', 'ordomain' ),
            ),
            array(
                'id'       => 'ordomain_twitter_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Twitter', 'ordomain' ),
                'subtitle' => esc_html__( 'Add Twitter URL', 'ordomain' ),
            ),
            array(
                'id'       => 'ordomain_google_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Google Plus', 'ordomain' ),
                'subtitle' => esc_html__( 'Add google plus URL', 'ordomain' ),
            ),
            array(
                'id'       => 'ordomain_youtube_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Youtube', 'ordomain' ),
                'subtitle' => esc_html__( 'Add youtube URL', 'ordomain' ),
            ),
            array(
                'id'       => 'ordomain_instagram_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Instagram', 'ordomain' ),
                'subtitle' => esc_html__( 'Add Instagram URL', 'ordomain' ),
            ),
            array(
                'id'       => 'ordomain_vimeo_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Vimeo', 'ordomain' ),
                'subtitle' => esc_html__( 'Add vimeo plus URL', 'ordomain' ),
            ),
            array(
                'id'       => 'ordomain_linkedin_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Linkedin', 'ordomain' ),
                'subtitle' => esc_html__( 'Add linkedin plus URL', 'ordomain' ),
            ),
            array(
                'id'       => 'ordomain_behance_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Behance', 'ordomain' ),
                'subtitle' => esc_html__( 'Add behance plus URL', 'ordomain' ),
            ),          
            array(
                'id'       => 'ordomain_pinterest_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Pinterest', 'ordomain' ),
                'subtitle' => esc_html__( 'Add pinterest plus URL', 'ordomain' ),
            ),          
            array(
                'id'       => 'ordomain_dribbble_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Dribbble', 'ordomain' ),
                'subtitle' => esc_html__( 'Add dribbble plus URL', 'ordomain' ),
            ),          
            array(
                'id'       => 'ordomain_github_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Github', 'ordomain' ),
                'subtitle' => esc_html__( 'Add github URL', 'ordomain' ),
            ), 
        ),
    ) );
    
    /* End social Media */
    
    // -> START Footer Media

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer', 'ordomain' ),
        'id'         => 'ord_footer_section',
        'icon'  => 'el el-photo',
        'fields'     => array(
            array(
                'id'       => 'ord_footer_weiget_disabled',
                'type'     => 'switch',
                'title'    => __( 'Footer Widgets Enabled/Disabled', 'ordomain' ),
                'subtitle' => __( 'Disabled footer Widgets section  ', 'ordomain' ),
                'default'  => 2,
                'on'       => 'Enabled',
                'off'      => 'Disabled',
            ),
            array(
                'id'       => 'ord_footercol_switch',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Select Widget Column', 'ordomain' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '6' => array(
                        'alt' => '2 Column Left',
                        'img' => ReduxFramework::$_url . 'assets/img/2-col-portfolio.png'
                    ),
                    '4' => array(
                        'alt' => '3 Column Right',
                        'img' => ReduxFramework::$_url . 'assets/img/3-col-portfolio.png'
                    ),

                    '3' => array(
                        'alt' => '4 Column Right',
                        'img' => ReduxFramework::$_url . 'assets/img/4-col-portfolio.png'
                    ),

                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'ord_footer_weiget_background',
                'type'     => 'background',
                'output'   => array( '.footer-widgets' ),
                'title'    => __( 'Footer Widgets Background', 'ordomain' ),
                'subtitle' => __( 'Footer Widgets section background with image, color, etc.', 'ordomain' ),
                'required' => array( 'ord_footer_weiget_disabled', 'equals', 1 ),
                'default'  => array(
                    'background-color' => '#1d1d21',
                ),
                
            ),
            array(
                'id'       => 'ord_footer_top_disabled',
                'type'     => 'switch',
                'title'    => __( 'Footer Top Enabled/Disabled', 'ordomain' ),
                'subtitle' => __( 'Disabled Top footer Widgets section  ', 'ordomain' ),
                'default'  => 2,
                'on'       => 'Enabled',
                'off'      => 'Disabled',
            ),
            array(
                'id'       => 'ord_footertop_accpet',
                'type'     => 'media',
                'url'      => true,
                'title'    => __( 'Payments Accpet', 'ordomain' ),
                'subtitle' => __( 'Upload payments accpeted logo', 'ordomain' ),
                'required' => array( 'ord_footer_top_disabled', 'equals', 1 ),
            ),
            array(
                'id'       => 'ord_footer_top_background',
                'type'     => 'background',
                'output'   => array( '.bottom' ),
                'title'    => __( 'Footer Top Background', 'ordomain' ),
                'subtitle' => __( 'Footer top section background with image, color, etc.', 'ordomain' ),
                'default'  => array(
                    'background-color' => '#232328',
                ),
                'required' => array( 'ord_footer_top_disabled', 'equals', 1 ),
            ),
            array(
                'id'       => 'ord_copyright_text',
                'type'     => 'text',
                'title'    => __( 'Copyright', 'ordomain' ),
                'subtitle' => __( 'Add Copyright ', 'ordomain' ),
                'default'  => __( 'Copyright 2016 &copy; <a href="#">OrDomain</a>. All Rights Reserved.', 'ordomain' ),
            ),
            array(
                'id'       => 'ord_footer_copyright_background',
                'type'     => 'background',
                'output'   => array( '.copyright' ),
                'title'    => __( 'Footer Background', 'ordomain' ),
                'subtitle' => __( 'Footer section background with image, color, etc.', 'ordomain' ),
                'default'  => array(
                    'background-color' => '#232328',
                ),
            ),
            
        ),
    ) );
    
    /* End Footer Media */

    /*
     * <--- END SECTIONS
     */


    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */

    /*
    *
    * --> Action hook examples
    *
    */

    // If Redux is running as a plugin, this will remove the demo notice and links
    //add_action( 'redux/loaded', 'remove_demo' );

    // Function to test the compiler hook and demo CSS output.
    // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
    //add_filter('redux/options/' . $opt_name . '/compiler', 'compiler_action', 10, 3);

    // Change the arguments after they've been declared, but before the panel is created
    //add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );

    // Change the default value of a field after it's been set, but before it's been useds
    //add_filter('redux/options/' . $opt_name . '/defaults', 'change_defaults' );

    // Dynamically add a section. Can be also used to modify sections/fields
    //add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');

    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $return['error'] = $field;
                $field['msg']    = 'your custom error message';
            }

            if ( $warning == true ) {
                $return['warning'] = $field;
                $field['msg']      = 'your custom warning message';
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => __( 'Section via hook', 'ordomain' ),
                'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'ordomain' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }
    }
