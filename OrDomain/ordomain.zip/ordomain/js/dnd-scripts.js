/* global screenReaderText */
/**
 * Theme functions file.
 *
 * Contains handlers for navigation and widget area.
 */


jQuery(function($){	

    /*Draggable Area*/
    $('.left_container .page_item').draggable({
        helper: 'clone',
        revert: 'invalid',
        scope: 'related_pages_scope',
        cursor: 'move',
        zIndex: 5
    });


    // Hide sections metabox on load
    var $postContainer2 = $('#postbox-container-2');
        $prefix = '_ord_';
        
    $postContainer2.find('.postbox[id^="' + $prefix + '"]').addClass('hidden');
        
    // Hide sections metabox on click
    $postContainer2.on('click', '.remove_item', function () {
        var $p = $(this).parent('.page_item'),
            targetId = $p.attr('id'),
            $targetId = $('#'+ $prefix + targetId +'_section');
        
        $p.remove();
        
        $targetId.addClass('hidden');
    });

    /* Droppable Area */
    $('.right_container').droppable({
        accept: '.page_item',
        scope: 'related_pages_scope',
        hoverClass: 'hover-over-draggable',
        tolerance: 'touch',
        create: function () {
            // Show sections metabox on load
            $(this).children('.page_item').each(function () {
                var $t = $(this),
                    targetId = $t.attr('id'),
                    $targetId = $('#'+ $prefix + targetId +'_section');

                $targetId.removeClass('hidden hide-if-js');
            });
        },
        drop: function( event, ui ){
            
            //define items for use
            var drop_helper = $('.right_container').find('.droppable-helper');
            var page_item = ui.draggable.clone(); 
            
            //on drop trigger actions
            page_item.find('.remove_item').addClass('active');
            page_item.append('<input type="hidden" name="related_pages[]" value="' + page_item.attr('data-page-id') + '"/>');
           
            //add this new item to the end of the droppable list
            drop_helper.before(page_item);
            drop_helper.removeClass('active');
            
            
            // Show sections metabox
            var targetId = ui.draggable.attr('id'),
                $targetEl = $('#'+ $prefix + targetId +'_section');
            
            $targetEl.removeClass('hidden hide-if-js');
            
        },
        over: function(event,ui){
            //when hovering over the droppable area, display the drop helper
            $('.right_container').find('.droppable-helper').addClass('active');
            
        },
        out: function(event,ui){
            $('.right_container').find('.droppable-helper').removeClass('active');
            
        }

        
    });


    /*Sortable Area*/
    $('.right_container').sortable({
        items: '.page_item',
        cursor: 'move',
        containment: 'parent',
        placeholder: 'my-placeholder'
    });
    
    /*page layout meta box closed*/
    
    $('#page_layout_meta_box').addClass('closed');
    
    
    // meta condation
    var selectorId = '#_ord_dnh_features_tables_0__ord_dnh_featurelefttitle';
    $( selectorId ).on('click', function(){
        
        if( $(this).is(':checked') ){
            
            $('.cmb2-id--ord-dnh-features-tables-0--ord-dnh-feature-1-btn').css( 'display', 'none' );
            $('.cmb2-id--ord-dnh-features-tables-0--ord-dnh-feature-1btnurl').css( 'display', 'none' );  
        }else{
            
            $('.cmb2-id--ord-dnh-features-tables-0--ord-dnh-feature-1-btn').css( 'display', 'block' );
            $('.cmb2-id--ord-dnh-features-tables-0--ord-dnh-feature-1btnurl').css( 'display', 'block' ); 
            
        }

    });
    
    if( $( selectorId ).is(':checked') ){
        
        $('.cmb2-id--ord-dnh-features-tables-0--ord-dnh-feature-1-btn').css( 'display', 'none' );
        $('.cmb2-id--ord-dnh-features-tables-0--ord-dnh-feature-1btnurl').css( 'display', 'none' );  
    }
    // meta condation end

});

