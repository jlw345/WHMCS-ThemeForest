jQuery(function($){
    'use strict';

    // slider options
    var $slideone   = $('#_ord_slide_header_active1'),
        $slidetwo   = $('#_ord_slide_header_active2'),
        $pageHeader = $('#_ord_slide_header_active3'),
        $none       = $('#_ord_slide_header_active4');
       
    var $ordSlideHeaderActive = $('input[type="radio"][name="_ord_slide_header_active"]');
    
    if ( $pageHeader.is(':checked') ) { // Page Header
        $('.similar-slider').hide();
        $('.header-breadcrumb').show();
    }else{
        $('.header-breadcrumb').hide();
    }
    
    if ( $none.is(':checked') ) { // None
        $('.header-none, .similar-slider').hide();
    }
    
    $ordSlideHeaderActive.on('click', function (e) {
        
        switch( $( e.target ).attr('id') ){
            case '_ord_slide_header_active3' :
                $('.header-none').show();
                $('.header-breadcrumb').show();
                $('.similar-slider').hide();
                break;
            case '_ord_slide_header_active4' :
                $('.header-none, .similar-slider, .header-breadcrumb').hide();
                break;
            default: 
                 $('.header-none, .similar-slider').show();
                 $('.header-breadcrumb').hide();
                break;
            
        }
            
        
    });
   
    /******** Breadcumb *********/
    
    var $page   = $('#_ord_sliderbg_breadcrumbglob1'),
        $global = $('#_ord_sliderbg_breadcrumbglob2'),
        $name   = '_ord_sliderbg_breadcrumbglob';
        
    var $ordSlidebreadcrumb = $('input[type="radio"][name="_ord_sliderbg_breadcrumbglob"]');
    
    $ordSlidebreadcrumb.on( 'click', function(e) {
        
        if( $(e.target).attr('id') === '_ord_sliderbg_breadcrumbglob1' ){
            $('.header-breadcrumbsect').show();
        }else{
            $('.header-breadcrumbsect').hide();
        }
        
        
    });
    
    if( $page.is(':checked') ){
        $('.header-breadcrumbsect').show();
    }else{
       $('.header-breadcrumbsect').hide(); 
    }

    
   
    /********** section media option ************/
    $.metaplug = function( options ){
        
        var  settings = $.extend({
            
            // Default val set
            opt1:  "",
            opt2:  "",
            name:  "",
            cont:  "",
            media: ""
            
        }, options );

        
        //
        var $Cont  = $( settings.opt1 ),
        $Gmed      = $( settings.opt2 ),
        $Name      = settings.name, 
        $Content   = $( settings.cont ),
        $Media     = $( settings.media );
        
       
    
        $( 'input[type=radio][name='+ $Name +']' ).on( 'click', function(){
            
            //
            if( $Cont.is(':checked') ){
               
                $Content.css('display', 'block');
            
            }else{
                $Content.css('display', 'none');
            }
            //
            if( $Gmed.is(':checked') ){
                
                $Media.css('display', 'block');
            
            }else{
               $Media.css('display', 'none'); 
            }

            
        });  
     
        // Flat Content checked 
        if( $Cont.is(':checked') ){
            
            $Content.css('display', 'block');

        }else{
            $Content.css('display', 'none');
        } 
        //
        if( $Gmed.is(':checked') ){
            
            $Media.css('display', 'block');

        }else{
             $Media.css('display', 'none');
        }
    
          
    };
    
    // Service section
    $.metaplug({
            opt1: "#_ord_services_setoption1",
            opt2: "#_ord_services_setoption2",
            name: "_ord_services_setoption",
            cont: ".service-content",
            media: ".service-media"
    });
    // Counter section
    $.metaplug({
            opt1: "#_ord_counter_setoption1",
            opt2: "#_ord_counter_setoption2",
            name: "_ord_counter_setoption",
            cont: ".counter-content",
            media: ".counter-media"
    });
    // testimonial section
    $.metaplug({
            opt1: "#_ord_testimonial_setoption1",
            opt2: "#_ord_testimonial_setoption2",
            name: "_ord_testimonial_setoption",
            cont: ".testimonial-counter",
            media: ".testimonial-media"
    });
    // Subscribe section
    $.metaplug({
            opt1: "#_ord_subscribe_setoption1",
            opt2: "#_ord_subscribe_setoption2",
            name: "_ord_subscribe_setoption",
            cont: ".subscribe-content",
            media: ".subscribe-media"
    });
    // blog section
    $.metaplug({
            opt1: "#_ord_blog_setoption1",
            opt2: "#_ord_blog_setoption2",
            name: "_ord_blog_setoption",
            cont: ".blog-content",
            media: ".blog-media"
    });
    // Home Domain Checker section
    $.metaplug({
            opt1: "#_ord_homeDomCheck_setoption1",
            opt2: "#_ord_homeDomCheck_setoption2",
            name: "_ord_homeDomCheck_setoption",
            cont: ".homeDomCheck-content",
            media: ".homeDomCheck-media"
    });
    
    // Faq section
    $.metaplug({
            opt1: "#_ord_faq_setoption1",
            opt2: "#_ord_faq_setoption2",
            name: "_ord_faq_setoption",
            cont: ".faq-content",
            media: ".faq-media"
    });
    
    // Extra Feature section
    $.metaplug({
            opt1: "#_ord_extrafeature_setoption1",
            opt2: "#_ord_extrafeature_setoption2",
            name: "_ord_extrafeature_setoption",
            cont: ".extrafeature-content",
            media: ".extrafeature-media"
    });
    
    // Team section
    $.metaplug({
            opt1: "#_ord_team_setoption1",
            opt2: "#_ord_team_setoption2",
            name: "_ord_team_setoption",
            cont: ".team-content",
            media: ".team-media"
    });
    
    // History section
    $.metaplug({
            opt1: "#_ord_history_setoption1",
            opt2: "#_ord_history_setoption2",
            name: "_ord_history_setoption",
            cont: ".history-content",
            media: ".history-media"
    });
    
    // Affiliate Pricing Section
    $.metaplug({
            opt1: "#_ord_affPricing_setoption1",
            opt2: "#_ord_affPricing_setoption2",
            name: "_ord_affPricing_setoption",
            cont: ".affPricing-content",
            media: ".affPricing-media"
    });

    // Affiliate Pricing Section
    $.metaplug({
            opt1: "#_ord_affiliateFeature_setoption1",
            opt2: "#_ord_affiliateFeature_setoption2",
            name: "_ord_affiliateFeature_setoption",
            cont: ".afeature-content",
            media: ".afeature-media"
    });

    // Affiliate Counter Section
    $.metaplug({
            opt1: "#_ord_affcounter_setoption1",
            opt2: "#_ord_affcounter_setoption2",
            name: "_ord_affcounter_setoption",
            cont: ".affcounter-counter",
            media: ".affcounter-media"
    });

    // Hosting Pricing Section
    $.metaplug({
            opt1: "#_ord_hosting_setoption1",
            opt2: "#_ord_hosting_setoption2",
            name: "_ord_hosting_setoption",
            cont: ".hosting-content",
            media: ".hosting-media"
    });

    // Domain Pricing Section
    $.metaplug({
            opt1: "#_ord_domain_setoption1",
            opt2: "#_ord_domain_setoption2",
            name: "_ord_domain_setoption",
            cont: ".domain-content",
            media: ".domain-media"
    });

    // Domain Ext Section
    $.metaplug({
            opt1: "#_ord_domextslid_setoption1",
            opt2: "#_ord_domextslid_setoption2",
            name: "_ord_domextslid_setoption",
            cont: ".domExtSlid-content",
            media: ".domExtSlid-media"
    });
   
    // Flat Content Section
    $.metaplug({
            opt1: "#_ord_flat_setoption1",
            opt2: "#_ord_flat_setoption2",
            name: "_ord_flat_setoption",
            cont: ".flatContent-content",
            media: ".flatContent-media"
    });
	
    // Flat One Content Section
    $.metaplug({
            opt1: "#_ord_flatone_setoption1",
            opt2: "#_ord_flatone_setoption2",
            name: "_ord_flatone_setoption",
            cont: ".flatContentone-content",
            media: ".flatContentone-media"
    });
   
    // Bulk Domain Section
    $.metaplug({
            opt1: "#_ord_bulkdomainchecker_setoption1",
            opt2: "#_ord_bulkdomainchecker_setoption2",
            name: "_ord_bulkdomainchecker_setoption",
            cont: ".bulkdom-content",
            media: ".bulkdom-media"
    });
    
    // Contact Action Section
    $.metaplug({
            opt1: "#_ord_contactAction_setoption1",
            opt2: "#_ord_contactAction_setoption2",
            name: "_ord_contactAction_setoption",
            cont: ".contactAction-content",
            media: ".contactAction-media"
    });
    
    // Dedicated Pricing Tab Section
    $.metaplug({
            opt1: "#_ord_dedicPriceTab_setoption1",
            opt2: "#_ord_dedicPriceTab_setoption2",
            name: "_ord_dedicPriceTab_setoption",
            cont: ".dedicPriceTab-content",
            media: ".dedicPriceTab-media"
    });
    
    // Dedicated Pricing Section
    $.metaplug({
            opt1: "#_ord_dedicate_setoption1",
            opt2: "#_ord_dedicate_setoption2",
            name: "_ord_dedicate_setoption",
            cont: ".dedicate-count",
            media: ".dedicate-media"
    });
    


});