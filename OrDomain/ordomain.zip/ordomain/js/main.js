/*

[Main Script]

Project: OrDomain - Responsive WHMCS Hosting WordPress Theme
Version: 1.6
Author : themelooks.com

*/

(function ($) {
    "use strict";
    
    $(function () {
        /* -------------------------------------------------------------------------*
         * NAVIGATION AREA
         * -------------------------------------------------------------------------*/
        var navigation = $('#navigation')
        ,   wn = $(window)
        ,   navTotalH = navigation.find('.contact-bar').outerHeight() + navigation.find('.navbar').outerHeight()
        ,   navigationSticky = function () {
                return (wn.scrollTop() > 1) ? navigation.addClass('sticky') : navigation.removeClass('sticky');
            };
            
        navigationSticky();
        
        navigation.find('.navbar').css('top', navigation.find('.contact-bar').outerHeight());
        
        navigation.next('.AdjustHeight').css('padding-top', navTotalH);

        /* ------------------------------------------------------------------------- *
         * BACKGROUND IMAGE
         * ------------------------------------------------------------------------- */
        var dataBgImg = $('[data-bg-img]');
        
        dataBgImg.each(function () {
            $(this).css('background-image', 'url('+ $(this).data('bg-img') +')').removeAttr('data-bg-img').addClass('bg-img');
        });
        
        /* ------------------------------------------------------------------------- *
         * BACKGROUND VIDEO
         * ------------------------------------------------------------------------- */
        var $bgVideoEl = $('[data-bg-video]');
        
        if ( $bgVideoEl.length ) {
            $bgVideoEl.tubular({videoId: $bgVideoEl.data('bg-video'), wrapperZIndex: '-1'});
        }

        /* ------------------------------------------------------------------------- *
         * PAGE HEADER SLIDER HEIGHT
         * ------------------------------------------------------------------------- */
        var pageHsliderEl = $('#pageHslider');
        
        if ( wn.width() > 767 ) {
            pageHsliderEl.css('height', wn.outerHeight());
        }

        /* ------------------------------------------------------------------------- *
         * OWL CAROUSEL
         * ------------------------------------------------------------------------- */
        var pageHslider = $('.pageHslider-slider'),
            $speed = $('#slidevtwo').data('slid-speed'),
            $loop  = $('#slidevtwo').data('slid-loop');
            
        if ( pageHslider.length ) {
            pageHslider.owlCarousel({
                items: 1,
                autoplay: true,
				loop: $loop,
                autoplaySpeed: $speed
            });
        }
        
        var clientsSlider = $('.clients-slider')
        ,   feedbackSlider = $('.feedback-slider');
        
        if ( clientsSlider.length ) {
            clientsSlider.owlCarousel({
                items: 1,
                autoplay: true,
                loop: true,
                dots: false,
                onChanged: function (e) {
                    var tIndx = $(e.target).find('.owl-item').eq(e.item.index).children('.item').data('id'), tIndx = tIndx - 1;
                    
                    feedbackSlider.trigger('to.owl.carousel', [tIndx, 500, true]);
                }
            }).on('click', '.owl-item', function (e) {
                var tIndx = $(e.currentTarget).children('.item').data('id') - 1;
                
                clientsSlider.trigger('to.owl.carousel', [tIndx, 500, true]);
            });
        }
        

        if ( feedbackSlider.length ) {
            feedbackSlider.owlCarousel({
                items: 1,
                autoplay: false,
                loop: true,
                dots: false,
                mouseDrag: false,
                touchDrag: false
            });
        }
        
        var extensionSlider = $('.extension-slider');
        
        if ( extensionSlider.length ) {
            var extensionSliderItems = extensionSlider.data('items');
            
            extensionSlider.owlCarousel({
                items: extensionSliderItems,
                loop: true,
                autoplay: true,
                dots: false,
                responsive:{
                    0:{
                        items: 1
                    },
                    480:{
                        items: 3
                    },
                    768:{
                        items: 4
                    },
                    992:{
                        items: extensionSliderItems
                    }
                }
            });
        }
        
        /* -------------------------------------------------------------------------*
         * VERTICAL SLIDER
         * -------------------------------------------------------------------------*/
        var serviceSlider = $('.service-slider')
        ,
            $OptionData = $('#slideData').data('slid-options')
        ,   serviceSliderMode = function () {
            return ( wn.width() < 991 ) ? 'horizontal' : 'vertical';
        };
            
        if ( serviceSlider.length ) {
            serviceSlider.bxSlider({
                mode: serviceSliderMode(),
                speed: $OptionData.speed,
                infiniteLoop: $OptionData.loop,
                controls: false,
                auto: true,
                pause: $OptionData.pause
            });
            
            wn.on('resize', function () {
                serviceSlider.reloadSlider();
            });
            
            
        }

        /* ------------------------------------------------------------------------- *
         * BACK TO TOP BUTTON
         * ------------------------------------------------------------------------- */
        var backToTop = $('.back-to-top')
        ,   backToTopBtn = $('.back-to-top button')
        ,   backToTopShow = function () {
                return ( wn.scrollTop() > 1 ) ? backToTop.addClass('show') : backToTop.removeClass('show');
            };
        
        backToTopBtn.on('click', function() {
            $("html, body").animate({scrollTop: 0}, 500);
        });
        
        /* -------------------------------------------------------------------------*
         * ON SCROLL
         * -------------------------------------------------------------------------*/
        wn.on('scroll', function () {
            /* NAVIGATION AREA BG */
            navigationSticky();
            
            /* BACK TO TOP */
            backToTopShow();
        });
        
        /* -------------------------------------------------------------------------*
         * TEXTAREA
         * -------------------------------------------------------------------------*/
        var bulkdomains = $('#bulkdomains')
        ,   bulkdomainsPlaceholder = 'Enter up to 20 domain names.\nEach name must be on a separate line.\n\nExamples:\nexample.com\nexample.net';
        
        bulkdomains.attr('placeholder', bulkdomainsPlaceholder);
        
        /* -------------------------------------------------------------------------*
         * COUNTER
         * -------------------------------------------------------------------------*/
        var counterNum = $('.counter-number');
            
        if ( counterNum.length ) {
            counterNum.counterUp({
                delay: 10,
                time: 1000
            });
        }
        
        /* -------------------------------------------------------------------------*
         * RESPONSIVE PRICING DETAILS
         * -------------------------------------------------------------------------*/
        if ( wn.width() < 992 ) {
            $('.pricing-details-item.body li').each(function () {
                var $this = $(this)
                ,   $thisIndx = $this.index()
                ,   $text = $this.parents('.pricing-details-item').siblings('.pricing-details-item.head').find('li').eq($thisIndx).text();

                $this.prepend('<span class="labelText">'+ $text +'</span>');
            });
        }
        
        /* -------------------------------------------------------------------------*
         * MAP
         * -------------------------------------------------------------------------*/
        var $map1 = $("#map1"),
            $map2 = $("#map2"),
            initMap = function ($el) {
                var latlng, map, marker;
                
                $.ajax({
                    type: 'POST',
                    url: ajaxmap.ajaxurl,
                    data: {
                        action: 'map_ajax',
                        vpscontent: ajaxmap.mapcontent
                    },
                    dataType: 'json',
                    success: function (res) {
                        latlng = {
                            lat: parseFloat(res[0].lat),
                            lng: parseFloat(res[0].lng)
                        };
                        
                        map = new google.maps.Map(document.getElementById( $el.attr('id') ), {
                            center: latlng,
                            zoom: parseFloat(res[0].zoom),
                            scrollwheel: false,
                            disableDefaultUI: true
                        });
                        
                        marker = new google.maps.Marker({
                            position: latlng,
                            map: map
                        });
                        
                        if( $el.attr('id') === 'map2' ) {
                            map.setOptions({
                                zoom: 5,
                                styles: [{featureType:"all",stylers:[{saturation:-80}]},{featureType:"road.arterial",elementType:"geometry",stylers:[{hue:"#00ffee"},{saturation:50}]},{featureType:"poi.business",elementType:"labels",stylers:[{visibility:"off"}]}]
                            });
                        
                            marker.setMap(null);
                            
                            for (var i = 0; i < res[1].locs.length; i++) {
                                marker = new google.maps.Marker({
                                    position: new google.maps.LatLng(res[1].locs[i].title, res[1].locs[i].progress),
                                    map: map
                                });
                            }
                        }
                    }
                });
            };
        
        if ( $map1.length ) {
            initMap( $map1 );
        } else if ( $map2.length ) {
            initMap( $map2 );
        }
        
        /* -------------------------------------------------------------------------*
         * ACCORDION
         * -------------------------------------------------------------------------*/
        $('.panel-heading a').on('click', function(e){
            if($(this).parents('.panel').children('.panel-collapse').hasClass('in')) {
                e.stopPropagation();
                e.preventDefault();
            }
        });
        
        /* -------------------------------------------------------------------------*
         * DOMAIN PRICING AREA
         * -------------------------------------------------------------------------*/
        if ( wn.width() < 992 ) {
            $('#dedicatedPricing table td, #domainPricing table td').each(function () {
                $(this).prepend('<span class="labelText">'+ $(this).data('label') + '</span>');
            });
        }
        
        /* -------------------------------------------------------------------------*
         * VPS SLIDER
         * -------------------------------------------------------------------------*/
        var $vpsPricing = $('#vpsPricing'),
            $vpsSlider = $('#vpsSlider').length ? $('#vpsSlider') : $('#vpsSlider2');

        if ( $vpsSlider.length ) {
            var $featureItemValue = $vpsPricing.find('.vps-item-feature-value'),
                $vpsTotalPriceChild = $vpsPricing.find('.vps-total-price span'),
                $vpsOrderLink = $vpsPricing.find('a.order-link');

            var changingVpsPlans = function ( res, indx ) {
                for ( var i = 0; i < res[ indx ][0].length; i++ ) {
                    $featureItemValue.eq(i).text( res[ indx ][0][i] );
                }

                $vpsTotalPriceChild.text(res[ indx ][2]);
                $vpsOrderLink.attr('href', res[ indx ][1]);
            };

            
            
            var vpsSliderInit = function (res) {
                $vpsSlider.slider({
                    animate: "fast",
                    range: "min",
                    min: 0,
                    max: (res.length - 1),
                    value: 0,
                    step: 1,
                    create: function( event ) {
                        changingVpsPlans( res, '0' );

                        $vpsSlider.find('.ui-slider-handle').append('<i class="fa fa-map-marker"></i>');
                    },
                    slide: function( event, ui ) {
                        changingVpsPlans( res, ui.value );
                    }
                });
            };

            $.ajax({
                type: 'POST',
                url: ajaxvps.ajaxurl,
                data: {
                    action: 'vpspricing_ajax',
                    vpscontent: ajaxvps.vpscontent
                },
                dataType: 'json',
                success: function (res) {
                    vpsSliderInit(res);
                }
            });
        }
        
        /* ------------------------------------------------------------------------- *
         * Mail Chimp ajax
         * ------------------------------------------------------------------------- */
        var $subscribeForm = $('#subscribeForm');
        
        $subscribeForm.on('submit', function () {
            var $t = $(this),
                email = $t.children('#subscribe_email').val(),
                ajax_url = $t.children('#admin-url').data('url');
            
            $.ajax({
                type: 'POST',
                url: ajax_url,
                data: {
                    subscribe_email: email,
                    action: 'ordomain_subscribe_ajax'
                },
                success: function( data ){
                    $t.siblings('#alert-message').html( data );
                }
            });
            
            return false;
        });
    });
    
    $(window).on('load', function () {
        /* ------------------------------------------------------------------------- *
         * PRELOADER
         * ------------------------------------------------------------------------- */
        $('#preloader').fadeOut('slow');
    });
})(jQuery);
