<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
* Template Name: Custom Page
*/

get_header();

$layouts = ordomain_meta_callback('custom_page_layout');
if( $layouts ){
    foreach( $layouts as $layout ){

        switch( $layout ){
            case '1' : get_template_part('ord-part/container');
                break;
            case '2' : get_template_part('ord-part/fullwidth');
                break;
            default : 
            #.....
                break;
        }

    }
}

get_footer();
?>