<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
* Template Name: whmcs Page
*/

get_header();
?>

<!-- WHMCS Bridge Area Start -->
<div class="whmcs-page">
    <div class="whmcs-desc-content">
        <?php 
            if( have_posts() ):
            while( have_posts()):the_post();
            
            the_content(); 
            
            // If comments are open comment template.
            if ( comments_open() || get_comments_number() ) {
                comments_template();
            }
            endwhile;
            wp_reset_postdata();
            else :
                get_template_part( 'template/content', 'none' );
            endif;
        ?>
    </div>
</div>
<!-- WHMCS Bridge Area End -->

<?php
get_footer();
?>