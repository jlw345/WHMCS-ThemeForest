<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <?php endif; ?>

    
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <?php 
    // preloader
    if( ordomain_opt('ord_display_preloader') ){
        ordomain_preloader();
    }
    
    ?>
    <!-- Wrapper Start -->
    <div class="wrapper">
    <?php 
        // get Navigation
        get_template_part('ord-part/navigation');
        
        // page header
        if( !is_404() ){
        $backgroud = ordomain_meta_callback('slide_header_active');
            switch( $backgroud ){
                case 'slider_vr1' : get_template_part('ord-part/slider-vr1');
                    break;
                case 'slider_vr2' : get_template_part('ord-part/slider-vr2');
                    break;
                case 'page_header' : get_template_part('ord-part/page-header');
                    break;
                case 'none' : 
                    echo '<div class="page-header-none AdjustHeight"></div>';
                    break;
                default : get_template_part('ord-part/page-header');
                    break;
            }
        }
        
    ?>