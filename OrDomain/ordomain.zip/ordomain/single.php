<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

get_header();
?>
<div id="blogPage">
    <div class="container">
        <div class="row">
            <?php 
            // sidebar left
            ordomain_blog_left_sidebar();
            
            // blog container
            if( ordomain_opt('ord_blog_sidebar') != '1' ){
                echo '<div class="col-md-8 blog-page-content">';
            }else{
               echo '<div class="col-md-8 col-md-offset-2 blog-page-content">'; 
            }
                // Blog Content Area
                if( have_posts() ){
                    while( have_posts() ){
                        the_post();
                        
                        get_template_part('templates/content', 'single' );
                        
                    }
                    wp_reset_postdata();
                }else{
                    get_template_part( 'templates/content', 'none' );
                }
            echo '</div>';

            // sidebar right
            ordomain_blog_right_sidebar();
            ?>
        </div>
    </div>
</div>
<?php
get_footer();