<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

// Define Template Path 
define('ORDOMAIN_PATHDEMOURI', get_template_directory_uri().'/inc/demo-data/' );
define('ORDOMAIN_PATHDEMO', get_parent_theme_file_path().'/inc/demo-data/' );
define('ORDOMAIN_PATHTEMPDIR', get_template_directory() );
define('ORDOMAIN_PATHTEMPDIRINC', get_template_directory().'/inc/' );
define('ORDOMAIN_PATHORDFRAME', get_template_directory() . '/inc/ord_framework/' );

// Theme Support Functions
if( !function_exists('ordomain_theme_support') ) {
    function ordomain_theme_support(){
        // content width
        $GLOBALS['content_width'] = apply_filters( 'ordomain_content_width', 840 );

        
        // text domain for translation.
        load_theme_textdomain( 'ordomain', get_template_directory() . '/languages' );
        
        // support title tage
        add_theme_support( 'title-tag' );
        
        // support logo
        add_theme_support( 'custom-logo' );
        
        //  support post format
        add_theme_support( 'post-formats', array( 'video','audio' ) );
        
        // support post-thumbnails
        add_theme_support( 'post-thumbnails' );

        // support custom background 
        add_theme_support( 'custom-background' );
        
        // support custom header
        add_theme_support( 'custom-header' );
        
        // support automatic feed links
        add_theme_support( 'automatic-feed-links' );

        add_theme_support( 'customize-selective-refresh-widgets' );
        
        // support html5
        add_theme_support( 'html5' );
        
        // Woocommerce Support
        add_theme_support( 'woocommerce' );
		
		// woo product gallery zoom, lightbox, slider support
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
		add_theme_support( 'wc-product-gallery-slider' );
		
        // register nav menu
        register_nav_menus( array(
            'primary-menu' => esc_html__( 'Primary Menu', 'ordomain' ),
        ) );
        
        // editor style
        add_editor_style('css/editor-style.css');
    }
    add_action( 'after_setup_theme', 'ordomain_theme_support' );
}


// Style & Script Enqueue Function
if( !function_exists('ordomain_enqueue_scripts') ){
    function ordomain_enqueue_scripts(){
        /**
         *style enqueue
         */
        
        // Add google fonts,.
        wp_enqueue_style( 'roboto-fonts', ordomain_roboto_fonts(), array(), '2.0' );
        
        // font-awesome style enqueue
        wp_enqueue_style( 'font-awesome.min', get_template_directory_uri().'/css/font-awesome.min.css', array(), '4.5.0' );
        
        // bootstrap style enqueue
        wp_enqueue_style( 'bootstrap.min', get_template_directory_uri().'/css/bootstrap.min.css', array(), '3.3.6' );
        
        // owl carousel style enqueue
        wp_enqueue_style( 'owl.carousel.min', get_template_directory_uri().'/css/owl.carousel.min.css', array(), '4.5.0' );
        
        // jquery ui custom style enqueue
        wp_enqueue_style( 'jquery-ui-custom.min', get_template_directory_uri().'/css/jquery-ui-custom.min.css', array(), '4.5.0' );
        
        // jquery bxslider style enqueue
        wp_enqueue_style( 'jquery.bxslider.min', get_template_directory_uri().'/css/jquery.bxslider.min.css', array(), '4.2.5' );
        
        // ordomain style enqueue
        wp_enqueue_style( 'ordomain', get_template_directory_uri().'/css/ordomain.css', array(), '1.0' );
        
        // responsive style enqueue
        wp_enqueue_style( 'ordomain-responsive', get_template_directory_uri().'/css/ordomain-responsive.css', array(), '1.0' );
        
        // Theme stylesheet.
        wp_enqueue_style( 'ordomain-style', get_stylesheet_uri() );

        
        /**
         *scripts enqueue
         */
         
        // Add Google MAPS API JavaScript .
        if( ordomain_opt('ord_map_apikey')  ){
            wp_enqueue_script( 'maps-googleapis', '//maps.googleapis.com/maps/api/js?key='.ordomain_opt('ord_map_apikey') );
        }
        
        // jquery-ui-custom
        wp_enqueue_script( 'jquery-ui-custom', get_template_directory_uri().'/js/jquery-ui-custom.min.js', array('jquery'), '1.0', true );
        
        // bootstrap script enqueue
        wp_enqueue_script( 'bootstrap.min', get_template_directory_uri().'/js/bootstrap.min.js', array('jquery'), '3.3.6', true );
        
        // owl carousel script enqueue
        wp_enqueue_script( 'owl.carousel.min', get_template_directory_uri().'/js/owl.carousel.min.js', array('jquery'), '4.5.0', true );
        
        // jquery bxslider script enqueue
        wp_enqueue_script( 'jquery.bxslider.min', get_template_directory_uri().'/js/jquery.bxslider.min.js', array('jquery'), '4.2.5', true );
        
        // jquery tubular script enqueue
        wp_enqueue_script( 'jquery.tubular.1.0', get_template_directory_uri().'/js/jquery.tubular.1.0.js', array('jquery'), '1.0', true );
        
        // jquery waypoints script enqueue
        wp_enqueue_script( 'jquery.waypoints.min', get_template_directory_uri().'/js/jquery.waypoints.min.js', array('jquery'), '4.0.0', true );
        
        // jquery counterup script enqueue
        wp_enqueue_script( 'jquery.counterup.min', get_template_directory_uri().'/js/jquery.counterup.min.js', array('jquery'), '1.0', true );
        
        // jquery.ui.touch-punch.min
        wp_enqueue_script( 'jquery.ui.touch-punch.min', get_template_directory_uri().'/js/jquery.ui.touch-punch.min.js', array('jquery'), '1.0', true );
        
        
        // jquery ajaxchimp script enqueue
        wp_enqueue_script( 'ajaxchimp', get_template_directory_uri().'/js/jquery.ajaxchimp.js', array('jquery'), '1.0', true );
        
        // ordomain main script enqueue
        wp_enqueue_script( 'ordomain-main', get_template_directory_uri().'/js/main.js', array('jquery'), '1.0', true );
        
        // comments reply enqueue
        if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
            wp_enqueue_script( 'comment-reply' );
        }
        
    }
    add_action( 'wp_enqueue_scripts', 'ordomain_enqueue_scripts' );
}


/**
 * google fonts 
 */

function ordomain_roboto_fonts() {
	
	$font_url = '';
	
	if( 'off' !== _x('on', 'Google Roboto font: on or off', 'ordomain' ) ){
        
		$font_url = add_query_arg( 'family', urlencode('Roboto:100,300,400,500,700,900'), '//fonts.googleapis.com/css' );
	}
	
	return $font_url;
}

/**
 * include file 
 */

require_once( ORDOMAIN_PATHTEMPDIRINC . 'ordomain-functions.php' );
require_once( ORDOMAIN_PATHTEMPDIRINC . 'ordomain-support.php' );
require_once( ORDOMAIN_PATHTEMPDIRINC . 'ordomain-option-slide-add-filed.php' );
require_once( ORDOMAIN_PATHTEMPDIRINC . 'wp_bootstrap_navwalker.php' );
require_once( ORDOMAIN_PATHTEMPDIRINC . 'ordomain-widgets-reg.php' );
require_once( ORDOMAIN_PATHTEMPDIRINC . 'ordomain-breadcrumbs.php' );
require_once( ORDOMAIN_PATHTEMPDIRINC . 'ordomain-wp_bootstrap_pagination.php' );
require_once( ORDOMAIN_PATHTEMPDIRINC . 'ordomain-css.php' );
require_once( ORDOMAIN_PATHTEMPDIRINC . 'demo-data/demo-import.php' );
require_once( ORDOMAIN_PATHORDFRAME   . 'ord_option/ordomain-option.php' );
require_once( ORDOMAIN_PATHORDFRAME   . 'ord_custom-meta/ordomain-config.php' );
require_once( ORDOMAIN_PATHORDFRAME   . 'ord_custom-meta/cmb2-radio-image.php' );
require_once( ORDOMAIN_PATHORDFRAME   . 'plugins-activation/ordomain-active-plugins.php' );