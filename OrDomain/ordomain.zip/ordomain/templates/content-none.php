<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/
?>
<div class="post-item">
<h1 class="blog-item-title"><?php esc_html_e( 'Nothing Found', 'ordomain' ); ?></h1>

<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>

    <p><?php printf( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'ordomain' ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>

<?php elseif ( is_search() ) : ?>

    <p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'ordomain' ); ?></p>
    <?php get_search_form(); ?>

<?php else : ?>

    <p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'ordomain' ); ?></p>
    <?php get_search_form(); ?>

<?php endif; ?>
</div>