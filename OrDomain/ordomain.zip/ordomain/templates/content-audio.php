<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

?>

<div id="post-<?php the_ID(); ?>" <?php post_class('post-item'); ?>>
    <?php 
        // blog post audio  
        if(  ordomain_embedded_media( array( 'audio','iframe' ) ) ){
            echo '<div class="post-audio">';
                echo ordomain_embedded_media( array( 'audio', 'iframe' ) );
            echo '</div>';
        }
        // blog post excerptMeta 
        ordomain_blog_excerptMeta();
    ?> 
</div>