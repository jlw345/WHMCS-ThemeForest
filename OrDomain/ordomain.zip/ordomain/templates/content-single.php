<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$year  = get_the_time('Y'); 
$month_link = get_the_time('m');
$day   = get_the_time('d'); 

?>

<div id="post-<?php the_ID(); ?>" <?php post_class('post-item full-post'); ?>>
    <?php 
        // blog post thumbnail 
        ordomain_blog_thumb();
    ?> 
    <div class="post-meta clearfix">
        <div class="date">
            <a href="<?php echo esc_url( get_day_link( $year, $month_link, $day ) ); ?>">
                <i class="fa fa-calendar"></i><?php the_date('M-d'); ?>
            </a>
        </div> 
        <div class="comments">
            <?php echo ordomain_posted_comments(); ?>
        </div>
    </div>

    <div class="post-item-content">
        <div class="summery">
        <?php
        // single page content 
        the_content();
        
        // page links
        wp_link_pages( array(
        'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'ordomain' ) . '</span>',
        'after'       => '</div>',
        'link_before' => '<span>',
        'link_after'  => '</span>',
        'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'ordomain' ) . ' </span>%',
        'separator'   => '<span class="screen-reader-text">, </span>',
        ) );
        
        ?>
        </div>
    </div>
    
    <?php
    ordomain_posts_categories();
    ?>
    <div class="tags">
    <?php 
    ordomain_posts_tag();
    ?>
    </div>

    <div class="row">
        <?php 
        // show avatar
        $avatar = get_avatar( get_the_author_meta( 'ID' ),70 );
        $url = get_avatar_url( get_the_author_meta( 'ID' ) );
        $blank = strpos( $url , 'd=blank');
        if( $avatar ):
        ?>
        <div class="col-sm-6">
            <div class="post-author-metadata">
                <?php 
                if( !$blank ){
                    echo wp_kses_post( $avatar );
                }
                ?>
                <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="post-author-name"><?php echo esc_html( get_the_author() ); ?></a>
            </div>
        </div>
        <?php 
        endif;
        ?>
        
        <?php 
        // share button
        if( ordomain_opt('ord_hide_shareBox') ){
            
            if( $avatar ){
                $blank = 'pull-right';
            }else{
               $blank = ''; 
            }
            
            echo '<div class="col-sm-6">';
                echo '<div class="post-social-links '.esc_attr( $blank ).'">';
                    ordomain_social_sharing_buttons();
                echo '</div>';
            echo '</div>'; 
        }
        ?>
    </div>
    <div class="post-comments">
        
        <?php 
        // comment template.
        if ( comments_open() || get_comments_number() ) {
            comments_template();
        }
        ?>
    </div>
</div>