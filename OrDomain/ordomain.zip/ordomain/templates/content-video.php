<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

?>

<div id="post-<?php the_ID(); ?>" <?php post_class('post-item'); ?>>
    <?php 
        // blog post video
        if( ordomain_embedded_media( array( 'video','iframe' ) ) ) {
            echo '<div class="post-video embed-responsive embed-responsive-16by9">';
                echo ordomain_embedded_media( array( 'video','iframe' ) );
            echo '</div>';
        }
        // blog post excerptMeta 
        ordomain_blog_excerptMeta();
    ?> 
</div>