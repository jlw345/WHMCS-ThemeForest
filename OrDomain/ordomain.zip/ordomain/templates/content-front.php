<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

?>

<div class="col-md-4">
    <div id="post-<?php the_ID(); ?>" <?php post_class('post-item'); ?>>
        
        <?php 
        if( !has_post_thumbnail() ){
            // video media post check
            if( has_post_format('video') ){
                echo '<div class="post-audio embed-responsive embed-responsive-16by9">';
                echo ordomain_embedded_media( array( 'video','iframe' ) );
                echo '</div>';
            }
            // audio media post check

            
            if( has_post_format('audio')  ){
                echo '<div class="post-video embed-responsive embed-responsive-16by9">';
                echo ordomain_embedded_media( array( 'audio','iframe' ) );
                echo '</div>';
            }
           
        }else{
            echo '<div class="post-image">';
            the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) );
            echo '</div>';
        }
        ?>
        
        <div class="post-content">
        
            <h2 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            
            <p class="meta"><?php esc_html_e( 'By', 'ordomain' ); ?> <a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>"><?php echo get_the_author(); ?></a> <?php esc_html_e( 'in ', 'ordomain' ); ordomain_front_posts_categories(); esc_html_e( 'at', 'ordomain' ); ?> <a href="<?php echo esc_url( ordomain_blog_date_permalink() ); ?>"><?php echo esc_html( get_the_date('M-d') ); ?></a></p>
            
            <div class="summery">
                <?php echo  ordomain_excerpt_length( ordomain_opt('ord_front_blogPost_excerpt') ); ?>
            </div>
            
            <div class="footer clearfix">
                <a href="<?php the_permalink(); ?>"><i class="fa fa-angle-double-right"></i> <?php esc_html_e( 'Read More', 'ordomain' ); ?></a>
                <div class="pull-right"><i class="fa fa-comments-o"></i> <?php echo ordomain_posted_comments(); ?></div>
            </div>
        </div>
    </div>
</div>