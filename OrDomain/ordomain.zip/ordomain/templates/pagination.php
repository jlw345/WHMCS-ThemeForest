<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/
?>
<nav class="blog-page--pagination">
    <?php
    //Pagination
    if ( function_exists('wp_bootstrap_pagination') ){
        wp_bootstrap_pagination();
    }
    else {
        posts_nav_link();
    }
    ?>
</nav>