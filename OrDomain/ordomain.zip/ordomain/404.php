<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

get_header();
?>
<!-- 404 Area Start -->
<div id="f0f" class="AdjustHeight">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="vc-parent">
                    <div class="vc-child">
                        <div class="section-title">
                            <?php 
                            if( !ordomain_opt('ord_fof_text') ){
                                echo '<h2>'.esc_html__( '404', 'ordomain' ).'</h2>';
                            }else{
                                echo '<h2>'.esc_html( ordomain_opt('ord_fof_text') ).'</h2>';
                            }
                            ?>   
                        </div>
                        <div class="description">
                            <?php 
                            if( ordomain_opt('ord_fof_desc') ){
                                echo '<p>'.esc_html( ordomain_opt('ord_fof_desc') ).'</p>';
                            }
                            // search form
                            get_search_form();
                            
                            ?>
                            <a href="<?php echo home_url('/'); ?>" class="btn btn-lg btn-custom"><i class="fa fa-home"></i><?php esc_html_e( 'Go Home', 'ordomain' ); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
get_footer();
?>