<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
* Template Name: Whmcs Login Page
*
*/

get_header();
?>
        <!-- Login Area Start -->
        <div id="login">
            <div class="container">
                <form action="<?php echo esc_url( ( ordomain_opt('ord_loginactionUrl') ) ? ordomain_opt('ord_loginactionUrl') : '#' ) ?>" method="post" id="loginForm">
                    <div class="form-group">
                        <label for="loginEmail"><?php esc_html_e( 'Email address *', 'ordomain' ); ?></label>
                        <input type="email" name="username" class="form-control" id="loginEmail" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <label for="loginPassword"><?php esc_html_e( 'Password *', 'ordomain' ); ?></label>
                        <input type="password" name="password" class="form-control" id="loginPassword" placeholder="Password">
                    </div>
                    <p class="help-block clearfix">
                    <?php 
                    if( ordomain_opt('ord_loginForgetPasswordUrl') ):
                    ?>
                        <a href="<?php echo esc_url( ordomain_opt('ord_loginForgetPasswordUrl') ); ?>" class="pull-left"><i class="fa fa-fw fa-key"></i><?php esc_html_e( 'Forget Password ?', 'ordomain' ); ?></a>
                    <?php 
                    endif;
                    ?>
                    <?php 
                    if( ordomain_opt('ord_loginRegisterUrl') ):
                    ?>
                        <a href="<?php echo esc_url( ordomain_opt('ord_loginRegisterUrl') ); ?>" class="pull-right"><i class="fa fa-fw fa-user-plus"></i><?php esc_html_e( 'Register Now', 'ordomain' ); ?></a>
                    <?php 
                    endif;
                    ?>
                    </p>
                    <button type="submit" class="btn btn-block submit-button"><?php esc_html_e(  'login', 'ordomain'); ?></button>
                </form>
            </div>
        </div>
        <!-- Login Area End -->
<?php
get_footer(); 
?>