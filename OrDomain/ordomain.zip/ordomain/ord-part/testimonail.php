<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$background   = ordomain_meta_callback('testimonial_background');
$overlay      = ordomain_meta_callback('testimonial_overlay');

if( $background ){
    $background = ' data-bg-img="'.esc_url( $background ).'"';
}else{
    $background = '';
}

// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}


$testimonials = ordomain_meta_callback('testimonial_contents');
?>

<div id="feedback"<?php echo wp_kses_post( $background.$overlay ); ?>>
    <div class="container">
        <?php 
        // Section Title
        ordomain_section_heading(
            array(
                'subtitle'  => 'testimonial_subtitle',
                'title'     => 'testimonial_secttitle',
            )
        );
        ?>
    </div>
    <div class="clients-holder">
        <div class="clients-slider owl-carousel">
        <?php
        if( $testimonials ){
            $i = 1;
            foreach( $testimonials as $testimonial ){
                if( isset( $testimonial['_ord_testimonial_img'] ) ){
            ?>
            <div class="item" data-id="<?php echo esc_attr( $i ); ?>">
                <img src="<?php echo esc_url( $testimonial['_ord_testimonial_img'] ); ?>" class="img-responsive" alt="testimonials">
            </div>
            <?php 
                }
            $i++;
            }
        }
        ?>
        </div>
    </div>
    <div class="feedback-slider owl-carousel">
        <?php 
        // Feedback Item
        if( $testimonials ){
            foreach( $testimonials as $testimonial ){
            ?>
                <div class="feedback-item">
                    <div class="feedback-comment">
                    <?php 
                    if( isset( $testimonial['_ord_testimonial_desc'] ) ){
                       echo '<p>'.esc_html( $testimonial['_ord_testimonial_desc'] ).'</p>'; 
                    }
                    ?>   
                    </div>
                    <div class="feedback-info">
                    <?php 
                    if( isset( $testimonial['_ord_testimonial_name'] ) ) {
                        echo '<span class="feedback-name">'.esc_html( $testimonial['_ord_testimonial_name'] ).'</span>';
                    } 
                    if( isset( $testimonial['_ord_testimonial_company'] ) ) {
                        echo '<span class="feedback-role">'.esc_html( $testimonial['_ord_testimonial_company'] ).'</span>';
                    }
                    ?>
                    </div>
                </div>
            <?php            
            }
        }
        
        ?>
    </div>
</div>
<!-- Feedback Area End -->