<?php 
/**
 * @version: 1.5
 * @package: OrDomain
 * @author: Themelooks
 * @Support: <support@themelooks.com>
 * @website: themelooks.com
 *
 */

if( ordomain_opt( 'ord_footercol_switch' ) ){
    $col = ordomain_opt( 'ord_footercol_switch' );
}else{
    $col = '4';
}
// Widget Wrapper
$colStert ='<div class="col-md-'.esc_attr( $col ).'">';
$colEnd   ='</div>';
?>
<!-- Footer Widgets Start -->
<div class="footer-widgets">
    <div class="container">
        <div class="row">
            <?php 
                // Footer widget 1
                if( is_active_sidebar( 'ord_footer_widget_one' ) ){
                    echo wp_kses_post( $colStert  );
                    dynamic_sidebar('ord_footer_widget_one');
                    echo wp_kses_post( $colEnd  );
                }
                // Footer widget 2
                if( is_active_sidebar( 'ord_footer_widget_two' ) ){
                    echo wp_kses_post( $colStert  );
                    dynamic_sidebar('ord_footer_widget_two');
                    echo wp_kses_post( $colEnd  );
                }
                // Footer widget 3
                if( is_active_sidebar( 'ord_footer_widget_three' ) ){
                    echo wp_kses_post( $colStert  );
                    dynamic_sidebar('ord_footer_widget_three');
                    echo wp_kses_post( $colEnd  );
                }
                // Footer widget 4
                if( is_active_sidebar( 'ord_footer_widget_four' ) ){
                    echo wp_kses_post( $colStert  );
                    dynamic_sidebar('ord_footer_widget_four');
                    echo wp_kses_post( $colEnd  );
                }
            ?>
        </div>
    </div>
</div>
