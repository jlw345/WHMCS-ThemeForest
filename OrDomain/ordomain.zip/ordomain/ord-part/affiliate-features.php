<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$services = ordomain_meta_callback('affiliateFeature_contents');
$overlay = ordomain_meta_callback('afeature_overlay');
$background = ordomain_meta_callback('afeature_background');

if( $background ){
    $background = ' data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}

// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}

?>
<!-- Feature Area Start -->
<div id="afeature"<?php echo wp_kses_post( $background.$overlay ); ?>>
    <div class="container">
        <?php 
        // Section Title 
        ordomain_section_heading(
            array(
                'subtitle'  => 'affiliateFeature_subtitle',
                'title'     => 'affiliateFeature_secttitle',
            )
        );
        ?>
        <div class="row">
            <!-- Feature Item Start -->
            <?php 
            if( $services ){
                foreach( $services as $service ){
            ?>
                    <div class="col-sm-4 feature-item counter">
                        
                        <?php 
                        // Icon
                        if( isset( $service['_ord_affiliateFeature_icon_type'] ) && $service['_ord_affiliateFeature_icon_type'] == 'icon' ){
                            if( isset( $service['_ord_affiliateFeature_icon'] ) && $service['_ord_affiliateFeature_icon'] ){
                                echo '<div class="icon">';
                                echo '<i class="fa '.esc_html( $service['_ord_affiliateFeature_icon'] ).'"></i>';
                                echo '</div>';
                            }
                        }
                        // Image Icon 
                        if( isset( $service['_ord_affiliateFeature_icon_type'] ) && $service['_ord_affiliateFeature_icon_type'] == 'image' ){
                            
                            $imgIcon = $service['_ord_affiliateFeature_imgicon'];
                            if( isset( $imgIcon ) && $imgIcon ){
                                echo '<div class="icon">';
                                    echo '<img src="'.esc_url( $imgIcon ).'" class="afffeat-imgicon" alt="'.ordomain_image_alt( esc_url( $imgIcon ) ).'" />';
                                echo '</div>';
                            }
                        }
                        ?>
                        
                        
                        <div class="content">
                        <?php 
                        if( isset( $service['_ord_affiliateFeature_title'] ) ){
                            echo '<h3 class="heading">'.esc_html( $service['_ord_affiliateFeature_title'] ).'</h3>';
                        }
                        if( isset( $service['_ord_affiliateFeature_description'] ) ){
                            echo '<p class="desc">'.esc_html( $service['_ord_affiliateFeature_description'] ).'</p>';
                        }
                        ?> 
                        </div>
                    </div>  
            <?php
                }                
            }
            ?>
        </div>
    </div>
</div>
<!-- Feature Area End -->