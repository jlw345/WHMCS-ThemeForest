<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$overlay    = ordomain_meta_callback('faq_overlay');
$background    = ordomain_meta_callback('faq_background');

if( $background ){
    $background = ' data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}
// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}

?>

<div id="faq"<?php echo wp_kses_post( $background.$overlay ); ?>>
    <div class="container">
        <?php 
        // Section Title
        ordomain_section_heading(
            array(
                'subtitle'  => 'faq_subtitle',
                'title'     => 'faq_secttitle',
            )
        );
        ?>
        <div class="col-sm-12 faq-content">
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active" id="sharedTab">
                    <div class="panel-group accordion" id="accordion1" role="tablist">
                    
                        <?php 
                        $term = ordomain_meta_callback('faq_taxonoy');
                        $args = array(
                            'post_type'      => 'faq',
                            'posts_per_page' => 1,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'faq_categories',
                                    'field'    => 'id',
                                    'terms'    => $term,
                                )
                                
                            )
                        );
                        $loop = new WP_Query( $args );
                        if( $loop->have_posts() ) :
                        
                            while( $loop->have_posts() ): $loop->the_post();
                            $faq_contents = ordomain_meta_callback('faq_contents');
                            $i = 1;
                            foreach( $faq_contents as $faq_content ):
                        ?>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab">
                                <a href="#sharedTabQ-<?php echo esc_html( $i ); ?>" class="<?php echo ( $i == 1)? '' : esc_attr( 'collapsed' ); ?>" data-toggle="collapse" data-parent="#accordion1" role="button">
                                    <h4 class="panel-title"><?php echo esc_html( $faq_content['_ord_faq_title'] ); ?> <i class="fa fa-minus"></i></h4>
                                </a>
                            </div>
                            <div id="sharedTabQ-<?php echo esc_html( $i ); ?>" class="panel-collapse collapse <?php echo ( $i == 1)? esc_attr( 'in' ) : ''; ?>" role="tabpanel">
                                <div class="panel-body link-color--child">
                                    <?php 
                                        if( $faq_content['_ord_faq_desc'] ){
                                            echo '<p>'.ordomain_wp_kses_allow( $faq_content['_ord_faq_desc'] ).'</p>';
                                        }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <?php 
                            $i++;
                            endforeach;
                            endwhile;
                             wp_reset_postdata();
                        endif;
                        ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>