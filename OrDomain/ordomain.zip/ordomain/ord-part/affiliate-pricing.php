<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/


$affPricing = ordomain_meta_callback('affPricing_contents');
$btntext    = ordomain_meta_callback('affPricing_btntext');
$btnurl     = ordomain_meta_callback('affPricing_btnurl');
$overlay    = ordomain_meta_callback('affPricing_overlay');
$background    = ordomain_meta_callback('affPricing_background');

if( $background ){
    $background = ' data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}

// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}

?>
<div id="aPricing"<?php echo wp_kses_post( $background.$overlay ); ?>>
    <div class="container">
        <div class="row">
            <?php 
            // Section Title
            ordomain_section_heading(
                array(
                    'subtitle'  => 'affPricing_subtitle',
                    'title'     => 'affPricing_secttitle',
                )
            );
            ?>
            <?php 
            //Pricing Item
            if( $affPricing ):
                foreach( $affPricing as $affPrice ):
                if( isset( $affPrice['_ord_affPricing_title'] ) || isset( $affPrice['_ord_affPricing_price'] ) ):
            ?>
                <div class="col-md-4 a-pricing-item">
                    <div class="head">
                    <?php 
                    if( isset( $affPrice['_ord_affPricing_title'] ) ){
                        echo '<h3 class="title">'.esc_html( $affPrice['_ord_affPricing_title'] ).'</h3>';
                    }
                    ?>   
                    <h4 class="price"><?php echo ( isset( $affPrice['_ord_affPricing_price_tag'] ) ? esc_html( $affPrice['_ord_affPricing_price_tag'] ) : '' ); ?><span><?php echo ( isset( $affPrice['_ord_affPricing_price'] ) ) ? ' '.esc_html( $affPrice['_ord_affPricing_price'] ) :''; ?></span></h4>
                    </div>
                </div>
            <?php 
                endif;
                endforeach;
            endif;
            ?>
        </div>
        <?php 
        if( $btntext && $btnurl ){
            echo '<div class="affiliate-signup-btn-holder">';
                echo '<a href="'.esc_url( $btnurl ).'" class="btn btn-lg btn-custom">'.esc_html( $btntext ).'</a>';
            echo '</div>'; 
        }
        ?>
    </div>
</div>
       