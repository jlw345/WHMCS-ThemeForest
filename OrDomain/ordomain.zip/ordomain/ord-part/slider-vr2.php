<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$sliders = ordomain_meta_callback('slider_contents');
$backgroud = ordomain_meta_callback('sliderbg_img');
$videobg = ordomain_meta_callback('sliderbg_video');
$speed = ordomain_meta_callback('slider_speed');
$loop  = ordomain_meta_callback('slider_loop');

//
if( $speed ){
    $speed = $speed;
    
}else{
    $speed = '800';
}
//
if( $loop ){
	$loop = $loop;
}else{
	$loop = false;
}

$getoverlay = ordomain_meta_callback('sliderbg_overlay');
$globoverlay = ordomain_opt('ord_allHeader_overlay');

if( $getoverlay == 'on' ){
    $overlay = 'bg--overlay';
}elseif( $getoverlay == 'global' && $globoverlay ){
   $overlay = 'bg--overlay';
}else{
   $overlay = ''; 
}
?>
<!-- Header Area Start -->
<?php 

if( $videobg ){
   echo '<div class="bg-video '.esc_attr( $overlay ).'" data-bg-video="'.$videobg.'"></div>'; 
}else{
    echo '<div id="pageHslider" class="'.esc_attr( $overlay ).'" data-bg-img="'.esc_url( $backgroud ).'">';
}

?>

    <div id="slidevtwo" class="pageHslider-slider owl-carousel" data-slid-speed="<?php echo esc_attr( $speed ); ?>" data-slid-loop="<?php echo esc_attr( $loop ); ?>">
        <?php 
        $i = 1;
        foreach( $sliders as $slider ):
        ?>
        <div class="item">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 pageHslider-item-content-holder <?php echo( $i%2 == 0 ) ? 'pull-right' : ''; ?>">
                        <div class="vc-parent">
                            <div class="vc-child">
                                <!-- Header Slider Content Start -->
                                <div class="pageHslider-item-content">
                                    <?php 
                                    // slider title
                                    if( isset( $slider['_ord_slid_subTitle'] ) ){
                                        echo '<p class="subtitle">'.esc_html( $slider['_ord_slid_subTitle'] ).'</p>';
                                    }
                                    if( isset( $slider['_ord_slid_title'] ) ){
                                        echo '<h2>'.esc_html( $slider['_ord_slid_title'] ).'</h2>';
                                    }
                                    
                                    // editor
                                    if( isset( $slider['_ord_slid_editor'] ) ) {
                                        echo '<p>'.ordomain_wp_kses_allow( $slider['_ord_slid_editor'] ).'</p>';
                                    } 
                                    // list content
                                    if( isset( $slider['_ord_slid_listcontent'] ) ) {
                                        echo '<ul>';
                                            foreach( $slider['_ord_slid_listcontent'] as $list ){
                                                echo '<li>';
                                                    echo '<p><i class="fa fa-check text-green"></i>&nbsp; '.esc_html( $list ).'</p>';
                                                echo '</li>';
                                            }
                                        echo '</ul>';
                                    } 
                                    ?>
                                    
                                    <?php 
                                    if( isset( $slider['_ord_Pricetag_text'] ) || isset( $slider['_ord_Pricetag_Price'] ) || isset( $slider['_ord_Pricetag_duration'] ) || isset( $slider['_ord_slid_buttonLink'] ) ):
                                    ?>
                                        <div class="price">
                                            <p><?php echo esc_html( $slider['_ord_Pricetag_text'] ); ?> <span><?php echo esc_html( $slider['_ord_Pricetag_Price'] ); ?><em><?php echo esc_html( $slider['_ord_Pricetag_duration'] ); ?></em></span></p>
                                            
                                            <?php 
                                            if( isset( $slider['_ord_slid_button'] ) && isset( $slider['_ord_slid_buttonLink'] )  ){
                                                
                                                echo '<a href="'.esc_url( $slider['_ord_slid_buttonLink'] ).'">'.esc_html( $slider['_ord_slid_button'] ).'</a>';
                                            }
                                            ?>
                                            
                                        </div>
                                    <?php 
                                    endif;
                                    ?>
                                </div>
                                <!-- Header Slider Content End -->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 pageHslider-item-img-holder">
                        <div class="vc-parent">
                            <div class="vc-child">
                                <?php 
                                // Header Slider Image Start
                                if( isset( $slider['_ord_slider_img'] ) ){
                                    echo '<div class="pageHslider-item-img">';
                                        echo '<img src="'.esc_url( $slider['_ord_slider_img'] ).'" alt="slider-image">';
                                    echo '</div>';  
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php 
        $i++;
        endforeach;
        ?>

    </div>
</div>
<!-- Header Area End -->