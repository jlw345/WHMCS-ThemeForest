<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/


$affcounters = ordomain_meta_callback('affcounter_contents');
$overlay     = ordomain_meta_callback('affcounter_overlay');
$background     = ordomain_meta_callback('affcounter_background');

if( $background ){
    $background = 'data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}

// Overlay
if( $overlay ){
    $overlay = ' bg--overlay';
}else{
    $overlay = '';
}

?>

<div id="aCounter" class="aCounter <?php echo esc_attr( $overlay ); ?>" <?php echo wp_kses_post( $background ); ?>>
    <div class="container">
        <div class="row">
            <?php 
            // Section Title
            ordomain_section_heading(
                array(
                    'subtitle'  => 'affcounter_subtitle',
                    'title'     => 'affcounter_secttitle',
                )
            );
            
            // counter content            
            if( $affcounters ):
                foreach( $affcounters as $affcounter ):
                
                if( isset( $affcounter['_ord_affcounter_title'] ) || isset( $affcounter['_ord_affcounter_number'] ) || isset( $affcounter['_ord_affcounter_curr'] ) ):

            ?>
                <div class="col-md-3 col-sm-6">
                    <div class="aCounter-holder">
                    <?php 
                    if( isset( $affcounter['_ord_affcounter_title'] ) ){
                        echo '<p class="aCounter-text">'.esc_html( $affcounter['_ord_affcounter_title'] ).'</p>';
                    }
                    
                    if( isset( $affcounter['_ord_affcounter_number'] ) || isset( $affcounter['_ord_affcounter_curr'] ) ){
                        echo '<div class="aCounter-number-holder">';
                            if( isset( $affcounter['_ord_affcounter_curr'] ) ){
                                echo esc_html( $affcounter['_ord_affcounter_curr'] ); 
                            }
                        echo '<span class="counter-number">'.esc_html( $affcounter['_ord_affcounter_number'] ).'</span></div>'; 
                    }
                    ?>
                     
                    </div>
                </div>
            <?php
                endif;
                endforeach;
            endif;
            ?>
       </div>
    </div>
</div>
        