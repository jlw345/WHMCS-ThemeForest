<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/


$feature_image = ordomain_meta_callback('extrafeature_image');
$extrafeatures = ordomain_meta_callback('extrafeature_contents');
$background    = ordomain_meta_callback('extrafeature_background');

if( $background ){
    $background = ' data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}

$overlay    = ordomain_meta_callback('extrafeature_overlay');
// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}

?>

<div id="extraFeature"<?php echo wp_kses_post( $background.$overlay );?>>
    <div class="container">
        <?php 
        // Section Title
        ordomain_section_heading(
            array(
                'subtitle'  => 'extrafeature_subtitle',
                'title'     => 'extrafeature_secttitle',
            )
        );
        ?>
        <div class="row">
            <div class="col-md-6">
                <?php 
                //Extra Feature Image
                if( $feature_image ){
                    
                    echo '<div class="extra-feature-img">';
                        echo '<img src="'.esc_url( $feature_image ).'" alt="feature-image" class="img-responsive" >';
                    echo '</div>'; 
                
                }
                ?>
            </div>
            <div class="col-md-6">
                <!-- Extra Feature Content Start -->
                <div class="extra-feature-content">
                <?php
                if( $extrafeatures ):                
                    foreach( $extrafeatures as $extrafeature ):
                ?>
                    <div class="item">
                        <?php 
                        // icon 
                        if( isset( $extrafeature['_ord_extfeature_icon_type'] ) && $extrafeature['_ord_extfeature_icon_type'] == 'icon' ){
                            
                            if( isset( $extrafeature['_ord_extfeature_icon'] ) && $extrafeature['_ord_extfeature_icon'] ){
                                echo '<div class="icon">';
                                    echo '<i class="fa '.esc_html( $extrafeature['_ord_extfeature_icon'] ).'"></i>';
                                echo '</div>';
                            }
                        }
                        // image icon
                        if( isset( $extrafeature['_ord_extfeature_icon_type'] ) && $extrafeature['_ord_extfeature_icon_type'] == 'image' ){
                            
                            $imgIcon = $extrafeature['_ord_extfeature_imgicon'];
                            if( isset( $imgIcon ) && $imgIcon ){
                                echo '<div class="icon">';
                                    echo '<div class="vc-parent">';
                                        echo '<div class="vc-child">';
                                            echo '<img src="'.esc_url( $imgIcon ).'" class="extrafeat-imgicon" alt="'.ordomain_image_alt( esc_url( $imgIcon ) ).'" />';
                                        echo '</div>';
                                    echo '</div>';
                                echo '</div>';
                            }
                        }
                        ?>
                        <div class="content">
                        <?php 
                        if( isset( $extrafeature['_ord_extfeature_title'] ) ){
                            echo '<h4 class="title">'.esc_html( $extrafeature['_ord_extfeature_title'] ).'</h4>';
                        }
                        if( isset( $extrafeature['_ord_extfeature_desc'] ) ){
                            echo ' <p class="desc">'.esc_html( $extrafeature['_ord_extfeature_desc'] ).'</p>';
                        }
                        ?>  
                        </div>
                    </div>
                <?php 
                    endforeach;
                endif;
                ?>
                </div>
                <!-- Extra Feature Content End -->
            </div>
        </div>
    </div>
</div>