<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/
?>
<!-- Pricing Area Start -->
<div id="pricing">
    <div class="container">
        <?php 
        // Section Title
        ordomain_section_heading(
            array(
                'subtitle'  => 'pricingTab_subTitle',
                'title'     => 'pricingTab_title',
            )
        );
        ?>
        <div class="pricing-tab-filter">
            <ul class="nav nav-tabs" role="tablist">
            
            <?php 
			$get_terms_id = get_post_meta( get_the_ID(), '_ord_pricingTab_cat', true );
			
			$terms = array();
			if( is_array( $get_terms_id ) ){
				foreach( $get_terms_id as $id ){
					
					$terms[] = get_term_by( 'id', $id, 'hosting_categories' );
					
				}
            }
			//
            if( is_array( $terms ) && count( $terms ) > 0  ){
				
                $i=1;
                foreach( $terms as $term ){
					
                    if( $i == 1 ){
                        $class = 'class="active"';
                    }else{
                        $class = '';
                    }
                    
                    echo '<li role="presentation" '.$class .'><a href="#'.esc_attr( $term->slug ).'" class="btn-custom-reverse" aria-controls="'.esc_attr( $term->slug ).'" role="tab" data-toggle="tab">'.esc_html( $term->name ).'</a></li>';
                $i++;
                }
                   
            }
            ?>
               
            </ul>
        </div>

        <div class="tab-content">
        
        <?php 
        if( is_array( $terms ) && count( $terms ) > 0 ):
            $i = 1;
            foreach( $terms as $term ):
        ?>
			<div role="tabpanel" class="tab-pane fade in <?php echo ($i == 1 )? 'active' : ''; ?>" id="<?php echo esc_attr( $term->slug ); ?>">
			
				<div class="row">
					<!-- Pricing Table Start -->
					<div class="pricing-table">
						<?php 
						//Pricing Item
						
						$args = array(
							'post_type' => 'hosting_price',
							'posts_per_page' => 1,
							'tax_query' => array(
								array(
									'taxonomy' => 'hosting_categories',
									'field' => 'id',
									'terms' => $term->term_id,
								)
							),
						);
						
						$loop = new WP_Query( $args );
						
						if( $loop->have_posts() ):
							while( $loop->have_posts() ): $loop->the_post(); 
							$features = get_post_meta( $post->ID, '_ord_hostingvart_features', true ); 
							$i = 1;
							foreach( $features as $feature ):
						?>
						<div class="col-md-4 pricing-item <?php echo ( isset( $feature['_ord_hostingvart_active'] ) && 'on' == $feature['_ord_hostingvart_active']  ) ? esc_attr('active') : ''; ?>">
							<div class="pricing-item-content">
								<?php 
								if( isset( $feature['_ord_hostingvart_ribbon'] ) && 'on' == $feature['_ord_hostingvart_ribbon']  ){
									echo '<div class="ribbon ribbon-small text-white">';
										echo '<div class="ribbon-content bg-green text-uppercase">'.esc_html__('Popular', 'ordomain' ).'</div>';
									echo '</div>';
								}
								?>
							
								<div class="head border-green">
								<?php 
								if( isset( $feature['_ord_hostingvart_title'] ) ){
										echo '<h3 class="title">'.esc_html( $feature['_ord_hostingvart_title'] ).'</h3>';
								}
								if( isset( $feature['_ord_hostingvart_desc'] ) ){
									echo '<p class="desc">'.esc_html( $feature['_ord_hostingvart_desc'] ).'</p>';
								}
								if( isset( $feature['_ord_hostingvart_subtitle'] ) || isset( $feature['_ord_hostingvart_price'] ) ){
								
									echo '<div class="price">';
										if( isset( $feature['_ord_hostingvart_subtitle'] ) ){
											echo '<div>'.esc_html( $feature['_ord_hostingvart_subtitle'] ).'</div>';
										}
									echo '<div>';
									if( isset( $feature['_ord_hostingvart_price'] ) ){
										echo '<span>'.esc_html( $feature['_ord_hostingvart_price'] ).'</span>';    
									}
									if( isset( $feature['_ord_hostingvart_period'] ) ){
										echo esc_html( $feature['_ord_hostingvart_period'] );
									}
									echo '</div>';
									echo '</div>';
								
								}
								?>
								  
								</div>
								<div class="body">
									<?php 
									if( isset( $feature['_ord_hostingvart_feature'] )  ){
										
										echo '<div class="features">';
											echo '<ul>';
											foreach( $feature['_ord_hostingvart_feature'] as $singfeature ){
												echo '<li>'.esc_html( $singfeature ).'</li>';
											}
											echo '</ul>';
										echo '</div>';
										
									}else{
										esc_html_e('Please set hosting pricing table feature from admin panel hosting pricing tab', 'ordomain' );
									}
									if( isset( $feature['_ord_hostingvart_url'] ) && isset( $feature['_ord_hostingvart_btntxt'] ) ){
										
										echo '<div class="buy-now">';
											echo '<a href="'.esc_url( $feature['_ord_hostingvart_url'] ).'" class="btn btn-lg btn-custom">'.esc_html( $feature['_ord_hostingvart_btntxt'] ).'</a>';
										echo '</div>';
									}
									?>

								</div>
							</div>
						</div>
						
						<?php 
						if( $i == 3 ){
							break;
						}
						$i++;
							endforeach;
							endwhile;
							wp_reset_postdata();
						endif;
						?>

					</div>
				</div>
			</div>
            <?php 
                $i++;
                endforeach;
            endif;
            ?>

        </div>
        
    </div>
</div>
<!-- Pricing Area End -->