<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$background     = ordomain_meta_callback('hosting_bg');
$overlay        = ordomain_meta_callback('hosting_overlay');

if( $background ){
    $background = 'data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}


// Overlay
if( $overlay ){
    $overlay = ' bg--overlay';
}else{
    $overlay = '';
}

?>

<!-- Pricing Area Start -->
<div id="pricing<?php echo esc_attr( $overlay ); ?>" <?php echo wp_kses_post( $background ); ?>>
    <div class="container">
        <?php 
        // Section Title
        ordomain_section_heading(
            array(
                'subtitle'  => 'hosting_secttitle',
                'title'     => 'hosting_sectsubtitle',
            )
        );
        ?>
        <div class="row">
            <!-- Pricing Table Start -->
            <div class="pricing-table">
                <?php 
                // column set 
                
                $column = get_post_meta( $post->ID, '_ord_pricing_col', true );
                if( $column ){
                    $col = $column;
                }else{
                    $col = '4';
                }  
                
                //Pricing Item
                $tax_id =  get_post_meta( get_the_ID() , '_ord_hosting_taxonoy', true ) ;
                $args = array(
                    'post_type' => 'hosting_price',
                    'posts_per_page' => 1,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'hosting_categories',
                            'field' => 'id',
                            'terms' => $tax_id,
                        )
                    ),
                );
                
                $loop = new WP_Query( $args );
              
                if( $loop->have_posts() ):
                    while( $loop->have_posts() ): $loop->the_post(); 
                    $features = get_post_meta( $post->ID, '_ord_hostingvart_features', true ); 
                  
                    foreach( $features as $feature ):
                ?>
                <div class="col-md-<?php echo esc_attr( $col ); ?> pricing-item <?php echo ( isset( $feature['_ord_hostingvart_active'] ) && 'on' == $feature['_ord_hostingvart_active']  ) ? esc_attr('active') : ''; ?>">
                    <div class="pricing-item-content">
                        <?php 
                        if( isset( $feature['_ord_hostingvart_ribbon'] ) && 'on' == $feature['_ord_hostingvart_ribbon']  ){
                            echo '<div class="ribbon ribbon-small text-white">';
                                echo '<div class="ribbon-content bg-green text-uppercase">'.esc_html__('Popular', 'ordomain' ).'</div>';
                            echo '</div>';
                        }
                        ?>
                    
                        <div class="head border-green">
                        <?php 
                        if( isset( $feature['_ord_hostingvart_title'] ) ){
                                echo '<h3 class="title">'.esc_html( $feature['_ord_hostingvart_title'] ).'</h3>';
                        }
                        if( isset( $feature['_ord_hostingvart_desc'] ) ){
                            echo '<p class="desc">'.esc_html( $feature['_ord_hostingvart_desc'] ).'</p>';
                        }
                        if( isset( $feature['_ord_hostingvart_subtitle'] ) || isset( $feature['_ord_hostingvart_price'] ) ){
                        
                            echo '<div class="price">';
                                if( isset( $feature['_ord_hostingvart_subtitle'] ) ){
                                    echo '<div>'.esc_html( $feature['_ord_hostingvart_subtitle'] ).'</div>';
                                }
                            echo '<div>';
                            if( isset( $feature['_ord_hostingvart_price'] ) ){
                                echo '<span>'.esc_html( $feature['_ord_hostingvart_price'] ).'</span>';    
                            }
                            if( isset( $feature['_ord_hostingvart_period'] ) ){
                                echo esc_html( $feature['_ord_hostingvart_period'] );
                            }
                            echo '</div>';
                            echo '</div>';
                        
                        }
                        ?>
                          
                        </div>
                        <div class="body">
                            <?php 
                            if( isset( $feature['_ord_hostingvart_feature'] )  ){
                                
                                echo '<div class="features">';
                                    echo '<ul>';
                                    foreach( $feature['_ord_hostingvart_feature'] as $singfeature ){
                                        echo '<li>'.esc_html( $singfeature ).'</li>';
                                    }
                                    echo '</ul>';
                                echo '</div>';
                                
                            }else{
                                esc_html_e('Please set hosting pricing table feature from admin panel hosting pricing tab', 'ordomain' );
                            }
                            if( isset( $feature['_ord_hostingvart_url'] ) && isset( $feature['_ord_hostingvart_btntxt'] ) ){
                                
                                echo '<div class="buy-now">';
                                    echo '<a href="'.esc_url( $feature['_ord_hostingvart_url'] ).'" class="btn btn-lg btn-custom">'.esc_html( $feature['_ord_hostingvart_btntxt'] ).'</a>';
                                echo '</div>';
                            }
                            ?>

                        </div>
                    </div>
                </div>
                <?php 
                    endforeach;
                    endwhile;
                    wp_reset_postdata();
                endif;
                ?>
            </div>
            <!-- Pricing Table End -->
        </div>
    </div>
</div>
<!-- Pricing Area End -->