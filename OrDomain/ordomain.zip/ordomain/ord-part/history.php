<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/


$histories = ordomain_meta_callback('history_contents');
$overlay   = ordomain_meta_callback('history_overlay');
$background   = ordomain_meta_callback('history_background');

if( $background ){
    $background = 'data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}

// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}

?>

<div id="history" <?php echo wp_kses_post( $background.$overlay ); ?>>
    <div class="container">
        <?php 
        // Section Title
        ordomain_section_heading(
            array(
                'subtitle'  => 'history_subtitle',
                'title'     => 'history_secttitle',
            )
        );
        ?>
        <ul class="timeline">
        <?php 
        if( $histories ):
        $i = 1;
            foreach( $histories as $history ):
            if( $history ):
        ?>
            <li <?php echo ( $i % 2 != 1 ) ? 'class="timeline-inverted"' : ''; ?>>
                <div class="timeline-badge">
                    <i class="fa fa-circle"></i>
                </div>
                <div class="timeline-panel">
                    <?php 
                    if( isset( $history['_ord_history_content'] ) ):
                    ?>
                    <div class="timeline-body link-color--child">
                        <p><?php echo ordomain_wp_kses_allow( $history['_ord_history_content'] ); ?></p>
                    </div>
                    <?php 
                    endif;
                    // year
                    if( isset( $history['_ord_history_year'] ) ):
                    ?>
                    <div class="timeline-footer">
                        <p class="text-right"><?php echo esc_html( $history['_ord_history_year'] ); ?></p>
                    </div>
                    <?php 
                    endif;
                    ?>
                </div>
            </li>

        <?php 
           endif;
        $i++;
            endforeach;
        endif;
        ?>
        </ul>
    </div>
</div>
       