<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

//Page Header 
if( ordomain_section_bg('ord_allHeader_bg') ) {
    $backgroud = 'data-bg-img="'.esc_url( ordomain_opt('ord_allHeader_bg', 'url') ).'"';
}else {
    $backgroud = ordomain_section_bg( get_header_image() );
}
// overlay
$getoverlay = ordomain_meta_callback('sliderbg_overlay');
$globoverlay = ordomain_opt('ord_allHeader_overlay');

if( $getoverlay == 'on' ){
    $overlay = 'bg--overlay';
}elseif( $getoverlay == 'global' && $globoverlay ){
   $overlay = 'bg--overlay';
}else{
   $overlay = ''; 
}
// blog page 
if( is_blog() ){
    $overlay = 'bg--overlay';
}
?>

<div id="pageHeader" class="AdjustHeight <?php echo esc_attr( $overlay ); ?>" <?php echo wp_kses_post( $backgroud ); ?>>

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="section-title">
                <?php 
				// title
				if(  is_ordomain_woocommerce_activated() && is_shop() ){
					echo '<h2>';
						woocommerce_page_title();
					echo '</h2>';
					
				}else{

					if ( is_archive() ){
						the_archive_title('<h2>', '</h2>');
					}elseif ( is_home() ){
						echo '<h2>'.esc_html__( 'Blog', 'ordomain' ).'</h2>';
					}elseif(is_search()){
						echo '<h2>'.esc_html__( 'Search Result', 'ordomain' ).'</h2>';
					} else{
						the_title( '<h2>', '</h2>' );
					}
				}
                ?>
                </div>
                <?php 
                // page header breadcrumbs 
                if( ordomain_meta_callback('sliderbg_breadcrumbglob') == 'page' ){
                    
                    if( ordomain_meta_callback('sliderbg_breadcrumbon') == 'show' ){
                        ordomain_breadcrumbs();   
                    }
                    
                }else{
                    if( ordomain_opt('ord_enable_breadcrumb') ){
                        ordomain_breadcrumbs();   
                    }
                }
                
                ?>
            </div>
        </div>
    </div>
</div>
<!-- Page Header End -->