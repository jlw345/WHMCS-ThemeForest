<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$overlay    = ordomain_meta_callback('bulkdom_overlay');
$background    = ordomain_meta_callback('bulk_domain_bg');

if( $background ){
    $background = 'data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}

// Overlay
if( $overlay ){
    $overlay = ' bg--overlay';
}else{
    $overlay = '';
}



?>

<div id="banner" class="bulkdom AdjustHeight<?php echo esc_attr( $overlay ); ?>" <?php echo wp_kses_post( $background ); ?>>
    <div class="container">
        <div class="vc-parent">
            <div class="vc-child">
                <div class="banner-content banner--secondary">
                <?php 
                if( ordomain_meta_callback('bulk_domain_ribbon') ){
                    
                    echo '<div class="ribbon text-white">';
                        echo '<div class="ribbon-content bg-green">';
                            echo ordomain_meta_callback('bulk_domain_ribbon');
                        echo '</div>';
                    echo '</div>';  
                }
                
                // Title, sub title, description 
                
                if( ordomain_meta_callback('bulk_domain_subtitle') || ordomain_meta_callback('bulk_domain_title') || ordomain_meta_callback('bulk_domain_description') ){
                    
                    echo '<div class="title text-black">';
                        if( ordomain_meta_callback('bulk_domain_subtitle') ){
                            
                           echo '<p class="paragraph-large">'.esc_html( ordomain_meta_callback('bulk_domain_subtitle') ).'</p>';
                           
                        }
                        if( ordomain_meta_callback('bulk_domain_title') ){
                            
                            echo '<h2>'.esc_html( ordomain_meta_callback('bulk_domain_title') ).'</h2>';
                        }
                        if( ordomain_meta_callback('bulk_domain_description') ){
                            echo '<p class="paragraph-small">'.esc_html( ordomain_meta_callback('bulk_domain_description') ).'</p>';
                        }
                    echo '</div>';
                }
  
                // domain checker action url
                if( ordomain_meta_callback('BulkDomCheck_whmcsurl') ){
                    
                    $url = ordomain_meta_callback('BulkDomCheck_whmcsurl');
           
                }else{
                    $url = '#';
                }
                ?>    
                    
                    <form action="<?php echo esc_url( $url ); ?>" method="post" id="bulkDomainSearchForm">
                        <div class="row">
                            <div class="col-md-8">
                                <textarea rows="8" name="bulkdomains" id="bulkdomains" class="form-control"></textarea>
                            </div>
                            <div class="col-md-4">
                                <div class="extensions">
                                    <div class="row">
                                        <?php 
                                        // domain extension
                                        $extesions = ordomain_meta_callback('bulk_domain_extesion');
                                        
                                        if( is_array( $extesions ) ){
                                            foreach( $extesions as $extesion ){
                                                if( $extesion ){
                                                    echo '<div class="col-sm-3 col-xs-6">';
                                                        echo '<input type="checkbox" name="'.esc_attr( $extesion ).'" value="'.esc_attr( $extesion ).'" checked disabled>';
                                                        echo '<label>'.esc_html( $extesion ).'</label>';
                                                    echo '</div>';     
                                                } 
                                            } 
                                        }
                                        ?>  
                                    </div>
                                </div>
                                <button class="submit-btn btn btn-custom btn-blue" type="submit"><?php esc_html_e( 'SEARCH', 'ordomain' ); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>