<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/
?>
<!-- Navigation Area Start -->
<nav id="navigation">
    <?php 
        if( function_exists('ordomain_social_media') || ordomain_opt('ord_header_email') || ordomain_opt('ord_header_tel') || ordomain_opt('ord_login_url') || ordomain_opt('ord_signup_url') ) {
    ?>
    <div class="contact-bar">
        <div class="container">
            <?php 
                // social media
                if( function_exists('ordomain_social_media') ) {
                    ordomain_social_media(
                        array(
                            'wrp_class' => 'social-icons pull-left',
                            'ul_class' => 'nav nav-tabs'
                        )
                    );
                }

                if( ordomain_opt('ord_header_email') ){
                    echo '<div class="contact-bar--text pull-left">';
                        echo '<p><a href="mailto:'.sanitize_email( ordomain_opt('ord_header_email') ).'"><i class="fa fm fa-envelope-o"></i>'.sanitize_email( ordomain_opt('ord_header_email') ).'</a></p>';
                    echo '</div>';  
                } 
                
                if( ordomain_opt('ord_header_tel') ){
                    echo '<div class="contact-bar--text pull-left">';
                        echo '<p><a href="tel:'.esc_html( ordomain_opt('ord_header_tel') ).'"><i class="fa fm fa-phone"></i>'.esc_html( ordomain_opt('ord_header_tel') ).'</a></p>';
                    echo '</div>';                    
                }
                
                if( ordomain_opt('ord_login_url') || ordomain_opt('ord_signup_url') ){
                    
                    echo '<div class="contact-bar--text text-capitalize pull-right">';
                        echo '<p>';
                        if( ordomain_opt('ord_login_url') ){
                            echo '<a href="'.esc_url( ordomain_opt('ord_login_url') ).'"><i class="fa fm fa-user"></i>'.esc_html__( 'login', 'ordomain' ).'</a>';
                        }
                        
                        if( ordomain_opt('ord_signup_url') ){
                            echo '<span class="slash">/</span><a href="'.esc_url( ordomain_opt('ord_signup_url') ).'"><i class="fa fm fa-user-plus"></i>'.esc_html__('signup','ordomain').'</a>';   
                        }
                        
                        echo '</p>';
                    echo '</div>';   
                }
                
            ?>

        </div>
    </div>
    <?php } ?>
    <div class="navbar">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
                    <span class="sr-only"><?php esc_html_e('Toggle navigation', 'ordomain' ); ?></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php 
                //Site Logo
                if( has_custom_logo() ){
                    the_custom_logo();
                    
                }elseif( ordomain_theme_logo() ){
                    echo ordomain_theme_logo();
                    
                }else{
                    echo '<a href="'.esc_url( home_url('/') ).'" class="navbar-brand"><div class="vc-parent"><div class="vc-child">';
                        bloginfo('name');
                    echo '</div></div></a>';
                }
                ?>
            </div>
            <div id="navbar" class="navbar-collapse collapse navbar-right reset-padding">
                <?php 
                //Navigation
                if( has_nav_menu('primary-menu') ){
                    $args = array(
                        'theme_location' => 'primary-menu',
                        'menu_class'     => 'nav navbar-nav',
                        'fallback_cb'    => 'wp_bootstrap_navwalker::fallback',
                        'walker'         => new wp_bootstrap_navwalker(),
                    );
                    
                    wp_nav_menu( $args );
                }
                ?>
            </div>
        </div>
    </div>
</nav>
<!-- Navigation Area End -->