<?php 
/**
 * @version: 1.5
 * @package: OrDomain
 * @author: Themelooks
 * @Support: <support@themelooks.com>
 * @website: themelooks.com
 *
 */

$sliders = ordomain_meta_callback('slider_contents');
$backgroud = ordomain_meta_callback('sliderbg_img');
$videobg = ordomain_meta_callback('sliderbg_video');
$speed = ordomain_meta_callback('slider_speed');
$pause = ordomain_meta_callback('slider_pause');
$loop = ordomain_meta_callback('slider_loop');

// speed default value set
if( $speed ){
    $speed = $speed;
}else{
    $speed = '800';
}
//
if( $loop ){
	$loop = $loop;
}else{
	$loop = false;
}
// pause default value set
if( $pause ){
    $pause = $pause;
}else{
    $pause = '4000';
}

$sliddata = json_encode( array( 'speed' => esc_html( $speed ), 'pause' => esc_html( $pause ), 'loop' => esc_html( $loop ) ) );

$getoverlay = ordomain_meta_callback('sliderbg_overlay');
$globoverlay = ordomain_opt('ord_allHeader_overlay');

if( $getoverlay == 'on' ){
    $overlay = 'bg--overlay';
}elseif( $getoverlay == 'global' && $globoverlay ){
   $overlay = 'bg--overlay';
}else{
   $overlay = ''; 
}

?>
<!-- Service Area Start -->
<div id="service" class="service-primary <?php echo esc_attr( $overlay ); ?>" data-bg-img="<?php echo esc_url( $backgroud ); ?>">
<?php 

if( $videobg ){
   echo '<div class="bg-video" data-bg-video="'.$videobg.'"></div>'; 
}

?>
    
    <div class="vc-parent">
        <div class="vc-child">
            <div id="slideData" class="service-slider" data-slid-options="<?php echo esc_attr( $sliddata ); ?>">
                <?php 
                if( $sliders ):
                    foreach( $sliders as $slider ):
                ?>
                    <div class="item">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-6">
                                <?php 
                                if( isset( $slider['_ord_slider_img'] ) ):
                                ?>
                                    <div class="image">
                                        <img src="<?php echo esc_url( $slider['_ord_slider_img'] ); ?>" alt="">
                                    </div>
                                <?php 
                                endif;
                                
                                if( ( isset( $slider['_ord_Pricetag_text'] ) && !empty( $slider['_ord_Pricetag_text'] ) ) || ( isset( $slider['_ord_Pricetag_Price'] ) && !empty( $slider['_ord_Pricetag_Price'] ) ) || ( isset( $slider['_ord_Pricetag_duration'] ) && !empty( $slider['_ord_Pricetag_duration'] ) ) ) :
                                ?>
                                    <div class="price-tag bg-green">
                                        <p><?php echo esc_html( $slider['_ord_Pricetag_text'] ); ?><span><?php echo esc_html( $slider['_ord_Pricetag_Price'] ); ?><em><?php echo esc_html( $slider['_ord_Pricetag_duration'] ); ?></em></span></p>
                                    </div>
                                <?php 
                                endif;
                                ?>
                                </div>
                                <div class="col-md-6">
                                    <div class="content">
                                    <?php 
                                    // slider title
                                    if( isset( $slider['_ord_slid_subTitle'] ) ){
                                        echo '<p class="subtitle">'.esc_html( $slider['_ord_slid_subTitle'] ).'</p>';
                                    }
                                    if( isset( $slider['_ord_slid_title'] ) ){
                                        echo '<h2 class="text-green">'.esc_html( $slider['_ord_slid_title'] ).'</h2>';
                                    }
                                    // editor
                                    if( isset( $slider['_ord_slid_editor'] ) ) {
                                        echo '<p>'.ordomain_wp_kses_allow( $slider['_ord_slid_editor'] ) .'</p>';
                                    } 
                                    // list content
                                    if( isset( $slider['_ord_slid_listcontent'] ) ) {
                                        echo '<ul>';
                                            foreach( $slider['_ord_slid_listcontent'] as $list ){
                                                echo '<li>';
                                                    echo '<p><i class="fa fa-check text-green"></i>&nbsp; '.esc_html( $list ).'</p>';
                                                echo '</li>';
                                            }
                                        echo '</ul>';
                                    } 
                                    
                                    // slider button
                                    if( isset( $slider['_ord_slid_button'] ) && isset( $slider['_ord_slid_buttonLink'] ) ){
                                        echo '<div class="content--footer">';
                                        
                                            echo '<a href="'.esc_url( $slider['_ord_slid_buttonLink'] ).'" class="btn btn-lg btn-custom btn-green">'.esc_html( $slider['_ord_slid_button'] ).'</a>';
                                            
                                        echo '</div>';    
                                    }
                                    ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php 
                    endforeach;
                endif;
                ?>
            </div>
        </div>
    </div>
</div>
<!-- Service Area End -->