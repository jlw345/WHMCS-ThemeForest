<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/


$contents = ordomain_meta_callback('contactAction_contents');
$overlay =  ordomain_meta_callback('contactAction_overlay');
$background =  ordomain_meta_callback('contactAction_background');

if( $background ){
    $background = ' data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}

if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}

?>
<div id="contactActionsgolb"<?php echo wp_kses_post( $background.$overlay ); ?>>
    <div class="container">
        <div class="row">
        <?php 
        // Section Title
        ordomain_section_heading(
            array(
                'subtitle'  => 'contactAction_subtitle',
                'title'     => 'contactAction_secttitle',
            )
        );
        
        // contact action
        
        if( $contents ):
            foreach( $contents as $content ):
                if( isset( $content['_ord_contactAction_title'] ) ):
        ?>
                <div class="col-sm-3">
                    <div class="ca-holder">
                        <?php 
                        // icon 
                        if( isset( $content['_ord_contactAction_icon_type'] ) && $content['_ord_contactAction_icon_type'] == 'icon' ){
                            
                            if( isset( $content['_ord_contactAction_icon'] ) && $content['_ord_contactAction_icon'] ){
                                
                                echo '<div class="ca-icon"><i class="fa '.esc_html( $content['_ord_contactAction_icon'] ).'"></i></div>';
                            }
                        }
                        // image icon
                        if( isset( $content['_ord_contactAction_icon_type'] ) && $content['_ord_contactAction_icon_type'] == 'image' ){
                            
                            $imgIcon = $content['_ord_contactAction_imgicon'];
                            if( isset( $imgIcon ) && $imgIcon ){
                                echo '<div class="ca-icon">';
                                    echo '<img src="'.esc_url( $imgIcon ).'" class="ca-imgicon" alt="'.ordomain_image_alt( esc_url( $imgIcon ) ).'" />';
                                echo '</div>';
                            }
                        }
                        // title
                        if( isset( $content['_ord_contactAction_title'] ) ){
                            
                            echo '<h4 class="ca-text">'.esc_html( $content['_ord_contactAction_title'] ).'</h4>';
                        }
                        if( isset( $content['_ord_contactAction_desc'] ) ){
                            
                           echo '<p class="sum">'.esc_html( $content['_ord_contactAction_desc'] ).'</p>'; 
                        }
                        if( isset( $content['_ord_contactAction_btnurl'] ) && isset( $content['_ord_contactAction_btntext'] ) ){
                            
                            echo '<a href="'.esc_url( $content['_ord_contactAction_btnurl'] ).'" class="btn btn-custom">'.esc_html( $content['_ord_contactAction_btntext'] ).'</a>';
                        }
                        ?>
                    </div>
                </div>
        <?php 
                endif;
            endforeach;
        endif;
        ?>
        </div>
    </div>
</div>