<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

// Background image
$background = ordomain_meta_callback('home_dom_check_background');
$overlay    = ordomain_meta_callback('homeDomCheck_overlay');

if( $background ){
    $background = 'data-bg-img="'.esc_url( $background ).'"';
}else{
    $background = '';
}



// Overlay
if( $overlay ){
    $overlay = ' bg--overlay';
}else{
    $overlay = '';
}

?>

<div id="banner" class="banner-primary AdjustHeight <?php echo esc_attr( $overlay ); ?>" <?php echo wp_kses_post( $background ); ?>>
    <div class="container">
        <?php 
        // Section Title 
        ordomain_section_heading(
            array(
                'subtitle'  => 'home_dom_check_subtitle',
                'title'     => 'home_dom_check_secttitle',
            )
        );
        
        // domain checker action url
        if( ordomain_meta_callback('home_domCheck_whmcsurl') ){
            
            //$url = trailingslashit( ordomain_meta_callback('home_domCheck_whmcsurl') ).'domainchecker.php';
            
            $url = ordomain_meta_callback('home_domCheck_whmcsurl');
   
        }else{
            $url = '#';
        }

        ?>
        <!-- Banner Content Start -->
        <div class="banner-content">
            <div class="row">
                <div class="col-md-6">
                    <div class="domain--search">
                        <form action="<?php echo esc_url( $url ); ?>" method="post" id="domainSearchForm" class="clearfix">
                            <div class="form-group">
                                <div class="input-group">
                                    <input type="text" name="domain" class="form-control" placeholder="eg. example">
                                    <span class="input-group-addon">
                                        <input type="submit" value="Search" class="form-control">
                                    </span>
                                </div>
                            </div>
                            <div class="row extensions">
                            <?php 
                            if( ordomain_meta_callback('extension_radion') ){
                                $i = 1;
                                foreach( ordomain_meta_callback('extension_radion') as $ext ){
                                    
                                    if( $i == 1){
                                        $checked = 'checked';
                                    }else{
                                        $checked ='';
                                    }
                                    
                                    echo '<div class="col-sm-2 col-xs-6">';
                                        echo '<input type="radio" name="ext" '.esc_attr( $checked ).' value=".'.esc_attr( $ext ).'" id="ext'.esc_attr( $ext ).'">';
                                        echo '<label for="ext'.esc_attr( $ext ).'">.'.esc_html( $ext ).'</label>';
                                    echo '</div>';  
                                $i++;
                                }  
                            }
                            ?>    
                            </div>
                        </form>
                    </div>
                    <div class="extension-slider-holder">
                        <?php 
                        //extension slider 
                        ordomain_extension_slider( ordomain_meta_callback('extension_slider') );
                        ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="domain--addons">
                        <?php 
                        if( ordomain_meta_callback('homeDomCheck_featureTitle') ){
                            echo '<h2>'.esc_html( ordomain_meta_callback('homeDomCheck_featureTitle') ).'</h2>';
                        }
                        
                        $features = ordomain_meta_callback('homeDomCheck_features');
                        
                        if( $features ) {
                            echo '<ul>';
                                foreach( $features as $feature ) {
                                    echo '<li>';
                                        // icon
                                        if( isset( $feature['_ord_homeDomCheck_icon_type'] ) && $feature['_ord_homeDomCheck_icon_type'] == 'icon' ){
                                            
                                            if( isset( $feature['_ord_homeDomCheck_features_icon'] ) && $feature['_ord_homeDomCheck_features_icon'] ){
                                                 echo '<i class="fa '.esc_html( $feature['_ord_homeDomCheck_features_icon'] ).'"></i>';
                                            }
                                        }
                                        // Image Icon
                                        if( isset( $feature['_ord_homeDomCheck_icon_type'] ) && $feature['_ord_homeDomCheck_icon_type'] == 'image' ){
                                            
                                            $imgIcon = $feature['_ord_homeDomCheck_features_imgicon'];
                                            if( isset( $imgIcon ) && $imgIcon ){
                                                echo '<div class="domcheck-imgbox">';
                                                    echo '<img src="'.esc_url( $imgIcon ).'" class="domcheck-imgicon" alt="'.ordomain_image_alt( esc_url( $imgIcon ) ).'" />';
                                                echo '</div>';
                                            }
                                        }
                                        // name
                                        if( isset( $feature['_ord_homeDomCheck_features_name'] ) ){
                                           echo '<h3>'.esc_html( $feature['_ord_homeDomCheck_features_name'] ).'</h3>'; 
                                        }
                                        if( isset( $feature['_ord_homeDomCheck_features_desc'] ) ){
                                            echo '<p>'.esc_html( $feature['_ord_homeDomCheck_features_desc'] ).'</p>';
                                        }
                                        
                                    echo '</li>'; 
                                }
                            echo '</ul>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>