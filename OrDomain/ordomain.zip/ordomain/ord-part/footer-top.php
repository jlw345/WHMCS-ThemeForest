<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/
?>
<div class="footer-widgets">
    <div class="bottom">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <?php 
                    //Payment Methods
                    if( ordomain_opt('ord_footertop_accpet', 'url') ){
                        echo '<div class="payment-methods">';
                            echo ''.esc_html_e( 'We Accpet', 'ordomain' ).': <img src="'.esc_url( ordomain_opt('ord_footertop_accpet', 'url') ).'" alt="we-accpet">';
                        echo '</div>';    
                    }
                    ?>
                </div>
                <div class="col-sm-6">
                    <div class="social-links">
                        <ul>
                            <?php 
                                echo ordomain_social();
                            ?>
                        </ul> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>