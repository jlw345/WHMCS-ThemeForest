<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

if( ordomain_meta_callback('faqTab_heading') ){
    $heading = ordomain_meta_callback('faqTab_heading');
}else{
    $heading = esc_html__( 'categories', 'ordomain' );
}

?>

<!-- FAQ Area Start -->


<div id="faq" class="bg-white">
    <div class="container">
    
        <div class="col-sm-3 faq-categories">
            <h3><?php echo esc_html( $heading ); ?></h3>
            <ul class="nav" role="tablist">
            <?php
            $tabargs = array(
                'taxonomy' => 'faq_categories',
                'hide_empty' => false
            );
            $tabTerms = get_terms( $tabargs );
            if( is_array( $tabTerms ) ){
                $i = 1;
                foreach( $tabTerms as $tabTerm ){
                    if( $i != 1 ){
                        $class = "";
                    }else{
                       $class = "active"; 
                    }
                    
                    echo '<li role="presentation" class="'.esc_attr( $class ).'"><a href="#'.esc_attr( $tabTerm->slug ).'" aria-controls="'.esc_attr( $tabTerm->slug ).'" role="tab" data-toggle="tab">'.esc_html( $tabTerm->name ).'</a></li>';
                    
                $i++;
                }
            }
            ?>
      
            </ul>
        </div>
        <div class="col-sm-9 faq-content">
            <div class="tab-content">
            <?php 
            $j = 1;
            foreach( $tabTerms as $tabTerm ):
            ?>
                <div role="tabpanel" class="tab-pane fade <?php echo ($j == 1 )? esc_attr( 'in active' ) : ''; ?>" id="<?php echo esc_attr( $tabTerm->slug ); ?>">
                    <div class="panel-group accordion" id="accordion<?php echo esc_html( $j ); ?>" role="tablist">
                        <!-- Accordion Item Start -->
                           
                        
                        <?php 
                        $tabargs = array(
                            'post_type'      => 'faq',
                            'posts_per_page' => 1,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'faq_categories',
                                    'field'    => 'id',
                                    'terms'    => $tabTerm->term_id,
                                )
                            )

                        );
                        
                        $tabloop = new WP_Query( $tabargs );
                        if( $tabloop->have_posts() ) :
                        
                            while( $tabloop->have_posts() ): $tabloop->the_post();
                            
                            $faq_contents = ordomain_meta_callback('faq_contents');
                            $i = 1;
                            foreach( $faq_contents as $faq_content ):
                            ?>
                                <div class="panel panel-default <?php echo ( $i == 1)? 'active' : ''; ?>">
                                    <div class="panel-heading" role="tab">
                                        <a href="#sharedTabQ-<?php echo esc_attr( $tabTerm->term_id.'-'.$i ); ?>" class="<?php echo ( $i == 1)? '' : esc_attr( 'collapsed' ); ?>" data-toggle="collapse" data-parent="#accordion<?php echo esc_html( $j ); ?>" role="button">
                                            <h4 class="panel-title"><?php echo esc_html( $faq_content['_ord_faq_title'] ); ?> <i class="fa fa-minus"></i></h4>
                                        </a>
                                    </div>
                                    <div id="sharedTabQ-<?php echo esc_attr( $tabTerm->term_id.'-'.$i ); ?>" class="panel-collapse collapse <?php echo ( $i == 1)? esc_attr( 'in' ) : ''; ?>" role="tabpanel">
                                        <div class="panel-body link-color--child">
                                            <?php 
                                                if( $faq_content['_ord_faq_desc'] ){
                                                    echo '<p>'.ordomain_wp_kses_allow( $faq_content['_ord_faq_desc'] ).'</p>';
                                                }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            <?php
                                $i++;
                                endforeach;
                            endwhile;
                             wp_reset_postdata();
                        endif;
                        ?>
                    </div>
                </div>
            <?php 
            $j++;
            endforeach;
            ?>
            </div>
        </div>
    </div>
</div>
<!-- FAQ Area End -->