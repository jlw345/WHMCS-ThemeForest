<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$vpsSlid = ordomain_opt('ord_vpspricing_version');

switch( $vpsSlid ){
    
    case '1' : get_template_part('ord-part/vpspricing-vr1');
        break;
    case '2' : get_template_part('ord-part/vpspricing-vr2');
        break;
    default : 
        #......
        break;
}
?>
