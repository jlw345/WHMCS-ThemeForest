<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

// Background image
$background = ordomain_meta_callback('counter_background');
$overlay    = ordomain_meta_callback('counter_overlay');

if( $background ){
    $background = ' data-bg-img="'.esc_url( $background ).'"';
}else{
    $background = '';
}

// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}


$counteres = ordomain_meta_callback('counter_contents');

?>
<!-- Counter Area Start -->
<div id="counter"<?php echo wp_kses_post( $background.$overlay ); ?>>
    <div class="container">
        <?php 
        // Section Title 
        ordomain_section_heading(
            array(
                'subtitle'  => 'counter_subtitle',
                'title'     => 'counter_secttitle',
            )
        );
        ?>
        <div class="row">
            <?php 
            if( $counteres ){
                foreach( $counteres as $counter ){
            ?>
                <div class="col-sm-3 col-xs-6">
                    <div class="counter-holder">
                        <div class="counter-number-holder">
                        <?php
                        // icon counter_imgicon
                        if( isset( $counter['_ord_counter_icon_type'] ) && $counter['_ord_counter_icon_type'] == 'icon'  ){
                            
                            if( isset( $counter['_ord_counter_icon'] ) && $counter['_ord_counter_icon'] ) {
                                echo '<i class="fa '.esc_html( $counter['_ord_counter_icon'] ).'"></i>';
                            }
                        }
                        // image icon
                        if( isset( $counter['_ord_counter_icon_type'] ) && $counter['_ord_counter_icon_type'] == 'image'  ){
                            $imgIcon = $counter['_ord_counter_imgicon'];
                            if( isset( $imgIcon ) && $imgIcon ){
                                echo '<img src="'.esc_url( $imgIcon ).'" class="counter-imgicon" alt="'.ordomain_image_alt( esc_url( $imgIcon ) ).'" />';
                            }
                        }
                        // number
                        if( isset( $counter['_ord_counter_number'] ) ){
                            echo '<span class="counter-number">'.esc_html( $counter['_ord_counter_number'] ).'</span>'; 
                        }
                        ?>                            
                        </div>
                        <?php 
                        if( isset( $counter['_ord_counter_title'] ) ){
                            echo ' <p class="counter-text">'.esc_html( $counter['_ord_counter_title'] ).'</p>';
                        }
                        ?>
                    </div>
                </div>
            <?php
                }                
            }
            ?>

        </div>
    </div>
</div>
<!-- Counter Area End -->