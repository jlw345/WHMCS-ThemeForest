<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

if( have_posts() ):
while( have_posts()):the_post();

$ids = get_post_meta( $post->ID, '_ord_sections_ids', true );

$sections = json_decode( $ids );

if( $sections ){
    foreach( $sections as $section ){
        switch( $section ){
            
            case 'services' : get_template_part('ord-part/features');
                break;
            case 'counter' : get_template_part('ord-part/counter');
                break;
            case 'testimonial' : get_template_part('ord-part/testimonail');
                break;
            case 'team' : get_template_part('ord-part/team');
                break;
            case 'subscribe' : get_template_part('ord-part/subscribe');
                break;
            case 'flat-content' : get_template_part('ord-part/flat-content');
                break;
            case 'flat-content-one' : get_template_part('ord-part/flat-content-one');
                break;
            case 'blog' : get_template_part('ord-part/blog');
                break;
            case 'faq' : get_template_part('ord-part/faq');
                break;
            case 'faq-tab' : get_template_part('ord-part/faq-tab');
                break;
            case 'history' : get_template_part('ord-part/history');
                break;
            case 'vps-slide' : get_template_part('ord-part/vpspricing');
                break;
            case 'affiliate-features' : get_template_part('ord-part/affiliate-features');
                break;
            case 'affiliate-counter' : get_template_part('ord-part/affiliate-counter');
                break;
            case 'affiliate-price' : get_template_part('ord-part/affiliate-pricing');
                break;
            case 'affiliate-action' : get_template_part('ord-part/contact-action');
                break;
            case 'home-domain-checker' : get_template_part('ord-part/homeDomain-checker');
                break;
            case 'bulkdomainchecker' : get_template_part('ord-part/bulkDomain-checker');
                break;
            case 'domain-and-hosting-feature' : get_template_part('ord-part/reseller-features');
                break;
            case 'domain-price' : get_template_part('ord-part/domain-pricing');
                break;
            case 'dedicated-pricing' : get_template_part('ord-part/dedicated-pricing');
                break;
            case 'dedicated-price-tab' : get_template_part('ord-part/dedicated-pricing-tab');
                break;
            case 'hosting-price' : get_template_part('ord-part/hosting-pricing');
                break;
            case 'pricing-tab' : get_template_part('ord-part/pricing-tab');
                break;
            case 'domain-extension' : get_template_part('ord-part/domain-ext');
                break;
            case 'extra-feature' : get_template_part('ord-part/extrafeature');
                break;
            case 'multiLocationMap' : get_template_part('ord-part/datacenter-map');
                break;
            default:
                #....
                break;
        }
    }
}

 
// If comments are open comment template.
if ( comments_open() || get_comments_number() ) {
    comments_template();
}
endwhile;
wp_reset_postdata();
else :
    get_template_part( 'template/content', 'none' );
endif;

