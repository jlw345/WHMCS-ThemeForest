<?php 
/**
 * @version: 1.5
 * @package: OrDomain
 * @author: Themelooks
 * @Support: <support@themelooks.com>
 * @website: themelooks.com
 *
 */

$sections_features = ordomain_meta_callback('dnh_features_tables');

?>

<?php 

foreach( $sections_features as $sect_feature ):

if( isset( $sect_feature['_ord_bg_color'] ) && $sect_feature['_ord_bg_color'] == 'bg-whitesmoke' )

{
  $bg =  $sect_feature['_ord_bg_color']; 
}else{
   $bg = ''; 
}

// Set Column 
if( !empty( $sect_feature['_ord_dnh_col'] ) ){
    
    switch( $sect_feature['_ord_dnh_col'] ){
        case '2':
            $col = '6';
            break;
        case '3':
            $col = '4';
            break;
        case '4':
            $col = '3';
            break;
        default :
            $col = '3';
            break;
    }
    
}else{
    $col = '3';
}

?>

<div class="pricing-details <?php echo esc_attr( $bg ); ?>">
    <div class="container">
        <?php 
        // Section Title
            if( isset( $sect_feature['_ord_dnh_title'] ) || isset( $sect_feature['_ord_dnh_subtitle'] ) ){
               echo '<div class="section-title">';
                    if( isset( $sect_feature['_ord_dnh_subtitle'] ) ){
                        
                        echo '<p>'.esc_html( $sect_feature['_ord_dnh_subtitle'] ).'</p>';
                    }
                   
                    if( isset( $sect_feature['_ord_dnh_title'] ) ){
                        
                        echo '<h2>'.esc_html( $sect_feature['_ord_dnh_title'] ).'</h2>';
                    }
               echo '</div>';   
            }
        ?>
        <div class="row reset-gutter">
            <?php 
            // Feature One
            if( isset( $sect_feature['_ord_dnh_feature_1'] ) && is_array( $sect_feature['_ord_dnh_feature_1'] ) ):
            ?>
                <div class="col-md-<?php echo esc_attr($col); ?> pricing-details-item<?php echo ( isset( $sect_feature['_ord_dnh_featurelefttitle'] ) && $sect_feature['_ord_dnh_featurelefttitle'] == 'on' ) ? ' head' : ' body';  ?>">
                    <?php 
                    if( isset( $sect_feature['_ord_dnh_topTitleactive'] ) && $sect_feature['_ord_dnh_topTitleactive'] == 'on' ){
                        
                       $hide =  '';
                    }else{
                        $hide =  ' hidden-md hidden-lg'; 
                    }
                    
                    if( isset( $sect_feature['_ord_dnh_topTitle1'] ) && $sect_feature['_ord_dnh_topTitle1'] ){
                        
                        echo '<div class="heading'.esc_attr( $hide ).'">';
                        
                            if( empty( $sect_feature['_ord_dnh_featurelefttitle'] ) ){
                                
                                if( isset( $sect_feature['_ord_dnh_topTitle1'] ) ){
                                    echo '<h3>'.esc_html( $sect_feature['_ord_dnh_topTitle1'] ).'</h3>';  
                                }
                                 
                            }
                        
                        echo '</div>';
                    }
                    ?>
                    <div class="content">
                        <ul>
                        <?php 
                        foreach( $sect_feature['_ord_dnh_feature_1'] as $leftTitle ):
                        
                                $check = strstr( $leftTitle, 'fa-');
                               
                                if( $check ){
                                    echo '<li><i class="fa '. esc_html( $leftTitle ) .'"></i></li>';
                                }else{
                                    echo '<li>'. esc_html( $leftTitle ) .'</li>';   
                                }
                                
                        endforeach;
                        ?>
                        </ul>
                        
                        <?php 
                        if( isset( $sect_feature['_ord_dnh_feature_1_btn'] ) && isset( $sect_feature['_ord_dnh_feature_1btnurl'] ) && !empty( $sect_feature['_ord_dnh_feature_1btnurl'] ) ){
                            
                            echo '<div class="action-btn">';
                            
                                echo '<a href="'.esc_url( $sect_feature['_ord_dnh_feature_1btnurl'] ).'" class="btn btn-custom">'.esc_html( $sect_feature['_ord_dnh_feature_1_btn'] ).'</a>';
                                
                            echo '</div>';
                        }
                        ?>
                        
                    </div>
                </div>
            <?php 
            endif;
            ?>
            
            <?php 
            // Feature Two
            if( isset( $sect_feature['_ord_dnh_feature_2'] ) && is_array( $sect_feature['_ord_dnh_feature_2'] ) ):
            ?>
                <div class="col-md-<?php echo esc_attr($col); ?> pricing-details-item body">
                    <?php 
                    if( isset( $sect_feature['_ord_dnh_topTitle2'] ) && $sect_feature['_ord_dnh_topTitle2'] ){
                        
                        echo '<div class="heading'.esc_attr( $hide ).'">';
                            if( isset( $sect_feature['_ord_dnh_topTitle2'] ) ){
                            echo '<h3>'.esc_html( $sect_feature['_ord_dnh_topTitle2'] ).'</h3>';    
                            }
                        echo '</div>';
                        
                    }
                    ?>
                    
                    <div class="content">
                        <ul class="text-center">
                            <?php 
                            foreach( $sect_feature['_ord_dnh_feature_2'] as $featureTwo ){
                                
                                $check = strstr( $featureTwo, 'fa-');
                               
                                if( $check ){
                                    echo '<li><i class="fa '. esc_html( $featureTwo ) .'"></i></li>';
                                }else{
                                    echo '<li>'. esc_html( $featureTwo ) .'</li>';   
                                }
                               
                            }
                            ?>
                        </ul>
                        <?php 
                        if( isset( $sect_feature['_ord_dnh_feature_2_btn'] ) && isset( $sect_feature['_ord_dnh_feature_2btnurl'] ) && !empty( $sect_feature['_ord_dnh_feature_2btnurl'] ) ){
                            
                            echo '<div class="action-btn">';
                            
                                echo '<a href="'.esc_url( $sect_feature['_ord_dnh_feature_2btnurl'] ).'" class="btn btn-custom">'.esc_html( $sect_feature['_ord_dnh_feature_2_btn'] ).'</a>';
                                
                            echo '</div>';
                        }
                        ?>

                    </div>
                </div>
            <?php 
            endif;
            ?>
            
            <?php 
            // Feature Three
            if( isset( $sect_feature['_ord_dnh_feature_3'] ) && is_array( $sect_feature['_ord_dnh_feature_3'] ) ):
            ?>
                <div class="col-md-<?php echo esc_attr($col); ?> pricing-details-item body">
                    <?php 
                    if( isset( $sect_feature['_ord_dnh_topTitle3'] ) && $sect_feature['_ord_dnh_topTitle3'] ){
                        
                        echo '<div class="heading'.esc_attr( $hide ).'">';
                        if( isset( $sect_feature['_ord_dnh_topTitle3'] ) ){
                            echo '<h3>'.esc_html( $sect_feature['_ord_dnh_topTitle3'] ).'</h3>';    
                        }  
                        echo '</div>';
                        
                    }
                    ?>
                    
                    <div class="content">
                        <ul class="text-center">
                            <?php 
                            if( isset( $sect_feature['_ord_dnh_feature_3'] ) && is_array( $sect_feature['_ord_dnh_feature_3'] ) ){
                                
                                foreach( $sect_feature['_ord_dnh_feature_3'] as $featureThree ){
                                    
                                    $check = strstr( $featureThree, 'fa-');
                                   
                                    if( $check ){
                                        echo '<li><i class="fa '. esc_html( $featureThree ) .'"></i></li>';
                                    }else{
                                        echo '<li>'. esc_html( $featureThree ) .'</li>';   
                                    }
                                   
                                }
                            }
                            ?>
                        </ul>
                        <?php 
                        if( isset( $sect_feature['_ord_dnh_feature_3_btn'] ) && isset( $sect_feature['_ord_dnh_feature_3btnurl'] ) && !empty( $sect_feature['_ord_dnh_feature_2btnurl'] ) ){
                            
                            echo '<div class="action-btn">';
                            
                                echo '<a href="'.esc_url( $sect_feature['_ord_dnh_feature_3btnurl'] ).'" class="btn btn-custom">'.esc_html( $sect_feature['_ord_dnh_feature_3_btn'] ).'</a>';
                                
                            echo '</div>';
                        }
                        ?>

                    </div>
                </div>
            <?php 
            endif;
            ?>
            
            <?php 
            // Feature Four
            if( isset( $sect_feature['_ord_dnh_feature_4'] ) && is_array( $sect_feature['_ord_dnh_feature_4'] ) ):
            ?>
                <div class="col-md-<?php echo esc_attr($col); ?> pricing-details-item body">
                    <?php 
                    if( isset( $sect_feature['_ord_dnh_topTitle4'] ) && $sect_feature['_ord_dnh_topTitle4'] ){
                        
                        echo '<div class="heading'.esc_attr( $hide ).'">';
                        
                        if( isset( $sect_feature['_ord_dnh_topTitle4'] ) ){
                            
                            echo '<h3>'.esc_html( $sect_feature['_ord_dnh_topTitle4'] ).'</h3>';    
                        }
                            
                        echo '</div>';
                        
                    }
                    ?>
                    
                    <div class="content">
                        <ul class="text-center">
                            <?php 
                            if( isset( $sect_feature['_ord_dnh_feature_4'] ) && is_array( $sect_feature['_ord_dnh_feature_4'] ) ){
                                foreach( $sect_feature['_ord_dnh_feature_4'] as $featureFour ){
                                    
                                    $check = strstr( $featureFour, 'fa-');
                                   
                                    if( $check ){
                                        echo '<li><i class="fa '. esc_html( $featureFour ) .'"></i></li>';
                                    }else{
                                        echo '<li>'. esc_html( $featureFour ) .'</li>';   
                                    }
                                    
                                }
                            }
                            ?>
                        </ul>
                        <?php 
                        if( isset( $sect_feature['_ord_dnh_feature_4_btn'] ) && isset( $sect_feature['_ord_dnh_feature_4btnurl'] ) && !empty( $sect_feature['_ord_dnh_feature_2btnurl'] ) ){
                            
                            echo '<div class="action-btn">';
                            
                                echo '<a href="'.esc_url( $sect_feature['_ord_dnh_feature_4btnurl'] ).'" class="btn btn-custom">'.esc_html( $sect_feature['_ord_dnh_feature_4_btn'] ).'</a>';
                                
                            echo '</div>';
                        }
                        ?>

                    </div>
                </div>
            <?php 
            endif;
            ?>
            
        </div>
    </div>
</div>
<?php 
endforeach;
?>