<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/
?>
<!-- VPS Pricing Area Start -->
<div id="vpsPricing">
    <div class="container">
        <?php 
        // Section Title
        if( ordomain_opt( 'ord_vpsslide_title' ) || ordomain_opt( 'ord_vpsslide_subtitle' ) ){
            echo '<div class="section-title">';
                // sub title
                if( ordomain_opt( 'ord_vpsslide_subtitle' ) ){
                    echo '<p>'.esc_html( ordomain_opt( 'ord_vpsslide_subtitle' ) ).'</p>';   
                }
                // title
                if( ordomain_opt( 'ord_vpsslide_title' ) ){
                    echo '<h2>'.esc_html( ordomain_opt( 'ord_vpsslide_title' ) ).'</h2>';
                }
                
            echo '</div>'; 
        }
        ?>
        <!-- VPS Slider Start -->
        <div class="vps-slider-holder">
            <?php 
            if( ordomain_opt( 'ord_vpspricingoffer' ) ){
                echo '<div class="ribbon ribbon-small text-white">';
                    echo '<div class="ribbon-content bg-green">';
                        echo ordomain_opt( 'ord_vpspricingoffer' );
                    echo '</div>';
                echo '</div>';
            }
            ?>
            <div id="vpsSlider"></div>
            <div class="vps-ruler" data-bg-img="<?php echo get_template_directory_uri(); ?>/img/ruler.png"></div>
        </div>
        <!-- VPS Slider End -->
        <!-- VPS Slider Default Content Start -->
        <div class="row">
           
            <?php
            // VPS Slider Item
                if( is_array( ordomain_opt('ord_vpspricing_title') ) ){
                $i = 1;
                foreach( ordomain_opt('ord_vpspricing_title') as $title ){
                    echo '<div class="col-sm-2 col-xs-6 vps-item-feature">';
                        
                        echo '<span class="vps-item-feature-name">'.esc_html( $title['title'] ).'</span>';

                           echo '<span class="vps-item-feature-value vps-item-'.esc_html( $i ).'"></span>';

                    echo '</div>';  
                $i++;
                }
                }
            ?>


        </div>
        <!-- VPS Slider Default Content End -->
        <!-- VPS Slider Price Tag Start -->
        <div class="vps-total-price"><span><?php esc_html( '$69.99' ); ?></span><?php echo esc_html( ordomain_opt( 'ord_vpspricingPackge_time' ) ); ?></div>
        <!-- VPS Slider Price Tag End -->
        <!-- VPS Slider Action Start -->
        <div class="action">
        <?php
        // Buy now button         
        if( ordomain_opt('ord_vpspricingBuybtn_text') ){
            echo '<a href="#" class="order-link btn btn-lg btn-custom">'.esc_html( ordomain_opt('ord_vpspricingBuybtn_text') ).'</a>';            
        }
        
        // Costom button 
        if( ordomain_opt('ord_vpspricingCustombtn_url') && ordomain_opt('ord_vpspricingCustombtn_text') ){
            echo '<a href="'.esc_html( ordomain_opt('ord_vpspricingCustombtn_url') ).'" class="deatils-link btn btn-lg btn-custom-reverse">'.esc_html( ordomain_opt('ord_vpspricingCustombtn_text') ).'</a>';
        }
        ?>   
        </div>
    </div>
</div>
<!-- VPS Pricing Area End -->