<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/
$background     = ordomain_meta_callback('domain_bg');
$overlay        = ordomain_meta_callback('domain_overlay');

if( $background ){
    $background = ' data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}

// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}

?>

<!-- Domain Pricing Area Start -->
<div id="domainPricing"<?php echo wp_kses_post( $background.$overlay ); ?>>
    <div class="container">
        <?php 
        // Section Title
        ordomain_section_heading(
            array(
                'subtitle'  => 'domain_sectsubtitle',
                'title'     => 'domain_secttitle',
            )
        );
        
        // wp query
        $tax_id =  get_post_meta( get_the_ID() , '_ord_domain_taxonoy', true ) ;
       
        $args = array(
            'post_type' => 'domain_pricing',
            'posts_per_page' => 1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'domain_categories',
                    'field' => 'id',
                    'terms' => esc_html( $tax_id ),
                )
            ),
        );
            
        
        $loop = new WP_Query( $args );
        
        if( $loop->have_posts() ):
            while( $loop->have_posts() ): $loop->the_post();
            $headings = get_post_meta( $post->ID, '_ord_doaminpricing_heading', true ); 
            $features = get_post_meta( $post->ID, '_ord_doaminpricing_features', true ); 

        ?>
            <table>
                <thead>
                    <tr>
                        <?php 
                        $moblabel = array();
                        foreach( $headings as $heading ){
                            $moblabel[] .= $heading;
                            echo '<th>'.esc_html( $heading ).'</th>';
                        
                        }
                        ?>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    foreach( $features as $feature ):
                    ?>
                        <tr>
                            <?php 
                            $i = 0;
                            foreach( $feature['_ord_dompritbl_Feature'] as $featur ){
                                echo '<td data-label="'.esc_attr( $moblabel[$i] ).'">'.esc_html( $featur ).'</td>';
                            $i++;
                            }
                            
                            // button url
                            if( isset( $feature['_ord_dompritbl_btnUrl'] ) && isset( $feature['_ord_dompritbl_btnText'] ) && !empty( $feature['_ord_dompritbl_btnText'] )  ){
                                
                                echo '<td data-label="'.esc_attr( end( $moblabel ) ).'"><a href="'.esc_url( $feature['_ord_dompritbl_btnUrl'] ).'" class="btn btn-custom">'.esc_html( $feature['_ord_dompritbl_btnText'] ).'</a></td>';
                            }
                            
                            ?> 
                        </tr>
                    <?php 
                    endforeach;
                    ?>
                </tbody>
            </table>
        <?php 
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
    </div>
</div>
<!-- Domain Pricing Area End -->