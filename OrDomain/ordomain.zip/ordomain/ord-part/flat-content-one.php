<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$background = ordomain_meta_callback('flatContentone_bgimg');

if( $background ){
    $bg = ' data-bg-img="'.esc_url( $background ).'"';
}else{
    $bg = '';
}

$overlay    = ordomain_meta_callback('flatContentone_overlay');

// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}

?>
<!-- Counter Area Start -->
<div id="flat_contentone"<?php echo wp_kses_post( $bg.$overlay ) ; ?>>
    <div class="container">
        <?php 
        // Section Title 
        ordomain_section_heading(
            array(
                'subtitle'  => 'flatContentone_subtitle',
                'title'     => 'flatContentone_secttitle',
            )
        );
        ?>
        <div class="row">
            <div class="col-sm-12">
                <?php 
                if( ordomain_meta_callback( 'flatContentone_content' ) ){
                    echo wpautop( ordomain_meta_callback( 'flatContentone_content' ) );
                }
                ?>
            </div>
        </div>
    </div>
</div>