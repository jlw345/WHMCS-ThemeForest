<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$overlay    = ordomain_meta_callback('blog_overlay');
$background    = ordomain_meta_callback('blog_background');

if( $background ){
    $background = ' data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}

// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}


?>

<!-- Blog Area Start -->
<div id="blog"<?php echo wp_kses_post( $background.$overlay ); ?>>
    <div class="container">
        <?php 
        // Section Title 
        ordomain_section_heading(
            array(
                'subtitle'  => 'blog_subtitle',
                'title'     => 'blog_secttitle',
            )
        );
        ?>
        
        <div class="row res-col">
            <?php 
            $args = array(
                'post_type' => 'post',
                'posts_per_page' => '3'
            );
            
            $loop = new WP_Query( $args );
            
            if( $loop->have_posts() ) {
                
                while( $loop->have_posts() ) {
                $loop->the_post();
                
                    get_template_part('templates/content', 'front' );
                }
                wp_reset_postdata();
            }else{
                get_template_part( 'templates/content', 'none' );
            }
            
            ?>
        </div>
    </div>
</div>