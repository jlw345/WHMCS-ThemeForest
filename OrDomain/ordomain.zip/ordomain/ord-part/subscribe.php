<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$secttitle  = ordomain_meta_callback('subscribe_secttitle');
$background = ordomain_meta_callback('subscribe_background');
$overlay    = ordomain_meta_callback('subscribe_overlay');
$content    = ordomain_meta_callback('subscribe_contents');

if( $background ){
    $background = ' data-bg-img="'.esc_url( $background ).'"';
}else{
    $background = '';
}

// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}

?>

<!-- Subscribe Area Start -->
<div id="subscribe"<?php echo wp_kses_post( $background.$overlay ); ?>>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <?php 
                if( $secttitle ){
                   echo '<h2>'.esc_html( $secttitle ).'</h2>'; 
                }
                if( $content ){
                  echo do_shortcode( $content );
                }
                
                // subscribe form callback
                if( isset( $_POST['subscribe'] ) ){
                    
                    echo ordomain_subscribe_ajax( $_POST );
                }
                
                ?>
                <div id="alert-message"></div>
                <form action="#" method="post" id="subscribeForm">
                    <input type="email" name="subscribe_email" id="subscribe_email" placeholder="Enter your email address" class="input-box">
                    <input type="hidden" id="admin-url" data-url="<?php echo admin_url('admin-ajax.php'); ?>" />
                    <input type="submit" value="Subscribe" name="subscribe" class="submit-button btn-green">
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Subscribe Area End -->
