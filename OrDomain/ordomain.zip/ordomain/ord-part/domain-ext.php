<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/


$extrafeatures = ordomain_meta_callback('extrafeature_contents');

?>

<!-- Domain Extension Area Start -->
<div id="domainExt" class="bg-green triangle-lg-down triangle-down-green">
    <div class="container">
        <div class="extension-slider owl-carousel text-center text-white" data-items="6">
            <?php 
            if( ordomain_meta_callback('domain_extension_slider') ){
                foreach( ordomain_meta_callback('domain_extension_slider') as $ext ){
                    if( isset( $ext['_ord_domain_extension_name'] ) || isset( $ext['_ord_domain_extension_price'] ) ){
                        echo '<div class="item">';
                            echo '<p class="ext--name">'.esc_html( $ext['_ord_domain_extension_name'] ).'</p>';
                            echo '<p class="ext--price text-green">'.esc_html( $ext['_ord_domain_extension_price'] ).'<span>'.esc_html( $ext['_ord_domain_extension_duration'] ).'</span></p>';
                        echo '</div>';    
                    }
   
                }
            }
            ?>

        </div>
    </div>
</div>