<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/
$background     = ordomain_meta_callback('dedicPriceTab_bgimg');
$overlay    = ordomain_meta_callback('dedicPriceTab_overlay');

if( $background ){
    $background = 'data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}


// Overlay
if( $overlay ){
    $overlay = ' bg--overlay';
}else{
    $overlay = '';
}

?>

<!-- Domain Pricing Area Start -->
<div id="dedicatedPricing" class="dedicatedPricing-tab<?php echo esc_attr( $overlay ); ?>" <?php echo wp_kses_post( $background ); ?>>
    <div class="container">
        <?php 
        // Section Title
        ordomain_section_heading(
            array(
                'subtitle'  => 'dedicPriceTab_sectsubtitle',
                'title'     => 'dedicPriceTab_secttitle',
            )
        );
        ?>
        
        <div class="dedicated-pricing-tab-filter">
            <ul class="nav nav-tabs" role="tablist">
            <?php 
			$get_terms_id = get_post_meta( get_the_ID(), '_ord_dedicPriceTab_cat', true );
			
			$terms = array();
			if( is_array( $get_terms_id ) ){
				foreach( $get_terms_id as $id ){
					
					$terms[] = get_term_by( 'id', $id, 'dedicate_categories' );
					
				}
            }
                
                if( is_array( $terms ) && count( $terms ) > 0 ){
                    $i=1;
                    foreach( $terms as $term ){
                        
                        if( $i == 1 ){
                            $class = 'class="active"';
                        }else{
                            $class = '';
                        }
                        echo '<li role="presentation" '.$class.'><a href="#'.esc_attr( $term->slug ).'-'.esc_attr( $term->term_id ).'" class="btn-custom-reverse" aria-controls="'.esc_attr( $term->slug ).'-'.esc_attr( $term->term_id ).'" role="tab" data-toggle="tab">'.esc_html( $term->name ).'</a></li>';
                    $i++;
                    }
                       
                }
            
            ?>
            </ul>
        </div>
        
        <!-- Tab panes -->
        <div class="tab-content">
  
        <?php 
        if( is_array( $terms ) && count( $terms ) > 0 ):
            $i = 1;
            foreach( $terms as $term ):
        ?>
            <div role="tabpanel" class="tab-pane fade<?php echo ($i == 1 )? ' in active' : ''; ?>" id="<?php echo esc_attr( $term->slug ).'-'.esc_attr( $term->term_id ); ?>">
            
            <?php 
            $args = array( 
                'post_type' => 'dedicate_pricing',
                'posts_per_page' => 1,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'dedicate_categories',
                        'field' => 'id',
                        'terms' => esc_html( $term->term_id ),
                    )
                ),
            );
            
            $loop = new WP_Query( $args );
    
            if( $loop->have_posts() ):
            while( $loop->have_posts() ): $loop->the_post();
            $headings = get_post_meta( $post->ID, '_ord_dedicate_heading', true ); 
            $features = get_post_meta( $post->ID, '_ord_dedicate_features', true ); 

            ?>
            
                <table>
                    <thead>
                        <tr>
                        <?php 
                        $moblabel = array();
                        foreach( $headings as $heading ){
                            $moblabel[] .= $heading; 
                            echo '<th>'.esc_html( $heading ).'</th>';
                        }
                        ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    foreach( $features as $feature ):
                    ?>
                        <tr>
                            <?php 
                            if( isset( $feature['_ord_dedpritbl_Feature']  ) ){
                                $i = 0;
                                foreach( $feature['_ord_dedpritbl_Feature'] as $featur ){
                                    echo '<td data-label="'.esc_attr( $moblabel[$i] ).'">'.esc_html( $featur ).'</td>';
                                $i++;
                                }   
                            }
                            
                            // button url
                            if( isset( $feature['_ord_dedpritbl_btnUrl'] ) && isset( $feature['_ord_dedpritbl_btnText'] ) && !empty( $feature['_ord_dedpritbl_btnText'] )  ){
                                
                                echo '<td data-label="'.esc_attr( end( $moblabel ) ).'"><a href="'.esc_url( $feature['_ord_dedpritbl_btnUrl'] ).'" class="btn btn-custom">'.esc_html( $feature['_ord_dedpritbl_btnText'] ).'</a></td>';
                            }
                            
                            ?> 
                        </tr>
                    <?php 
                    endforeach;
                    ?>
                    
                    </tbody>
                </table>
            <?php 
                endwhile;
                wp_reset_postdata();
            endif;
            ?>
            
            </div>
        <?php 
            $i++;
            endforeach;
        endif;
        ?>   
        </div>
     
    </div>
</div>
<!-- Domain Pricing Area End -->