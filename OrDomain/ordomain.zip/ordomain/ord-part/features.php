<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$services = ordomain_meta_callback('services_contents');

// bg
if( ordomain_meta_callback('service_bgimg') ){
    $bg = ' data-bg-img="'.esc_url( ordomain_meta_callback('service_bgimg') ).'"';
}else{
   $bg = ''; 
}
// overlay 
if( ordomain_meta_callback('service_overlay') ){
    $overlay = 'class="bg--overlay"';
}else{
   $overlay = ''; 
}
?>
<!-- Feature Area Start -->
<div id="feature"<?php echo wp_kses_post( $bg.' '.$overlay ); ?>>
    <div class="container">
        <?php 
        // Section Title 
        ordomain_section_heading(
            array(
                'subtitle'  => 'services_subtitle',
                'title'     => 'services_secttitle',
            )
        );
        ?>
        <div class="row row-eq-height">
            <!-- Feature Item Start -->
            <?php 
            if( $services ){
                foreach( $services as $service ){
            ?>
                    <div class="col-md-3 col-sm-6 feature-item">
                        <?php 
                        // icon
                        if( isset( $service['_ord_service_icon_type'] ) && $service['_ord_service_icon_type'] == 'icon' ){
                            if( isset( $service['_ord_service_icon'] ) && $service['_ord_service_icon'] ){
                                echo '<div class="icon">';
                                    echo '<i class="fa '.esc_html( $service['_ord_service_icon'] ).'"></i>';
                                echo '</div>';
                            }
                        }
                        // image icon
                        if( isset( $service['_ord_service_icon_type'] ) && $service['_ord_service_icon_type'] == 'image' ){
                            $Imgicon = $service['_ord_service_imgicon'];
                            if( isset( $Imgicon ) && $Imgicon ){
                                echo '<div class="icon">';
                                    echo '<img src="'.esc_url( $Imgicon ).'" class="serv-imgicon" alt="'.ordomain_image_alt( esc_url( $Imgicon ) ).'" />';
                                echo '</div>';
                            }
                        }
                        ?>
                        <div class="content">
                        <?php 
                        if( isset( $service['_ord_service_title'] ) ){
                            echo '<h3 class="heading">'.esc_html( $service['_ord_service_title'] ).'</h3>';
                        }
                        if( isset( $service['_ord_service_description'] ) ){
                            echo '<p class="desc">'.esc_html( $service['_ord_service_description'] ).'</p>';
                        }
                        ?> 
                        </div>
                    </div>  
            <?php
                }                
            }
            ?>
        </div>
    </div>
</div>
<!-- Feature Area End -->