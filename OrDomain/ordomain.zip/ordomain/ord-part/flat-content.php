<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/

$background = ordomain_meta_callback('flatContent_bgimg');

if( $background ){
    $bg = ' data-bg-img="'.esc_url( $background ).'"';
}else{
    $bg = '';
}

$overlay    = ordomain_meta_callback('flatContent_overlay');

// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}

?>

<div id="flat_content"<?php echo wp_kses_post( $bg.$overlay ) ; ?>>
    <div class="container">
        <?php
        // Section Title 
        ordomain_section_heading(
            array(
                'subtitle'  => 'flatContent_subtitle',
                'title'     => 'flatContent_secttitle',
            )
        );
        ?>
        <div class="row">
            <div class="col-sm-12">
                <?php 
                if( ordomain_meta_callback( 'flatContent_content' ) ){
                    echo wpautop( ordomain_meta_callback( 'flatContent_content' ) );
                }
                ?>
            </div>
        </div>
    </div>
</div>