<?php 
/**
* @version: 1.5
* @package: OrDomain
* @author: Themelooks
* @Support: <support@themelooks.com>
* @website: themelooks.com
*
*/


$teams = ordomain_meta_callback('team_contents');
$overlay = ordomain_meta_callback('team_overlay');
$background = ordomain_meta_callback('team_background');

if( $background ){
    $background = ' data-bg-img="'. esc_url( $background ) .'"';
}else{
    $background = '';
}

// Overlay
if( $overlay ){
    $overlay = ' class="bg--overlay"';
}else{
    $overlay = '';
}
?>

<div id="team"<?php echo wp_kses_post( $background.$overlay ); ?>>
    <div class="container">
        <?php 
        // Section Title
        ordomain_section_heading(
            array(
                'subtitle'  => 'team_subtitle',
                'title'     => 'team_secttitle',
            )
        );
        ?>
        <div class="row">
            <?php 
            // Team Item
            if( $teams ):
            foreach( $teams as $team ):
            ?>
            <div class="col-md-3 col-sm-6 team-item">
                <figure>
                <?php 
                if( isset( $team['_ord_teamMember_pic'] ) ){
                    echo '<img src="'.esc_url( $team['_ord_teamMember_pic'] ).'" alt="team member image" class="img-responsive img-circle" />';
                }
                ?>
                    <figcaption>
                    <?php 
                    if( isset( $team['_ord_teamMmember_name'] ) ){
                        echo '<h3 class="name">'.esc_html( $team['_ord_teamMmember_name'] ).'</h3>';
                    }
                    if( isset( $team['_ord_teamMember_designation'] ) ){
                        echo '<p class="role">'.esc_html( $team['_ord_teamMember_designation'] ).'</p>';
                    }
                    ?>
                        
                    <div class="team-social-links">
                        <ul class="nav navbar-nav">
                        <?php 
                            
                        // facebook
                        if( isset( $team['_ord_teamMember_fb'] ) && $team['_ord_teamMember_fb'] ){
                           echo '<li><a href="'.esc_url( $team['_ord_teamMember_fb'] ).'"><i class="fa fa-facebook"></i></a></li>'; 
                        }
                        // Twitter
                        if( isset( $team['_ord_teamMember_twit'] ) && $team['_ord_teamMember_twit'] ){
                            echo '<li><a href="'.esc_url( $team['_ord_teamMember_twit'] ).'"><i class="fa fa-twitter"></i></a></li>';
                        }
                        // google plus
                        if( isset( $team['_ord_teamMember_gp'] ) && $team['_ord_teamMember_gp'] ){
                            
                            echo '<li><a href="'.esc_url( $team['_ord_teamMember_gp'] ).'"><i class="fa fa-google-plus"></i></a></li>';
                        }
                        // linkedin
                        if( isset( $team['_ord_teamMember_lkd'] ) && $team['_ord_teamMember_lkd'] ){
                            
                            echo '<li><a href="'.esc_url( $team['_ord_teamMember_lkd'] ).'"><i class="fa fa-linkedin"></i></a></li>';
                        }
                        ?>
                            
                        </ul>
                    </div>
                        
                    </figcaption>
                </figure>
            </div>
            <?php 
            endforeach;
            endif;
            ?>
        </div>
    </div>
</div>