<?php
/**
 * @version    1.0
 * @package    OrDomain
 * @author     Themelooks  <support@themelooks.com>
 * @copyright  Copyright (C) 2014 themelooks.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.themelooks.com
 */

/**
 * Enqueue style of child theme
 */
function ordomain_child_enqueue_styles() {
    wp_enqueue_style( 'ordomain-child-style', get_stylesheet_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'ordomain_child_enqueue_styles', 100000 );