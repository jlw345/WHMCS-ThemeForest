<?php

/**
 * Page Component
 *
 * @package		SpyroPress
 * @category	Components
 */

class SpyropressPage extends SpyropressComponent {

    private $path;

    function __construct() {

        $this->path = dirname(__FILE__);
        add_action( 'spyropress_register_taxonomy', array( $this, 'register' ) );
    }

    function register() {

        $post = new SpyropressCustomPostType( 'Page' );

        // Add Meta Boxes
        $sliders['builint'] = 'Builtin Slider';
        if( function_exists( 'rev_slider_shortcode' ) )
            $sliders['rev'] = 'Revolution Slider';

        $fields['options'] = array(
            array(
                'label' => 'Slider',
                'type' => 'heading',
                'slug' => 'options'
            ),

            array(
                'label' => 'Slider Type',
                'id' => 'type',
                'type' => 'select',
                'class' => 'enable_changer',
                'options' => $sliders
            ),

            array(
                'label' => 'Builtin Sliders',
                'id' => 'builtin_sliders',
                'type' => 'select',
                'class' => 'type builint',
                'options' => spyropress_get_sliders()
            )
        );

        if( function_exists( 'rev_slider_shortcode' ) ) {
            
            $revslider = new RevSlider();
            $arrSliders = $revslider->getArrSlidersShort();

            $fields['options'][] = array(
                'label' => 'Revolution Type',
                'id' => 'rev_sliders',
                'type' => 'select',
                'class' => 'type rev',
                'options' => $arrSliders
            );
        }
        
        $fields['layout'] = array(
            array(
                'label' => 'Layout',
                'type' => 'heading',
                'slug' => 'layout'
            ),

            array(
                'id' => 'no_title',
                'type' => 'checkbox',
                'options' => array(
                    '1' => 'Remove Page Title'
                )
            )
        );

        $post->add_meta_box( 'page_options', 'Page Options', $fields, '_page_options' );
    }

    function register_module( $modules ) {

        $modules[] = $this->path . '/module/bucket.php';

        return $modules;
    }

    function shortcode_handler( $atts, $content = '' ) {

        if( isset( $atts['id'] ) && $atts['id'] )
            return spyropress_get_the_bucket( $atts['id'] );
    }
}

/**
 * Init the Component
 */
new SpyropressPage();
?>