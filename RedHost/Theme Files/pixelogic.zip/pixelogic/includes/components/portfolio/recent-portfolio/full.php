<?php

// Setup Instance for view
$instance = spyropress_clean_array( $instance );
$instance['callback'] = array( $this, "generate_portfolio_full_item" );
$instance['pagination'] = ( isset( $instance['settings'] ) && in_array( 'pagination', $instance['settings'] ) ) ? true : false;

$tmpl = '<div class="blog row-fluid">{content}{pagination}</div>';

echo $before_widget;    

    echo $this->query( $instance, $tmpl );
    
echo $after_widget;
?>