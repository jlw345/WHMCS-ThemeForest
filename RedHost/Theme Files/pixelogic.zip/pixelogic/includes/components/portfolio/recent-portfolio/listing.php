<?php

// Setup Instance for view
$instance = spyropress_clean_array( $instance );
$instance['callback'] = array( $this, 'generate_portfolio_listing_item' );

// Filters
$filters = '';
$filter = ( isset( $instance['settings'] ) && in_array( 'filters', $instance['settings'] ) ) ? true : false;
$instance['pagination'] = ( isset( $instance['settings'] ) && in_array( 'pagination', $instance['settings'] ) ) ? true : false;

if( $filter ) {
    $terms = get_terms( 'portfolio_category' );
    $filters .= '<ul id="portfolio-filter"><li><a href="#" class="active4" data-filter="*">all</a></li>';
    foreach( $terms as $term ) {
        $filters .= '<li><a href="#" data-filter=".' . $term->slug . '">' . $term->name . '</a></li>';
    }
    $filters .= '</ul>';
}

$tmpl = $filters . '<ul class="portfolio clearfix">{content}</ul>{pagination}';

echo $before_widget;    

    echo $this->query( $instance, $tmpl );
    
echo $after_widget;

$js = '
var $container	 	= $(".portfolio");
var $filter 		= $("#portfolio-filter");

$container.imagesLoaded( function() {
    $("ul.portfolio").show();
    $container.isotope({
        filter				: "*",
        layoutMode   		: "masonry",
        animationOptions	: {
            duration			: 750,
            easing				: "linear"
        }
    });
});

$(window).bind("resize", function() {
    var selector = $filter.find("a.active4").attr("data-filter");
    $container.isotope({
        filter	: selector,
        animationOptions: {
            duration: 750,
            easing	: "linear",
            queue	: false,
  		}
    });
    return false;
});
		
// Isotope Filter
$filter.find("a").click(function(){
    var selector = $(this).attr("data-filter");
    $container.isotope({
        filter	: selector,
        animationOptions: {
            duration: 750,
            easing	: "linear",
            queue	: false,
  		}
    });
    return false;
});';
add_inline_js($js);
?>