<?php

/**
 * Module: Portfolio
 * Display a list of portfolio
 *
 * @author 		SpyroSol
 * @category 	BuilderModules
 * @package 	Spyropress
 */

class Spyropress_Module_Portfolio extends SpyropressBuilderModule {

    var $path;

    public function __construct() {

        $this->path = dirname( __FILE__ );

        // Widget variable settings.
        $this->cssclass = 'module-portfolio';
        $this->description = __( 'Display a list of portfolio.', 'spyropress' );
        $this->id_base = 'spyropress_portfolio';
        $this->name = __( 'Portfolio', 'spyropress' );

        $this->templates['listing'] = array(
            'view' => 'listing.php',
            'label' => 'Portfolio Listing'
        );
        $this->templates['full'] = array(
            'view' => 'full.php',
            'label' => 'Portfolio Full width'
        );
        // Fields
        $this->fields = array(
        
            array(
                'label' => 'Template',
                'id' => 'template',
                'class' => 'enable_changer section-full',
                'type' => 'select',
                'options' => $this->get_option_templates()
            ),

            array(
                'label' => __( 'Title', 'spyropress' ),
                'id' => 'title',
                'type' => 'text',
                'std' => $this->name
            ),

            array('type' => 'row'),
                array('type' => 'col', 'size' => 6),
                array(
                    'label' => __( 'Number of items per page', 'spyropress' ),
                    'id' => 'limit',
                    'type' => 'range_slider',
                    'max' => 30,
                    'std' => 4
                ),

                array(
                    'label' => __( 'Number of Column', 'spyropress' ),
                    'id' => 'column',
                    'type' => 'range_slider',
                    'class' => 'template listing view',
                    'max' => 4,
                    'std' => 4
                ),

                array('type' => 'col_end'),

                array('type' => 'col', 'size' => 6),
                array(
                    'label' => __( 'Portfolio Category', 'spyropress' ),
                    'id' => 'cat',
                    'type' => 'multi_select',
                    'options' => spyropress_get_taxonomies( 'portfolio_category' )
                ),

                array(
                    'label' => __('Enable', 'spyropress'),
                    'id' => 'settings',
                    'type' => 'checkbox',
                    'desc' => 'Will show pagination if portfolio per page is set.',
                    'options' => array(
                        'pagination' => __('Enable pagination for the next page', 'spyropress'),
                        'filters' => __('Enable category filters.', 'spyropress')
                    )
                ),
                array('type' => 'col_end'),

            array('type' => 'row_end'),

            
        );

        $this->create_widget();
    }

    function widget( $args, $instance ) {

        // extracting info
        extract( $args );
        $template = isset( $instance['template'] ) ? $instance['template'] : '';

        // get view to render
        include $this->get_view( $template );
    }

    function query( $atts, $content = null ) {

        $default = array (
            'post_type' => 'portfolio',
            'limit' => -1,
            'columns' => false,
            'callback' => array( $this, 'generate_portfolio_item' ),
            'item_class' => 'portfolio-entry'
        );
        $atts = wp_parse_args( $atts, $default );

        if ( ! empty( $atts['cat'] ) ) {

            $atts['tax_query']['relation'] = 'OR';
            if ( ! empty( $atts['cat'] ) ) {
                $atts['tax_query'][] = array(
                    'taxonomy' => 'portfolio_category',
                    'field' => 'slug',
                    'terms' => $atts['cat'],
                    );
                unset( $atts['cat'] );
            }
        }

        if ( $content )
            return token_repalce( $content, spyropress_query_generator( $atts ) );

        return spyropress_query_generator( $atts );
    }

    function generate_portfolio_item( $post_ID, $atts ) {

        // these arguments will be available from inside $content
        $image = array(
            'post_id' => $post_ID,
            'echo' => false
        );
        $image_tag = get_image( $image );

        $image['width'] = 9999;
        $image['type'] = 'src';
        $image_url = get_image( $image );

        // item tempalte
        $item_tmpl = '
        <div class="left">
            ' . $image_tag . '
            <a href="' . get_permalink( $post_ID ) . '" class="up"></a>
            <a href="' . $image_url . '" class="down" rel="gallery"></a>
            <p>' . get_the_title( $post_ID ) . '</p>
        </div>';

        return $item_tmpl;
    }

    function generate_portfolio_listing_item( $post_ID, $atts ) {

        // these arguments will be available from inside $content
        $width = ( 2 == $atts['column'] ) ? 999 : 300;
        $image = array(
            'post_id' => $post_ID,
            'echo' => false,
            'width' => $width,
            'type' => 'src'
        );
        $image_url = get_image( $image );

        // item tempalte
        $terms = get_the_terms( $post_ID, 'portfolio_category' );
        $class = '';
        foreach( $terms as $term ) {
            $class .= ' ' . $term->slug;
        }

        $item_tmpl = '
        <li class="portfolio-post col' . $atts['column'] . $class . '">
            <img src="' . $image_url . '" alt="" />
            <a href="' . get_permalink( $post_ID ) . '" class="up"></a>
            <a href="' . $image_url . '" class="down" rel="galery2"></a>
            <p>' . get_the_title( $post_ID ) . '</p>
        </li>';

        return $item_tmpl;
    }
    
    function generate_portfolio_full_item( $post_ID, $atts ) {

        // these arguments will be available from inside $content
        $width = 9999;
        if( 2 == $atts['columns'] )  $width = 470;
        elseif( 3 == $atts['columns'] )  $width = 300;
        elseif( 4 == $atts['columns'] )  $width = 300;
        
        $image = array(
            'post_id' => $post_ID,
            'echo' => false,
            'width' => $width,
            'crop' => true
        );
        if( 4 == $atts['columns'] )  $image['height'] = 201;
        $image_tag = get_image( $image );
        
        // item tempalte
        $item_tmpl = '';
        if( 4 == $atts['columns'] ) {
            $item_tmpl = sprintf('
            <div class="blog-post %7$s">
                <a href="%1$s">%2$s</a>
                <div class="post-title">
                    <h1>
                        <a href="%1$s">%3$s</a>
                    </h1>
                    <p>
                        <span>Posted by %4$s</span>
                        <span>in %5$s</span>
                    </p>
                </div>
                %6$s
                <a id="read-more" href="%1$s">Read More <span></span></a>
            </div>',
            get_permalink( $post_ID ), $image_tag, get_the_title( $post_ID ), get_the_author_link(),
            get_the_category_list( ', '), get_the_excerpt(), $atts['column_class']
            );
        }
        else {
            $item_tmpl = sprintf('
            <div class="blog-post %9$s">
                <a href="%1$s">%2$s</a>
                <div class="post-title">
                    <div class="post-date">
                        <span>%4$s</span><span>%5$s</span>
                    </div>
                    <h1>
                        <a href="%1$s">%3$s</a>
                    </h1>
                    <p>
                        <span>Posted by %6$s</span>
                        <span>in %7$s</span>
                    </p>
                </div>
                %8$s
                <a id="read-more" href="%1$s">Read More <span></span></a>
            </div>',
            get_permalink( $post_ID ), $image_tag, get_the_title( $post_ID ), get_the_date( 'j' ), get_the_date( 'M' ),
            get_the_author_link(), get_the_category_list( ', '), get_the_excerpt(), $atts['column_class']
            );
        }
        
        return $item_tmpl;
    }
}

spyropress_builder_register_module( 'Spyropress_Module_Portfolio' );
?>