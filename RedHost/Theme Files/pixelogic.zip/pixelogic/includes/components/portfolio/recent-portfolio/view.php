<?php

// Setup Instance for view
$instance = spyropress_clean_array( $instance );

// tempalte
$tmpl = '{content}{pagination}';

echo $before_widget;
    
    echo '<div id="recent" class="clearfix">';

        // title
        if ( $instance['title'] ) echo '<h1>' . $instance['title'] . '</h1>';    
        // output content
        echo $this->query( $instance, $tmpl );

    echo '</div>';
    
echo $after_widget;
?>