<?php

/**
 * Portfolio Component
 *
 * @package		SpyroPress
 * @category	Components
 */

class SpyropressPortfolio extends SpyropressComponent {

    private $path;
    
    function __construct() {

        $this->path = dirname(__FILE__);
        add_action( 'spyropress_register_taxonomy', array( $this, 'register' ) );
        add_filter( 'builder_include_modules', array( $this, 'register_module' ) );
    }

    function register() {

        // Init Post Type
        $args = array(
            'supports'          => array( 'title', 'editor', 'thumbnail' )
        );
        $post = new SpyropressCustomPostType( __( 'Portfolio', 'spyropress' ), '', $args );
        
        // Add Taxonomy
        $post->add_taxonomy( 'Category', 'portfolio_category', 'Categories', array( 'hierarchical' => true ) );
        
        // Add Meta Boxes
        $meta_fields['portfolio'] = array(
            array(
                'label' => 'Layout and Details',
                'type' => 'heading',
                'slug' => 'portfolio'
            ),
            
            array(
                'label' => 'Style',
                'id' => 'style',
                'type' => 'select',
                'options' => array(
                    'full' => 'Full Width',
                    'half' => 'Half Width',
                ),
                'std' => 'half'
            ),
    
            array(
                'label' => 'Project URL',
                'id' => 'project_url',
                'type' => 'text'
            ),
            
            array(
                'label' => __( 'Services', 'spyropress' ),
                'type' => 'repeater',
                'id' => 'service',
                'item_title' => 'title',
                'fields' => array(
                    array(
                        'label' => __( 'Service name', 'spyropress' ),
                        'id' => 'title',
                        'type' => 'text',
                    )
                )
            )
        );
        
        $meta_fields['gallery'] = array(
            array(
                'label' => 'Gallery',
                'type' => 'heading',
                'slug' => 'gallery'
            ),
            
            array(
                'label' => __( 'Images', 'spyropress' ),
                'type' => 'repeater',
                'id' => 'images',
                'hide_label' => true,
                'item_title' => 'title',
                'fields' => array(
                    array(
                        'label' => __( 'Image', 'spyropress' ),
                        'id' => 'image',
                        'type' => 'upload',
                    ),
                    
                    array(
                        'label' => __( 'Caption', 'spyropress' ),
                        'id' => 'caption',
                        'type' => 'textarea',
                        'rows' => 4
                    )
                )
            )
        );
        
        $post->add_meta_box( 'portfolio_info', 'Portfolio Details', $meta_fields, '_portfolio_details' );
    }
    
    function register_widget( $widgets ) {
        
        $widgets[] = $this->path . '/widget';
        
        return $widgets;
    }
    
    function register_module( $modules ) {

        $modules[] = $this->path . '/recent-portfolio/module.php';

        return $modules;
    }
}

/**
 * Init the Component
 */
new SpyropressPortfolio();