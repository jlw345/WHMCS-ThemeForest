<?php

if ( $bucket ) {
    
    if( $is_widget ) echo $before_widget;
    
        if ( $title != '' ) echo $before_title . $title . $after_title;
        echo spyropress_the_bucket( $bucket );
        echo '<div class="clear"></div>';
    
    if( $is_widget ) echo $after_widget;
}

?>