<?php

/**
 * Init Theme Related Settings
 */

/** Internal Settings **/
require_once 'version.php';

/**
 * Required and Recommended Plugins
 */
function spyropress_register_plugins() {

    /**
     * Array of plugin arrays. Required keys are name and slug.
     * If the source is NOT from the .org repo, then source is also required.
     */
    $plugins = array(

        // Wordpress SEO
        array(
            'name'      => 'WordPress SEO by Yoast',
            'slug'      => 'wordpress-seo',
            'required'  => false,
        ),

        // Contact Form 7
        array(
            'name'      => 'Contact Form 7',
            'slug'      => 'contact-form-7',
            'required'  => true,
        ),
        
        //Revolution slider
        array(
            'name'      => 'Revolution Slider',
            'slug'      => 'revslider',
            'required'  => true,
            'source'    => get_template_directory() . '/includes/plugins/revslider.zip'
        ),
        
        array(
            'name'      => 'Breadcrumb NavXT',
            'slug'      => 'breadcrumb-navxt',
            'source'    => include_path() . 'plugins/breadcrumb-navxt.zip',
            'required'  => true,
            'force_activation'      => true,
            'force_deactivation'    => true
        )
    );

    tgmpa( $plugins );
}
add_action( 'tgmpa_register', 'spyropress_register_plugins' );

/**
 * Add modules and tempaltes to SpyroBuilder
 */
function spyropress_register_builder_modules( $modules ) {

    $path = dirname(__FILE__);

    $custom = array(
        'modules/callout/callout.php',
        'modules/divider/divider.php',
        'modules/icon-teaser/icon-teaser.php',
        'modules/icon-list/icon-list.php',
        'modules/our-clients/clients.php',
        'modules/our-team/our-team.php',
        'modules/heading/heading.php',
        'modules/skills/skills.php',
        'modules/recent-posts/recent-posts.php',
        'modules/toggle-content/toggle-content.php',
        'modules/tabs/tabs.php',
        'modules/testimonials/testimonials.php',
        'modules/sidebar/sidebar.php',
    );

    return array_merge( $modules, $custom );
}
add_filter( 'builder_include_modules', 'spyropress_register_builder_modules' );

/**
 * Define the row wrapper html
 */
function spyropress_row_wrapper( $row_ID, $row ) {
    
    // CssClass
    $section_class = array();
    if( isset( $row['options']['custom_container_class'] ) && !empty( $row['options']['custom_container_class'] ) )
        $section_class[] = $row['options']['custom_container_class'];

    $row_html = sprintf( '
        <div id="%1$s" class="%2$s">
            <div class="container">
                <div class="%3$s">
                    %4$s
                </div>
            </div>
        </div>', $row_ID, spyropress_clean_cssclass( $section_class ), get_row_class( true ), builder_render_frontend_columns( $row['columns'] )
    );

    return $row_html;
}
add_filter( 'spyropress_builder_row_wrapper', 'spyropress_row_wrapper', 10, 2 );

/**
 * Include Widgets
 */
function spyropress_register_widgets( $widgets ) {
    
    $path = dirname(__FILE__) . '/widgets/';

    $custom = array(
        $path . 'text/text.php',
        $path . 'recent-comments/recent-comments.php',
        $path . 'photostream/photostream.php',
        $path . 'twitter/twitter.php',
        $path . 'contact-info/contact.php',
        $path . 'tab-widget/tab-widget.php'
    );

    return array_merge( $widgets, $custom );
}
add_filter( 'spyropress_register_widgets', 'spyropress_register_widgets' );

/**
 * Unregister Widgets
 */
function spyropress_unregister_widgets( $widgets ) {
    
    $custom = array(
        'WP_Widget_Recent_Comments',
        'WP_Nav_Menu_Widget'
    );

    return array_merge( $widgets, $custom );
}
add_filter( 'spyropress_unregister_widgets', 'spyropress_unregister_widgets' );

/**
 * Comment Callback
 */
if( !function_exists( 'spyropress_comment' ) ) :
function spyropress_comment( $comment, $args, $depth ) {
	$translate['comment-reply'] = get_setting( 'translate' ) ? get_setting( 'comment-reply', 'Reply' ) : __( 'Reply', 'spyropress' );
    $GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' :
	?>
	<li class="post pingback">
		<p><?php _e( 'Pingback:', 'spyropress' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( __( 'Edit', 'spyropress' ), '<span class="edit-link">', '</span>' ); ?></p>
	<?php
			break;
		default :
	?>
    <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
	   <?php
            $avatar_size = ( '0' != $comment->comment_parent ) ? 60 : 74;
            echo get_avatar( $comment, $avatar_size );
        ?>
		<div>
			<h5><?php comment_author_link(); ?></h5>
            <?php printf( __( '<span>%1$s / %2$s</span>', 'spyropress' ), get_comment_date(), get_comment_time() ) ?>
			<?php if ( $comment->comment_approved == '0' ) { ?>
                <em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'spyropress' ); ?></em><br />
            <?php
                }
                comment_text();
            ?>
			<?php
                comment_reply_link( array_merge( $args, array(
                    'depth' => $depth,
                    'reply_text' => $translate['comment-reply'],
                    'max_depth' => $args['max_depth'],
                ) ) );
            ?>
		</div>
	<?php
			break;
	endswitch;
}
endif;

/**
 * Pagination Defaults
 */
function spyropress_pagination_defaults( $defaults = array() ) {
    
    $defaults['style'] = 'simple';
    $defaults['container_class'] = 'pagination';
    $defaults['options']['pages_text'] = false;
    
    return $defaults;
}
add_filter( 'spyropress_pagination_defaults', 'spyropress_pagination_defaults' );

/**
 * oEmbed Modifier
 */
function oembed_modifier( $html ) {
    
    $html = preg_replace( '/(width|height|frameborder)="\d*"\s/', "", $html );
    
    if( is_str_contain( 'video-container', $html ) ) return $html;
    
    return '<div class="video-container">' . $html . '</div>';
}
add_filter( 'embed_oembed_html', 'oembed_modifier', 10 );
add_filter( 'oembed_result', 'oembed_modifier', 10 );