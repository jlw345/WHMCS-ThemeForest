<?php

/**
 * Shortcodes
 */

init_shortcode();
function init_shortcode() {
    
    $shortcodes = array(
        'footer_information'    => 'spyropress_footer_information',
        'socials'               => 'spyropress_socials',
        'img'                   => 'spyropress_image',
        'img_frame'             => 'spyropress_image_frame',
        'icon'                  => 'spyropress_icon',
        'social_icon'           => 'spyropress_social_icon',
        'dropcap'               => 'spyropress_dropcap',
        'blockquote'            => 'spyropress_blockquote',
        'gmap'                  => 'spyropress_google_map',
    );
    
    foreach( $shortcodes as $tag => $func )
        add_shortcode( $tag, $func );
}

function spyropress_image( $atts = array(), $content = '' ) {
    
    // Defaults
    $defaults = array( 'align' => '' );
    $atts = shortcode_atts( $defaults, $atts );
    extract( $atts );
    
    return '<div class="' . $align . '-img"><img alt="" src="' . $content . '"></div>';
}

function spyropress_image_frame( $atts = array(), $content = '' ) {
    
    return '<div class="img_frame"><img alt="" src="' . $content . '"></div>';
}

function spyropress_icon( $atts = array(), $content = '' ) {
    
    // Defaults
    $defaults = array( 'code' => '' );
    $atts = shortcode_atts( $defaults, $atts );
    extract( $atts );
    
    return '<img alt="" src="' . assets_img() . 'icons/' . $code . '.png" />';
}

function spyropress_social_icon( $atts = array(), $content = '' ) {
    
    // Defaults
    $defaults = array( 'network' => '' );
    $atts = shortcode_atts( $defaults, $atts );
    extract( $atts );
    
    return '<a href="' . $content . '"><img alt="" src="' . assets_img() . 'social_icons/' . $network . '.png" /></a>';
}

function spyropress_google_map( $atts = array(), $content = '' ) {
       
    return '<div class="googlemap" data-address="' . $content . '"></div>';
}

function spyropress_dropcap( $atts = array(), $content = '' ) {
    
    return '<span class="dropcap">' . $content . '</span>';
}

function spyropress_blockquote( $atts = array(), $content = '' ) {
    
    return '<blockquote class="blockquote2">' . $content . '</blockquote>';
}

function spyropress_socials( $atts = array(), $content = '' ) {

    $socials = get_setting_array( 'socials' );
    if( empty( $socials ) ) return;
    
    $content = '';
    foreach( $socials as $social ) {
        $content .= '<li><a target="_blank" href="' . $social['link'] . '"><img alt="" src="' . assets_img() . $social['network'] .'.png"></a></li>';
    }
    
    return '<ul class="social-links">' . $content . '</ul>';
}

function spyropress_footer_information( $atts = array(), $content = '' ) {

    // Defaults
    $defaults = array(
        'ph_label' => 'Questions?',
        'ph' => 'Call 1-800-8000',
        'email_label' => 'You can also email us at:',
        'email' => 'me@spyropress.com'
    );
    $atts = shortcode_atts( $defaults, $atts );
    extract( $atts );
    
    $content = '
    <ul class="footer-information">
        <li class="phone-info">
            <p>' . $ph_label . '</p>
            <p><strong>Call ' . $ph . '</strong></p>
        </li>
        <li class="email-info">
            <p>' . $email_label . '</p>
            <p><a href="mailto:' . $email . '">' . $email . '</a></p>
        </li>
    </ul>';
    
    return $content;
}

?>