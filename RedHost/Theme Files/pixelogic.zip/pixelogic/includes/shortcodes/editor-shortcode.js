(function() {

    tinymce.create( 'tinymce.plugins.spyropressShortcodes', {

        init: function ( ed, url )
		{
			ed.addCommand( 'spyropressPopup', function ( a, params ) {

				// load thickbox
                tb_show( params.title + ' Shortcode Generator', spyropress_admin_settings['shortcode_url'] + "popup.php?popup=" + params.identifier + "&width=" + 800 );
			});
		},

        addImmediate: function ( ed, title, sc) {
			ed.add({
				title: title,
				onclick: function () {
					tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, sc )
				}
			})
		},

        addWithPopup: function ( ed, title, id ) {
			ed.add({
				title: title,
				onclick: function () {
					tinyMCE.activeEditor.execCommand( 'spyropressPopup', false, {
						title: title,
						identifier: id
					})
				}
			})
		},

        createControl: function ( btn, e ) {
			if ( btn == 'spyropress_shortcodes' )
			{
				var a = this;

				var btn = e.createSplitButton('spyropress_shortcodes', {
                    title: "Insert Shortcode",
					image: spyropress_admin_settings['media_url'] + 'shortcode_icon.png',
					icons: false
                });

                btn.onRenderMenu.add(function (c, b) {

                    
                    
                    a.addImmediate( b, "Socials (ThemeOption)", "[socials]");
                    a.addWithPopup( b, "Social Icon", "social_icon" );
                    b.addSeparator();
                    a.addWithPopup( b, "Image", "img" );
                    a.addWithPopup( b, "Image with Frame", "img_frame" );
                    a.addWithPopup( b, "Icon", "icon" );
                    b.addSeparator();
                    a.addWithPopup( b, "Google map", "gmap");
                    a.addImmediate( b, "Dropcap", "[dropcap]Text here[/dropcap]");
                    a.addImmediate( b, "Blockquote", "[blockquote]Quote here[/blockquote]");
				});

                return btn;
			}

			return null;
		},

        getInfo: function () {
			return {
				longname: 'Spyropress Shortcodes',
				author: 'Spyropress',
				authorurl: 'http://themeforest.net/user/spyropress/',
				infourl: 'http://wiki.moxiecode.com/',
				version: '1.0'
			}
		}
    });

    tinymce.PluginManager.add( 'spyropressShortcodes', tinymce.plugins.spyropressShortcodes );

})();