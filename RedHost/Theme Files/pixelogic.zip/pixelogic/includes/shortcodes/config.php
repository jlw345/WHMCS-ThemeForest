<?php

/*-----------------------------------------------------------------------------------*/
/*	Data Sources
/*-----------------------------------------------------------------------------------*/
$spyropress_sc_variations = array(
    'primary' => 'Primary',
    'info' => 'Info',
    'success' => 'Success',
    'warning' => 'Warning',
    'danger' => 'Danger',
    'inverse' => 'Inverse'
);

$spyropress_sc_float = array(
    'left' => 'Left',
    'right' => 'Right'
);

$spyropress_sc_window = array(
    '_blank' => 'New window',
    '_self' => 'Same window'
);
$spyropress_sc_animation = array(
    'flash' => 'Flash',
    'shake' => 'Shake',
    'bounce' => 'Bounce',
    'tada' => 'Tada',
    'swing' => 'Swing',
    'wobble' => 'Wobble',
    'wiggle' => 'Wiggle',
    'pulse' => 'Pulse',
    'fadeIn' => 'FadeIn',
    'fadeInUp' => 'FadeInUp',
    'fadeInDown' => 'FadeInDown',
    'fadeInLeft' => 'FadeInLeft',
    'fadeInRight' => 'FadeInRight',
    'fadeInUpBig' => 'FadeInUpBig',
    'fadeInDownBig' => 'FadeInDownBig',
    'fadeInLeftBig' => 'FadeInLeftBig',
    'fadeInRightBig' => 'FadeInRightBig',
    'bounceIn' => 'BounceIn',
    'bounceInUp' => 'BounceInUp',
    'bounceInDown' => 'BounceInDown',
    'bounceInLeft' => 'BounceInLeft',
    'bounceInRight' => 'BounceInRight',
    'rotateIn' => 'RotateIn',
    'rotateInUpLeft' => 'RotateInUpLeft',
    'rotateInDownLeft' => 'RotateInDownLeft',
    'rotateInUpRight' => 'RotateInUpRight',
    'rotateInDownRight' => 'RotateInDownRight'
);

/**
 * Image Config
 */
$spyropress_shortcodes['img'] = array(
	'no_preview' => true,
	'params' => array(

        'content' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Image URL', 'spyropress'),
			'desc' => __('Add the image\'s url eg http://example.com', 'spyropress' )
		),

		'align' => array(
			'type' => 'select',
			'label' => __( 'Image Alignment', 'spyropress'),
			'desc' => __('Select the image alignment left or right', 'spyropress'),
			'options' => $spyropress_sc_float
		)
	),
	'shortcode' => 'img',
);

/**
 * Image Frame Config
 */
$spyropress_shortcodes['img_frame'] = array(
	'no_preview' => true,
	'params' => array(

        'content' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Image URL', 'spyropress'),
			'desc' => __('Add the image\'s url eg http://example.com', 'spyropress' )
		)
	),
	'shortcode' => 'img_frame',
);

/**
 * Icon Config
 */
$spyropress_shortcodes['icon'] = array(
	'no_preview' => true,
	'params' => array(

        'code' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Icon Code', 'spyropress'),
			'desc' => ''
		)
	),
	'shortcode' => 'icon',
);

/**
 * Icon Config
 */
$spyropress_shortcodes['social_icon'] = array(
	'no_preview' => true,
	'params' => array(

        'network' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Icon Code', 'spyropress'),
			'desc' => ''
		),

        'content' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Button URL', 'spyropress'),
			'desc' => __('Add the button\'s url eg http://example.com', 'spyropress' )
		),
	),
	'shortcode' => 'social_icon',
);

/**
 * Google Map Config
 */
$spyropress_shortcodes['gmap'] = array(
	'no_preview' => true,
	'params' => array(

        'content' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __('Address', 'spyropress'),
			'desc' => __('Add the address to display on google map.', 'spyropress' )
		)
	),
	'shortcode' => 'gmap',
);
/**
 * Blockquote Font Config
 */
$spyropress_shortcodes['blockquote'] = array(
	'no_preview' => true,
	'params' => array(
		'content' => array(
			'type' => 'text',
			'label' => __('Content', 'spyropress'),
			'desc' => '',
			'std' => 'Content goes here'
		),

		'animation' => array(
			'type' => 'select',
			'label' => __( 'Animation', 'spyropress'),
			'desc' => '',
			'options' => $spyropress_sc_animation
		)
	),
	'shortcode' => 'blockquote'
);
?>