<?php 

echo $before_widget;

    if ($title != '')
        echo $before_title . $title . $after_title;

    $tweets = $this->get_tweets( $username, $twitter_counts );
    if ( ! empty( $tweets ) ) {
        
        foreach ( $tweets as $tweet ) {
        	
         $text = str_replace( '@envato_help', '', $tweet->text );
            
            echo '<div><p><img src="'. assets_img() .'twi-icon.png" /> '. $text .' <a href="'. $tweet->user->url .'">'. $tweet->user->url .'</a><br/><span>'. human_time_diff( strtotime($tweet->created_at), current_time('timestamp') ) .' ago </span></p></div>';
            
        }  
        
    }
    
echo $after_widget;
?>