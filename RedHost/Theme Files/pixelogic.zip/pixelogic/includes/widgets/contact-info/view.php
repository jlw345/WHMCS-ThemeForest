<?php

echo $before_widget;

if ( $instance['title'] != '' )
    echo $before_title . $instance['title'] . $after_title;

if ( $phone )
    echo '<p><img alt="" src="' . assets_img() . 'con-info1.png"><span>' . $phone . '</span></p>';
if ( $email )
    echo '<p><img alt="" src="' . assets_img() . 'con-info2.png"><span><a href="mailto:' . $email . '">' . $email . '</a></span></p>';
if ( $mobile )
    echo '<p><img alt="" src="' . assets_img() . 'con-info3.png"><span>' . $mobile . '</span></p>';
if ( $address )
    echo '<p><img alt="" src="' . assets_img() . 'con-info4.png"><span>' . $address . '</span></p>';
echo $after_widget;

?>