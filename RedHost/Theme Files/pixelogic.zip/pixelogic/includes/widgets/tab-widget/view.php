<?php

if( empty( $hide ) ) $hide = array();

echo $before_widget;

echo '<ul class="tab-links clearfix">';
    if( !in_array( 'popular', $hide ) ) echo '<li class="active" ><a href="#popular-tab">Popular</a></li>';
    if( !in_array( 'recent', $hide ) ) echo '<li><a href="#recent-tab">Recent</a></li>';
    if( !in_array( 'comment', $hide ) ) echo '<li><a href="#comments-tab">Comments</a></li>';
echo '</ul>';

echo '<ul class="tab-content">';
    if( !in_array( 'popular', $hide ) ) {
        echo '<li>';
        $popular_query = new WP_Query( array(
            'showposts' => $popular,
            'nopaging' => 0,
            'orderby'=> 'comment_count',
            'post_status' => 'publish',
            'ignore_sticky_posts' => 1
        ) );
        
        $out = '';
        while ( $popular_query->have_posts() ) {
            $popular_query->the_post();
            
            $out .= '<div>';
                $out .= get_image(array(
                    'width' => 58,
                    'height' => 58,
                    'crop' => true,
                    'type' => 'url',
                    'echo' => false
                ) );
                $out .= sprintf(
                    '<h3><a href="%1$s">%2$s</a></h3><span><img src="%3$sclock.png">%4$s %5$s</span>',
                    get_permalink(), get_the_title(), assets_img(), get_the_date( 'j F' ), get_the_time()
                );
            $out .= '</div>';
		}
        
        echo $out;
        echo '</li>';
    }
    if( !in_array( 'recent', $hide ) ) {
        echo '<li>';
        $popular_query = new WP_Query( array(
            'showposts' => $recent,
            'nopaging' => 0,
            'post_status' => 'publish',
            'ignore_sticky_posts' => 1
        ) );
        
        $out = '';
        while ( $popular_query->have_posts() ) {
            $popular_query->the_post();
            
            $out .= '<div>';
                $out .= get_image(array(
                    'width' => 58,
                    'height' => 58,
                    'crop' => true,
                    'type' => 'url',
                    'echo' => false
                ) );
                $out .= sprintf(
                    '<h3><a href="%1$s">%2$s</a></h3><span><img src="%3$sclock.png">%4$s %5$s</span>',
                    get_permalink(), get_the_title(), assets_img(), get_the_date( 'j F' ), get_the_time()
                );
            $out .= '</div>';
		}
        
        echo $out;
        echo '</li>';
    }
    if( !in_array( 'comment', $hide ) ) {
        echo '<li>';
        $comments = get_comments( array(
            'number' => $comment,
            'status' => 'approve',
            'post_status' => 'publish'
        ) );
        
        $out = '';
        
        if ( $comments ) {
			foreach ( (array) $comments as $comment) {            
                $out .= '<div>';
                    $out .= get_avatar( $comment->comment_author_email, '51' );
                    $comment_excerpt = wp_html_excerpt( $comment->comment_content, 72 );
                    $out .= sprintf(
                        '<h3><a href="%1$s">%2$s says:</a></h3>%3$s</span>',
                        esc_url( get_comment_link($comment->comment_ID) ), get_comment_author(), $comment_excerpt
                    );
                $out .= '</div>';
            }
		}
        
        echo $out;
        echo '</li>';
    }
echo '</ul>';

echo $after_widget;

?>