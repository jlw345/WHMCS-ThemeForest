<?php

/**
 * Text and Photo Widget
 * Display static text and photo.
 *
 * @package		SpyroPress
 * @category	Widgets
 * @author		SpyroSol
 */

class SpyroPress_Widget_TabWidget extends SpyropressWidget {

    /**
     * Constructor
     */
    function __construct() {

        // Widget variable settings.
        $this->cssclass = 'tabs-widget';
        $this->description = __( 'Display posts and comments in tab.', 'spyropress' );
        $this->id_base = 'spyropress_tabwodget';
        $this->name = __( 'Spyropress: Tab Widget', 'spyropress' );

        $this->fields = array(

            array(
                'label' => __( 'Disable Tabs', 'spyropress' ),
                'id' => 'hide',
                'type' => 'checkbox',
                'options' => array(
                    'popular' => 'Hide Popular Tab',
                    'recent' => 'Hide Recent Tab',
                    'comment' => 'Hide Comment Tab',
                )
            ),

            array(
                'label' => __( 'Num of Popular Posts', 'spyropress' ),
                'id' => 'popular',
                'type' => 'text',
                'std' => 5
            ),
            
            array(
                'label' => __( 'Num of Recent Posts', 'spyropress' ),
                'id' => 'recent',
                'type' => 'text',
                'std' => 5
            ),
            
            array(
                'label' => __( 'Num of Comments', 'spyropress' ),
                'id' => 'comment',
                'type' => 'text',
                'std' => 5
            )
        );

        $this->create_widget();
    }

    function widget( $args, $instance ) {

        // extracting info
        extract( $args );
        extract( spyropress_clean_array( $instance ) );

        // get view to render
        include $this->get_view();
    }
} // class SpyroPress_Widget_TabWidget

register_widget( 'SpyroPress_Widget_TabWidget' );
?>