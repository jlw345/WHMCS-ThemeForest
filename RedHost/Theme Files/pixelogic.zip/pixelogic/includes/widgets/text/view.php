<?php

echo $before_widget;
if ( $title != '' )
    echo $before_title . $title . $after_title;

$photo = isset( $instance['photo'] ) ? $photo : false;
if( $photo ) {
    echo '<div class="img-frame ' . get_float_class( $float ) . '">';
    if ( $size )
        $photo = get_image( array(
            'url' => $photo,
            'width' => $size,
            'responsive' => true
        ) );
    else
        echo '<img src="' . $photo . '" alt="" />';
    echo '</div>';
}
echo '<div class="text">' . do_shortcode( isset($instance['filter'] ) ? wpautop( $content ) : $content ) . '</div><div class="clear"></div>';
echo $after_widget;

?>