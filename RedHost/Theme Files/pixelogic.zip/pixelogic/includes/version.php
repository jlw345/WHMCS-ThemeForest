<?php

/**
 * Theme Meta Info for internal usage
 *
 * Dont Mess with it.
 */
add_action( 'before_spyropress_core_includes', 'spyropress_setup_theme' );
function spyropress_setup_theme() {
    global $spyropress;
    
    $spyropress->internal_name = 'pixelogic';
    $spyropress->theme_name = 'Pixelogic';
    $spyropress->theme_version = '2.0';
    
    $spyropress->row_class = 'row-fluid';
	$spyropress->framework = 'bs';
    $spyropress->grid_columns = 12;
}
?>