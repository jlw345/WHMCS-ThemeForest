<?php

/**
 * Enqueue scripts and stylesheets
 *
 * @category Core
 * @package SpyroPress
 *
 */

/**
 * Register StyleSheets
 */
function spyropress_register_stylesheets() {

    // Google Webfonts
    $families = get_option( '_spyropress_google_fontfamilies' );
    if ( ! empty( $families ) ) {
        $gurl = 'http' . ( is_ssl() ? 's' : '' ) . '://fonts.googleapis.com/css?family=' . urlencode( implode( '|', $families ) );
        wp_enqueue_style( 'google-fonts', $gurl );
    }
    
    wp_enqueue_style( 'bootstrap', assets_css() . 'bootstrap.css', false, '2.1.1' );
    wp_enqueue_style( 'responsive', assets_css() . 'bootstrap-responsive.css', false, '2.1.1' );

    wp_enqueue_style( 'base', assets_css() . 'base.css', false, '1.0' );
    wp_enqueue_style( 'base-responsive', assets_css() . 'base-responsive.css', false, '1.0' );
    //wp_enqueue_style( 'r-slider', assets_css() . 'rslider.css', false, '1.4.5' );

    // Dynamic StyleSheet
    if ( file_exists( dynamic_css_path() . 'dynamic.css' ) )
        wp_enqueue_style( 'dynamic', dynamic_css_url() . 'dynamic.css', false, '2.0.0' );

    // Builder StyleSheet
    if ( file_exists( dynamic_css_path() . 'builder.css' ) )
        wp_enqueue_style( 'builder', dynamic_css_url() . 'builder.css', false, '2.0.0' );

    // modernizr
    wp_enqueue_script( 'modernizr', assets_js() . 'modernizr.min.js', array( 'jquery' ), '2.6.2', false );
}

/**
 * Enqueque Scripts
 */
function spyropress_register_scripts() {

    /**
     * Register Scripts
     */
    // threaded comments
    if ( is_single() && comments_open() && get_option( 'thread_comments' ) )
        wp_enqueue_script( 'comment-reply' );

    
    // plugins
    wp_register_script( 'jquery-ticker', assets_js() . 'jquery.ticker.js', false, false, true );
    wp_register_script( 'jquery-superfish', assets_js() . 'jquery.superfish.js', false, false, true );
    wp_register_script( 'jquery-selectbox', assets_js() . 'jquery.selectbox.min.js', false, false, true );
    wp_register_script( 'jquery-fancybox', assets_js() . 'jquery.fancybox.js', false, false, true );
    wp_register_script( 'jquery-imagesloaded', assets_js() . 'jquery.imagesloaded.min.js', false, false, true );
    wp_register_script( 'jquery-isotope', assets_js() . 'jquery.isotope.min.js', false, false, true );
    wp_register_script( 'jquery-cookie', assets_js() . 'jquery.cookie.js', false, false, true );
    
    wp_register_script( 'google-api', 'http://maps.google.com/maps/api/js?sensor=false', false, false, true );
    wp_register_script( 'jquery-gmap', assets_js() . 'jquery.gmap3.min.js', array( 'google-api' ), false, true );
    
    $deps = array(
        'jquery-ticker',
        'jquery-superfish',
        'jquery-selectbox',
        'jquery-imagesloaded',
        'jquery-isotope',
        'jquery-fancybox',
        'jquery-gmap',
        'jquery-cookie'
    );
    
    // custom scripts
    wp_register_script( 'custom-script', assets_js() . 'script.js', $deps, '2.1', true );

    /**
     * Enqueue All
     */
    wp_enqueue_script( 'custom-script' );
    
    if( get_setting( 'header_fixed' ) ) {
        wp_enqueue_script( 'jquery-sticky', assets_js() . 'jquery.sticky.js', false, false, true );
        
        add_jquery_ready( '$("#menu").sticky({topSpacing:0});' );
    }
}

function spyropress_conditional_scripts() {

    $content = '<!--[if lt IE 9]>
		<script src="' . assets_js() . 'ie8.js"></script>
	<![endif]-->';

    echo get_relative_url( $content );
}