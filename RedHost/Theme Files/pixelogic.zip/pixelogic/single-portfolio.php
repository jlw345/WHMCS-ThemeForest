<?php get_header(); ?>

<?php spyropress_before_main_container(); ?>
<!-- content -->
<div id="content" class="singlework">
    <header class="cont-head">
        <div class="cont-text container">
            <?php spyropress_before_post_title(); ?>
            <h1 class="entry-title">PORTFOLIO</h1>
            <?php spyropress_after_post_title(); ?>
            <p><?php _e('You are Here','spyropress'); ?>:<?php if( function_exists( 'bcn_display' ) ) { bcn_display(); } ?></p>
        </div>
    </header>
    <?php
    spyropress_before_loop();
    while( have_posts() ) {
        the_post();
        
        spyropress_before_post();
        
        $details = get_post_meta( get_the_ID(), '_portfolio_details', true );
    ?>
    <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    	<div id="inner-content" class="container">
            <div class="single-nav">
                <?php spyropress_next_prev_post_link(); ?>
                <a id="lnch" href="<?php echo $details['project_url']; ?>"><span></span>Launch Project</a>
            </div>
            <?php if( 'full' == $details['style'] ) get_template_part( 'templates/portfolio', 'slider' ); ?>
            <div class="row-fluid">
                <div class="single-post span8">
                <?php if( 'half' == $details['style'] ) get_template_part( 'templates/portfolio', 'slider' ); ?>
                    <?php
                        the_title( '<h2 class="entry-title">', '</h2>' );
                        spyropress_before_post_content();
                        spyropress_the_content( );
                        wp_link_pages( array( 'before' => '<div class="page-link">' . __( 'Pages:', 'spyropress' ), 'after' => '</div>' ) );
                        spyropress_after_post_content();
                    ?>
                </div>
                <aside id="sidebar" class="span4">
                    <ul>
            			<?php if( !empty( $details['service'] ) ) { ?>
                        <li class="widget serv2-widget">
            				<h1>Services Used</h1>
                            <?php
                                foreach( $details['service'] as $item )
                                    echo '<p><span></span>' . $item['title'] . '</p>';
                            ?>
            			</li>
                        <?php } ?>
           				<?php echo get_the_term_list( get_the_ID(), 'portfolio_category', '<li class="widget widget_tag_cloud"><h1>'. __( 'Tags', 'spyropress' ) .'</h1>', '', '</li>' ); ?>
            		</ul>
                </aside>
            </div>
        </div>
    </div>
    <?php
            
        spyropress_after_post();
    }
    spyropress_after_loop();
    ?>
</div>
<!-- /content -->
<?php spyropress_after_main_container(); ?>
<?php get_footer(); ?>