var $ = jQuery.noConflict();

$(document).ready(function($) {
	/*-------------------------------------------------*/
	/* =  Dropdown Menu - Superfish
	/*-------------------------------------------------*/
	$('.flicker-images a:nth-child(3n), .main3 .recent2 ul li:nth-child(3n)').css({'margin-right': '0px'});
	$('#recent .left:last-child').css({'margin-right': '0px'});
	$('.main3 .recent2 ul li:nth-child(3n)').css({'margin-right': '0px'});
	$('li.flicker-widget a:nth-child(3n+1)').css({'margin-right': '0px'});
	$('.blog .span6:nth-child(2n+1)').css({'margin-left': '0px'});
	$('.blog .span4:nth-child(3n+1)').css({'margin-left': '0px'});
	$('.blog .span3:nth-child(4n+1)').css({'margin-left': '0px'});
	$('#about .images ul li:nth-child(3n)').css({'border-right': '1px solid #e1e1e1'});
	$('#about .images ul li:nth-child(3n)').css({'border-bottom': '1px solid #e1e1e1'});
	$('#about .images ul li:nth-child(3n-1)').css({'border-bottom': '1px solid #e1e1e1'});
	$('#about .images ul li:nth-child(3n-2)').css({'border-bottom': '1px solid #e1e1e1'});
	$('#marg').css({'margin-top': '40px'});
});