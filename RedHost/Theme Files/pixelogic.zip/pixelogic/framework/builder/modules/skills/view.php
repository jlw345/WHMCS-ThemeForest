<?php

if( empty( $skills ) ) return;

echo $before_widget;
    if( $title ) echo '<h1 class="huppercase">' . $title . '</h1>';
    foreach( $skills as $skill ) {
        
        echo '
        <h4>' . $skill['title'] . '</h4>
        <div class="backgr">
            <div class="skill" style="width:' . $skill['percentage'] . '%"></div>
        </div>';
    }
echo $after_widget;
?>