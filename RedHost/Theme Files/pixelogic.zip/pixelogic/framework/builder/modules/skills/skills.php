<?php

/**
 * Module: Skills
 *
 * @author 		SpyroSol
 * @category 	BuilderModules
 * @package 	Spyropress
 */

class Spyropress_Module_Skills extends SpyropressBuilderModule {

    /**
     * Constructor
     */
    public function __construct() {

        $this->path = dirname(__FILE__);
        // Widget variable settings
        $this->cssclass = 'module-skills';
        $this->description = __( 'Display a list skills.', 'spyropress' );
        $this->id_base = 'spyropress_skills';
        $this->name = __( 'Skills', 'spyropress' );
        
        // Fields
        $this->fields = array (
            
            array(
                'label' => __( 'Title', 'spyropress' ),
                'id' => 'title',
                'type' => 'text'
            ),
            
            array(
                'label' => __( 'Skill', 'spyropress' ),
                'id' => 'skills',
                'type' => 'repeater',
                'item_title' => 'title',
                'fields' => array(
                    array(
                        'label' => __( 'Name', 'spyropress' ),
                        'id' => 'title',
                        'type' => 'text'
                    ),
                    
                    array(
                        'label' => __( 'Percentage', 'spyropress' ),
                        'id' => 'percentage',
                        'type' => 'text'
                    )
                )
            ),
        );
        
        $this->create_widget();
    }

    function widget( $args, $instance ) {
        
        // extracting info
        extract( $args ); extract( $instance );
        $template = isset( $instance['template'] ) ? $instance['template'] : '';
        include $this->get_view( $template );
    }

}

spyropress_builder_register_module( 'Spyropress_Module_Skills' );

?>