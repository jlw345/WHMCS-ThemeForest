<?php

/**
 * Module: Our Clients
 * Display a list of our clients
 *
 * @author 		SpyroSol
 * @category 	BuilderModules
 * @package 	Spyropress
 */

class Spyropress_Module_Our_Clients extends SpyropressBuilderModule {

    /**
     * Constructor
     */
    public function __construct() {

        // Widget variable settings
        $this->cssclass = 'module-our-clients';
        $this->description = __( 'Display a list of our clients.', 'spyropress' );
        $this->id_base = 'spyropress_our_clients';
        $this->name = __( 'Our Clients', 'spyropress' );

        // Fields
        $this->fields = array (

            array(
                'label' => __( 'Title', 'spyropress' ),
                'id' => 'title',
                'type' => 'text'
            ),

            array(
                'id' => 'clients',
                'label' => 'Client',
                'type' => 'repeater',
                'fields' => array(
                    array(
                        'label' => __( 'Logo', 'spyropress' ),
                        'id' => 'logo',
                        'type' => 'upload'
                    ),
                )
            )
        );

        $this->create_widget();
    }

    function widget( $args, $instance ) {

        // extracting info
        extract( $args ); extract( $instance );

        include $this->get_view();
    }

}

spyropress_builder_register_module( 'Spyropress_Module_Our_Clients' );

?>