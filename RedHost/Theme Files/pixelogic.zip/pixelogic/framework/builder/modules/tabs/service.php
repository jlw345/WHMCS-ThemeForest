<?php

// chcek
if ( empty( $tabs ) ) return;

$count = 0;
$tab_nav = $tabs_content = '';
foreach( $tabs as $tab ) {
    ++$count;
    $li_class = ( $count == 1 ) ? ' class="active3"' : '';
    
    $tab_nav .= '<li' . $li_class . '>' . $tab['title'] . '</li>';
    $tabs_content .= '<li class="displayed">';
    
    // content
    if( isset( $tab['bucket'] ) ) {
        $args = array(
            'post_type' => 'bucket',
            'p' => $tab['bucket']
        );
        $query = new WP_Query( $args );
        while( $query->have_posts() ) {
            $query->the_post();
            $tabs_content .= spyropress_get_the_content();
        }
    }
    else {
        $tabs_content .= $tab['content'];
    }
    $tabs_content .= '</li> <!-- end tab-pane -->';
}
wp_reset_query();
?>
<div id="serv3" class="services3 row-fluid clearfix">
    <ul class="span3">
        <?php echo $tab_nav; ?>
    </ul>
    <ul class="wrapper span9">
        <?php echo $tabs_content; ?>
    </ul>
<?php echo $after_widget; ?><!-- end tabbable -->