<?php

// chcek
if ( empty( $tabs ) ) return;

$count = 0;
$tab_nav = $tabs_content = '';
foreach( $tabs as $tab ) {
    ++$count;
    $li_class = ( $count == 1 ) ? ' class="active"' : '';
    
    $tab_nav .= '<li' . $li_class . '><a href="#tab' . $count . '" data-toggle="tab">' . $tab['title'] . '</a></li>';
    $tabs_content .= '<li class="clearfix" id="tab' . $count . '">';
    
    // content
    if( isset( $tab['bucket'] ) ) {
        $args = array(
            'post_type' => 'bucket',
            'p' => $tab['bucket']
        );
        $query = new WP_Query( $args );
        while( $query->have_posts() ) {
            $query->the_post();
            $tabs_content .= spyropress_get_the_content();
        }
    }
    else {
        $tabs_content .= $tab['content'];
    }
    $tabs_content .= '</li> <!-- end tab-pane -->';
}
wp_reset_query();
?>
<?php echo $before_widget; ?>
    <ul class="tab-list clearfix">
        <?php echo $tab_nav; ?>
    </ul>
    <ul class="tab-cont">
        <?php echo $tabs_content; ?>
    </ul>
<?php echo $after_widget; ?><!-- end tabbable -->