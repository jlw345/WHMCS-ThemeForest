<?php

/**
 * Module: Divider 
 * Separate sections of the layout.
 *
 * @author 		SpyroSol
 * @category 	BuilderModules
 * @package 	Spyropress
 */

class Spyropress_Module_Divider extends SpyropressBuilderModule {

    public function __construct() {

        // Widget variable settings.
        $this->cssclass = 'module-divider';
        $this->description = __( 'Separate sections of the layout.', 'spyropress' );
        $this->id_base = 'spyropress_divider';
        $this->name = __( 'Divider', 'spyropress' );

        $this->fields = array(
            array(
                'label' => __( 'Divider Style', 'spyropress' ),
                'id' => 'divider_type',
                'type' => 'select',
                'class' => 'enable_changer',
                'options' => array(
                    'divider' => __( 'Divider', 'spyropress' ),
                    'divider_flat' => __( 'Flat Divider', 'spyropress' )
                )
            )
        );

        $this->create_widget();

    }

    function widget( $args, $instance ) {
        // outputs the content of the widget
        extract( $instance );

        if ( ! $divider_type ) return;
        
        $classes = array(
            'divider' => 'divider',
            'divider_flat' => 'divider divider-flat'
        );
        
        echo sprintf( '<div class="%1$s"></div>', $classes[$divider_type] );
    }

}

spyropress_builder_register_module( 'Spyropress_Module_Divider' );

?>