<?php

echo $before_widget;
    spyropress_before_sidebar();
    echo '<aside id="sidebar">';
    	dynamic_sidebar($sidebar);
    echo '</aside>';
    spyropress_after_sidebar();
    echo '<div class="clear"></div>';
echo $after_widget;
?>