<?php

echo $before_widget;
    echo '<h2><span>' . $icon . '</span>' . $title . '</h2>';
    echo wpautop( $content );
echo $after_widget;
?>