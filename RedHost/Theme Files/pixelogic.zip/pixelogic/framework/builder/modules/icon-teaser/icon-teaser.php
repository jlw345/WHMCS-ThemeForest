<?php

/**
 * Module: Icon Teaser
 * Display a brief text with a link and use hundreds of built-in icons
 *
 * @author 		SpyroSol
 * @category 	BuilderModules
 * @package 	Spyropress
 */

class Spyropress_Module_Icon_Teaser extends SpyropressBuilderModule {

    /**
     * Constructor
     */
    public function __construct() {

        $this->path = dirname(__FILE__);
        // Widget variable settings
        $this->cssclass = 'module-icon-teaser';
        $this->description = __( 'Display a brief text with a link and use of icons.', 'spyropress' );
        $this->id_base = 'spyropress_icon_teaser';
        $this->name = __( 'Icon Teaser', 'spyropress' );

        $this->templates['style2'] = array(
            'label' => 'Style2',
            'view'  => 'style2.php',
            'class' => 'teaser2'
        );
        
        $this->templates['style3'] = array(
            'label' => 'Style3',
            'view'  => 'style3.php',
            'class' => 'teaser3'
        );
        
        $this->templates['style4'] = array(
            'label' => 'Style4',
            'view'  => 'style4.php',
            'class' => 'teaser4'
        );
        
        $this->templates['style5'] = array(
            'label' => 'Style5',
            'view'  => 'style5.php',
            'class' => 'teaser5'
        );
        
        $this->templates['style6'] = array(
            'label' => 'Style6',
            'view'  => 'style6.php',
            'class' => 'teaser6'
        );
        
        // Fields
        $this->fields = array (
            
            array(
                'label' => __( 'Title', 'spyropress' ),
                'id' => 'title',
                'type' => 'text'
            ),
            
            array(
                'label' => __( 'Upload Icon', 'spyropress' ),
                'id' => 'icon',
                'type' => 'upload'
            ),

            array(
                'label' => __( 'Content', 'spyropress' ),
                'id' => 'content',
                'type' => 'textarea',
                'rows' => 6
            ),
            
            array(
                'label' => __( 'Style', 'spyropress' ),
                'id' => 'template',
                'type' => 'select',
                'options' => $this->get_option_templates()
            ),
        );
        
        $this->fields = spyropress_get_options_link( $this->fields );
        
        $this->create_widget();
    }

    function widget( $args, $instance ) {
        
        $instance = spyropress_clean_array( $instance );
        $defaults = array(
            'url_text' => 'Read More',
            'url' => '#',
            'link_url' => '',
            'template' => ''
        );
        // extracting info
        extract( $args ); extract( wp_parse_args( $instance, $defaults ) );
        
        include $this->get_view( $template );
    }

}

spyropress_builder_register_module( 'Spyropress_Module_Icon_Teaser' );

?>