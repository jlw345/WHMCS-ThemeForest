<?php

// title, icon, content, url_text, url, link_url
if( $icon )
    $icon = '<img alt="" src="' . $icon . '">';

echo $before_widget;
    echo '<h2><span>' . $title . '</span></h2>';
    echo wpautop( $icon . $content );
echo $after_widget;
?>