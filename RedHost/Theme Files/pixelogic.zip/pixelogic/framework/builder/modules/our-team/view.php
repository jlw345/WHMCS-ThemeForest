<?php

if( empty( $mates ) ) return;

echo $before_widget;
    echo '<div class="row-fliud clearfix" id="our-team">';
        if( $title ) echo '<h1 class="huppercase">' . $title . '</h1>';
        $count = 0;
        foreach( $mates as $mate ) {
            
            $class = ( 0 == $count++ ) ? ' column_first' : '';
            echo '
            <div class="span3' . $class . '">
                <a href="#"><img alt="" src="' . $mate['picture'] . '"></a>
				<h4>' . $mate['title'] . '</h4>
				<span>' . $mate['designation'] . '</span>
                ' . wpautop( $mate['content'] ) . '
            </div>';
        }
    echo '</div>';
echo $after_widget;
?>