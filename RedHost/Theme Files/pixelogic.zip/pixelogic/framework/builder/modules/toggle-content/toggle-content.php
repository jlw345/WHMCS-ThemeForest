<?php

/**
 * Module: Toggle Content
 * Display toggle content list of
 *
 * @author 		SpyroSol
 * @category 	BuilderModules
 * @package 	Spyropress
 */

class Spyropress_Module_Toggle_Content extends SpyropressBuilderModule {

    /**
     * Constructor
     */
    public function __construct() {
        
        // Widget variable settings
        $this->cssclass = 'module-toggle-content';
        $this->description = __( 'Display toggle content list.', 'spyropress' );
        $this->id_base = 'spyropress_toggle_content';
        $this->name = __( 'Toggle Content', 'spyropress' );

        // Fields
        $this->fields = array (

            array(
                'label' => __( 'Title', 'spyropress' ),
                'id' => 'title',
                'type' => 'text'
            ),
            
            array(
                'id' => 'toggles',
                'label' => 'Content',
                'type' => 'repeater',
                'item_title' => 'title',
                'fields' => array(
                    array(
                        'label' => __( 'Title', 'spyropress' ),
                        'id' => 'title',
                        'type' => 'text'
                    ),
                    
                    array(
                        'label' => __( 'Icon', 'spyropress' ),
                        'id' => 'icon',
                        'type' => 'upload'
                    ),
                    
                    array(
                        'label' => __( 'Content', 'spyropress' ),
                        'id' => 'content',
                        'type' => 'textarea',
                        'rows' => 6
                    ),
                )
            )
        );

        $this->create_widget();
    }

    function widget( $args, $instance ) {

        // extracting info
        extract( $args ); extract( $instance );

        include $this->get_view();
    }

}

spyropress_builder_register_module( 'Spyropress_Module_Toggle_Content' );
?>