<?php

if( empty( $toggles ) ) return;

echo $before_widget;
if( isset( $title ) && $title ) echo '<h1 class="huppercase">' . $title . '</h1>';
echo '<div class="serv-widget"><div class="serv-item">';
        
    foreach( $toggles as $toggle ) {
        
        if( isset( $toggle['icon'] ) )
            $icon = '<img src="' . $toggle['icon'] . '">';
            echo '<h3>' . $icon . $toggle['title'] . '</h3>';
            echo wpautop( $toggle['content'] );
    }

echo '</div></div>';
echo $after_widget;
?>