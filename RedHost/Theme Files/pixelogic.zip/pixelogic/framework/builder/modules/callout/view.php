<?php

// $title, $content, $url, $link_url, $url_text

if ( $content ) {
    $url_text = ( $url_text ) ? $url_text : 'Buy Now';
    $url = ( $link_url ) ? get_permalink( $link_url ) : $url;

    if ( $url ) $url = ' <a href="' . $url . '">' . $url_text . '</a>';
}

echo $before_widget;
    echo '<blockquote>' . $content .'</blockquote>';
    echo $url;
    echo '<div class="clear"></div>';
echo $after_widget;

?>