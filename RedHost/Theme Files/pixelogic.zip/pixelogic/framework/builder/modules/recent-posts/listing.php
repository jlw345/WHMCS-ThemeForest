<?php

// Setup Instance for view
$instance = spyropress_clean_array( $instance );
$instance['callback'] = array( $this, "generate_post_{$template}_item" );

$tmpl = '<div class="blog row-fluid">{content}{pagination}</div>';

echo $before_widget;    

    echo $this->query( $instance, $tmpl );
    
echo $after_widget;
?>