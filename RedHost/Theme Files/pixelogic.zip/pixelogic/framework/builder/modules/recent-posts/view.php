<?php

// Setup Instance for view
$instance = spyropress_clean_array( $instance );

// tempalte
$tmpl = '{content}{pagination}';

echo $before_widget;

    // title
    if ( $instance['title'] ) echo '<h1 class="huppercase">' . $instance['title'] . '</h1>';    
    // output content
    echo $this->query( $instance, $tmpl );
    
echo $after_widget;
?>