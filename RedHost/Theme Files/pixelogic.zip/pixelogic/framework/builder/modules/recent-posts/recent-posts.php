<?php

/**
 * Module: Recent Posts
 * Display a list of recent posts
 *
 * @author 		SpyroSol
 * @category 	BuilderModules
 * @package 	Spyropress
 */

class Spyropress_Module_Recent_Posts extends SpyropressBuilderModule {

    public function __construct() {

        $this->path = dirname(__FILE__);
        // Widget variable settings.
        $this->cssclass = 'popular-post';
        $this->description = __( 'Display a list of recent post.', 'spyropress' );
        $this->id_base = 'spyropress_recent_posts';
        $this->name = __( 'Posts', 'spyropress' );

        $this->templates['listing'] = array(
            'view' => 'listing.php',
            'label' => 'Blog Listing'
        );
        
        $this->templates['listing2'] = array(
            'view' => 'listing.php',
            'label' => 'Blog Listing 2'
        );
        
        // Fields
        $this->fields = array(

            array(
                'label' => __( 'Title', 'spyropress' ),
                'id' => 'title',
                'type' => 'text',
                'std' => $this->name
            ),

            array('type' => 'row'),
                array('type' => 'col', 'size' => 6),
                array(
                    'label' => __( 'Number of items per page', 'spyropress' ),
                    'id' => 'limit',
                    'type' => 'range_slider',
                    'min' => 1,
                    'max' => 30,
                    'std' => 4
                ),
                array(
                    'label' => __( 'Number of Columns', 'spyropress' ),
                    'id' => 'columns',
                    'type' => 'range_slider',
                    'min' => 1,
                    'max' => 4,
                    'std' => 2
                ),
                
                array('type' => 'col_end'),
            
                array('type' => 'col', 'size' => 6),
                array(
                    'label' => __( 'Category', 'spyropress' ),
                    'id' => 'cat',
                    'type' => 'multi_select',
                    'options' => spyropress_get_taxonomies( 'category' )
                ),
    
                array(
                    'label' => __('Pagination', 'spyropress'),
                    'id' => 'pagination',
                    'type' => 'checkbox',
                    'desc' => 'Will show pagination if portfolio per page is set.',
                    'options' => array(
                        '1' => __('Enable pagination for the next page', 'spyropress')
                    )
                ),
                array('type' => 'col_end'),
                
            array('type' => 'row_end'),
            
            array(
                'label' => 'Template',
                'id' => 'template',
                'type' => 'select',
                'options' => $this->get_option_templates()
            )
        );

        $this->create_widget();
    }

    function widget( $args, $instance ) {
        
        // extracting info
        extract( $args );

        $template = isset( $instance['template'] ) ? $instance['template'] : '';

        // get view to render
        include $this->get_view( $template );
    }
    
    function query( $atts, $content = null ) {

        $default = array (
            'post_type' => 'post',
            'limit' => -1,
            'columns' => false,
            'callback' => array( $this, 'generate_post_item' ),
            'item_class' => 'post-entry'
        );
        $atts = wp_parse_args( $atts, $default );
    
        if ( ! empty( $atts['cat'] ) ) {
    
            $atts['tax_query']['relation'] = 'OR';
            if ( ! empty( $atts['cat'] ) ) {
                $atts['tax_query'][] = array(
                    'taxonomy' => 'category',
                    'field' => 'slug',
                    'terms' => $atts['cat'],
                );
                unset( $atts['cat'] );
            }
        }
    
        if ( $content )
            return token_repalce( $content, spyropress_query_generator( $atts ) );
    
        return spyropress_query_generator( $atts );
    }
    
    function generate_post_item( $post_ID, $atts ) {

        // these arguments will be available from inside $content
        $image = array(
            'post_id' => $post_ID,
            'echo' => false,
            'width' => 58,
            'height' => 58,
            'crop' => true
        );
        $image_tag = get_image( $image );
        
        // item tempalte
        $item_tmpl = '
        <div class="post">
            ' . $image_tag . '
            <a href="' . get_permalink( $post_ID ) . '"><p>' . get_the_title( $post_ID ) . '</p></a>
            <span>' . get_the_date( ) . '</span>
        </div>';
        
        return $item_tmpl;
    }
    
    function generate_post_listing_item( $post_ID, $atts ) {
    
        // these arguments will be available from inside $content
        $width = 9999;
        if( 2 == $atts['columns'] )  $width = 470;
        elseif( 3 == $atts['columns'] )  $width = 300;
        elseif( 4 == $atts['columns'] )  $width = 300;
        
        $image = array(
            'post_id' => $post_ID,
            'echo' => false,
            'width' => $width,
            'crop' => true
        );
        if( 4 == $atts['columns'] )  $image['height'] = 201;
        $image_tag = get_image( $image );
        
        // item tempalte
        $item_tmpl = '';
        if( 4 == $atts['columns'] ) {
            $item_tmpl = sprintf('
            <div class="blog-post %7$s">
                <a href="%1$s">%2$s</a>
                <div class="post-title">
                    <h1>
                        <a href="%1$s">%3$s</a>
                    </h1>
                    <p>
                        <span>Posted by %4$s</span>
                        <span>in %5$s</span>
                    </p>
                </div>
                %6$s
                <a id="read-more" href="%1$s">Read More <span></span></a>
            </div>',
            get_permalink( $post_ID ), $image_tag, get_the_title( $post_ID ), get_the_author_link(),
            get_the_category_list( ', '), get_the_excerpt(), $atts['column_class']
            );
        }
        else {
            $item_tmpl = sprintf('
            <div class="blog-post %9$s">
                <a href="%1$s">%2$s</a>
                <div class="post-title">
                    <div class="post-date">
                        <span>%4$s</span><span>%5$s</span>
                    </div>
                    <h1>
                        <a href="%1$s">%3$s</a>
                    </h1>
                    <p>
                        <span>Posted by %6$s</span>
                        <span>in %7$s</span>
                    </p>
                </div>
                %8$s
                <a id="read-more" href="%1$s">Read More <span></span></a>
            </div>',
            get_permalink( $post_ID ), $image_tag, get_the_title( $post_ID ), get_the_date( 'j' ), get_the_date( 'M' ),
            get_the_author_link(), get_the_category_list( ', '), get_the_excerpt(), $atts['column_class']
            );
        }
        
        return $item_tmpl;
    }
    
    function generate_post_listing2_item( $post_ID, $atts ) {
    
        // these arguments will be available from inside $content
        $width = 9999;
        if( 2 == $atts['columns'] )  $width = 470;
        elseif( 3 == $atts['columns'] )  $width = 300;
        elseif( 4 == $atts['columns'] )  $width = 300;
        
        $image = array(
            'post_id' => $post_ID,
            'echo' => false,
            'width' => $width,
            'crop' => true
        );
        if( 4 == $atts['columns'] )  $image['height'] = 201;
        $image_tag = get_image( $image );
        
        // item tempalte
        $item_tmpl = '';
        if( 4 == $atts['columns'] ) {
            $item_tmpl = sprintf('
            <div class="blog-post %7$s">
                <div class="post-title">
                    <h1>
                        <a href="%1$s">%3$s</a>
                    </h1>
                    <p>
                        <span>Posted by %4$s</span>
                        <span>in %5$s</span>
                    </p>
                </div>
                <a href="%1$s">%2$s</a>
                %6$s
                <a id="read-more" href="%1$s">Read More <span></span></a>
            </div>',
            get_permalink( $post_ID ), $image_tag, get_the_title( $post_ID ), get_the_author_link(),
            get_the_category_list( ', '), get_the_excerpt(), $atts['column_class']
            );
        }
        else {
            $item_tmpl = sprintf('
            <div class="blog-post %9$s">
                <div class="post-title">
                    <div class="post-date">
                        <span>%4$s</span><span>%5$s</span>
                    </div>
                    <h1>
                        <a href="%1$s">%3$s</a>
                    </h1>
                    <p>
                        <span>Posted by %6$s</span>
                        <span>in %7$s</span>
                    </p>
                </div>
                <a href="%1$s">%2$s</a>
                %8$s
                <a id="read-more" href="%1$s">Read More <span></span></a>
            </div>',
            get_permalink( $post_ID ), $image_tag, get_the_title( $post_ID ), get_the_date( 'j' ), get_the_date( 'M' ),
            get_the_author_link(), get_the_category_list( ', '), get_the_excerpt(), $atts['column_class']
            );
        }
        
        return $item_tmpl;
    }
}

spyropress_builder_register_module( 'Spyropress_Module_Recent_Posts' );
?>