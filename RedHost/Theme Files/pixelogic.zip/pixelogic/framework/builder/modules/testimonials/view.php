<?php

// chcek
if ( empty( $testimonials ) ) return;

echo $before_widget;
    if( $title ) echo '<h1 class="huppercase">' . $title . '</h1>';
    
    echo '<ul>';
        foreach( $testimonials as $testimonial ) {
            echo '<li><blockquote>' . $testimonial['content'] . '<br><span>' . $testimonial['author'] . '</span></blockquote>';
        }
    echo '</ul>';
    wp_reset_query();
echo $after_widget;
?>