<?php

if( empty( $icons ) ) return;

echo $before_widget;
    
    if( $title ) echo '<h1>' . $title . '</h1>';
    
    foreach( $icons as $icon ) {
        
        if( $icon['icon'] )
            echo '<p><img alt="" src="' . $icon['icon'] . '"> ' . $icon['content'] . '</p>';
    }
echo $after_widget;
?>