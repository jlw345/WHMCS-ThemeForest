<?php

/**
 * Module: Icon List
 * Display a brief text with a link and use hundreds of built-in icons
 *
 * @author 		SpyroSol
 * @category 	BuilderModules
 * @package 	Spyropress
 */

class Spyropress_Module_Icon_List extends SpyropressBuilderModule {

    /**
     * Constructor
     */
    public function __construct() {

        $this->path = dirname(__FILE__);
        // Widget variable settings
        $this->cssclass = 'list-icons';
        $this->description = __( 'Display a brief text with an icon.', 'spyropress' );
        $this->id_base = 'spyropress_icon_list';
        $this->name = __( 'Icon List', 'spyropress' );
        
        // Fields
        $this->fields = array (
            
            array(
                'label' => __( 'Title', 'spyropress' ),
                'id' => 'title',
                'type' => 'text'
            ),
                    
            array(
                'label' => __( 'Icon', 'spyropress' ),
                'id' => 'icons',
                'type' => 'repeater',
                'fields' => array(
            
                    array(
                        'label' => __( 'Upload Icon', 'spyropress' ),
                        'id' => 'icon',
                        'type' => 'upload'
                    ),
        
                    array(
                        'label' => __( 'Content', 'spyropress' ),
                        'id' => 'content',
                        'type' => 'textarea',
                        'rows' => 6
                    )
                )
            )
                
        );
        
        $this->create_widget();
    }

    function widget( $args, $instance ) {
        
        $defaults = array(
            'url_text' => 'Read More',
            'url' => '#'
        );
        // extracting info
        extract( $args ); extract( wp_parse_args( spyropress_clean_array( $instance ), $defaults ) );

        $template = isset( $instance['template'] ) ? $instance['template'] : '';
        
        include $this->get_view( $template );
    }

}

spyropress_builder_register_module( 'Spyropress_Module_Icon_List' );

?>