<?php
$translate['404-title'] = get_setting( 'translate' ) ? get_setting( 'error-404-title', 'Ooops... Error 404' ) : __( 'Ooops... Error 404', 'spyropress' );
$translate['404-subtitle'] = get_setting('translate') ? get_setting( 'error-404-subtitle', 'We`re sorry, but the page you are looking for doesn`t exist.' ) : __( 'We`re sorry, but the page you are looking for doesn`t exist.', 'spyropress' );
$translate['404-text'] = get_setting('translate') ? get_setting( 'error-404-text', 'Please check entered address and try again <em>or</em>' ) : __( 'Please check entered address and try again <em>or</em>', 'spyropress' );
$translate['404-btn'] = get_setting('translate') ? get_setting( 'error-404-btn', 'go to homepage' ) : __( 'go to homepage', 'spyropress' );

$options = get_post_meta( get_the_ID(), '_page_options', true );

$no_title = ( isset( $options['no_title'] ) ) ? true : false;
get_header();
?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <?php if( !is_front_page() && !is_home() && !$no_title ) { ?>
    <header class="cont-head">
        <div class="cont-text container">
            <?php spyropress_before_post_title(); ?>
            <h1 class="entry-title"><?php the_title(); ?></h1>
            <?php spyropress_after_post_title(); ?>
            <p>You are Here: <?php if( function_exists( 'bcn_display' ) ) { bcn_display(); } ?></p>
        </div>
    </header>
    <?php } // end_if ?>
	<div id="inner-content" class="container">
        <div id="post-0" class="container marginTop">
            
            <!-- 404 page -->
    		<div class="error">
    			<h1 class="entry-title"><?php echo $translate['404-title']; ?></h1>
    			<h4><?php echo $translate['404-subtitle']; ?></h4>
    			<div class="entry-content">
                    <p><span class="check"><?php echo $translate['404-text']; ?></span> <a href="<?php echo site_url(); ?>"><?php echo $translate['404-btn']; ?> <span>&rarr;</span></a></p>
                </div>
    		</div>
            
        </div>
    <?php
        if( get_setting( 'footer_recent_posts' ) )
            get_template_part( 'templates/footer', 'recent-posts' );
    ?>
    </div>
</div>
    
<?php get_footer(); ?>