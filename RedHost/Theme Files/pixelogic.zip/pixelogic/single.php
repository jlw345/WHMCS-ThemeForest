<?php get_header(); ?>

<?php spyropress_before_main_container(); ?>
<!-- content -->
<div id="content">
    <header class="cont-head">
        <div class="cont-text container">
            <?php spyropress_before_post_title(); ?>
            <h1 class="entry-title">Blog</h1>
            <?php spyropress_after_post_title(); ?>
            <p><?php _e('You are Here','spyropress'); ?>:<?php if( function_exists( 'bcn_display' ) ) { bcn_display(); } ?></p>
        </div>
    </header>
    <?php
    spyropress_before_loop();
    while( have_posts() ) {
        the_post();
        
        spyropress_before_post();
    ?>
    <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    	<div id="inner-content" class="container">
            <div class="blog row-fluid">
                <div class="blog-vers2 span8">
                    <div class="single-post span12">
						<?php get_image( 'width=9999' ); ?>
						<div class="post-title">
							<div class="post-date"><span><?php echo get_the_date( 'j' ); ?></span><span><?php echo get_the_date( 'M' ); ?></span></div>
							<?php spyropress_before_post_title(); ?>
                            <h1 class="entry-title"><?php the_title(); ?></h1>
                            <?php spyropress_after_post_title(); ?>
							<p>
								<span>Posted by <?php the_author_link(); ?></span>
								<span>in <?php the_category( ', ' ); ?></span>
							</p>
						</div>
                        <?php
                            spyropress_before_post_content();
                            spyropress_the_content( );
                            wp_link_pages( array( 'before' => '<div class="page-link">' . __( 'Pages:', 'spyropress' ), 'after' => '</div>' ) );
                            spyropress_after_post_content();
                        ?>
					</div>
                    <?php get_template_part( 'templates/author', 'box' ); ?>
                    <?php comments_template( '', true ); ?>
                </div>
                <aside id="sidebar" class="span4">
                    <?php dynamic_sidebar( 'primary' ); ?>
                </aside>
            </div>
        </div>
    </div>
    <?php
            
        spyropress_after_post();
    }
    spyropress_after_loop();
    ?>
</div>
<!-- /content -->
<?php spyropress_after_main_container(); ?>
<?php get_footer(); ?>