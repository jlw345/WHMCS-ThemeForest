<?php 
    $translate['blog-title'] = get_setting( 'translate' ) ? get_setting( 'blog-title', '<span>Our</span> Blog' ) : __( '<span>Our</span> Blog', 'spyropress' );
    $translate['cat-title'] = get_setting( 'translate' ) ? get_setting( 'cat-title', '<span>Category:</span> %s' ) : __( '<span>Category:</span> %s', 'spyropress' );
    $translate['tag-title'] = get_setting( 'translate' ) ? get_setting( 'tag-title', '<span>Tag:</span> %s' ) : __( '<span>Tag:</span> %s', 'spyropress' );
    $translate['day-title'] = get_setting( 'translate' ) ? get_setting( 'day-title', '<span>Daily:</span> %s' ) : __( '<span>Daily:</span> %s', 'spyropress' );
    $translate['month-title'] = get_setting( 'translate' ) ? get_setting( 'month-title', '<span>Monthly:</span> %s' ) : __( '<span>Monthly:</span> %s', 'spyropress' );
    $translate['year-title'] = get_setting( 'translate' ) ? get_setting( 'year-title', '<span>Yearly:</span> %s' ) : __( '<span>Yearly:</span> %s', 'spyropress' );
    $translate['archive-title'] = get_setting( 'translate' ) ? get_setting( 'archive-title', 'Archives' ) : __( 'Archives', 'spyropress' );
    get_header(); 
?>

<?php spyropress_before_main_container(); ?>
<!-- content -->
<div id="content">
    <header class="cont-head">
        <div class="cont-text container">
            <h1 class="entry-title"><?php
                if( is_home() || is_single() ) :
                    echo $translate['blog-title'];
        		elseif ( is_category() ) :
        			printf( $translate['cat-title'], single_cat_title( '', false ) );
                elseif ( is_tag() ) :
        			printf( $translate['tag-title'], single_tag_title( '', false ) );
                elseif ( is_day() ) :
        			printf( $translate['day-title'], get_the_date() );
        		elseif ( is_month() ) :
        			printf( $translate['month-title'], get_the_date( _x( 'F Y', 'monthly archives date format', 'spyropress' ) ) );
        		elseif ( is_year() ) :
        			printf( $translate['year-title'], get_the_date( _x( 'Y', 'yearly archives date format', 'spyropress' ) ) );
        		else :
        			echo $translate['archive-title'];
        		endif;
            ?></h1>
            <p>You are Here: <?php if( function_exists( 'bcn_display' ) ) { bcn_display(); } ?></p>
        </div>
    </header>
	<div id="inner-content" class="container">
        <div class="blog row-fluid">
            <div class="blog-vers2 span8">
            <?php
                if( have_posts () ):
                    spyropress_before_loop();
                    while( have_posts() ) {
                        the_post();
                        
                        spyropress_before_post();
            ?>
                <div class="blog-post">
                    <a href="<?php the_permalink(); ?>">
                    <?php
                        $image = array(
                            'post_id' => get_the_ID(),
                            'width' => 999,
                            'crop' => true
                        );
                        get_image( $image );
                    ?>
                    </a>
                    <div class="post-title">
                        <div class="post-date">
                            <span><?php echo get_the_date( 'j' ); ?></span><span><?php echo get_the_date( 'M' ); ?></span>
                        </div>
                        <h1>
                            <a href="<?php the_permalink(); ?>">
                                <?php spyropress_before_post_title(); ?>
                                <?php the_title(); ?>
                                <?php spyropress_after_post_title(); ?>
                            </a>
                        </h1>
                        <p>
                            <span>Posted by <?php the_author_link(); ?></span>
                            <span>in <?php the_category(', '); ?></span>
                        </p>
                    </div>
                    <?php spyropress_before_post_content(); ?>
                    <?php the_excerpt(); ?>
                    <?php spyropress_after_post_content(); ?>
                    <a id="read-more" href="<?php the_permalink(); ?>">Read More <span></span></a>
                </div>
            <?php
                    
                    spyropress_after_post();
                }
                wp_pagenavi();
                spyropress_after_loop();
             else:
                _e( 'Sorry no post were found', 'spyropress' );
             endif;
                
            ?>
            </div>
            <aside id="sidebar" class="span4">
            <?php
                if( is_active_sidebar( 'primary' ) )
                    dynamic_sidebar( 'primary' );
                else {
                    echo '<section id="spyropress_tabwodget-2" class="widget tabs-widget"><ul class="tab-links clearfix"><li class="active"><a href="#popular-tab">Popular</a></li><li><a href="#recent-tab">Recent</a></li><li><a href="#comments-tab">Comments</a></li></ul><ul class="tab-content"><li><div><a href="http://pixelogic.spyropress.com/corning-glass-new-rumors-update-2012-2/"><img width="58" height="58" src="http://pixelogic.spyropress.com/wp-content/uploads/2013/05/photo2-58x58.jpg" class="" alt="" title=""></a><h3><a href="http://pixelogic.spyropress.com/corning-glass-new-rumors-update-2012-2/">Corning Glass New Rumors Update 2012</a></h3><span><img src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/clock.png">14 May 11:01 pm</span></div><div><a href="http://pixelogic.spyropress.com/apple-become-the-largest-company-in-the-world/"><img width="58" height="58" src="http://pixelogic.spyropress.com/wp-content/uploads/2013/05/photo5-58x58.jpg" class="" alt="" title=""></a><h3><a href="http://pixelogic.spyropress.com/apple-become-the-largest-company-in-the-world/">Apple Become The Largest Company in The World</a></h3><span><img src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/clock.png">14 May 6:19 pm</span></div><div><a href="http://pixelogic.spyropress.com/facebook-new-feature-updates-more-fast-fresh/"><img width="58" height="58" src="http://pixelogic.spyropress.com/wp-content/uploads/2013/05/photo4-58x58.jpg" class="" alt="" title=""></a><h3><a href="http://pixelogic.spyropress.com/facebook-new-feature-updates-more-fast-fresh/">Facebook New Feature Updates, More Fast &amp; Fresh</a></h3><span><img src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/clock.png">14 May 6:19 pm</span></div><div><a href="http://pixelogic.spyropress.com/microsoft-will-release-windows-phone-8/"><img width="58" height="58" src="http://pixelogic.spyropress.com/wp-content/uploads/2013/05/photo3-58x58.jpg" class="" alt="" title=""></a><h3><a href="http://pixelogic.spyropress.com/microsoft-will-release-windows-phone-8/">Microsoft Will Release Windows Phone 8</a></h3><span><img src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/clock.png">14 May 6:20 pm</span></div><div><a href="http://pixelogic.spyropress.com/corning-glass-new-rumors-update-2012/"><img width="58" height="58" src="http://pixelogic.spyropress.com/wp-content/uploads/2013/05/photo2-58x58.jpg" class="" alt="" title=""></a><h3><a href="http://pixelogic.spyropress.com/corning-glass-new-rumors-update-2012/">Corning Glass New Rumors Update 2012</a></h3><span><img src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/clock.png">14 May 6:22 pm</span></div></li><li><div><a href="http://pixelogic.spyropress.com/corning-glass-new-rumors-update-2012-2/"><img width="58" height="58" src="http://pixelogic.spyropress.com/wp-content/uploads/2013/05/photo2-58x58.jpg" class="" alt="" title=""></a><h3><a href="http://pixelogic.spyropress.com/corning-glass-new-rumors-update-2012-2/">Corning Glass New Rumors Update 2012</a></h3><span><img src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/clock.png">14 May 11:01 pm</span></div><div><a href="http://pixelogic.spyropress.com/facebook-new-feature-updates-more-fast-fresh-2/"><img width="58" height="58" src="http://pixelogic.spyropress.com/wp-content/uploads/2013/05/photo4-58x58.jpg" class="" alt="" title=""></a><h3><a href="http://pixelogic.spyropress.com/facebook-new-feature-updates-more-fast-fresh-2/">Facebook New Feature Updates, More Fast &amp; Fresh</a></h3><span><img src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/clock.png">14 May 11:01 pm</span></div><div><a href="http://pixelogic.spyropress.com/apple-become-the-largest-company-in-the-world-2/"><img width="58" height="58" src="http://pixelogic.spyropress.com/wp-content/uploads/2013/05/photo5-58x58.jpg" class="" alt="" title=""></a><h3><a href="http://pixelogic.spyropress.com/apple-become-the-largest-company-in-the-world-2/">Apple Become The Largest Company in The World</a></h3><span><img src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/clock.png">14 May 11:01 pm</span></div><div><a href="http://pixelogic.spyropress.com/microsoft-will-release-windows-phone-8-2/"><img width="58" height="58" src="http://pixelogic.spyropress.com/wp-content/uploads/2013/05/photo3-58x58.jpg" class="" alt="" title=""></a><h3><a href="http://pixelogic.spyropress.com/microsoft-will-release-windows-phone-8-2/">Microsoft Will Release Windows Phone 8</a></h3><span><img src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/clock.png">14 May 11:01 pm</span></div><div><a href="http://pixelogic.spyropress.com/volvo-v40-cross-country-look-more-intense/"><img width="58" height="58" src="http://pixelogic.spyropress.com/wp-content/uploads/2013/05/photo1-58x58.jpg" class="" alt="" title=""></a><h3><a href="http://pixelogic.spyropress.com/volvo-v40-cross-country-look-more-intense/">Volvo V40 Cross Country Look More Intense</a></h3><span><img src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/clock.png">14 May 6:23 pm</span></div></li><li><div><img alt="" src="http://0.gravatar.com/avatar/64c5911762b8c3362500fd755c22d1da?s=51&amp;d=&amp;r=G" class="avatar avatar-51 photo" height="51" width="51"><h3><a href="/corning-glass-new-rumors-update-2012-2/#comment-6">Anonymous says:</a></h3>Quisque tellus turpis, ultrices a aliquet at, pellentesque a nibh. Ut fe</div><div><img alt="" src="http://0.gravatar.com/avatar/ecb7464246475aabdce6c3d990cca8f8?s=51&amp;d=&amp;r=G" class="avatar avatar-51 photo" height="51" width="51"><h3><a href="/corning-glass-new-rumors-update-2012-2/#comment-5">Anonymous says:</a></h3>Pellentesque sed eros sit amet eros congue dictum. Nullam fringilla adip</div><div><img alt="" src="http://0.gravatar.com/avatar/ecb7464246475aabdce6c3d990cca8f8?s=51&amp;d=&amp;r=G" class="avatar avatar-51 photo" height="51" width="51"><h3><a href="/corning-glass-new-rumors-update-2012-2/#comment-4">Anonymous says:</a></h3>Etiam risus ligula, elementum et fringilla eget, porta id neque. Quisque</div><div><img alt="" src="http://1.gravatar.com/avatar/3c0d20db0e8911bc94be89c0cd9c0399?s=51&amp;d=&amp;r=G" class="avatar avatar-51 photo" height="51" width="51"><h3><a href="/corning-glass-new-rumors-update-2012-2/#comment-3">Anonymous says:</a></h3>Praesent mattis mauris urna. Suspendisse vulputate, urna sit amet laoree</div><div><img alt="" src="http://0.gravatar.com/avatar/64c5911762b8c3362500fd755c22d1da?s=51&amp;d=&amp;r=G" class="avatar avatar-51 photo" height="51" width="51"><h3><a href="/corning-glass-new-rumors-update-2012-2/#comment-2">Anonymous says:</a></h3>Pellentesque sed eros sit amet eros congue dictum. Nullam fringilla adip</div></li></ul></section><section id="spyropress_textphoto-39" class="widget text-photo"><h3 class="widget-title">Text Widget</h3><div class="text">Formerly known as the Admin Bar, the Toolbar has links to various administration functions, and is displayed at the top of</div><div class="clear"></div></section><section id="spyropress_bucket-2" class="widget module-bucket"><h3 class="widget-title">OUR SERVICES</h3>
        <div id="builder-row-519346b1aba87">
            <div class="container">
                <div class="row-fluid">
                    
        <div id="builder-column-519346b1aba95" class="span12 column_first">
            <div id="builder-module-519346b79ff18" class="module module-toggle-content"><div class="serv-widget"><div class="serv-item"><h3><img src="http://pixelogic.spyropress.com/wp-content/uploads/2013/04/serv-icon1.png">Powerful Admin</h3><p>Formerly known as the Admin Bar, the Toolbar has links to various administration functions, and is displayed at the top of each Administra</p>
<h3><img src="http://pixelogic.spyropress.com/wp-content/uploads/2013/04/serv-icon2.png">Optimized Code</h3><p class="hide">Formerly known as the Admin Bar, the Toolbar has links to various administration functions, and is displayed at the top of each Administra</p>
<h3><img src="http://pixelogic.spyropress.com/wp-content/uploads/2013/04/serv-icon3.png">Flexible Layout</h3><p class="hide">Formerly known as the Admin Bar, the Toolbar has links to various administration functions, and is displayed at the top of each Administra</p>
<h3><img src="http://pixelogic.spyropress.com/wp-content/uploads/2013/04/serv-icon4.png">Clean Design</h3><p class="hide">Formerly known as the Admin Bar, the Toolbar has links to various administration functions, and is displayed at the top of each Administra</p>
</div></div></div>
        </div>
                </div>
            </div>
        </div><div class="clear"></div></section><section id="tag_cloud-2" class="widget widget_tag_cloud"><h3 class="widget-title">TAGS</h3><div class="tagcloud"><a href="/tag/business/" class="tag-link-12" title="9 topics" style="font-size: 8pt;">business</a>
<a href="/tag/css/" class="tag-link-15" title="9 topics" style="font-size: 8pt;">css</a>
<a href="/tag/jquery/" class="tag-link-17" title="9 topics" style="font-size: 8pt;">jQuery</a>
<a href="/tag/photoshop/" class="tag-link-14" title="9 topics" style="font-size: 8pt;">photoshop</a>
<a href="/tag/php/" class="tag-link-19" title="9 topics" style="font-size: 8pt;">php</a>
<a href="/tag/technology/" class="tag-link-20" title="9 topics" style="font-size: 8pt;">technology</a>
<a href="/tag/themeforest/" class="tag-link-13" title="9 topics" style="font-size: 8pt;">themeforest</a>
<a href="/tag/themes/" class="tag-link-18" title="9 topics" style="font-size: 8pt;">themes</a>
<a href="/tag/tutorials/" class="tag-link-16" title="9 topics" style="font-size: 8pt;">tutorials</a>
<a href="/tag/web-design/" class="tag-link-6" title="9 topics" style="font-size: 8pt;">web design</a>
<a href="/tag/wordpress/" class="tag-link-11" title="9 topics" style="font-size: 8pt;">wordpress</a></div>
</section><section id="spyropress_photostream-3" class="widget photostream"><h3 class="widget-title">FLICKR WIDGET</h3><div class="flicker-images">
                <a class="photo" target="_blank" href="http://www.flickr.com/photos/52617155@N08/8355855347" title="Envato Christmas Party 2012">
                    <img src="http://farm9.staticflickr.com/8369/8355855347_b4eb81dcc2_s.jpg" alt="Envato Christmas Party 2012">
                </a>
                <a class="photo" target="_blank" href="http://www.flickr.com/photos/52617155@N08/8355855227" title="Envato Christmas Party 2012">
                    <img src="http://farm9.staticflickr.com/8084/8355855227_78d846aa6f_s.jpg" alt="Envato Christmas Party 2012">
                </a>
                <a class="photo" target="_blank" href="http://www.flickr.com/photos/52617155@N08/8356917922" title="Envato Christmas Party 2012">
                    <img src="http://farm9.staticflickr.com/8192/8356917922_3ca8594abc_s.jpg" alt="Envato Christmas Party 2012">
                </a>
                <a class="photo" target="_blank" href="http://www.flickr.com/photos/52617155@N08/8355854939" title="Envato Christmas Party 2012">
                    <img src="http://farm9.staticflickr.com/8363/8355854939_50c76b6965_s.jpg" alt="Envato Christmas Party 2012">
                </a>
                <a class="photo" target="_blank" href="http://www.flickr.com/photos/52617155@N08/8356917664" title="Envato Christmas Party 2012">
                    <img src="http://farm9.staticflickr.com/8513/8356917664_e105996a1b_s.jpg" alt="Envato Christmas Party 2012">
                </a>
                <a class="photo" target="_blank" href="http://www.flickr.com/photos/52617155@N08/8355854725" title="Envato Christmas Party 2012">
                    <img src="http://farm9.staticflickr.com/8472/8355854725_81863a2731_s.jpg" alt="Envato Christmas Party 2012">
                </a>
                <a class="photo" target="_blank" href="http://www.flickr.com/photos/52617155@N08/8356917416" title="Envato Christmas Party 2012">
                    <img src="http://farm9.staticflickr.com/8196/8356917416_2cb31164f8_s.jpg" alt="Envato Christmas Party 2012">
                </a>
                <a class="photo" target="_blank" href="http://www.flickr.com/photos/52617155@N08/8355854443" title="Envato Christmas Party 2012">
                    <img src="http://farm9.staticflickr.com/8051/8355854443_346bf21ac2_s.jpg" alt="Envato Christmas Party 2012">
                </a>
                <a class="photo" target="_blank" href="http://www.flickr.com/photos/52617155@N08/8355854317" title="Envato Christmas Party 2012">
                    <img src="http://farm9.staticflickr.com/8336/8355854317_da9ebaac5b_s.jpg" alt="Envato Christmas Party 2012">
                </a></div></section><section id="spyropress_twitter-3" class="widget Twiter"><h3 class="widget-title">Tweets</h3><div><p><img alt="" src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/twi-icon.png">Download free psd &amp;amp; vector graphics at <a href="http://t.co/04NjUdIc6B" class="twitter-link">http://t.co/04NjUdIc6B</a> <span class="twitter-timestamp">about 2013/05/16</span></p></div><div><p><img alt="" src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/twi-icon.png">I just downloaded a free facebook widget from <a href="http://t.co/04NjUdIc6B" class="twitter-link">http://t.co/04NjUdIc6B</a> ! <span class="twitter-timestamp">about 2013/05/16</span></p></div><div><p><img alt="" src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/twi-icon.png">Download Free Psd Website Templates &amp;amp; Other Psd freebies at <a href="http://t.co/04NjUdIc6B" class="twitter-link">http://t.co/04NjUdIc6B</a> ! Enjoy :) <span class="twitter-timestamp">about 2013/05/16</span></p></div><div><p><img alt="" src="http://pixelogic.spyropress.com/wp-content/themes/pixelogic/assets/images/twi-icon.png"><a href="http://twitter.com/aleemb" class="twitter-user">@aleemb</a> why are you using Phalcon framework for the new Dawn website and why dropping WordPress?? <span class="twitter-timestamp">about 2013/05/06</span></p></div></section><em>Add widgets these are dummy.</em>';
                }
            ?>
            </aside>
        </div>
        <?php
            if( get_setting( 'footer_recent_posts' ) )
                get_template_part( 'templates/footer', 'recent-posts' );
        ?>
    </div>
</div>
<!-- /content -->
<?php spyropress_after_main_container(); ?>
<?php get_footer(); ?>