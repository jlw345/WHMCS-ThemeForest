<?php

$options = get_post_meta( get_the_ID(), '_page_options', true );

$no_title = ( isset( $options['no_title'] ) ) ? true : false;
?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <?php if( !is_front_page() && !is_home() && !$no_title ) { ?>
    <header class="cont-head">
        <div class="cont-text container">
            <?php spyropress_before_post_title(); ?>
            <h1 class="entry-title"><?php the_title(); ?></h1>
            <?php spyropress_after_post_title(); ?>
            <p>You are Here: <?php if( function_exists( 'bcn_display' ) ) { bcn_display(); } ?></p>
        </div>
    </header>
    <?php } // end_if ?>
	<div id="inner-content" class="container">
    <?php
        spyropress_before_post_content();
        spyropress_the_content();
        wp_link_pages( array( 'before' => '<div class="page-link">' . __( 'Pages:', 'spyropress' ), 'after' => '</div>' ) );
        spyropress_after_post_content();
    ?>
    <?php
        if( get_setting( 'footer_recent_posts' ) )
            get_template_part( 'templates/footer', 'recent-posts' );
    ?>
    </div>
</div>