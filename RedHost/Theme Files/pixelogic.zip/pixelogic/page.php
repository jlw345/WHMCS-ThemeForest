<?php

/**
 * Default Page Template
 */
?>
<?php get_header(); ?>

<?php spyropress_before_main_container(); ?>
<!-- content -->
<div id="content">
    <?php
    spyropress_before_loop();
    while( have_posts() ) {
        the_post();
        
        spyropress_before_post();
            
            get_template_part( 'page', 'content' );
            
        spyropress_after_post();
    }
    spyropress_after_loop();
    ?>
</div>
<!-- /content -->
<?php spyropress_after_main_container(); ?>
<?php get_footer(); ?>