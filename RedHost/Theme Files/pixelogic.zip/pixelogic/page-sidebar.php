<?php

/*
Template Name: Page Sidebar
 */
?>
<?php get_header(); ?>

<?php spyropress_before_main_container(); ?>
<!-- content -->
<div id="content">
    <?php
    spyropress_before_loop();
    while( have_posts() ) {
        the_post();
        
        spyropress_before_post();
        
        $options = get_post_meta( get_the_ID(), '_page_options', true );
        $no_title = ( isset( $options['no_title'] ) ) ? true : false;
    ?>
    <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <?php if( !is_front_page() && !is_home() && !$no_title ) { ?>
        <header class="cont-head">
            <div class="cont-text container">
                <?php spyropress_before_post_title(); ?>
                <h1 class="entry-title"><?php the_title(); ?></h1>
                <?php spyropress_after_post_title(); ?>
                <p><?php _e('You are Here','spyropress'); ?>:<?php if( function_exists( 'bcn_display' ) ) { bcn_display(); } ?></p>
            </div>
        </header>
        <?php } // end_if ?>
    	<div id="inner-content" class="container">
            <div class="row-fluid">
                <div class="blog-vers2 span8">
                <?php
                    spyropress_before_post_content();
                    spyropress_the_content( );
                    wp_link_pages( array( 'before' => '<div class="page-link">' . __( 'Pages:', 'spyropress' ), 'after' => '</div>' ) );
                    spyropress_after_post_content();
                ?>
                </div>
                <aside id="sidebar" class="span4">
                    <?php dynamic_sidebar( 'primary' ); ?>
                </aside>
            </div>
            <?php
                if( get_setting( 'footer_recent_posts' ) )
                    get_template_part( 'templates/footer', 'recent-posts' );
            ?>
        </div>
    </div>
    <?php
            
        spyropress_after_post();
    }
    spyropress_after_loop();
    ?>
</div>
<!-- /content -->
<?php spyropress_after_main_container(); ?>
<?php get_footer(); ?>