<?php
/*
 * If the current post is protected by a password and the visitor has not yet
 * entered the password we will return early without loading the comments.
 */
if ( post_password_required() ) return;
$translate['comment'] = get_setting( 'translate' ) ? get_setting( 'translate-comment', 'Comment' ) : __( 'Comment', 'spyropress' );
$translate['comments'] = get_setting( 'translate' ) ? get_setting( 'translate-comments', 'Comments' ) : __( 'Comments', 'spyropress' );
$translate['comments-off'] = get_setting( 'translate' ) ? get_setting( 'translate-comments-off', 'Comments are closed.' ) : __( 'Comments are closed.', 'spyropress' );

?>

<div id="comments" class="comments-area">
	<?php if ( have_comments() ) { ?>
        <h1 class="comments-title">
			<?php
				printf( _nx( '1 '. $translate['comment'] .'', '%1$s '. $translate['comments'] .'', get_comments_number(), 'comments title', 'spyropress' ),
					number_format_i18n( get_comments_number() ), '<span>' . get_the_title() . '</span>' );
			?>
		</h1>

		<ul class="comment-list">
			<?php
				wp_list_comments( array(
					'format'      => 'html5',
					'short_ping'  => true,
                    'callback' => 'spyropress_comment'
				) );
			?>
		</ul><!-- .comment-list -->

		<?php
			// Are there comments to navigate through?
			if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
		?>
		<nav class="navigation comment-navigation" role="navigation">
			<h1 class="screen-reader-text section-heading"><?php _e( 'Comment navigation', 'spyropress' ); ?></h1>
			<div class="nav-previous"><?php previous_comments_link( __( '&larr; Older Comments', 'spyropress' ) ); ?></div>
			<div class="nav-next"><?php next_comments_link( __( 'Newer Comments &rarr;', 'spyropress' ) ); ?></div>
		</nav><!-- .comment-navigation -->
		<?php endif; // Check for comment navigation ?>

		<?php if ( ! comments_open() && get_comments_number() ) : ?>
		<p class="no-comments"><?php echo $translate['comments-off']; ?></p>
		<?php endif; ?>

	<?php
        } else {
            echo '<h1 class="comments-title">0 '. $translate['comment'] .'</h1>';
        }
    ?>
    <div id="comment-leave" class="clearfix">
    <?php
        $req = get_option( 'require_name_email' );
        $aria_req = ( $req ? " aria-required='true'" : '' );
        
        $args = array(
            'fields' => array(
                'author' => '<label id="label-author" for="author"></label><input id="author" name="author" placeholder="'. __( 'Name', 'spyropress' ) .'" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '"' . $aria_req . ' />',
                'email'  => '<label id="label-email" for="email"></label><input id="email" name="email" placeholder="'. __( 'Email', 'spyropress' ) .'" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '"' . $aria_req . ' />',
                'url'    => '<label id="label-url" for="url"></label><input id="url" name="url" placeholder="'. __( 'Website', 'spyropress' ) .'" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) . '" />'
            ),
            'comment_field' => '<textarea placeholder="'. __( 'Message', 'spyropress' ) .'" id="comment" name="comment" cols="45" rows="8" ></textarea>',
            'format' => 'html5',
            'label_submit' => __( 'Submit Comment', 'spyropress' )
        );
        comment_form( $args ); ?>
    </div>
</div><!-- #comments -->