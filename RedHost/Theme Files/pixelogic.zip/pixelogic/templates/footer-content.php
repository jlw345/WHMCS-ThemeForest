<?php
$footer_layout = get_setting( 'footer_layout', '0col' );
$areas = array( 'footer-1', 'footer-2', 'footer-3', 'footer-4', 'footer-5', 'footer-6' );
$footer_layouts = array(
    '0col'  =>  array(),
    '1col'  =>  array(12),
    '2col'  =>  array(6,6),
    '3col'  =>  array(4,4,4),
    '4col'  =>  array(3,3,3,3),
    '6col'  =>  array(2,2,2,2,2,2),
    'h2col' =>  array(6,3,3),
    '2hcol' =>  array(3,3,6),
    'h3col' =>  array(6,2,2,2),
    '3hcol' =>  array(2,2,2,6),
    't4col' =>  array(4,2,2,2,2),
    '4tcol' =>  array(2,2,2,2,4)
);

$footer_layout = $footer_layouts[$footer_layout];
?>
<div class="innerfooter container">
    <div class="<?php get_row_class(); ?>">
    <?php
        if ( !empty( $footer_layout ) ) {
            echo '<!-- footer-widget-areas -->' . "\n";
            foreach($footer_layout as $k => $area) {
                echo '<div class="span'.$area.'">';
                    dynamic_sidebar( $areas[$k] );
                echo '</div>';
            }
            echo '<!-- /footer-widget-areas -->' . "\n";
        }
    ?>
    </div>
</div>
<div class="end">
    <div class="back-to-top">
        <img alt="" src="<?php echo assets_img() . 'back-to-top.png'; ?>" />
        <?php echo do_shortcode( get_setting( 'custom_footer_text' ) ); ?>
    </div>
</div>