<div id="first-line">
	<div id="top-line" class="container">
		<article class="span12">
			<?php get_setting_e( 'top_bar_text' ); ?>
			<a id="close" href="#"><span></span></a>
			<a id="open" href="#"><span></span></a>
		</article>
	</div>
</div>