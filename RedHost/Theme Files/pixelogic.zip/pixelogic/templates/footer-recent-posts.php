<?php

$args = array(
    'posts_per_page' => get_setting( 'footer_recent_posts_limit', 4 )
);
$rposts = new WP_Query( $args );

if( ! $rposts->have_posts() ) return;
?>
<div id="recentpost">
	<ul id="js-news" class="js-hidden">
    <?php
        while( $rposts->have_posts() ) {
            $rposts->the_post();
    ?>
        <li class="news-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
    <?php
        }
    ?>
	</ul>
</div>