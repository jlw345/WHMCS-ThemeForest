<div id="top" class="clearfix">
	<?php spyropress_logo(); ?>
	<aside> 
		<?php if( get_setting( 'search_box' ) ) get_search_form(); ?>
	    <?php echo do_shortcode( '[socials]' ) ?>
	</aside>
</div>
<div id="menu" class="clearfix">
<?php
    $args = array(
        'container_class' => 'navigation',
        'menu_class' => 'sf-menu'
    );
    spyropress_get_nav_menu( 'primary', $args );
?>
</div>