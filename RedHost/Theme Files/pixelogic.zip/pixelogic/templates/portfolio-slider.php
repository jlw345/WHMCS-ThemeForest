<?php
$details = get_post_meta( get_the_ID(), '_portfolio_details', true );
if( isset( $details['images'] ) && empty( $details['images'] ) ) return;

// js
$js = "
$('.flexslider').flexslider({
    animation: 'fade',
    start: function(slider){
        $('body').removeClass('loading');
    }
});";
add_jquery_ready($js);

$slides = $details['images'];
$width = 9999;

if( 'half' == $details['style'] ) $width = 620;
?>
<!-- Slider -->
<section class="slider" id="sliderP">
	<div class="flexslider">
	    <ul class="slides">
	    <?php
            foreach( $slides as $slide ) {
                echo '<li>';
                
                    $img = array(
                        'url' => $slide['image'],
                        'width' => $width
                    );
                    get_image( $img );
                    
                    if( isset( $slide['caption'] ) && $slide['caption'] )
                        echo '<p class="flex-caption">' . $slide['caption'] . '</p>';
                    
                    echo '<a href="' . $slide['image'] . '" id="down" rel="galery2"></a>';
                
                echo '</li>';
            }
        ?>
	    </ul>
	</div>
</section>
<!-- End Slider -->