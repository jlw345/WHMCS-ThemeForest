<?php
$meta_author = get_setting_array( 'meta_authorbox' );

if( isset( $meta_author[0] ))return;
    
$social = isset( $meta_author[1] )? true : '';

$author_info = get_avatar( get_the_author_meta( 'ID' ) ) . '<h4>' . get_the_author_meta( 'display_name' ) . '</h4>';
$author_designation = get_the_author_meta( 'designation' );

?>
<div id="author" class="span12">
	<h1><?php get_setting_e( 'authorbox_title', 'About the Author' );?></h1>
	<ul class="member-post clearfix">
		<li class="active">
			<a href="##"><img src="<?php echo assets_img(); ?>biography.png"><span><?php _e( 'Biography', 'spyropress' ); ?></span></a>
		</li>
        <?php if( empty( $social ) ) { ?>
		<li>
			<a href="##"><img src="<?php echo assets_img(); ?>/twitter.png"><span><?php _e( 'Twitter', 'spyropress' ); ?></span></a>
		</li>
		<li>
			<a href="##"><img src="<?php echo assets_img(); ?>/facebook.png"><span><?php _e( 'Facebook', 'spyropress' ); ?></span></a>
		</li>
		<li>
			<a href="##"><img src="<?php echo assets_img(); ?>/google+.png"><span><?php _e( 'Google+', 'spyropress' ); ?></span></a>
		</li>
		<li>
			<a href="##"><img src="<?php echo assets_img(); ?>/linkedin.png"><span><?php _e( 'Linkedin', 'spyropress' ); ?></span></a>
		</li>
        <?php } ?>
	</ul>

	<ul class="member-data">
		<li>
			<?php echo $author_info; ?>
			<a href="##"><?php echo $author_designation; ?></a>
            <p><?php the_author_meta( 'description' ); ?></p>
		</li>
        <?php if( empty( $social ) ) { ?>
		<li>
			<?php echo $author_info; ?>
			<a href="<?php the_author_meta( 'twitter' ); ?>"><?php echo $author_designation; ?></a>
			<?php _e( '<p>View my profile on Twitter</p>', 'spyropress' ); ?>
		</li>

		<li>
			<?php echo $author_info; ?>
			<a href="<?php the_author_meta( 'facebook' ); ?>"><?php echo $author_designation; ?></a>
			<?php _e( '<p>View my profile on facebook</p>', 'spyropress' ); ?>
		</li>

		<li>
			<?php echo $author_info; ?>
			<a href="<?php the_author_meta( 'googleplus' ); ?>"><?php echo $author_designation; ?></a>
			<?php _e( '<p>You can comunicate with me on google+</p>', 'spyropress' ); ?>
		</li>

		<li>
			<?php echo $author_info; ?>
			<a href="<?php the_author_meta( 'linkedin' ); ?>"><?php echo $author_designation; ?></a>
			<?php _e( '<p>View my profile on linkedin</p>', 'spyropress' ); ?>
		</li>
        <?php } ?>
	</ul>
</div>