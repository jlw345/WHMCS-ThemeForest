<?php
global $post;
$options = get_post_meta( $post->ID, '_page_options' , true );

if( empty( $options ) ) return;

echo '<!-- default-slider -->';

if( 'rev' == $options['type'] ) {
?>
<div class="fullwidthbanner-container">
    <div class="fullwidthbanner">
        <?php putRevSlider( $options['rev_sliders'] ); ?>
        <div class="tp-bannertimer"></div>
    </div>
</div>
<?php
}
else {
    echo do_shortcode( '[slider id="' . $options['builtin_sliders'] . '"]' );
}
?>
<!-- /default-slider-->