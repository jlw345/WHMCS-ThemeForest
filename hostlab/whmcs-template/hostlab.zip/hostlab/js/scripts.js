document.addEventListener('DOMContentLoaded', function() {
    "use strict";

    loadWindowEvents();
    loadMenu();
    loadWindowSettings();
});
/*-------------------------*/
/*  RUN SCROLL FUNCTIONS   */
/*-------------------------*/
function loadWindowEvents() {
    $(window).bind('scroll', function() {
        if ($(window).scrollTop() > 53) {
            $('.menu-wrap').addClass('fixed');
        } else {
            $('.menu-wrap').removeClass('fixed');
        }
    });
}
/*-------------------------*/
/*     MENU                */
/*-------------------------*/
function loadMenu() {
    $(".nav-menu .menu-toggle").on("click", function() {
        $(this).closest(".menu-wrap").toggleClass("active");
    });
    $('.btn-scroll').on("click", function() {
        $('html, body').animate({
            scrollTop: $($.attr(this, 'href')).offset().top - 10
        }, 500);
        return false;
    });

    $(".menu-item").on('click',
        function() {
            if ($(".sub-menu", this).css('display') == 'none') {
                $(".sub-menu", this).css("display", "block");
            } else {
                $(".sub-menu", this).css("display", "none");
            }
        }
    );
}
/*-------------------------*/
/*       FIXED MENU        */
/*-------------------------*/
function loadWindowSettings() {
    if ($(window).width() < 750) {
        $(".nav-menu .main-menu > .menu-item-has-children > a").on("click", function() {
            if ($(this).attr('href') != '#') {
                $(this).next().slideToggle(0);
                return false;
            }
        });
    }
}















